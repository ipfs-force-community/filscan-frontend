exports.id = 2225;
exports.ids = [2225];
exports.modules = {

/***/ 6221:
/***/ ((module) => {

// Exports
module.exports = {
	"owner": "Owner_owner__jpE00"
};


/***/ }),

/***/ 8289:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2881);
/* harmony import */ var _packages_Table__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(430);
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8804);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3495);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8108);
/* harmony import */ var _contents_contract__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5509);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _packages_Table__WEBPACK_IMPORTED_MODULE_3__, _utils__WEBPACK_IMPORTED_MODULE_5__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_7__, _contents_contract__WEBPACK_IMPORTED_MODULE_8__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _packages_Table__WEBPACK_IMPORTED_MODULE_3__, _utils__WEBPACK_IMPORTED_MODULE_5__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_7__, _contents_contract__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 








/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ id })=>{
    const { theme, lang } = (0,_store_FilscanStore__WEBPACK_IMPORTED_MODULE_4__/* .useFilscanStore */ .J)();
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__/* .Translation */ .W)({
        ns: "contract"
    });
    const { axiosData, loading } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)({
        dataSource: [],
        total: 0
    });
    //const [loading, setLoading] = useState<boolean>(false);
    const [current, setCurrent] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(1);
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        if (id) {
            load();
        }
    }, [
        id
    ]);
    const load = async (cur)=>{
        // setLoading(true);
        const index = cur || current;
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.contract_ERC20Dex, {
            contract_id: id,
            page: index - 1,
            limit: _utils__WEBPACK_IMPORTED_MODULE_5__/* .pageLimit */ .P5
        });
        // setLoading(false);
        setData({
            dataSource: result?.items || [],
            total: result?.total || 0
        });
    };
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_6__.useMemo)(()=>{
        return _contents_contract__WEBPACK_IMPORTED_MODULE_8__/* .token_Dex_columns */ .oH.map((v)=>{
            return {
                ...v,
                title: tr(v.title)
            };
        });
    }, [
        theme,
        tr
    ]);
    const handleChange = (pagination, filters, sorter)=>{
        let cur = pagination.current || current;
        setCurrent(cur);
        load(cur);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "text_des text-sm ml-2.5",
                children: tr("dex_total", {
                    value: (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatNumber */ .uf)(data?.total || 0)
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "card_shadow p-5 mt-2.5 rounded-xl border border_color ",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_Table__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    data: data.dataSource,
                    total: data.total,
                    columns: columns,
                    loading: loading,
                    onChange: handleChange
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1051:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2881);
/* harmony import */ var _packages_Table__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(430);
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8804);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3495);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8108);
/* harmony import */ var _Owner_module_scss__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6221);
/* harmony import */ var _Owner_module_scss__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_Owner_module_scss__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _contents_contract__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5509);
/* harmony import */ var _components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1061);
/* harmony import */ var _components_copy__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5174);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_12__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _packages_Table__WEBPACK_IMPORTED_MODULE_3__, _utils__WEBPACK_IMPORTED_MODULE_5__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_7__, _contents_contract__WEBPACK_IMPORTED_MODULE_8__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _packages_Table__WEBPACK_IMPORTED_MODULE_3__, _utils__WEBPACK_IMPORTED_MODULE_5__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_7__, _contents_contract__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 













/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ type, id })=>{
    const { theme, lang } = (0,_store_FilscanStore__WEBPACK_IMPORTED_MODULE_4__/* .useFilscanStore */ .J)();
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__/* .Translation */ .W)({
        ns: "contract"
    });
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)({
        dataSource: [],
        total: 0
    });
    const [loadingTable, setTableLoading] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false);
    const [current, setCurrent] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(1);
    const [ownerList, setOwner] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)({});
    const [toList, setTo] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)({});
    const { isMobile } = (0,_components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        if (id) {
            load();
        }
    }, [
        id,
        type
    ]);
    const load = async (cur)=>{
        setTableLoading(true);
        const index = cur || current;
        const axiosUrl = type === "nfts" ? _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.contract_NFTOwners : _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.contract_ERC20Owner;
        const result = await axiosData(axiosUrl, {
            contract_id: id,
            contract: id,
            page: index - 1,
            limit: _utils__WEBPACK_IMPORTED_MODULE_5__/* .pageLimit */ .P5
        });
        setTableLoading(false);
        setData({
            dataSource: result?.items || [],
            total: result?.total || 0
        });
        if (result?.items && result.items.length > 0) {
            const formItems = result?.items.map((v)=>v.owner);
            loadFnsUrl(formItems, "owner");
        }
    };
    const loadFnsUrl = async (items, type)=>{
        if (items.length > 0) {
            const fnsData = await axiosData(`${_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.contract_fnsUrl}`, {
                addresses: items
            });
            setOwner(fnsData);
        }
    };
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_6__.useMemo)(()=>{
        const newColumns = type === "nfts" ? _contents_contract__WEBPACK_IMPORTED_MODULE_8__/* .nft_owner_columns */ .oO : _contents_contract__WEBPACK_IMPORTED_MODULE_8__/* .token_owner_columns */ .Gg;
        return newColumns(ownerList).map((v)=>{
            const ol = ownerList;
            if (type !== "nfts" && isMobile) {
                if (v.dataIndex === "rank") {
                    v.render = (value)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: (_Owner_module_scss__WEBPACK_IMPORTED_MODULE_13___default().rank),
                            children: value
                        });
                }
                if (v.dataIndex === "owner") {
                    v.render = (value)=>{
                        if (!value) return "--";
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: classnames__WEBPACK_IMPORTED_MODULE_12___default()((_Owner_module_scss__WEBPACK_IMPORTED_MODULE_13___default().owner), "link_text"),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    children: [
                                        " ",
                                        value
                                    ]
                                }),
                                value && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                    text: value
                                }),
                                ol?.domains && ol?.domains[value] && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_11___default()), {
                                    href: `/domain/${ol.domains[value]}?provider=${ol.provider}`,
                                    children: [
                                        "(",
                                        ol.domains[value],
                                        ")"
                                    ]
                                })
                            ]
                        });
                    };
                }
            }
            return {
                ...v,
                title: tr(v.title)
            };
        });
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        theme,
        tr,
        ownerList,
        toList
    ]);
    const handleChange = (pagination, filters, sorter)=>{
        let cur = pagination.current || current;
        setCurrent(cur);
        load(cur);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "text_des text-sm ml-2.5",
                children: tr("owner_total", {
                    value: (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatNumber */ .uf)(data?.total || 0)
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "card_shadow p-5 mt-2.5 rounded-xl border border_color",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_Table__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    data: data.dataSource,
                    total: data.total,
                    columns: columns,
                    loading: loadingTable,
                    onChange: handleChange
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8936:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2881);
/* harmony import */ var _packages_Table__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(430);
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8804);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3495);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8108);
/* harmony import */ var _contents_contract__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5509);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _packages_Table__WEBPACK_IMPORTED_MODULE_3__, _utils__WEBPACK_IMPORTED_MODULE_5__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_7__, _contents_contract__WEBPACK_IMPORTED_MODULE_8__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _packages_Table__WEBPACK_IMPORTED_MODULE_3__, _utils__WEBPACK_IMPORTED_MODULE_5__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_7__, _contents_contract__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 








/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ id, type })=>{
    const { theme } = (0,_store_FilscanStore__WEBPACK_IMPORTED_MODULE_4__/* .useFilscanStore */ .J)();
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__/* .Translation */ .W)({
        ns: "contract"
    });
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)({
        dataSource: [],
        total: 0
    });
    const [loadingTable, setTableLoading] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false);
    const [current, setCurrent] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(1);
    const [fromList, setFrom] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)({});
    const [toList, setTo] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)({});
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        if (id) {
            load();
        }
    }, [
        id,
        type
    ]);
    const load = async (cur)=>{
        setTableLoading(true);
        const index = cur || current;
        const axiosUrl = type === "nfts" ? _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.contract_NFTTransfers : _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.contract_ERC20Transfer;
        const result = await axiosData(axiosUrl, {
            contract_id: id,
            contract: id,
            page: index - 1,
            limit: _utils__WEBPACK_IMPORTED_MODULE_5__/* .pageLimit */ .P5
        });
        setTableLoading(false);
        setData({
            dataSource: result?.items || [],
            total: result?.total || 0
        });
        if (result?.items && result.items.length > 0) {
            const formItems = result?.items.map((v)=>v.from);
            const toItems = result?.items.map((v)=>v.to);
            loadFnsUrl(formItems, "form");
            loadFnsUrl(toItems, "to");
        }
    };
    const loadFnsUrl = async (items, type)=>{
        if (items.length > 0) {
            const fnsData = await axiosData(`${_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.contract_fnsUrl}`, {
                addresses: items
            });
            if (type === "form") {
                setFrom(fnsData);
            } else {
                setTo(fnsData);
            }
        }
    };
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_6__.useMemo)(()=>{
        const newColumns = type === "nfts" ? _contents_contract__WEBPACK_IMPORTED_MODULE_8__/* .nft_transfer_columns */ .Mz : _contents_contract__WEBPACK_IMPORTED_MODULE_8__/* .token_transfer_columns */ .aN;
        return newColumns(fromList, toList).map((v)=>{
            return {
                ...v,
                title: tr(v.title)
            };
        });
    }, [
        theme,
        tr,
        fromList,
        toList
    ]);
    const handleChange = (pagination, filters, sorter)=>{
        let cur = pagination.current || current;
        setCurrent(cur);
        load(cur);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "text_des text-sm ml-2.5",
                children: tr("transfer_total", {
                    value: (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatNumber */ .uf)(data?.total || 0)
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "card_shadow p-5 mt-2.5 rounded-xl border border_color min-h-[260px] ",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_Table__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    data: data.dataSource,
                    total: data.total,
                    columns: columns,
                    loading: loadingTable,
                    onChange: handleChange
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2225:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_useHash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8087);
/* harmony import */ var _packages_segmented__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5622);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_hooks_useUpdateQuery__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2680);
/* harmony import */ var _components_hooks_useRemoveQuery__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6699);
/* harmony import */ var _Transfer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8936);
/* harmony import */ var _Owner__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1051);
/* harmony import */ var _Dex__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8289);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_packages_segmented__WEBPACK_IMPORTED_MODULE_2__, _components_hooks_useUpdateQuery__WEBPACK_IMPORTED_MODULE_4__, _Transfer__WEBPACK_IMPORTED_MODULE_6__, _Owner__WEBPACK_IMPORTED_MODULE_7__, _Dex__WEBPACK_IMPORTED_MODULE_8__]);
([_packages_segmented__WEBPACK_IMPORTED_MODULE_2__, _components_hooks_useUpdateQuery__WEBPACK_IMPORTED_MODULE_4__, _Transfer__WEBPACK_IMPORTED_MODULE_6__, _Owner__WEBPACK_IMPORTED_MODULE_7__, _Dex__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 









/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { ids, tabList, defaultActive, type } = props;
    const updateQuery = (0,_components_hooks_useUpdateQuery__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
    const removeQueryParam = (0,_components_hooks_useRemoveQuery__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    const { hash, hashParams } = (0,_components_hooks_useHash__WEBPACK_IMPORTED_MODULE_1__/* .useHash */ .H)();
    const { p } = hashParams || {};
    const activeTab = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        if (hash) {
            return hash;
        }
        return defaultActive;
    }, [
        defaultActive,
        hash
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `${classnames__WEBPACK_IMPORTED_MODULE_9___default()(props.className)} mt-5`,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_segmented__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                data: tabList || [],
                ns: "contract",
                defaultValue: activeTab,
                defaultActive: defaultActive,
                isHash: true
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "min-h-[300px] pt-2.5",
                children: [
                    activeTab === "transfer" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Transfer__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        id: ids,
                        type: type
                    }),
                    activeTab === "owner" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Owner__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        id: ids,
                        type: type
                    }),
                    activeTab === "dex" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Dex__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        id: ids
                    })
                ]
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;