exports.id = 1830;
exports.ids = [1830];
exports.modules = {

/***/ 1994:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap": "EventLog_wrap__P7w0V",
	"content": "EventLog_content__r6bca"
};


/***/ }),

/***/ 4853:
/***/ ((module) => {

// Exports
module.exports = {
	"list": "list_list__Bpgo2",
	"list-header": "list_list-header__pJ9BN",
	"select-wrap": "list_select-wrap__faXqN",
	"reset": "list_reset__th3Xw",
	"table": "list_table__MzqlD"
};


/***/ }),

/***/ 1798:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap": "verify_wrap__bzpW8"
};


/***/ }),

/***/ 7671:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1061);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8054);
/* harmony import */ var _contents_contract__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5509);
/* harmony import */ var _packages_content__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5586);
/* harmony import */ var _packages_noData__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5178);
/* harmony import */ var _packages_skeleton__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8465);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8108);
/* harmony import */ var antd_lib_pagination__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4528);
/* harmony import */ var antd_lib_pagination__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(antd_lib_pagination__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _EventLog_module_scss__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1994);
/* harmony import */ var _EventLog_module_scss__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_EventLog_module_scss__WEBPACK_IMPORTED_MODULE_11__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_contents_contract__WEBPACK_IMPORTED_MODULE_3__, _packages_content__WEBPACK_IMPORTED_MODULE_4__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_7__]);
([_contents_contract__WEBPACK_IMPORTED_MODULE_3__, _packages_content__WEBPACK_IMPORTED_MODULE_4__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ actorId })=>{
    const { axiosData, loading } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    //const [loading, setLoading] = useState(false);
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)([]);
    const [current, setCurrent] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)(1);
    const [total, setTotal] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)(0);
    const { isMobile } = (0,_components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)();
    (0,react__WEBPACK_IMPORTED_MODULE_10__.useEffect)(()=>{
        if (actorId) {
            load();
        }
    }, [
        actorId
    ]);
    const load = async (cur)=>{
        // setLoading(true);
        const showIndex = cur || current;
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_2__/* .apiUrl */ .JW.contract_verify_logs, {
            actor_id: actorId,
            page: showIndex - 1,
            limit: 5
        });
        // setLoading(false)
        setData(result?.event_list || []);
        setTotal(result?.total_count);
    };
    const handleChange = (cur)=>{
        setCurrent(cur);
        load(cur);
    };
    if (loading) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "main_contain",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_skeleton__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_skeleton__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_skeleton__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
            ]
        });
    }
    if (!loading && data.length === 0) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_noData__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {});
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_9___default()((_EventLog_module_scss__WEBPACK_IMPORTED_MODULE_11___default().wrap)),
                children: data.map((item, index)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_content__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        contents: _contents_contract__WEBPACK_IMPORTED_MODULE_3__/* .contract_log */ .OR,
                        className: classnames__WEBPACK_IMPORTED_MODULE_9___default()("border-b border_color mt-5 last:border-none", (_EventLog_module_scss__WEBPACK_IMPORTED_MODULE_11___default().content)),
                        ns: "contract",
                        data: item
                    }, index);
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_pagination__WEBPACK_IMPORTED_MODULE_8___default()), {
                showQuickJumper: true,
                showLessItems: isMobile,
                className: `custom_Pagination`,
                style: {
                    float: "right"
                },
                pageSize: 5,
                current: current,
                total: total,
                onChange: handleChange
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1197:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2881);
/* harmony import */ var _contents_detail__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8817);
/* harmony import */ var _packages_Table__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(430);
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8804);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3495);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8108);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9676);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_detail__WEBPACK_IMPORTED_MODULE_3__, _packages_Table__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_6__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_detail__WEBPACK_IMPORTED_MODULE_3__, _packages_Table__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_6__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 









/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ accountId, total })=>{
    const { theme, lang } = (0,_store_FilscanStore__WEBPACK_IMPORTED_MODULE_5__/* .useFilscanStore */ .J)();
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__/* .Translation */ .W)({
        ns: "detail"
    });
    const [loadingTable, setTableLoading] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)(false);
    const { axiosData, loading } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({
        dataSource: [],
        total: 0
    });
    const [current, setCurrent] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)(1);
    const [fromList, setFrom] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({});
    const [toList, setTo] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({});
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return (0,_contents_detail__WEBPACK_IMPORTED_MODULE_3__/* .ercToken_list */ .EH)(fromList, toList).map((v)=>{
            return {
                ...v,
                title: tr(v.title)
            };
        });
    }, [
        theme,
        tr,
        fromList,
        toList
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        if (accountId) {
            load();
        }
    }, [
        accountId
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        total(data.total);
    }, [
        data
    ]);
    const load = async (cur)=>{
        setTableLoading(true);
        const showIndex = cur || current;
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.contract_ERC20Transfers, {
            address: accountId,
            filters: {
                page: showIndex - 1,
                limit: _utils__WEBPACK_IMPORTED_MODULE_6__/* .pageLimit */ .P5
            }
        });
        setTableLoading(false);
        const showList = result?.items || [];
        setData({
            dataSource: showList,
            total: result?.total
        });
        if (showList.length > 0) {
            const formItems = showList.map((v)=>v.from);
            const toItems = showList.map((v)=>v.to);
            loadFnsUrl(formItems, "form");
            loadFnsUrl(toItems, "to");
        }
    };
    const loadFnsUrl = async (items, type)=>{
        if (items.length > 0) {
            const fnsData = await axiosData(`${_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.contract_fnsUrl}`, {
                addresses: items
            }, {
                loading: false
            });
            if (type === "form") {
                setFrom(fnsData);
            } else {
                setTo(fnsData);
            }
        }
    };
    const handleChange = (pagination, filters, sorter)=>{
        let cur = pagination.current || current;
        setCurrent(cur);
        load(cur);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_9__/* .BrowserView */ .I, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "absolute -top-5 text_des text-xs",
                    children: tr("erc20_transfer_total", {
                        value: (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatNumber */ .uf)(data.total)
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_Table__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                data: data.dataSource,
                total: data.total,
                columns: columns,
                loading: loading,
                onChange: handleChange
            }, "list_token")
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7528:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2881);
/* harmony import */ var _contents_detail__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8817);
/* harmony import */ var _packages_Table__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(430);
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8804);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3495);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8108);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9676);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_detail__WEBPACK_IMPORTED_MODULE_3__, _packages_Table__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_6__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_detail__WEBPACK_IMPORTED_MODULE_3__, _packages_Table__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_6__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 









/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ methodName, accountId, total })=>{
    const { theme, lang } = (0,_store_FilscanStore__WEBPACK_IMPORTED_MODULE_5__/* .useFilscanStore */ .J)();
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__/* .Translation */ .W)({
        ns: "detail"
    });
    const { axiosData, loading } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    const [loadingTable, setTableLoading] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)(false);
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({
        dataSource: [],
        total: 0
    });
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        total(data.total);
    }, [
        data
    ]);
    const [current, setCurrent] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)(1);
    const [fromList, setFrom] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({});
    const [toList, setTo] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({});
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return (0,_contents_detail__WEBPACK_IMPORTED_MODULE_3__/* .block_list */ .kF)(fromList, toList).map((v)=>{
            return {
                ...v,
                title: tr(v.title)
            };
        });
    }, [
        theme,
        tr,
        fromList,
        toList
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        if (accountId) {
            load();
        }
    }, [
        accountId
    ]);
    const load = async (cur, method)=>{
        setTableLoading(true);
        const showIndex = cur || current;
        const showMethod = method || methodName;
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.detail_block_list, {
            account_id: accountId,
            filters: {
                index: showIndex - 1,
                limit: _utils__WEBPACK_IMPORTED_MODULE_6__/* .pageLimit */ .P5,
                method_name: showMethod === "all" ? "" : showMethod
            }
        });
        setTableLoading(false);
        const showList = result?.blocks_by_account_id_list || [];
        setData({
            dataSource: showList,
            total: result?.total_count
        });
        if (showList.length > 0) {
            const formItems = showList.map((v)=>v.from);
            const toItems = showList.map((v)=>v.to);
            loadFnsUrl(formItems, "form");
            loadFnsUrl(toItems, "to");
        }
    };
    const loadFnsUrl = async (items, type)=>{
        if (items.length > 0) {
            const fnsData = await axiosData(`${_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.contract_fnsUrl}`, {
                addresses: items
            }, {
                loading: false
            });
            if (type === "form") {
                setFrom(fnsData);
            } else {
                setTo(fnsData);
            }
        }
    };
    const handleChange = (pagination, filters, sorter)=>{
        let cur = pagination.current || current;
        setCurrent(cur);
        load(cur);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_9__/* .BrowserView */ .I, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "absolute -top-5 text_des text-xs",
                    children: tr("block_list_total", {
                        value: (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatNumber */ .uf)(data.total)
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_Table__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                data: data.dataSource,
                total: data.total,
                columns: columns,
                loading: loading,
                onChange: handleChange
            }, "block_list")
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1830:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_useHash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8087);
/* harmony import */ var _packages_segmented__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5622);
/* harmony import */ var _packages_selects__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(869);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _messageList__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4257);
/* harmony import */ var _blockList__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7528);
/* harmony import */ var _components_hooks_useUpdateQuery__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2680);
/* harmony import */ var _components_hooks_useRemoveQuery__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6699);
/* harmony import */ var _tracesList__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7120);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(4853);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _EventLog__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7671);
/* harmony import */ var _verify__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3643);
/* harmony import */ var _TokenList__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1197);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(2881);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(9676);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(3495);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_packages_segmented__WEBPACK_IMPORTED_MODULE_2__, _messageList__WEBPACK_IMPORTED_MODULE_5__, _blockList__WEBPACK_IMPORTED_MODULE_6__, _components_hooks_useUpdateQuery__WEBPACK_IMPORTED_MODULE_7__, _tracesList__WEBPACK_IMPORTED_MODULE_9__, _EventLog__WEBPACK_IMPORTED_MODULE_11__, _verify__WEBPACK_IMPORTED_MODULE_12__, _TokenList__WEBPACK_IMPORTED_MODULE_13__, _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_14__, _utils__WEBPACK_IMPORTED_MODULE_16__]);
([_packages_segmented__WEBPACK_IMPORTED_MODULE_2__, _messageList__WEBPACK_IMPORTED_MODULE_5__, _blockList__WEBPACK_IMPORTED_MODULE_6__, _components_hooks_useUpdateQuery__WEBPACK_IMPORTED_MODULE_7__, _tracesList__WEBPACK_IMPORTED_MODULE_9__, _EventLog__WEBPACK_IMPORTED_MODULE_11__, _verify__WEBPACK_IMPORTED_MODULE_12__, _TokenList__WEBPACK_IMPORTED_MODULE_13__, _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_14__, _utils__WEBPACK_IMPORTED_MODULE_16__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 

















/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ accountId, tabList, defaultActive, actorId, verifyData })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_14__/* .Translation */ .W)({
        ns: "detail"
    });
    const updateQuery = (0,_components_hooks_useUpdateQuery__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    const removeQueryParam = (0,_components_hooks_useRemoveQuery__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    const { hash, hashParams } = (0,_components_hooks_useHash__WEBPACK_IMPORTED_MODULE_1__/* .useHash */ .H)();
    const [activeTab, setActiveTab] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(defaultActive);
    const { name, p } = hashParams || {};
    const [num, setNum] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(0);
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        if (hash) {
            if (tabList.find((v)=>v.dataIndex === hash)) {
                setActiveTab(hash);
            } else {
                setActiveTab(defaultActive);
            }
        } else {
            setActiveTab(defaultActive);
        }
    }, [
        tabList,
        hash,
        defaultActive
    ]);
    const method = (0,react__WEBPACK_IMPORTED_MODULE_4__.useMemo)(()=>{
        if (name && typeof name === "string") {
            return name;
        }
        return "all";
    }, [
        name
    ]);
    const activeItem = (0,react__WEBPACK_IMPORTED_MODULE_4__.useMemo)(()=>{
        return tabList.find((v)=>v.dataIndex === activeTab);
    }, [
        activeTab,
        tabList
    ]);
    const headerOptions = (0,react__WEBPACK_IMPORTED_MODULE_4__.useMemo)(()=>{
        if (activeItem?.headerOptions) {
            return activeItem?.headerOptions?.map((v)=>{
                return {
                    ...v,
                    label: tr(v.dataIndex || v.value)
                };
            });
        }
        return [];
    }, [
        activeItem,
        tr
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_10___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_17___default().list), "mt-5"),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_10___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_17___default()["list-header"]), "flex justify-between items-center mr-2.5"),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_segmented__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        data: tabList || [],
                        ns: "detail",
                        defaultValue: activeTab,
                        defaultActive: defaultActive,
                        isHash: true
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_15__/* .MobileView */ .$, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text_des text-xs pt-[8px]",
                            children: tr("message_list_total", {
                                value: (0,_utils__WEBPACK_IMPORTED_MODULE_16__/* .formatNumber */ .uf)(num)
                            })
                        })
                    }),
                    activeItem?.headerOptions && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_selects__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_17___default()["select-wrap"])} !min-w-[210px]`,
                        value: method,
                        options: headerOptions || [],
                        onChange: (value)=>{
                            if (value !== "all") {
                                updateQuery({
                                    name: value
                                });
                            } else {
                                removeQueryParam("name");
                            }
                        }
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "relative",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: classnames__WEBPACK_IMPORTED_MODULE_10___default()("card_shadow p-5 mt-7 min-h-[300px] border border_color rounded-xl", (_index_module_scss__WEBPACK_IMPORTED_MODULE_17___default().table), (_index_module_scss__WEBPACK_IMPORTED_MODULE_17___default().reset)),
                    children: [
                        activeTab === "message_list" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_messageList__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            total: (num)=>{
                                setNum(num);
                            },
                            accountId: accountId,
                            methodName: method
                        }),
                        activeTab === "block_list" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_blockList__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                            total: (num)=>{
                                setNum(num);
                            },
                            accountId: accountId
                        }),
                        activeTab === "traces_list" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tracesList__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                            total: (num)=>{
                                setNum(num);
                            },
                            accountId: accountId,
                            methodName: method
                        }),
                        activeTab === "ercList" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TokenList__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                            total: (num)=>{
                                setNum(num);
                            },
                            accountId: accountId
                        }),
                        activeTab === "contract_verify" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_verify__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                            actorId: actorId,
                            verifyData: verifyData
                        }),
                        activeTab === "event_log" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_EventLog__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                            actorId: actorId
                        })
                    ]
                })
            })
        ]
    });
}); //table

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4257:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2881);
/* harmony import */ var _contents_detail__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8817);
/* harmony import */ var _packages_Table__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(430);
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8804);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3495);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8108);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9676);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_detail__WEBPACK_IMPORTED_MODULE_3__, _packages_Table__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_6__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_detail__WEBPACK_IMPORTED_MODULE_3__, _packages_Table__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_6__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 









/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ methodName, accountId, total })=>{
    const { theme, lang } = (0,_store_FilscanStore__WEBPACK_IMPORTED_MODULE_5__/* .useFilscanStore */ .J)();
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__/* .Translation */ .W)({
        ns: "detail"
    });
    const [loadingTable, setTableLoading] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)(false);
    const { axiosData, loading } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({
        dataSource: [],
        total: 0
    });
    const [current, setCurrent] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)(1);
    const [fromList, setFrom] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({});
    const [toList, setTo] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({});
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return (0,_contents_detail__WEBPACK_IMPORTED_MODULE_3__/* .message_list */ .Xd)(fromList, toList).map((v)=>{
            return {
                ...v,
                title: tr(v.title)
            };
        });
    }, [
        theme,
        tr,
        fromList,
        toList
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        if (accountId) {
            setTableLoading(true);
            load();
        }
    }, [
        accountId,
        methodName
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        total(data.total);
    }, [
        data
    ]);
    const load = async (cur, method)=>{
        const showIndex = cur || current;
        const showMethod = method || methodName;
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.detail_message_list, {
            account_id: accountId,
            filters: {
                index: showIndex - 1,
                limit: _utils__WEBPACK_IMPORTED_MODULE_6__/* .pageLimit */ .P5,
                method_name: showMethod === "all" ? "" : showMethod
            }
        });
        setTableLoading(false);
        const showList = result?.messages_by_account_id_list || [];
        setData({
            dataSource: showList,
            total: result?.total_count
        });
        if (showList.length > 0) {
            const formItems = showList.map((v)=>v.from);
            const toItems = showList.map((v)=>v.to);
            loadFnsUrl(formItems, "form");
            loadFnsUrl(toItems, "to");
        }
    };
    const loadFnsUrl = async (items, type)=>{
        if (items.length > 0) {
            const fnsData = await axiosData(`${_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.contract_fnsUrl}`, {
                addresses: items
            }, {
                loading: false
            });
            if (type === "form") {
                setFrom(fnsData);
            } else {
                setTo(fnsData);
            }
        }
    };
    const handleChange = (pagination, filters, sorter)=>{
        let cur = pagination.current || current;
        setCurrent(cur);
        load(cur);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_9__/* .BrowserView */ .I, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "absolute -top-5 text_des text-xs",
                    children: tr("message_list_total", {
                        value: (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatNumber */ .uf)(data.total)
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_Table__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                data: data.dataSource,
                total: data.total,
                columns: columns,
                loading: loading,
                onChange: handleChange
            }, "list_message")
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7120:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2881);
/* harmony import */ var _contents_detail__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8817);
/* harmony import */ var _packages_Table__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(430);
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8804);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3495);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8108);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9676);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_detail__WEBPACK_IMPORTED_MODULE_3__, _packages_Table__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_6__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_detail__WEBPACK_IMPORTED_MODULE_3__, _packages_Table__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_6__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 









/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ methodName, accountId, total })=>{
    const { theme, lang } = (0,_store_FilscanStore__WEBPACK_IMPORTED_MODULE_5__/* .useFilscanStore */ .J)();
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__/* .Translation */ .W)({
        ns: "detail"
    });
    const [loadingTable, setTableLoading] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)(false);
    const { axiosData, loading } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({
        dataSource: [],
        total: 0
    });
    const [current, setCurrent] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)(1);
    const [fromList, setFrom] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({});
    const [toList, setTo] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({});
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return (0,_contents_detail__WEBPACK_IMPORTED_MODULE_3__/* .trance_list */ .hC)(fromList, toList).map((v)=>{
            return {
                ...v,
                title: tr(v.title)
            };
        });
    }, [
        theme,
        tr,
        fromList,
        toList
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        if (accountId) {
            load();
        }
    }, [
        accountId,
        methodName
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        total(data.total);
    }, [
        data
    ]);
    const load = async (cur, method)=>{
        setTableLoading(true);
        const showIndex = cur || current;
        const showMethod = method || methodName;
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.detail_trance_list, {
            account_id: accountId,
            filters: {
                index: showIndex - 1,
                limit: _utils__WEBPACK_IMPORTED_MODULE_6__/* .pageLimit */ .P5,
                method_name: showMethod === "all" ? "" : showMethod
            }
        });
        setTableLoading(false);
        const showList = result?.traces_by_account_id_list || [];
        setData({
            dataSource: showList,
            total: result?.total_count
        });
        if (showList.length > 0) {
            const formItems = showList.map((v)=>v.from);
            const toItems = showList.map((v)=>v.to);
            loadFnsUrl(formItems, "form");
            loadFnsUrl(toItems, "to");
        }
    };
    const loadFnsUrl = async (items, type)=>{
        if (items.length > 0) {
            const fnsData = await axiosData(`${_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.contract_fnsUrl}`, {
                addresses: items
            }, {
                loading: false
            });
            if (type === "form") {
                setFrom(fnsData);
            } else {
                setTo(fnsData);
            }
        }
    };
    const handleChange = (pagination, filters, sorter)=>{
        let cur = pagination.current || current;
        setCurrent(cur);
        load(cur);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_9__/* .BrowserView */ .I, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "absolute -top-5 text_des text-xs",
                    children: tr("traces_list_total", {
                        value: (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatNumber */ .uf)(data.total)
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_Table__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                data: data.dataSource,
                total: data.total,
                columns: columns,
                loading: loading,
                onChange: handleChange
            }, "list_traces")
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4232:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_copy__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5174);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9676);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2881);
/* harmony import */ var _contents_contract__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5509);
/* harmony import */ var _packages_selects__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(869);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7947);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_contract__WEBPACK_IMPORTED_MODULE_4__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_contract__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const Editor = next_dynamic__WEBPACK_IMPORTED_MODULE_8___default()(null, {
    loadableGenerated: {
        modules: [
            "../src/detail/list/verify/Code.tsx -> " + "@/components/ace"
        ]
    },
    ssr: false
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ data = {}, actorId })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__/* .Translation */ .W)({
        ns: "contract"
    });
    const { compiled_file = {}, source_file = [] } = data;
    const handleAbiChange = (value)=>{
        if (actorId) {
            window.open(`${window.location.origin}/contract/abi/${actorId}?format=${value}`);
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_7___default()("mt-5"),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: "flex items-center gap-x-1",
                children: [
                    (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_6__/* .getSvgIcon */ .a)("successIcon"),
                    tr("verify_contract")
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                className: "flex flex-wrap gap-y-2 border border_color mt-5 rounded-md p-5",
                children: _contents_contract__WEBPACK_IMPORTED_MODULE_4__/* .contract_detail */ .JZ.list.map((item)=>{
                    const { dataIndex, title, render } = item;
                    const value = render && compiled_file ? render(compiled_file[dataIndex] || "", data) : compiled_file && compiled_file[dataIndex] || "";
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                        className: "flex items-center h-9 w-1/2",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "w-28 text_des",
                                children: [
                                    tr(item.title),
                                    ":"
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: value
                            })
                        ]
                    }, dataIndex);
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_device_detect__WEBPACK_IMPORTED_MODULE_2__/* .BrowserView */ .I, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "my-5",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "mb-5",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    className: "text-sm font-medium",
                                    children: [
                                        `${tr("source_code")} (Solidity)`,
                                        " "
                                    ]
                                })
                            }),
                            source_file?.map((item, index)=>{
                                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex justify-between items-center my-2.5",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: item?.file_name || ""
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "w-7 h-7 flex items-center justify-center border border_color rounded-[5px]",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                        text: item.source_code,
                                                        className: "text_color"
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Editor, {
                                            value: item.source_code || {},
                                            otherProps: {
                                                readOnly: true
                                            }
                                        })
                                    ]
                                }, index);
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "my-5",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex items-center justify-between mb-3",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "text-sm font-medium",
                                        children: [
                                            `${tr("contract_abi")}`,
                                            " "
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_selects__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                        placeholder: tr(_contents_contract__WEBPACK_IMPORTED_MODULE_4__/* .contract_detail */ .JZ.abiOptions.placeholder),
                                        options: _contents_contract__WEBPACK_IMPORTED_MODULE_4__/* .contract_detail */ .JZ.abiOptions.list,
                                        onChange: handleAbiChange
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "h-[300px] p-5 overflow-auto border border_color rounded-[5px] break-words",
                                children: compiled_file?.ABI || ""
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "my-5",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex justify-between items-center mb-3",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "text-sm font-medium",
                                        children: [
                                            `${tr("source_code_create")}`,
                                            " "
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "w-7 h-7 flex items-center justify-center border border_color rounded-[5px]",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                            text: compiled_file?.byte_code,
                                            className: "text_color"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "h-[300px] p-5 overflow-auto border border_color rounded-[5px] break-words",
                                children: compiled_file?.byte_code || ""
                            })
                        ]
                    })
                ]
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3643:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2881);
/* harmony import */ var _contents_contract__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5509);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8108);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _Code__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4232);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1798);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_contract__WEBPACK_IMPORTED_MODULE_2__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_3__, _Code__WEBPACK_IMPORTED_MODULE_5__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_contract__WEBPACK_IMPORTED_MODULE_2__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_3__, _Code__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const Read = next_dynamic__WEBPACK_IMPORTED_MODULE_6___default()(null, {
    loadableGenerated: {
        modules: [
            "../src/detail/list/verify/index.tsx -> " + "./Read"
        ]
    },
    ssr: false
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ actorId, verifyData })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "contract"
    });
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("Verify_code");
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)();
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        setData(verifyData);
    }, [
        verifyData
    ]);
    // useEffect(() => {
    //   if (actorId && !verifyData) {
    //     load()
    //   }
    // },[actorId,verifyData])
    // const load = async () => {
    //   const result= await axiosData(apiUrl.contract_verify_des, {
    //     input_address:actorId
    //   })
    //   console.log('---33result',result)
    //   setData({ ...result});
    // }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        "data-content": tr("pleaseCheckContractWithPC"),
        className: classnames__WEBPACK_IMPORTED_MODULE_7___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().wrap)),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                className: classnames__WEBPACK_IMPORTED_MODULE_7___default()("flex items-center gap-x-2 des_bg_color rounded-md  w-fit"),
                children: _contents_contract__WEBPACK_IMPORTED_MODULE_2__/* .verify_tabs */ .s3.map((item)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                        onClick: ()=>setActive(item.dataIndex),
                        className: `p-2.5 cursor-pointer  ${active === item.dataIndex ? "text-primary" : ""}`,
                        children: tr(item.title)
                    }, item.dataIndex);
                })
            }),
            active === "Verify_code" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Code__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                data: data,
                actorId: actorId
            }),
            active === "Verify_read" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Read, {
                verifyData: data?.compiled_file || {},
                type: "view",
                actorId: actorId
            }),
            active === "Verify_write" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Read, {
                verifyData: data?.compiled_file || {},
                type: "write",
                actorId: actorId
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;