exports.id = 1163;
exports.ids = [1163];
exports.modules = {

/***/ 5177:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgIconClose = function SvgIconClose(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 40 40"
  }, props), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#fff",
    d: "M0 0h40v40H0z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#333",
    fillRule: "nonzero",
    d: "M20.607 22.963 12.12 31.45a1.667 1.667 0 0 1-2.357-2.357l8.486-8.486-8.486-8.485a1.667 1.667 0 0 1 2.357-2.357l8.486 8.485 8.485-8.485a1.667 1.667 0 0 1 2.357 2.357l-8.485 8.485 8.485 8.486a1.667 1.667 0 0 1-2.357 2.357z"
  }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgIconClose);

/***/ }),

/***/ 8644:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgIconOpen = function SvgIconOpen(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 40 40"
  }, props), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#fff",
    d: "M0 0h40v40H0z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#000",
    fillRule: "nonzero",
    d: "M6.333 6.667h27.334C34.403 6.667 35 7.264 35 8v.667C35 9.403 34.403 10 33.667 10H6.333A1.333 1.333 0 0 1 5 8.667V8c0-.736.597-1.333 1.333-1.333zm0 11.666h27.334c.736 0 1.333.597 1.333 1.334v.666c0 .737-.597 1.334-1.333 1.334H6.333A1.333 1.333 0 0 1 5 20.333v-.666c0-.737.597-1.334 1.333-1.334zM6.667 30h26.666a1.667 1.667 0 0 1 0 3.333H6.667a1.667 1.667 0 0 1 0-3.333z"
  }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgIconOpen);

/***/ }),

/***/ 1779:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgIconSearch = function SvgIconSearch(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 28 28"
  }, props), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M0 0h28v28H0z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#333",
    fillRule: "nonzero",
    d: "m20.952 19.336 4.088 4.087a1.143 1.143 0 0 1-1.617 1.617l-4.087-4.088a10.244 10.244 0 0 1-6.422 2.251c-5.68 0-10.289-4.61-10.289-10.289 0-5.68 4.61-10.289 10.29-10.289 5.679 0 10.288 4.61 10.288 10.29 0 2.427-.842 4.66-2.25 6.42zm-2.293-.849a7.976 7.976 0 0 0 2.258-5.573 8 8 0 0 0-8.003-8.003 8 8 0 0 0-8.003 8.003 8 8 0 0 0 8.003 8.003c2.167 0 4.133-.86 5.573-2.258z"
  }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgIconSearch);

/***/ }),

/***/ 5903:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgIconCopy = function SvgIconCopy(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 22 22",
    width: "1em",
    height: "1em"
  }, props), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "#336afa"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M16.5 3.14H2.12C.95 3.14.01 4.02 0 5.1v14.93c0 1.08.95 1.96 2.12 1.96H16.5c1.17 0 2.12-.88 2.12-1.96V5.11c0-1.08-.95-1.96-2.12-1.96zm.42 16.89c0 .22-.19.39-.42.39H2.12c-.23 0-.42-.18-.42-.39V5.11c0-.22.19-.39.42-.39H16.5c.23 0 .42.18.42.39v14.93z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M19.88 0H5.5c-.47 0-.85.35-.85.79s.38.79.85.79h14.38c.23 0 .42.18.42.39V16.9c0 .43.38.79.85.79s.85-.35.85-.79V1.96C22 .88 21.05 0 19.88 0z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M13.54 9.03H5.08c-.47 0-.85.35-.85.79s.38.79.85.79h8.46c.47 0 .85-.35.85-.79s-.38-.79-.85-.79zm-3.38 4.81H5.08c-.47 0-.85.35-.85.79s.38.79.85.79h5.08c.47 0 .85-.35.85-.79s-.38-.79-.85-.79z"
  }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgIconCopy);

/***/ }),

/***/ 5563:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _defs, _path;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgLogoMobile = function SvgLogoMobile(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 34 31"
  }, props), _defs || (_defs = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("defs", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("linearGradient", {
    id: "logo-mobile_svg__a",
    x1: "5.864%",
    x2: "75.628%",
    y1: "89.411%",
    y2: "-.081%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: "0%",
    stopColor: "#1764FF"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: "67.358%",
    stopColor: "#16CDE5"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: "99.92%",
    stopColor: "#A2E7A2"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: "100%",
    stopColor: "#ABE99E"
  })))), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "url(#logo-mobile_svg__a)",
    fillRule: "evenodd",
    d: "M9.526 17.82c.188-.07.428-.056.638-.033.14.016.32.07.536.162.502-.041.881-.017 1.14.073.386.134.563.305.66.553.064.165.065.35.004.554-.188-.145-.358-.226-.511-.245-.23-.029-.347.015-.7.148-.235.09-.424.2-.566.332l-3.743 3.182-.706 3.686c-.314 1.023-.73 1.843-1.246 2.458-.775.924-1.3 1.17-2.237 1.664-.625.328-1.341.544-2.15.646.396-.086.815-.414 1.257-.985.172-.223.599-.763.735-1.62.141-.89.22-2.992.234-6.308l-2.396-.835 9.051-3.432Zm18.92-7.049c.836 2.374.03 5.781-.914 7.978-2.204 5.129-7.267 8.214-12.582 8.214-1.776 0-3.578-.344-5.313-1.072-.604-.253-1.168-.6-1.622-.878l-.095-.057 2.539-4.045.098.06c.329.203.701.431.961.54 4.483 1.88 9.677-.194 11.58-4.621.778-1.811 1.046-3.855.799-4.557ZM2.407 8.214C5.346 1.37 13.375-1.833 20.302 1.072c3.205 1.344 5.703 3.77 7.112 6.881L34 6.711 0 20.058l1.339-7.154a13.33 13.33 0 0 1 1.067-4.69ZM18.42 5.452c-4.483-1.88-9.677.193-11.58 4.62a8.76 8.76 0 0 0-.565 1.868l16.2-3.055a8.715 8.715 0 0 0-4.055-3.433Z"
  })));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgLogoMobile);

/***/ }),

/***/ 8091:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _defs, _path;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgLogo = function SvgLogo(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 34 31"
  }, props), _defs || (_defs = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("defs", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("linearGradient", {
    id: "logo_svg__a",
    x1: "5.864%",
    x2: "75.628%",
    y1: "89.411%",
    y2: "-.081%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: "0%",
    stopColor: "#1764FF"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: "67.358%",
    stopColor: "#16CDE5"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: "99.92%",
    stopColor: "#A2E7A2"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: "100%",
    stopColor: "#ABE99E"
  })))), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "url(#logo_svg__a)",
    fillRule: "evenodd",
    d: "M9.526 17.82c.188-.07.428-.056.638-.033.14.016.32.07.536.162.502-.041.881-.017 1.14.073.386.134.563.305.66.553.064.165.065.35.004.554-.188-.145-.358-.226-.511-.245-.23-.029-.347.015-.7.148-.235.09-.424.2-.566.332l-3.743 3.182-.706 3.686c-.314 1.023-.73 1.843-1.246 2.458-.775.924-1.3 1.17-2.237 1.664-.625.328-1.341.544-2.15.646.396-.086.815-.414 1.257-.985.172-.223.599-.763.735-1.62.141-.89.22-2.992.234-6.308l-2.396-.835 9.051-3.432Zm18.92-7.049c.836 2.374.03 5.781-.914 7.978-2.204 5.129-7.267 8.214-12.582 8.214-1.776 0-3.578-.344-5.313-1.072-.604-.253-1.168-.6-1.622-.878l-.095-.057 2.539-4.045.098.06c.329.203.701.431.961.54 4.483 1.88 9.677-.194 11.58-4.621.778-1.811 1.046-3.855.799-4.557ZM2.407 8.214C5.346 1.37 13.375-1.833 20.302 1.072c3.205 1.344 5.703 3.77 7.112 6.881L34 6.711 0 20.058l1.339-7.154a13.33 13.33 0 0 1 1.067-4.69ZM18.42 5.452c-4.483-1.88-9.677.193-11.58 4.62a8.76 8.76 0 0 0-.565 1.868l16.2-3.055a8.715 8.715 0 0 0-4.055-3.433Z"
  })));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgLogo);

/***/ }),

/***/ 3001:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _linearGradient, _filter, _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgSearchIconB = function SvgSearchIconB(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 34 34"
  }, props), _linearGradient || (_linearGradient = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("linearGradient", {
    id: "searchIcon_b_svg__a",
    x1: "11%",
    x2: "86.397%",
    y1: "13.256%",
    y2: "85.045%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 0,
    stopColor: "#398bef"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 1,
    stopColor: "#1c6afd"
  }))), _filter || (_filter = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("filter", {
    id: "searchIcon_b_svg__b"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("feColorMatrix", {
    in: "SourceGraphic",
    values: "0 0 0 0 0.047059 0 0 0 0 0.050980 0 0 0 0 0.054902 0 0 0 1.000000 0"
  }))), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", {
    width: 34,
    height: 34,
    fill: "url(#searchIcon_b_svg__a)",
    rx: 5
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    filter: "url(#searchIcon_b_svg__b)"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "#2c2c2c",
    fillRule: "nonzero"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M24.37 18.46H9.783a.594.594 0 0 1-.594-.594v-1.187c0-.328.266-.594.594-.594H24.37z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "m18.713 23.344-.838-.837a.591.591 0 0 1 0-.838l4.397-4.397-4.397-4.397a.593.593 0 0 1 0-.837l.838-.838a.593.593 0 0 1 .837 0l6.072 6.072-6.072 6.072a.593.593 0 0 1-.837 0z"
  }))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgSearchIconB);

/***/ }),

/***/ 434:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _linearGradient, _filter, _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgSearchIconW = function SvgSearchIconW(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 28 28"
  }, props), _linearGradient || (_linearGradient = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("linearGradient", {
    id: "searchIcon_w_svg__a",
    x1: "11%",
    x2: "86.397%",
    y1: "13.256%",
    y2: "85.045%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 0,
    stopColor: "#398bef"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 1,
    stopColor: "#1c6afd"
  }))), _filter || (_filter = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("filter", {
    id: "searchIcon_w_svg__b"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("feColorMatrix", {
    in: "SourceGraphic",
    values: "0 0 0 0 1.000000 0 0 0 0 1.000000 0 0 0 0 1.000000 0 0 0 1.000000 0"
  }))), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", {
    width: 28,
    height: 28,
    fill: "url(#searchIcon_w_svg__a)",
    rx: 5
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    filter: "url(#searchIcon_w_svg__b)"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "#fff",
    fillRule: "nonzero"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M20.07 15.202H8.055a.489.489 0 0 1-.488-.489v-.978c0-.27.218-.489.488-.489H20.07z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "m15.41 19.224-.69-.69a.487.487 0 0 1 0-.689l3.622-3.62-3.621-3.622a.488.488 0 0 1 0-.69l.69-.69c.19-.19.499-.19.689 0l5 5.001-5 5c-.19.19-.5.19-.69 0z"
  }))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgSearchIconW);

/***/ }),

/***/ 3224:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap": "copy_wrap__ZheNH"
};


/***/ }),

/***/ 5420:
/***/ ((module) => {

// Exports
module.exports = {
	"mobile": "device-detect_mobile__LTHQ5",
	"browser": "device-detect_browser__ADyub"
};


/***/ }),

/***/ 7687:
/***/ ((module) => {

// Exports
module.exports = {
	"footer-wrap": "footer_footer-wrap__yu5YB",
	"top": "footer_top__IsQyN",
	"text": "footer_text__Jlm1r",
	"bottom": "footer_bottom__Y4FIh"
};


/***/ }),

/***/ 8327:
/***/ ((module) => {

// Exports
module.exports = {
	"header-wrap": "header_header-wrap__OUJNT",
	"header": "header_header__Vn1rR",
	"nav": "header_nav___l_aP",
	"fil": "header_fil__SLnbl",
	"body": "header_body__zAiPK",
	"active": "header_active__SFXvq"
};


/***/ }),

/***/ 3651:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap": "search_wrap__ZlGOI",
	"search-wrap": "search_search-wrap__RhRDF",
	"search": "search_search__Hk_10",
	"mask-wrap": "search_mask-wrap__fouyQ",
	"mask": "search_mask__y9A0k",
	"disabled": "search_disabled__KEhCc"
};


/***/ }),

/***/ 6298:
/***/ ((module) => {

// Exports
module.exports = {
	"search_input": "search_search_input__ThE72",
	"ant-input": "search_ant-input__ykxVp",
	"ant-input-suffix": "search_ant-input-suffix__EBepm",
	"banner_search": "search_banner_search__h9KfG"
};


/***/ }),

/***/ 6209:
/***/ ((module) => {

// Exports
module.exports = {
	"component": "_app_component__e_lxU",
	"home": "_app_home__DELaW",
	"other": "_app_other__079cS",
	"title": "_app_title__CL_aL",
	"search": "_app_search__M6UrI"
};


/***/ }),

/***/ 1062:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-accelerate.aliyuncs.com/client/_next/static/media/logo.a0364323.png","height":62,"width":68,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAYAAAA1WQxeAAAA5klEQVR42mMAAZFDL0IkTz35Ynjxxl/Pa2feRd86HAXEDIE3jjMwiK154yi2/dVH0VNPwxi+3+Y0vHSjwOnKhf/BN44Flt3fwscgtuj9DrGl7y6LrX6bDVS4nuvQy37p8w+6TC5dbwNiBgaxiZ9viM35+EZsxdsdYjteegIxg8jh55Uix5+dAGKggtZvU8R6vu4Tm/Q5DYgZxBa/9xbb9Pq/2K6XQUAMVFD5s0Cs9sdGoKLVQNM+ic378EJs2btsIGYQX/mWiUE852+6WO4fayBmEOv4qime+IcNiBnEdr1iEtv1igEAtSx1VidlJcoAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":7});

/***/ }),

/***/ 7937:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-accelerate.aliyuncs.com/client/_next/static/media/logoText.f92cae7c.png","height":32,"width":190,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAYAAADjAO9DAAAAKklEQVR4nGMUS/2XxyD45xMD998XDEJ/9Bh4/r5gEvz97TPvfzUNoY8sAOtbDl0LcSBVAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":1});

/***/ }),

/***/ 8980:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/** @format */ 
class ErrorBoundary extends react__WEBPACK_IMPORTED_MODULE_0__.Component {
    static getDerivedStateFromError(_) {
        // Update state so the next render will show the fallback UI.
        return {
            hasError: true
        };
    }
    componentDidCatch(error, errorInfo) {
        console.error("Uncaught error:", error, errorInfo);
    }
    render() {
        if (this.state.hasError) {
            return this.props.fallback;
        }
        return this.props.children;
    }
    constructor(...args){
        super(...args);
        this.state = {
            hasError: false
        };
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ErrorBoundary);


/***/ }),

/***/ 3175:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3495);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _hooks_Translation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2881);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils__WEBPACK_IMPORTED_MODULE_1__, _hooks_Translation__WEBPACK_IMPORTED_MODULE_3__]);
([_utils__WEBPACK_IMPORTED_MODULE_1__, _hooks_Translation__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { text, ns } = props;
    const { tr } = (0,_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__/* .Translation */ .W)({
        ns
    });
    const [show, setShow] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const showTime = (number)=>{
        let showText = "";
        const { days, hours, minutes, seconds } = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatTime */ .mr)(Number(number * 1000));
        if (days !== 0) {
            showText = `${days}${tr("day")} ${hours}${tr("hours")} ${minutes}${tr("minutes")} `;
        } else if (hours !== 0) {
            showText = `${hours}${tr("hours")} ${minutes}${tr("minutes")} `;
        } else if (minutes !== 0) {
            showText = `${minutes}${tr("minutes")} ${seconds}${tr("seconds")} `;
        } else {
            showText = `${seconds}${tr("seconds")} `;
        }
        setShow(showText);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (text) {
            showTime(text);
        }
        const interval = setInterval(()=>{
            showTime(text);
        }, 1000);
        return ()=>{
            clearInterval(interval);
        };
    }, [
        text
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
        children: show
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5174:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ components_copy)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: external "antd/lib/message"
var message_ = __webpack_require__(7369);
var message_default = /*#__PURE__*/__webpack_require__.n(message_);
// EXTERNAL MODULE: external "copy-to-clipboard"
var external_copy_to_clipboard_ = __webpack_require__(8887);
var external_copy_to_clipboard_default = /*#__PURE__*/__webpack_require__.n(external_copy_to_clipboard_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./assets/images/copy.svg
var _filter, _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgCopy = function SvgCopy(props) {
  return /*#__PURE__*/external_react_.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 13 14"
  }, props), _filter || (_filter = /*#__PURE__*/external_react_.createElement("filter", {
    id: "copy_svg__a"
  }, /*#__PURE__*/external_react_.createElement("feColorMatrix", {
    in: "SourceGraphic",
    values: "0 0 0 0 0.141176 0 0 0 0 0.450980 0 0 0 0 0.980392 0 0 0 1.000000 0"
  }))), _g || (_g = /*#__PURE__*/external_react_.createElement("g", {
    fill: "none",
    fillRule: "evenodd",
    filter: "url(#copy_svg__a)",
    transform: "translate(-213 -138)"
  }, /*#__PURE__*/external_react_.createElement("g", {
    fill: "#336afa",
    fillRule: "nonzero"
  }, /*#__PURE__*/external_react_.createElement("path", {
    d: "M222.389 139.944h-8.185c-.665.001-1.203.545-1.204 1.216v9.236c0 .67.54 1.215 1.204 1.215h8.185a1.21 1.21 0 0 0 1.204-1.215v-9.236c0-.67-.54-1.216-1.204-1.216zm.24 10.452a.243.243 0 0 1-.24.243h-8.185a.242.242 0 0 1-.241-.243v-9.236c0-.135.108-.243.24-.243h8.186c.133 0 .24.108.24.243z"
  }), /*#__PURE__*/external_react_.createElement("path", {
    d: "M224.315 138h-8.185a.484.484 0 0 0-.482.486c0 .269.216.486.482.486h8.185c.133 0 .24.109.24.243v9.236c0 .269.216.486.482.486a.484.484 0 0 0 .482-.486v-9.236c0-.67-.54-1.215-1.204-1.215z"
  }), /*#__PURE__*/external_react_.createElement("path", {
    d: "M220.704 143.585h-4.815a.484.484 0 0 0-.482.487c0 .268.216.486.482.486h4.815a.484.484 0 0 0 .481-.486.484.484 0 0 0-.481-.487zm-1.926 2.974h-2.89a.484.484 0 0 0-.48.487c0 .268.215.486.48.486h2.89a.484.484 0 0 0 .481-.486.484.484 0 0 0-.481-.487z"
  })))));
};
/* harmony default export */ const copy = (SvgCopy);
// EXTERNAL MODULE: ./components/copy/index.module.scss
var index_module = __webpack_require__(3224);
var index_module_default = /*#__PURE__*/__webpack_require__.n(index_module);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(9003);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: ./svgsIcon.tsx
var svgsIcon = __webpack_require__(7947);
// EXTERNAL MODULE: ./components/device-detect/index.tsx
var device_detect = __webpack_require__(9676);
;// CONCATENATED MODULE: ./components/copy/index.tsx
/** @format */ 







/* harmony default export */ const components_copy = (({ text, icon, className })=>{
    const handleClick = ()=>{
        //copynavigator
        external_copy_to_clipboard_default()(text);
        return message_default().success("Clipboard Successfully");
    // navigator?.clipboard?.writeText(text).then(function() {
    //     /* clipboard successfully set */
    //     message.success('clipboard successfully')
    //     }, function() {
    //     /* clipboard write failed */
    //     message.warning('clipboard failed')
    //     });
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("span", {
        style: {
            cursor: "pointer",
            width: "13px"
        },
        className: external_classnames_default()(`flex-center text-bgCopy ${className}`, (index_module_default()).wrap),
        onClick: handleClick,
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(device_detect/* BrowserView */.I, {
                children: [
                    (0,svgsIcon/* getSvgIcon */.a)("copyIcon"),
                    " "
                ]
            }),
            /*#__PURE__*/ jsx_runtime.jsx(device_detect/* MobileView */.$, {
                children: icon ?? /*#__PURE__*/ jsx_runtime.jsx(copy, {
                    width: 13,
                    height: 14
                })
            })
        ]
    });
});


/***/ }),

/***/ 9676:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $: () => (/* binding */ MobileView),
/* harmony export */   I: () => (/* binding */ BrowserView)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5420);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _hooks_useWindown__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1061);




const BrowserView = (props)=>{
    const { isMobile } = (0,_hooks_useWindown__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
    return isMobile ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: props.children
    });
};
const MobileView = (props)=>{
    const { isMobile } = (0,_hooks_useWindown__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)();
    return !isMobile ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_1___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default().mobile)),
        children: props.children
    });
};


/***/ }),

/***/ 4753:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _assets_images_logo_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8091);
/* harmony import */ var _hooks_Translation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2881);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7947);
/* harmony import */ var _device_detect__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9676);
/* harmony import */ var _components_mobile_footer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6151);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _components_mobile_footer__WEBPACK_IMPORTED_MODULE_5__]);
([_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _components_mobile_footer__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 





const footerLinks = [
    {
        label: "twitter",
        type: "_blank",
        link: "https://twitter.com/FilscanOfficial"
    },
    {
        label: "telegram",
        type: "_blank",
        link: "https://t.me/+bI9fUEkmPjMzYjg1"
    },
    {
        label: "outlook",
        type: "_self",
        link: "mailto:filscanteam@outlook.com"
    }
];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    const { tr } = (0,_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__/* .Translation */ .W)({
        ns: "common"
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_device_detect__WEBPACK_IMPORTED_MODULE_4__/* .MobileView */ .$, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_mobile_footer__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_device_detect__WEBPACK_IMPORTED_MODULE_4__/* .BrowserView */ .I, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-screen h-[140px] bg-footerColor",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "custom_footer flex justify-between flex-col bg-footerColor",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "!text-white flex items-center mt-4",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_logo_svg__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                        width: 30,
                                        height: 30
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "font-Barlow font-medium text-xl ml-2",
                                        children: "Filscan.io "
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex justify-between items-end text-border_des",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex flex-col gap-y-1 text-xs",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: tr("footer_des1")
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: tr("footer_des2")
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                                className: "flex text-white gap-x-5",
                                                children: footerLinks.map((linkItem)=>{
                                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                                        className: "w-5 h-5 bg-white rounded",
                                                        target: linkItem.type,
                                                        style: {
                                                            color: "#fff"
                                                        },
                                                        href: linkItem.link,
                                                        children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_3__/* .getSvgIcon */ .a)(linkItem.label)
                                                    }, linkItem.label);
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "mt-5",
                                                children: "filscanteam@outlook.com"
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7011:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _contents_nav__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7978);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2881);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _Search__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9655);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7947);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _Search__WEBPACK_IMPORTED_MODULE_5__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _Search__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 







/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__/* .Translation */ .W)({
        ns: "nav"
    });
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
    const renderChild = (children, num)=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
            className: "hidden group-hover:block h-fit absolute z-50 inset-y-full max-h-fit w-max list-none  border p-4 -ml-8 rounded-[5px] select_shadow  main_bg_color  border_color",
            children: children.map((item, index)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                    href: `${item.link}`,
                    className: "h-10 text_color font-normal flex items-center cursor-pointer rounded-[5px]  hover:text-primary hover:bg-bg_hover",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "px-4",
                        children: tr(item.key)
                    })
                }, index);
            })
        }, num);
    };
    const isHome = router.asPath === "/home" || router.asPath === "/";
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex items-center m-auto h-[60px] justify-between text-sm  font-medium custom_header",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                href: "/",
                className: "flex gap-x-2 items-center text_color cursor-pointer mt-1",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                        src: "https://filscan-v2.oss-cn-hongkong.aliyuncs.com/fvm_manage/images/logo.png",
                        width: 40,
                        height: 40,
                        alt: "logo"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                        src: "https://filscan-v2.oss-cn-hongkong.aliyuncs.com/fvm_manage/images/logoText.png",
                        alt: "logo",
                        width: 95,
                        height: 16
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex-1 ml-5 mr-10",
                children: !isHome && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Search__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                    className: "!h-10 !max-w-lg "
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex relative gap-x-9 h-full justify-between items-center",
                children: _contents_nav__WEBPACK_IMPORTED_MODULE_2__/* .navMenu */ .$.map((nav, index)=>{
                    if (nav?.children) {
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "group h-full relative  gap-x-1 flex cursor-pointer items-center hover:text-primary",
                            children: [
                                tr(nav.key),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_7__/* .getSvgIcon */ .a)("downIcon")
                                }),
                                nav.sufIcon && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "absolute top-[13px] -right-[12px]",
                                    children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_7__/* .getSvgIcon */ .a)(nav.sufIcon)
                                }),
                                renderChild(nav.children, index)
                            ]
                        }, index);
                    }
                    if (nav.outLink) {
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "relative",
                            onClick: ()=>{
                                window?.open(nav.outLink);
                            },
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    className: "cursor-pointer text_color list-none  hover:text-primary",
                                    children: tr(nav.key)
                                }),
                                nav.sufIcon && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "absolute -top-[8px] -right-6",
                                    children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_7__/* .getSvgIcon */ .a)(nav.sufIcon)
                                })
                            ]
                        }, nav.key);
                    }
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "relative",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                href: `${nav.link || nav.outLink}`,
                                className: "cursor-pointer text_color  hover:text-primary",
                                children: tr(nav.key)
                            }),
                            nav.sufIcon && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "absolute -top-[8px] -right-6",
                                children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_7__/* .getSvgIcon */ .a)(nav.sufIcon)
                            })
                        ]
                    }, nav.key);
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9655:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_search__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1519);
/* harmony import */ var _contents_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5934);
/* harmony import */ var _assets_images_searchIcon_w_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(434);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8108);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8054);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _ant_design_icons_lib_icons_LoadingOutlined__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7529);
/* harmony import */ var _ant_design_icons_lib_icons_LoadingOutlined__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons_lib_icons_LoadingOutlined__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_search__WEBPACK_IMPORTED_MODULE_1__, _contents_common__WEBPACK_IMPORTED_MODULE_2__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_5__]);
([_components_search__WEBPACK_IMPORTED_MODULE_1__, _contents_common__WEBPACK_IMPORTED_MODULE_2__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 









/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ origin, className = "" })=>{
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_7__.useRouter)();
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)([]);
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)("");
    const [searchLoading, setSearchLoading] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(()=>{
        if (router.asPath.includes("address/miner")) {
            const addressValue = router.asPath.split("?")[1];
            const showValue = addressValue.split("=")[1];
            handleSearch(showValue);
        }
    }, [
        router
    ]);
    const handleSearch = async (value)=>{
        const showInput = value.trim();
        if (showInput) {
            setSearchLoading(true);
            const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_6__/* .apiUrl */ .JW.searchInfo, {
                input: showInput
            });
            setSearchLoading(false);
            const type = result?.result_type;
            if (type) {
                if (type === "owner") {
                    //owner
                    router.push(`/owner/${showInput}`);
                } else if (type === "address") {
                    router.push(`/address/${showInput}`);
                } else if (type === "height") {
                    router.push(`/height/${showInput}`);
                } else if (type === "message_details") {
                    router.push(`/message/${showInput}`);
                } else if (type === "miner") {
                    router.push(`/miner/${showInput}`);
                } else if (type === "block_details") {
                    router.push(`/cid/${showInput}`);
                } else if (type === "fns") {
                    if (result?.fns_tokens.length > 0) {
                        setOptions(result?.fns_tokens || []);
                        setActive(type);
                    } else {
                        router.push(`/domain/${showInput}`);
                    }
                } else {
                    router.push(`/address/${showInput}`);
                }
            } else {
                //404
                router.push(`/noResult/${showInput}`);
            }
        }
    };
    const handleClick = (item)=>{
        router.push(`/domain/${item.name}?provider=${item.provider}`);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "relative w-auto group",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_search__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                className: `${className} focus:outline-none`,
                ns: "common",
                placeholder: _contents_common__WEBPACK_IMPORTED_MODULE_2__/* .search */ .yC.holder,
                onSearch: handleSearch,
                origin: origin,
                onClick: handleSearch,
                suffix: searchLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "flex items-center justify-center bg-primary rounded-[5px]",
                    style: {
                        width: origin === "banner" ? 40 : 21,
                        height: origin === "banner" ? 40 : 21
                    },
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_ant_design_icons_lib_icons_LoadingOutlined__WEBPACK_IMPORTED_MODULE_9___default()), {
                        className: "custom-icon text-xs"
                    })
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_searchIcon_w_svg__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    width: origin === "banner" ? 40 : 21,
                    height: origin === "banner" ? 40 : 21
                })
            }),
            active === "fns" && options && options.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                className: `opacity-0 group-focus-within:opacity-100  absolute flex gap-y-2 flex-col  w-full h-fit p-3 card_shadow border border_color ${origin === "home" ? "" : "!max-w-lg"}`,
                children: options.map((item)=>{
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                        className: "flex p-2 items-center gap-x-1 hover:bg-bg_hover cursor-pointer rounded-[5px]",
                        onClick: ()=>handleClick(item),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                                src: item.icon,
                                alt: "",
                                width: 45,
                                height: 45,
                                className: "logo_img rounded-[5px]"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: item.name
                            })
                        ]
                    }, item.value);
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3340:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _contents_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5934);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2881);
/* harmony import */ var _Nav__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7011);
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8804);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _packages_select__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6423);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7947);
/* harmony import */ var _i18n__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1091);
/* harmony import */ var _device_detect__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9676);
/* harmony import */ var _components_mobile_header_index__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9733);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(8108);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8054);
/* harmony import */ var _TimerHtml__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(3175);
/* harmony import */ var _hooks_useInterval__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(9447);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_contents_common__WEBPACK_IMPORTED_MODULE_1__, _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _Nav__WEBPACK_IMPORTED_MODULE_3__, _packages_select__WEBPACK_IMPORTED_MODULE_6__, _i18n__WEBPACK_IMPORTED_MODULE_9__, _components_mobile_header_index__WEBPACK_IMPORTED_MODULE_11__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_12__, _TimerHtml__WEBPACK_IMPORTED_MODULE_14__]);
([_contents_common__WEBPACK_IMPORTED_MODULE_1__, _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _Nav__WEBPACK_IMPORTED_MODULE_3__, _packages_select__WEBPACK_IMPORTED_MODULE_6__, _i18n__WEBPACK_IMPORTED_MODULE_9__, _components_mobile_header_index__WEBPACK_IMPORTED_MODULE_11__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_12__, _TimerHtml__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 















// import Skeleton from '@/packages/skeleton';
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__/* .Translation */ .W)({
        ns: "common"
    });
    const { theme, lang, setTheme, setLang } = (0,_store_FilscanStore__WEBPACK_IMPORTED_MODULE_4__/* .useFilscanStore */ .J)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_7__.useRouter)();
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)();
    const [fil, setFilData] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)({});
    const [finalHeight, setFinalHeight] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)({});
    const [show, setShow] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    const [lastScrollTop, setLastScrollTop] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(0);
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        const handleScroll = ()=>{
            const st = window.pageYOffset || document.documentElement.scrollTop;
            if (st > lastScrollTop) {
                setShow(false);
            } else {
                setShow(true);
            }
            setLastScrollTop(st <= 0 ? 0 : st);
        };
        window.addEventListener("scroll", handleScroll);
        return ()=>window.removeEventListener("scroll", handleScroll);
    }, [
        lastScrollTop
    ]);
    (0,_hooks_useInterval__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z)(()=>{
        loadFilPrice();
    }, 15000);
    const loadFilPrice = async ()=>{
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_13__/* .FilPrice */ .lR);
        setFilData(result || {});
        const finalHeight = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_13__/* .FinalHeight */ .kY);
        setFinalHeight(finalHeight || {});
    };
    const handleLangChange = (value)=>{
        localStorage.setItem("lang", value);
        _i18n__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z.changeLanguage(lang); // 更改i18n语言
        setLang(value);
        router.push(router.asPath, router.asPath, {
            locale: value
        });
    };
    const handleNetwork = (value)=>{
        if (value === "Calibration") {
            window.open("https://calibration.filscan.io/");
        } else if (value === "Mainnet") {
            window.open("https://filscan.io/");
        }
    };
    const apiFlag = "Mainnet";
    // px-24
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_device_detect__WEBPACK_IMPORTED_MODULE_10__/* .MobileView */ .$, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_mobile_header_index__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                    data: {
                        ...fil,
                        ...finalHeight
                    }
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_device_detect__WEBPACK_IMPORTED_MODULE_10__/* .BrowserView */ .I, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: `${show ? " header-fade-in visible fixed top-0 " : "absolute top-0"} ${lastScrollTop > 100 ? "header-fade-in" : ""}  z-50 w-full h-[110px] main_bg_color`,
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex justify-between items-center text-xs w-full h-[45px] custom_header",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                    className: "flex gap-x-5 list-none",
                                    children: _contents_common__WEBPACK_IMPORTED_MODULE_1__/* .header_top */ .cK.left.map((item)=>{
                                        const { title, dataIndex, render } = item;
                                        const data = {
                                            ...fil,
                                            ...finalHeight
                                        };
                                        const value = data && data[dataIndex];
                                        let renderDom = render && render(value, data);
                                        if (dataIndex === "block_time") {
                                            renderDom = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_TimerHtml__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                                                ns: "home",
                                                text: value
                                            });
                                        }
                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            className: "flex gap-x-1",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    children: [
                                                        tr(title),
                                                        ":"
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: renderDom || value
                                                })
                                            ]
                                        }, dataIndex);
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex gap-x-2.5 items-center",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_select__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                            ns: "",
                                            wrapClassName: "main_bg_color",
                                            className: "!-inset-x-1/2 ",
                                            value: apiFlag || "Mainnet",
                                            header: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "flex items-center justify-center w-7 h-7 border  cursor-pointer rounded-[5px] main_bg_color border_color ",
                                                children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_8__/* .getSvgIcon */ .a)("network")
                                            }),
                                            onChange: handleNetwork,
                                            options: _contents_common__WEBPACK_IMPORTED_MODULE_1__/* .networkOptions */ .Dc
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_select__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                            ns: "",
                                            wrapClassName: "main_bg_color",
                                            className: "!-inset-x-1/2 ",
                                            header: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "flex items-center justify-center w-7 h-7 border main_bg_color  border_color cursor-pointer rounded-[5px]",
                                                children: tr(lang)
                                            }),
                                            value: lang,
                                            onChange: handleLangChange,
                                            options: _contents_common__WEBPACK_IMPORTED_MODULE_1__/* .langOptions */ .YH
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: theme === "dark" ? "text-white cursor-pointer w-7 h-7 border border_color rounded-[5px]" : "cursor-pointer",
                                            onClick: ()=>{
                                                localStorage.setItem("theme", theme === "dark" ? "light" : "dark");
                                                setTheme(theme === "dark" ? "light" : "dark");
                                            },
                                            children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_8__/* .getSvgIcon */ .a)(theme === "dark" ? "sun" : "moon")
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                            className: "border_color"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Nav__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
                    ]
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2881:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   W: () => (/* binding */ Translation)
/* harmony export */ });
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8804);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7987);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_2__]);
react_i18next__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const Translation = ({ ns })=>{
    const { lang } = (0,_store_FilscanStore__WEBPACK_IMPORTED_MODULE_0__/* .useFilscanStore */ .J)(); // 使用你的 store 获取 lang 状态
    const { t, i18n } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)(ns);
    // 当 lang 状态改变时，重新设置语言
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        i18n.changeLanguage(lang);
    }, [
        lang,
        i18n
    ]);
    const tr = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((label, value)=>{
        if (value) {
            return t(label, {
                ...value,
                ns: ns
            });
        }
        return t(label, {
            ns: ns
        });
    }, [
        i18n.language
    ]);
    return {
        tr
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9447:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/** @format */ 
function useInterval(callback, delay) {
    const savedCallback = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
    // 保存新回调
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        savedCallback.current = callback;
    }, [
        callback
    ]);
    // 设置 interval
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        function tick() {
            if (savedCallback.current !== null) {
                savedCallback.current();
            }
        }
        if (delay !== null) {
            tick();
            let id = setInterval(tick, delay);
            return ()=>clearInterval(id);
        }
    }, [
        delay
    ]);
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useInterval);


/***/ }),

/***/ 1061:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _store_DeviceContext__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2707);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const useWindow = ()=>{
    const context = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_store_DeviceContext__WEBPACK_IMPORTED_MODULE_0__/* .DeviceContext */ .T);
    const [isMobile, setIsMobile] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const calcWidth = ()=>{
        let windowHeight = document.documentElement.clientHeight;
        let elements = document.getElementsByClassName("container_body");
        for(let i = 0; i < elements.length; i++){
            elements[i].style.minHeight = windowHeight + "px"; // 将高度值转换为字符串，并添加单位
        }
    };
    const onResize = ()=>{
        calcWidth();
        setIsMobile(window.innerWidth <= 1000);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        window.addEventListener("resize", onResize);
        calcWidth();
        setIsMobile(window.innerWidth <= 1000);
        return ()=>{
            window.removeEventListener("resize", onResize);
        };
    }, []);
    return {
        isMobile: isMobile ?? context.isMobile
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useWindow);


/***/ }),

/***/ 6151:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _assets_images_logo_mobile_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5563);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7687);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7987);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7947);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_3__]);
react_i18next__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const links = [
    {
        label: "twitter",
        type: "_blank",
        link: "https://twitter.com/FilscanOfficial"
    },
    {
        label: "telegram",
        type: "_blank",
        link: "https://t.me/+bI9fUEkmPjMzYjg1"
    },
    {
        label: "outlook",
        type: "_self",
        link: "mailto:filscan@ipfsforce.com"
    }
];
const Header = ()=>{
    const { t } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)("common");
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default()["footer-wrap"]),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().top),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_logo_mobile_svg__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: "Filscan.io"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_2___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().text)),
                children: [
                    "        ",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: t("footer_des1")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: t("footer_des2")
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_2___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().bottom)),
                children: links.map((item, index)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        className: "w-5 h-5 bg-white rounded",
                        target: item.type,
                        style: {
                            color: "#fff"
                        },
                        href: item.link,
                        children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_4__/* .getSvgIcon */ .a)(item.label)
                    }, item.label);
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9733:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _assets_images_header_icon_close_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5177);
/* harmony import */ var _assets_images_header_icon_open_svg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8644);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8327);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var antd_lib_menu__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(274);
/* harmony import */ var antd_lib_menu__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(antd_lib_menu__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7987);
/* harmony import */ var _contents_nav__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7978);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6517);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _assets_images_logo_png__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1062);
/* harmony import */ var _assets_images_logoText_png__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7937);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2881);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _contents_common__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5934);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_6__, _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_12__, _contents_common__WEBPACK_IMPORTED_MODULE_14__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_6__, _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_12__, _contents_common__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const rootSubmenuKeys = [
    "1",
    "2",
    "3",
    "4",
    "5"
];





const Header = (props)=>{
    const { t } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_6__.useTranslation)("nav");
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_12__/* .Translation */ .W)({
        ns: "common"
    });
    const [open, setOpen] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const [openKeys, setOpenKeys] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);
    const [selectKeys, setSelectKeys] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);
    const [items, setItems] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_8__.useRouter)();
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        document.body.style.overflow = open ? "hidden" : "auto";
    }, [
        open
    ]);
    const onOpen = ()=>{
        setSelectKeys([]);
        setOpenKeys([]);
        setOpen(!open);
    };
    const onOpenChange = (keys)=>{
        const latestOpenKey = keys.find((key)=>openKeys.indexOf(key) === -1);
        if (latestOpenKey && rootSubmenuKeys.indexOf(latestOpenKey) === -1) {
            setOpenKeys(keys);
        } else {
            setOpenKeys(latestOpenKey ? [
                latestOpenKey
            ] : []);
        }
    };
    const onSelect = (select)=>{
        setOpen(false);
        setSelectKeys(select.selectedKeys);
        const link = lodash__WEBPACK_IMPORTED_MODULE_9___default().get(_contents_nav__WEBPACK_IMPORTED_MODULE_7__/* .mobileNavMenu */ .s, select.key).link;
        router.push(link);
    };
    function getItem(label, key, children, type) {
        return {
            key,
            children,
            label,
            type
        };
    }
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        let _items = [];
        _contents_nav__WEBPACK_IMPORTED_MODULE_7__/* .mobileNavMenu */ .s.forEach((value, index)=>{
            if (value.children) {
                _items.push(getItem(`${t(value.key)}`, index, value.children.map((val, idx)=>{
                    return getItem(`${t(val.key)}`, `[${index}].children[${[
                        idx
                    ]}]`);
                })));
            } else {
                _items.push(getItem(`${t(value.key)}`, `[${index}]`));
            }
        });
        setItems(_items);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    const onClick = ()=>{
        router.push("/");
    };
    const onMaskClick = ()=>{
        setOpen(false);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default()["header-wrap"]),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().header),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().nav),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                onClick: onClick,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_13___default()), {
                                        src: _assets_images_logo_png__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z,
                                        alt: "logo",
                                        width: 19.5,
                                        height: 18
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_13___default()), {
                                        src: _assets_images_logoText_png__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z,
                                        alt: "logo",
                                        width: 95,
                                        height: 16
                                    })
                                ]
                            }),
                            open ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_header_icon_close_svg__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                onClick: onOpen
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_header_icon_open_svg__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                onClick: onOpen
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().fil),
                        children: _contents_common__WEBPACK_IMPORTED_MODULE_14__/* .header_top */ .cK.left.filter((value)=>{
                            return value.dataIndex === "base_fee" || value.dataIndex === "price";
                        }).map((item, index)=>{
                            const { title, dataIndex, render } = item;
                            const value = props.data && props.data[dataIndex];
                            let renderDom = render && render(value, props.data);
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                className: "flex gap-x-1",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        children: [
                                            tr(title),
                                            ":"
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: renderDom || value
                                    })
                                ]
                            }, dataIndex);
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                id: "mask",
                onClick: onMaskClick,
                className: classnames__WEBPACK_IMPORTED_MODULE_4___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().body), open ? (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().active) : ""),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    onClick: (e)=>{
                        e.stopPropagation();
                    },
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().menuWrap),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_menu__WEBPACK_IMPORTED_MODULE_5___default()), {
                        mode: "inline",
                        selectedKeys: selectKeys,
                        openKeys: openKeys,
                        onOpenChange: onOpenChange,
                        onSelect: onSelect,
                        items: items
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8825:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _assets_images_header_icon_search_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1779);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3651);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(675);
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(antd_lib_input__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8108);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8054);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_store_useAxiosData__WEBPACK_IMPORTED_MODULE_5__]);
_store_useAxiosData__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









const Search = (props)=>{
    const [isSearch, setIsSearch] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const ref = (0,react__WEBPACK_IMPORTED_MODULE_4__.useRef)();
    const onMaskClick = ()=>{
        setIsSearch(true);
        ref.current.focus();
    };
    const onCancelClick = ()=>{
        setIsSearch(false);
    };
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_7__.useRouter)();
    const onSearch = async (value)=>{
        const showInput = value.trim();
        if (showInput) {
            const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_6__/* .apiUrl */ .JW.searchInfo, {
                input: showInput
            });
            const type = result?.result_type;
            if (type) {
                if (type === "owner") {
                    //owner
                    router.push(`/owner/${showInput}`);
                } else if (type === "address") {
                    router.push(`/address/${showInput}`);
                } else if (type === "height") {
                    router.push(`/height/${showInput}`);
                } else if (type === "message_details") {
                    router.push(`/message/${showInput}`);
                } else if (type === "miner") {
                    router.push(`/miner/${showInput}`);
                } else if (type === "block_details") {
                    router.push(`/cid/${showInput}`);
                } else if (type === "fns") {
                    router.push(`/domain/${showInput}`);
                } else {
                    router.push(`/address/${showInput}`);
                }
            } else {
                //404
                router.push(`/noResult/${showInput}`);
            }
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().wrap), props.className),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_2___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default()["search-wrap"]), isSearch ? "" : (_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().disabled)),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().search),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                            action: "",
                            id: "search-form",
                            onSubmit: (e)=>{
                                onSearch(ref.current.input.value);
                                e.preventDefault();
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_input__WEBPACK_IMPORTED_MODULE_3___default()), {
                                type: "search",
                                allowClear: true,
                                ref: ref,
                                prefix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_header_icon_search_svg__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {}),
                                onBlur: (e)=>{
                                    setIsSearch(false);
                                }
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        onClick: onCancelClick,
                        children: "取消"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                onClick: onMaskClick,
                className: classnames__WEBPACK_IMPORTED_MODULE_2___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default()["mask-wrap"]), isSearch ? (_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().disabled) : ""),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: classnames__WEBPACK_IMPORTED_MODULE_2___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_8___default().mask)),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_header_icon_search_svg__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: "搜索区块/高度/账户/地址/消息/FNS"
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Search);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1519:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(675);
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd_lib_input__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6298);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _hooks_Translation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2881);
/* harmony import */ var _assets_images_searchIcon_b_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3001);
/* harmony import */ var _assets_images_searchIcon_w_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(434);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6517);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__]);
_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/** @format */ 







/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ className, origin, onSearch, onClick, ns, placeholder = "", suffix, clear, disabled = false, value })=>{
    const { tr } = (0,_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__/* .Translation */ .W)({
        ns
    });
    const [inputValue, setValue] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)("");
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        if (value) {
            setValue(value.trim());
        }
    }, [
        value
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_input__WEBPACK_IMPORTED_MODULE_1___default()), {
            className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_7___default().search_input)} text-color custom_input  ${className} ${origin === "banner" ? `custom_input_banner ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_7___default().banner_search)}` : ""}`,
            placeholder: tr(placeholder),
            value: inputValue,
            onChange: (e)=>{
                if (!disabled) {
                    setValue(e.target.value.trim());
                }
            },
            onPressEnter: lodash__WEBPACK_IMPORTED_MODULE_6___default().debounce(()=>{
                if (clear) {
                    setValue("");
                }
                if (inputValue.length > 0) {
                    onSearch(inputValue);
                }
            }, 300),
            suffix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "cursor-pointer",
                onClick: lodash__WEBPACK_IMPORTED_MODULE_6___default().debounce(()=>{
                    if (onClick && inputValue?.length > 0) {
                        if (clear) {
                            setValue("");
                        }
                        onSearch(inputValue);
                    }
                }, 300),
                children: suffix
            }) || /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: origin === "banner" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_searchIcon_b_svg__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_searchIcon_w_svg__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
            })
        })
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8054:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   I3: () => (/* binding */ heightDetail),
/* harmony export */   JW: () => (/* binding */ apiUrl),
/* harmony export */   Uh: () => (/* binding */ EvmContractSummary),
/* harmony export */   a1: () => (/* binding */ TransMethod),
/* harmony export */   b: () => (/* binding */ DCTrend),
/* harmony export */   dE: () => (/* binding */ fvmUrl),
/* harmony export */   g2: () => (/* binding */ proApi),
/* harmony export */   i5: () => (/* binding */ EvmTxsHistory),
/* harmony export */   kY: () => (/* binding */ FinalHeight),
/* harmony export */   lR: () => (/* binding */ FilPrice)
/* harmony export */ });
const mianUrl = "https://api-v2.filscan.io/api/v1";
const proUrl = "http://8.217.144.232:29000/pro/v1" || 0;
const fvmUrl = "https://filscan-v2.oss-accelerate.aliyuncs.com/fvm_manage";
const proApi = {
    //登录注册
    mail_exists: proUrl + "/MailExists",
    resetPassword: proUrl + "/ResetPasswordByCode",
    send_code: proUrl + "/SendVerificationCode",
    byCode: proUrl + "/ResetPasswordByCode",
    login: proUrl + "/Login",
    userInfo: proUrl + "/UserInfo",
    updateInfo: proUrl + "/UpdateUserInfo",
    getOverview: proUrl + "/MinerInfoDetail",
    getGroups: proUrl + "/GetUserGroups",
    getGroupsId: proUrl + "/GetGroup",
    createGroup: proUrl + "/CreateGroup",
    saveGroup: proUrl + "/SaveGroupMiners",
    delGroup: proUrl + "/DeleteGroup",
    getLucky: proUrl + "/LuckyRateDetail",
    getBalance: proUrl + "/BalanceDetail",
    getReward: proUrl + "/RewardDetail",
    getGas: proUrl + "/GasCostDetail",
    getPower: proUrl + "/PowerDetail",
    getSector: proUrl + "/SectorDetail",
    account_miners: proUrl + "/CountUserMiners",
    saveMiner: proUrl + "/SaveUserMiners"
};
const heightDetail = mianUrl + "/TipsetDetail";
const EvmContractSummary = mianUrl + "/EvmContractSummary";
const EvmTxsHistory = mianUrl + "/EvmTxsHistory";
const FilPrice = mianUrl + "/FilPrice";
const FinalHeight = mianUrl + "/FinalHeight";
const DCTrend = mianUrl + "/DCTrend";
const TransMethod = mianUrl + "/TransferMethodByAccountID";
const apiUrl = {
    fvm_hot: mianUrl + "/GetFEvmHotItems",
    fvm_category: mianUrl + "/GetFEvmCategory",
    fvm_items: mianUrl + "/GetFEvmItemsByCategory",
    home_banner: mianUrl + "/GetBannerList",
    searchInfo: mianUrl + "/SearchInfo",
    home_meta: mianUrl + "/TotalIndicators",
    line_trend: mianUrl + "/BaseLineTrend",
    static_gas: mianUrl + "/BaseFeeTrend",
    static_gas_24: mianUrl + "/GasDataTrend",
    static_fil_chart: mianUrl + "/FilCompose",
    static_block_trend: mianUrl + "/BlockRewardTrend",
    static_active_miner: mianUrl + "/ActiveMinerTrend",
    static_message_trend: mianUrl + "/MessageCountTrend",
    rank_pool: mianUrl + "/OwnerRank",
    rank_provider: mianUrl + "/MinerRank",
    rank_growth: mianUrl + "/MinerPowerRank",
    rank_rewards: mianUrl + "/MinerRewardRank",
    tipset_chain: mianUrl + "/LatestBlocks",
    tipset_BlockDetails: mianUrl + "/BlockDetails",
    tipset_Block_messages: mianUrl + "/MessagesByBlock",
    tipset_message_opt: mianUrl + "/AllMethods",
    tipset_message_pool_opt: mianUrl + "/AllMethodsByMessagePool",
    tipset_block_message_opt: mianUrl + "/AllMethodsByBlock",
    tipset_message: mianUrl + "/LatestMessages",
    tipset_address: mianUrl + "/RichAccountRank",
    tipset_transfer: mianUrl + "/LargeTransfers",
    tipset_Dsn: mianUrl + "/SearchMarketDeals",
    tipset_pool: mianUrl + "/MessagesPool",
    detail_account: mianUrl + "/AccountInfoByID",
    detail_owner: mianUrl + "/AccountOwnerByID",
    detail_message: mianUrl + "/MessageDetails",
    detail_message_event: mianUrl + "/EventsInMessage",
    detail_message_trans: mianUrl + "/InternalTransfer",
    detail_miner_list: mianUrl,
    detail_list_method: mianUrl + "/AllMethodByAccountID",
    detail_message_list: mianUrl + "/MessagesByAccountID",
    detail_block_list: mianUrl + "/BlocksByAccountID",
    detail_trance_list: mianUrl + "/TracesByAccountID",
    detail_deal: mianUrl + "/DealDetails",
    account_change: mianUrl + "/BalanceTrendByAccountID",
    account_trend: mianUrl + "/PowerTrendByAccountID",
    detail_Indicators: mianUrl + "/IndicatorsByAccountID",
    contract_verify: mianUrl + "/VerifyContract",
    contract_hard_verify: mianUrl + "/VerifyHardhatContract",
    contract_verify_list: mianUrl + "/VerifiedContractList",
    contract_verify_logs: mianUrl + "/ActorEventsList",
    contract_rank: mianUrl + "/EvmContractList",
    contract_verify_des: mianUrl + "/VerifiedContractByActorID",
    contract_solidity: mianUrl + "/SolidityVersions",
    contract_Licenses: mianUrl + "/Licenses",
    contract_transferInMessage: mianUrl + "/ERC20TransferInMessage",
    contract_transferInMessageNft: mianUrl + "/NFTMessageTransfers",
    contract_swap: mianUrl + "/SwapInfoInMessage",
    contract_ERC20List: mianUrl + "/ERC20List",
    contract_ERC20TokenList: mianUrl + "/ERC20OwnerTokenList",
    contract_ERC20Transfer: mianUrl + "/ERC20Transfer",
    contract_ERC20Owner: mianUrl + "/ERC20Owner",
    contract_ERC20Dex: mianUrl + "/ERC20DexTrade",
    contract_NFTTransfers: mianUrl + "/NFTTransfers",
    contract_NFTOwners: mianUrl + "/NFTOwners",
    contract_ERC20Transfers: mianUrl + "/ERC20AddrTransfers",
    contract_ERC20Summary: mianUrl + "/ERC20Summary",
    contract_ERC20Market: mianUrl + "/ERC20Market",
    contract_detailList: mianUrl,
    contract_nfts: mianUrl + "/NFTTokens",
    contract_fnsUrl: mianUrl + "/FnsBindDomains",
    contract_FnsSummary: mianUrl + "/NFTSummary",
    contract_domain: mianUrl + "/FnsDomainDetail",
    contract_domain_address: mianUrl + "/FnsAddressDomains",
    fevm_defiSummary: mianUrl + "/DefiSummary",
    fevm_defiList: mianUrl + "/DefiProtocolList"
};


/***/ }),

/***/ 5934:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Dc: () => (/* binding */ networkOptions),
/* harmony export */   HJ: () => (/* binding */ SEO),
/* harmony export */   YH: () => (/* binding */ langOptions),
/* harmony export */   cK: () => (/* binding */ header_top),
/* harmony export */   yC: () => (/* binding */ search)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3495);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils__WEBPACK_IMPORTED_MODULE_1__]);
_utils__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/** @format */ 

const header_top = {
    left: [
        {
            title: "fil",
            dataIndex: "price",
            render: (text, record)=>{
                if (!text) return null;
                const changeText = record?.percent_change_24h && Number(record.percent_change_24h);
                const className = changeText ? changeText < 0 ? "text_red" : "text_green" : "";
                const flag = changeText ? changeText > 0 ? "+" : "-" : "";
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "flex gap-x-1 items-end",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "text_primary",
                            children: [
                                (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .get$Number */ .Uy)(text),
                                " "
                            ]
                        }),
                        changeText && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: `${className} ml-1`,
                            children: [
                                flag,
                                Math.abs(changeText).toFixed(2),
                                "%"
                            ]
                        })
                    ]
                });
            }
        },
        {
            title: "last_time",
            dataIndex: "block_time"
        },
        {
            title: "base_fee",
            dataIndex: "base_fee",
            render: (text)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "text_primary",
                    children: [
                        text ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(text, false, false, 2) : text,
                        " "
                    ]
                })
        },
        {
            title: "last_height",
            dataIndex: "height",
            render: (text)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "text_primary",
                    children: [
                        text ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(text, 2) : text,
                        " "
                    ]
                })
        }
    ],
    right: [
        {
            title: "",
            dataIndex: "network"
        },
        {
            title: "",
            dataIndex: "network"
        },
        {
            title: "",
            dataIndex: "network"
        }
    ]
};
const search = {
    holder: "search_holder",
    opt: [
        {
            label: "all",
            value: "all"
        },
        {
            label: "address",
            value: "address"
        },
        {
            label: "message_id",
            value: "message_id"
        },
        {
            label: "height",
            value: "height"
        },
        {
            label: "cid",
            value: "cid"
        },
        {
            label: "node",
            value: "node"
        }
    ]
};
const langOptions = [
    {
        value: "zh",
        label: "中文"
    },
    {
        value: "en",
        label: "English"
    },
    {
        value: "kr",
        label: "한국인"
    }
];
const networkOptions = [
    {
        value: "Mainnet",
        label: "Mainnet"
    },
    {
        value: "Calibration",
        label: "Calibration"
    }
];
const SEO = {
    "zh": {
        title: "Filscan Filecoin 浏览器",
        description: "Filecoin官方区块浏览器,Filecoin官方浏览器, Filscan,Filecoin,最新区块,Filecoin Explorer,FIL,IPFS，FIL,Filecoin区块链查询浏览器,FIL浏览器,Filecoin浏览器,Filecoin区块查询,区块链搜索引擎,区块高度,区块链交易",
        keywords: "Filecoin官方区块浏览器,Filecoin官方浏览器,",
        url: "https://filscan.io/"
    },
    "en": {
        title: "Filscan Filecoin Explorer",
        description: `Filscan is a blockchain explorer that serves as a fundamental tool for the Filecoin ecosystem, providing real-time on-chain data. It enables users to query information about Filecoin's blockchain, transactions, FIL tokens, wallets, etc., and synchronizes real-time information from all nodes.`,
        keywords: "Filecoin官方区块浏览器,Filecoin官方浏览器, Filecoin Explorer,fvm,Filscan,Filecoin, blockchain, crypto, currency,最新区块,FIL,IPFS，FIL,Filecoin区块链查询浏览器,FIL浏览器,Filecoin浏览器,Filecoin区块查询,区块链搜索引擎,区块高度,区块链交易",
        url: "https://filscan.io/en"
    },
    "kr": {
        title: "파일코인 익스플로러",
        description: "Filecoin 공식 브라우저 ,Filecoin 공식 블록 탐색기 ,Filecoin 블록 쿼리 ,FIL 브라우저 ,FVM ,IPFS, 블록 높이,블록체인 트랜잭션,블록체인 검색 엔진,최신 블록",
        keywords: "Filecoin官方区块浏览器,Filecoin官方浏览器, Filecoin Explorer,fvm,Filscan,Filecoin, blockchain, crypto, currency,最新区块,FIL,IPFS，FIL,Filecoin区块链查询浏览器,FIL浏览器,Filecoin浏览器,Filecoin区块查询,区块链搜索引擎,区块高度,区块链交易",
        url: "https://filscan.io/kr"
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7978:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $: () => (/* binding */ navMenu),
/* harmony export */   s: () => (/* binding */ mobileNavMenu)
/* harmony export */ });
const navMenu = [
    {
        key: "fvm",
        sufIcon: "hot",
        color: "#F44C30",
        link: "/fvm"
    },
    // {
    //   key: 'home',
    //   link: '/home'
    // },
    {
        key: "tipset",
        children: [
            {
                key: "tipset_chain",
                link: "/tipset/chain/"
            },
            {
                key: "tipset_message",
                link: "/tipset/message-list/"
            },
            {
                key: "tipset_dsn",
                link: "/tipset/dsn/"
            },
            {
                key: "tipset_pool-message",
                link: "/tipset/pool-message/"
            }
        ]
    },
    {
        key: "contract",
        sufIcon: "newIcon",
        color: "#F44C30",
        children: [
            {
                key: "token",
                link: "/contract/token/"
            },
            {
                key: "nft",
                link: "/contract/nft/"
            },
            {
                key: "defi_dashboard",
                link: "/fevm/defi/"
            },
            {
                key: "contract_rank",
                link: "/contract/rank/"
            },
            {
                key: "contract_list",
                link: "/contract/list/"
            }
        ]
    },
    {
        key: "network_overview",
        link: "/rank",
        children: [
            {
                key: "ranking",
                link: "/rank"
            },
            {
                key: "tipset_ranking",
                link: "/tipset/address-list/"
            },
            {
                key: "statistics_gas",
                link: "/statistics/gas"
            },
            {
                key: "statistics_charts",
                link: "/statistics/charts"
            }
        ]
    },
    {
        key: "develop",
        children: [
            {
                key: "contract_verify",
                link: "/contract/verify/"
            }
        ]
    },
    {
        key: "provider",
        outLink: "http://v1.filscan.io/account?key=login"
    }
];
const mobileNavMenu = [
    {
        key: "fvm",
        sufIcon: "hotIcon",
        color: "#F44C30",
        link: "/fvm"
    },
    {
        key: "home",
        link: "/"
    },
    {
        key: "tipset",
        children: [
            {
                key: "tipset_chain",
                link: "/tipset/chain/"
            },
            {
                key: "tipset_message",
                link: "/tipset/message-list/"
            },
            {
                key: "tipset_dsn",
                link: "/tipset/dsn/"
            },
            {
                key: "tipset_pool-message",
                link: "/tipset/pool-message/"
            },
            {
                key: "tipset_transfer",
                link: "/tipset/transfer/"
            }
        ]
    },
    {
        key: "contract",
        preIcon: "newIcon",
        color: "#F44C30",
        children: [
            {
                key: "token",
                link: "/contract/token/"
            },
            {
                key: "nft",
                link: "/contract/nft/"
            },
            {
                key: "defi_dashboard",
                link: "/fevm/defi/"
            },
            {
                key: "contract_rank",
                link: "/contract/rank/"
            },
            {
                key: "contract_list",
                link: "/contract/list/"
            }
        ]
    },
    {
        key: "network_overview",
        link: "/rank",
        children: [
            {
                key: "ranking",
                link: "/rank"
            },
            {
                key: "tipset_ranking",
                link: "/tipset/address-list/"
            },
            {
                key: "statistics_gas",
                link: "/statistics/gas"
            },
            {
                key: "statistics_charts",
                link: "/statistics/charts"
            }
        ]
    }
];



/***/ }),

/***/ 2324:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const account = {
    date: "Date",
    confirm: "Confirm",
    cancel: "Cancel",
    go_home: "Back to Homepage",
    go_login: "Login",
    back: "Back",
    account_title: "Miner Metrics",
    overview: "Overview",
    miners: "Miners",
    personal: "Personal",
    logout: "Logout",
    default_group: "Default Group",
    welcome: "Welcome to Filscan!",
    welcome_text1: "Congratulations! Your account has been successfully registered! Please login with your email and password.",
    welcome_text2: "Please login and have fun!",
    last_time: "Latest Update Time",
    all: "All",
    edit: "Edit",
    miner_add: "Add Miner",
    //个人账户 Personal
    register_success: "Congratulations! Your account has been successfully registered!",
    register_btn: "Activate",
    //数据概览 Data Overview
    overview_power: "Power Overview",
    overview_gas: "Gas",
    overview_expired: "Sector Status",
    overview_reward: "Reward",
    overview_lucky: "Lucky",
    overview_balance: "Balance Overview",
    no_node_data: "No Node",
    miners_add: "Add Miner",
    group_add: "Add Group",
    miners_group_manage: "Manage Miners Group",
    total_out_come_gas: "Total Cost/Gas Cost",
    pledge_amount_24: "FIL Pledged/24H Changes",
    balance_24: "Balance/24H Changes",
    quality_power_24: "Quality Power/24H Changes",
    //节点管理 Miner Manager
    delete_group: "Delete Group",
    delete_record_group: "Confirm？",
    delete_group_text: "This group will no longer be displayed in the list after deletion!",
    delete_miner: "Delete Miner",
    delete_record_miner: "Are you sure you want to delete the miner?",
    delete_miner_text: "This miner will no longer be displayed in the group",
    //添加节点 Add Miner
    custom_tag: "Custom Tag",
    miner_add_placeholder: "Please enter the Miner account ID ",
    miner_select_group_placeholder: 'Please select a group(if no group is selected, the added miner will be placed in the" Default Group")',
    //分组
    create_group: "Create Group",
    create_group_holder: "Please enter name of the group you want to create.",
    item_value: "{{value}} miner in this group",
    group_name: "Group Name",
    //幸运值 Lucky
    "all": "All",
    "24h_lucky": "24H Lucky    ",
    "7d_lucky": "7D Lucky",
    "30d_lucky": "30D Lucky",
    "1year_lucky": "1 Year Lucky",
    tag: "Tag",
    miner_id: "Miner ID",
    //地址余额 Address Balance
    miner_balance: "Miner Balance",
    owner_balance: "Owner Balance",
    worker_balance: "Worker Balance",
    controller_0_balance: "Controller0 Balance",
    controller_1_balance: "Controller1 Balance",
    controller_2_balance: "Controller2 Balance",
    beneficiary_balance: "Beneficiary Balance",
    market_balance: "Market Balance",
    //奖励 Reward
    block_count: "Block Count",
    win_count: "Win Count",
    block_reward: "Block Reward",
    total_reward: "Total Reward",
    total_reward_24: "Total Reward/24H Reward",
    //算力概览 Power Overview
    quality_power: "Quality Power",
    dc_power: "DC Power",
    raw_power: "Raw Power",
    cc_power: "CC Power",
    sector_size: "Sector Size",
    sector_power_change: "Sector Change",
    sector_power_count: "Sector Count",
    sector_count_change: "Sector Count Change",
    pledge_changed: "Pledge Change",
    pledge_changed_per_t: "Pledge Change/T",
    penalty: "Penalty",
    fault_sectors: "Fault Sectors",
    sector_power_change_tip: "Sector Count/RawBytePower  The sum of additions and terminations",
    pledge_changed_tip: "Sector Count The sum of changes in pledge for additions and terminations",
    pledge_changed_per_t_tip: "Pledge change devided by sector change.",
    penalty_tip: "The amount of FIL subjected to Penalty",
    fault_sectors_tip: "The number of newly added faulty sectors/RawBytePower.",
    total_gas_cost_tip: "The total sum of gas consumption for all types.",
    seal_gas_cost_tip: "The total sum of gas cost for sector sealing(PreCommitSector+ProveCommitSector+PreCommitSectorBatch+ProveCommitAggregate+PreCommit Net Fee+ProveCommit Net Fee)",
    seal_gas_per_t_tip: "Gas consumption per newly sealed sector (TiB)",
    deal_gas_cost_tip: "DC consumption of PublishStorageDeals",
    wd_post_gas_cost_tip: "Consumption of SubmitWindowedPoSt",
    wd_post_gas_per_t_tip: "SubmitWindowedPoSt cost devided by RawBytePower(TiB)",
    //gas
    total_gas_cost: "Total Gas Cost",
    seal_gas_cost: "Seal Gas Cost",
    seal_gas_per_t: "Seal Gas Cost/T",
    deal_gas_cost: "Deal Gas Cost",
    wd_post_gas_cost: "Wd Post Gas Cost",
    wd_post_gas_per_t: "Wd Post Gas Cost/T",
    //到期扇区 Exp. Sector
    exp_month: "Expires in {{value}} year {{value}} month",
    exp_time: "Exp. Time",
    miner_count: "Miner Count",
    exp_power: "Exp. Power",
    sector_count: "Exp. Sector Count",
    exp_dc: "Exp.DC",
    exp_pledge: "Exp. Pledge",
    //个人中心 Personal Center
    default_user: "Regular User",
    last_login: "Last Login",
    personal_setting: "Account Setting",
    personal_name: "Account Name",
    old_placeholder: "Please enter old password",
    old_password: "Old Password",
    new_password: "New Password",
    new_placeholder: "Please enter new password",
    confirm_password: "Confirm",
    confirm_placeholder: "Please enter new password again",
    personal_name_holder: "Please enter your account name"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (account);


/***/ }),

/***/ 2329:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const common = {
    zh: "中",
    en: "En",
    kr: "Kr",
    login: "Login",
    cancel: "Cancel",
    confirm: "Confirm",
    open: "Unfold",
    no_open: "fold",
    lang: "中",
    fil: "FIL",
    last_time: "Latest Block",
    base_fee: "Base Fee",
    last_height: "Block Height",
    go_home: "Back to Homepage",
    go_login: "Go Login",
    //search
    "search_holder": "Please enter address/message ID/height/block CID/miner ID/FNS",
    all: "All",
    address: "Address",
    message_id: "Message ID",
    height: "Height",
    cid: "Block CID",
    node: "Node",
    //messages
    no_account: "This email is not registered. Please register first.",
    //登录注册
    register: "Email Registration",
    password_login: "Passward Login",
    verification_code: "Login with Verification Code",
    email_placeholder: "Enter Email Address",
    password_placeholder: "Enter Passward",
    code_placeholder: "Enter Verification Code",
    remember_me: "Remember me and login automatically",
    forgot_password: "Forgot Passward",
    get_code: "Get Verification Code",
    retry_code: "Resend Code",
    no_account: "No Account?",
    have_account: "Have account already?",
    go_register: "Register now",
    new_password: "Passward Setting",
    confirm_password: "Confirm Passward",
    agreement: 'Registration implies acceptance of the "Agreement" and "Privacy Policy"',
    //校验
    email_required: "Please enter your email",
    email_rules: "Invalid email format, please modify",
    code_rules: "Please enter the 6-digi verification code correctly",
    password_rules: "请输入 8-20 个字符，需同时包含数字、字母以及特殊符号,密码不能与您的邮箱地址相同",
    confirm_password_rules: "The passwards entered do not match. Please re-enter them",
    email_exists: "Email exists",
    Export: "Download Excel",
    //footer
    "footer_des1": "Filscan.io is a Filecoin blockchain explorer and data service platform.",
    "footer_des2": "It offers a range of one-stop data services, including mining ranking, blockchain data query, visualization charts, and FVM ecosystem data analysis."
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (common);


/***/ }),

/***/ 7889:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const contract = {
    overview: "Overview",
    market: "Market",
    look_adres: "View Account",
    gohome: "Go Home",
    reset_ver: "Revalidate",
    next: "Continue",
    reset: "Reset",
    confirm: "Verify&Publish",
    back: "Return to Main",
    file_name: "SELECT *.SOL FILES",
    file_name_json: "SELECT *.JSON FILES",
    config_file_name: "SELECT Metadata FILES",
    config_file_des1: "> When do I need to upload a metadata file?",
    config_file_des1_1: "1. The metadata file contains various compiler settings. If you have used advanced optimization parameters or compiled your code with a compilation configuration file (e.g. compiler_config.json in Remix), you will be required to upload the metadata file for verification.",
    config_file_des1_2: "2. The hierarchical directory of imports in the contract is in the initial format (e.g. import '@openzeppelin/contracts/access/Ownable.sol') and is the same as the path under 'sources' in the metadata file. You don't need to upload the metadata file (if the hierarchical directory of import in the contract is point to the current folder)",
    config_file_des2: "> How can I obtain the metadata file?",
    config_file_des2_1: "1. By using the Solidity Compiler (solc):  solc --metadata Contract.sol -o metadata.json",
    config_file_des2_2: "2. Download it using Remix IDE: There is a download button for metadata.json after deployed on the Remix website.",
    verify_title: "Verify & Publish Contract Source Code",
    verify_des: "COMPILER TYPE AND VERSION SELECTION",
    verify_content: `Source code verification provides transparency for users interacting with smart contracts. By uploading the source code, Filscan will match the compiled code with that on the blockchain. Just like contracts, a "smart contract" should provide end users with more information on what they are "digitally signing" for and give users an opportunity to audit the code to independently verify that it actually does what it is supposed to do.`,
    content_des: `Source code verification provides transparency for users interacting with smart contracts. By uploading the source code, Filscan will match the compiled code with that on the blockchain. Just like contracts, a "smart contract" should provide end users with more information on what they are "digitally signing" for and give users an opportunity to audit the code to independently verify that it actually does what it is supposed to do. Contract verification can be performed quickly by uploading the JSON file in the "artifacts/build-info/" directory.
Hardhat stores the compilation outputs in the "artifacts/build-info/" directory within the project. The directory includes a .json file that contains the Standard JSON Input-Output for all contracts, which is the recommended approach for interacting with the Solidity compiler, especially in advanced and automated configurations. This JSON-input-output interface is uniformly supported across all compiler distributions.`,
    address: "Please Enter Contract Address to Verify",
    address_placeholder: "Please enter the Contract Address",
    verify_model: "Compiler Type",
    verify_model_placeholder: "Please select Compiler Type",
    verify_address: "Please Enter Complier Version to Verify",
    verify_address_placeholder: "Please select",
    license_type: "Please select Open Source License Type",
    content_des1: "1. If the contract compiles correctly at REMIX, it should also compile correctly here.",
    content_des2: "2. We have limited support for verifying contracts created by another contract and there is a timeout of up to 45 seconds for each contract compiled.",
    content_des3: "3. For programatic contract verification, check out the Contract API Endpoint.",
    checkbox_service: "I agree to the terms of service",
    verify_select_placeholder: "Please select",
    //logs
    ver_sucess: "Success",
    ver_err: "Error",
    has_been_verified: "Error:Has Been Verified",
    byte_code: "Compilation log",
    contract_name: " Contract Name ",
    local_byte_code: "Contract Bytecode",
    compiler: "Complier Verison",
    //step1
    address_verify: "Contract Address",
    step1_verify_des: "SELECT ONE OR MORE *.SOL FILES",
    source_code: "Contract Source Code",
    compile_version: "Complier",
    compile_output: "Complier Output",
    Optimizations: "Optimizations",
    run_optimizer: "Runs(Optimizer)",
    arguments: "Constructor Argument",
    optimize: "Optimization Enabled",
    //token list
    token_list: "All Tokens",
    token_name: "Token",
    vol_24: "Trading Volume(24h)",
    transfer_total: "Total Messages of {{value}}",
    owner_total: "From a total of {{value}} Hodlers",
    dex_total: "Total Message of {{value}} Transactions ",
    nfts_total: "Total Nfts of {{value}} Transactions ",
    // 已验证合约
    Verify_code: "Code",
    Verify_read: "Read Contract",
    Verify_write: "Write Contract",
    byte_code_no_verify: "The contract is not verified go to",
    go_to_verify: "verify the contract",
    contract_verify: "Contract verification",
    contract_verify_tips: "Please go to the PC for contract verification",
    //nft list
    nfts_list: "All NFTs",
    trading_volume: "Trading Volume",
    nfts_trans: "NFTs Transfer",
    // ft /fns dashborad
    "total_supply": "Circulating Supply",
    "total_supply_tip": "This data is the standard method return value for the contract ERC20",
    "owners": "Hodlers",
    "transfers": "Total Transfers",
    latest_price: "Price",
    market_value: "Market Cap",
    token_contract: "Token Contract",
    transfer: "Transfers",
    owner: "Hodlers",
    domain: "Contract",
    dex: "Dex Trades",
    //list
    message_cid: "Message ID",
    method: "Method",
    time: "Time",
    from: "From",
    to: "To",
    amount: "Amount",
    //拥有者
    rank: "Rank",
    percentage: "Percentage",
    //dex
    platform: "Platform",
    Txn_Value: "Txn Value",
    "swapped_Rate": "Swapped Rate",
    "Token_Amount_in": "Token Amount(In)",
    "Token_Amount_out": "Token Amount(Out)",
    Action: "Action",
    //合约列表
    contract_list: "Verified Contracts",
    contract_address: "Address",
    language: "Language",
    license: "License",
    //合约详情
    contract_list_total: "Total of {{value}} Contracts",
    verify_contract: "Contract Source Code Verified",
    source_code: "Contract Source Code",
    source_code_create: "Contract Creation Code",
    source_abi: "Contract ABI",
    source_abi_default: "Export ABI",
    nfts_list: "NFTs List",
    owner_nft: "Owner",
    item: "Item",
    controller: "Registrant",
    //rank
    contract_rank_des: "Latest Update on:{{value}}",
    contract_rank_total: "Total of {{value}} Contracts",
    contract_rank: "Contract Rank",
    actor_id: "actorID",
    actor_address: "actorAddress",
    transaction_count: "TransCount",
    user_count: "TransAddress",
    actor_balance: "Balance",
    gas_cost: "Gas Cost",
    ver_address: "Pending Verification",
    see_more: "See More",
    //log
    epoch: "Height",
    cid: "CID",
    event_name: "Method",
    topics: "Topics",
    coompoent_data: "Params",
    log_index: "Index",
    removed: "Removed"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (contract);


/***/ }),

/***/ 9451:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// pool-detail
const detail = {
    "24h": "24H",
    "7d": "7D",
    "30d": "30D",
    "1year": "1Y",
    "all": "All Methods",
    //owner
    "owner_title": "Pool Detail",
    "owner_title_tip": "The data of mine pool is collected from the data of nodes.",
    account: "Account",
    account_title: "Account",
    owner_address: "Owner Address",
    owned_miners: "Nodes",
    account_id: "Account Address",
    look_all: "View All Data",
    transfer_records: "Transfer records",
    //account_type
    miner: "Miner",
    evm: "EVM",
    ethaddress: "ETHAddress",
    ethaccount: "ETHAccount",
    account_name: "Account",
    latest_transfer_time: "Latest Transaction",
    multisig: "MultiSign Account",
    from_ath: "From",
    to_ath: "To",
    //概览
    owner_overview_title: "Pool Overview",
    balance: "Total Balance",
    available_balance: "Available",
    init_pledge: "Initial Pledge",
    pre_deposits: "PreCommitDeposits",
    locked_balance: "Locked Rewards",
    balance_tip: "Total Balance=Available+InitialPledge+PreCommitDeposits+Locked Rewards",
    available_balance_tip: "Available spendable amount in the account excluding initial pledge and locked rewards",
    init_pledge_tip: "The actual amount pledged after the successful completion of the second phase of Proof of Replication",
    pre_deposits_tip: "The PreCommit Deposits amount during the first phase of Proof of Replication will be adjusted based on the actual pledged amount per sector after successfully submitting the proof within the specified time during the second phase; otherwise, if the proof is not submitted within the given timeframe, a penalty will be imposed",
    locked_balance_tip: "The unreleased portion of block rewards will be linearly released over time",
    sector_count: "Total",
    live_sector_count: "Active",
    fault_sector_count: "Faults",
    recover_sector_count: "Recoveries",
    eth_address: "ETH Address",
    eth_message: "ETH Hash",
    stable_address: "Stable Address",
    showContract: "Contract: {{value}}",
    showAddress: "Address: {{value}}",
    account_detail: "Account Detail",
    contract_name: "Contract Name",
    //统计指标
    indicators: "Statistical Indicator",
    power_increase_indicators: "Power Increase",
    power_ratio: "Power Growth Rate",
    sector_increase: "Sector Increase",
    precommit_deposits: "PreCommitDeposits Increase",
    gas_fee: "Gas Fee",
    block_rewards: "Block Rewards",
    block_count: "Block",
    block_count_tip: "Block= The sum of the blocks mined",
    mining_efficiency: "Efficiency",
    mining_efficiency_tip: "The ratio of node's cumulative block reward to the adjusted storage power in the selected period.",
    lucky: "Lucky",
    lucky_tip: "The ratio of the actual number of block reward to the expected number of block reward. If the QualityAdjPower is less than 1 PiB, this value has significant randomness and should be taken as a reference only",
    sector_ratio: "Sector Rate",
    win_count: "Winner Rewards",
    win_count_tip: "In Filecoin mining model, there may be multiple blocks under a tipset, and each block may receive multiple win counts.",
    net_profit_per_tb: "Gas Consumption/T",
    net_profit_per_tb_tip: "The gas consumption for sealing a single sector of size T within a selected period",
    //账户变化
    account_change: "Account Change",
    power: "Pool Overview",
    power_increase: "QualityAdjPower Increase",
    quality_adjust_power: "QualityAdjPower",
    quality_power_rank: "Ranking",
    raw_power_percentage: "Power Rate",
    raw_power: "RawBytePower",
    total_block_count: "30D  Blocks",
    total_block_count_tip: "Total Blocks in the past 30 days",
    total_reward: "30D  Reward",
    total_reward_tip: "Total Reward in the past 30 days",
    total_win_count: "30D  Wincount",
    total_win_count_tip: "Total Wincount in the past 30 days",
    total_balance_tip: "Total Balance=Available+Initial Pledge+PreCommitDeposits+Locked Rewards",
    sector_size: "Sector Size",
    sector_status: "Sector Status",
    contract_verify: "Contract",
    //账户总览
    account_overview: "Account Overview",
    create_time: "Create Time",
    account_type: "Type",
    peer_id: "Peer ID",
    account_address: "Address",
    // eslint-disable-next-line no-dupe-keys
    owner_address: "Owner",
    area: "Region",
    worker_address: "Worker",
    controllers_address: "Controller",
    beneficiary_address: "Beneficiary",
    code_cid: "CODE CID",
    nonce: "Nonce Count",
    // message
    message_overview_detail: "Transaction Details",
    trade: "Internal Transaction",
    message_detail: "Overview",
    event_log: "Log",
    message_overview: "Message Overview",
    cid: "Message ID",
    height: "Height",
    time: "Time",
    blk_cids: "Block Cid",
    value: "Value",
    from: "From",
    to: "To",
    status: "Status",
    method_name: "Method",
    message_other: "Others",
    version: "Version",
    // eslint-disable-next-line no-dupe-keys
    nonce: "Nonce",
    gas_fee_cap: "Gas Fee Cap",
    gas_premium: "Gas Premium",
    gas_limit: "Gas Limit",
    gas_used: "Gas Used",
    base_fee: "BaseFee",
    all_gas_fee: "Gas Fee",
    params: "Params",
    returns: "Returns",
    message_tranf: "Transactions",
    from_tranf: "From",
    to_tranf: "To",
    consume_type: "Type",
    MinerTip: "Miner Tip",
    BaseFeeBurn: "BaseFee Burn",
    Transfer: "Transfer",
    Burn: "Burn",
    exit_code: "Status",
    //内部交易
    amount: "Value",
    method: "Method",
    topic: "Topics",
    //通证转移
    message_ERC20Trans: "Tokens Transferred",
    message_NftTrans: "NFTS Transferred",
    // 出块列表
    block_cid: "Block Cid",
    block_height: "Height",
    block_time: "Time",
    block_messages_count: "Messages",
    block_miner_id: "Storage Provider",
    block_mined_reward: "Rewards",
    //miner
    message_list: "Message",
    block_list: "Block",
    traces_list: "Transaction",
    message_list_total: "Total of {{value}} Messages",
    block_list_total: "Total of  {{value}} Blocks",
    traces_list_total: "Total of {{value}} Messages",
    erc20_transfer_total: "Total of {{value}} Transactions",
    // contract_token_list_total: 'Total of {{value}} Token',
    //general
    general_overview_title: "Account",
    base_account_id: "ID",
    tokenList: "Token Holdings",
    //dns detail
    deal_details: "dsn Detail",
    deal_id: "Dsn ID",
    epoch: "Block",
    service_start_time: "Create Time",
    message_cid: "Message",
    piece_cid: "Piece CID",
    verified_deal: "Verified",
    deal_hosting: "Storage Detail",
    deal_left_title: "Client",
    deal_right_title: "Provider",
    deal_value: "Provider",
    deal_cash: "Storage Cost",
    deal_time: "to",
    user_count: "User Count",
    transfer_count: "Transfer Count",
    go_verify: "To Verify",
    //Token
    contract_token_list: "Field",
    token_name: "Token Name",
    contract_id: "Contract Id",
    amount: "Amount",
    //erc20 transfer
    erc20_transfer: "Token Transactions",
    platform: "Platform",
    power_change: "Power Change",
    owned_active_miners: "实际工作节点",
    //height
    blcok_time: "Block Time",
    message_count_deduplicate: "Block Message (Deduplication) ",
    miner_id: "Miner",
    messages_count: "Message",
    reward: "Reward",
    //cid detail
    block_list: "Block List",
    blocks_cid: "Cid",
    blocks_miner: "Miner",
    blocks_messages: "Message",
    blocks_reward: "Reward",
    win_count: "WinCount",
    blk_cids_message: "Block Message",
    //cid_details
    message_list_total: "Total of {{value}} messages",
    chain_cid_detail: "Block Details",
    cid_height: "Height",
    parent_weight: "Parent Weight",
    parents_cid: "Parent CID",
    parent_base_fee: "Parent Basefee",
    ticket_value: "Ticket",
    state_root: "State Root",
    message_count: "Message Count"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (detail);


/***/ }),

/***/ 8210:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const domain = {
    domain_title: "Overview",
    resolved_address: "Resolved Address",
    expired_at: "Expiration Date",
    registrant: "Registrant",
    controller: "Controller",
    Result_for: "Result for",
    allDomains: "All Domains"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (domain);


/***/ }),

/***/ 8819:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const fevm = {
    tp_token: "Add Token To TokenPocket",
    rank: "Rank",
    defi_overview: "DeFi Protocol",
    fevm_staked: "FEVM Staked",
    staked_change_in_24h: "24h Staked",
    total_user: "Total Users",
    user_change_in_24h: "24h Users",
    fil_staked: "FIL Staked",
    defi_list: "DeFi Protocol",
    Protocol: "Protocol",
    defi_list_time: "Latest Update on: {{value}}",
    tvl: "TVL",
    tvl_change_rate_in_24h: "24h Staked Change",
    tvl_change_in_24h: "24h Staked",
    tokens: "Top Tokens",
    tokens_tip: "Percentage of different tokens staked in this protocol",
    users: "Users"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (fevm);


/***/ }),

/***/ 1475:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const fvm = {
    hot: "Explore FVM on FIlscan",
    all: "Filecoin Ecosystem",
    Defi: "Defi",
    Dex: "Dex",
    DID: "DID",
    NFT: "NFT",
    MarketPlace: "MarketPlace",
    Launchpad: "Launchpad",
    see_more: "See More"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (fvm);


/***/ }),

/***/ 5128:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const home = {
    seconds: "s",
    minutes: "m",
    hours: "h",
    day: "D",
    meta_title: "The Filecoin Network Data Index",
    mata_show: "Unfold",
    mata_show_false: "Fold",
    latest_height: "Block Height",
    latest_block_time: "Latest Block",
    total_blocks: "Total Block",
    total_rewards: "Total Block Rewards",
    total_quality_power: "Network QualityAdjPower",
    total_quality_power_tip: "Total current effective computing power (effective storage space) of the Filecoin network",
    base_fee: "Base Fee",
    miner_initial_pledge: "Current Sector Initial Pledge",
    power_increase_24h: "Latest 24h Power Growth",
    rewards_increase_24h: "Block Rewards in 24h",
    fil_per_tera_24h: "Output Efficiency in 24h",
    fil_per_tera_24h_tip: "The average\xa0reward output\xa0for each TiB of storage capacity over the last 24 hours",
    gas_in_32g: "24H Gas Cost for Sealing 32GiB sectors/TiB",
    gas_in_32g_meta: "Gas Used of a 32GiB Sector",
    gas_in_32g_tip: "Gas used of Sealing a 32GiB Sector in the last 24 hours",
    add_power_in_32g: "Est. Cost of a 32GiB Sector",
    add_power_in_32g_tip: "The cost of sealing a 32GiB sector in the past 24 hours, including the sector’s initial pledge and message fee",
    gas_in_64g: "24H Gas Cost for Sealing 64GiB sectors/TiB",
    gas_in_64g_meta: "Gas Used of a 64GiB Sector",
    gas_in_64g_tip: "Gas used of sealing a 64GiB sector in the last 24 hours",
    add_power_in_64g: "Est. Cost of a 64GiB Sector",
    add_power_in_64g_tip: "The cost of sealing a 64GiB sector in the past 24 hours, including the sector’s initial pledge and message fee",
    win_count_reward: "Rewards per Wincount",
    win_count_reward_tip: "",
    avg_block_count: "Avg. Blocks per TipSet",
    avg_block_count_tip: "Average blocks produced per tipSet in 24h",
    avg_message_count: "Avg. Messages per TipSet",
    avg_message_count_tip: "Average messages packaged per tipSet in 24h",
    active_miners: "Active Nodes",
    burnt: "Burnt",
    circulating_percent: "Circulation Amount",
    rank: "Ranking List",
    footer_text: "Filscan browser is the filecoin blockchain browser and data service platform.It provides one-stop data services such as mining ranking, blockchain data query and visualization chart based on filecoin.",
    footer_outlook: "Email",
    footer_detail_a: "Copyright \xa9 Filecoin-Project devgrants. Distributed under the ",
    footer_detail_b: " and ",
    footer_detail_c: "license",
    search_notFound: "Search Not Found",
    warn_text: "Oops! The search string you enterd was:",
    warn_details: "Sorry! This is an invalid search string",
    go_home: "Back Home",
    base_gas: "24h BaseFee",
    rank: "Rank",
    blockchain_browser: "blockchain browser",
    "quality_power/increase_24h": "Net QualityAdjPower/in 24h",
    total_contract: "Active Contract",
    "total_contract/24h_contract": "Active Contract/in 24h",
    "total_contract_24h_contract": "Active Contract in 24h",
    verified_contracts: "Verified Contracts",
    contract_transaction: "ContTransCount",
    "contract_transaction/24h_change": "ContTransCount/in 24h",
    "contract_transaction_24h_change": "ContTransCount in 24h",
    "contract_address/24h_change": "ContTransAddr/in 24h",
    "contract_address_24h_change": "ContTransAddr in 24h",
    "contract_address": "ContTransAddr",
    "total_contract/24h_contract_tip": "Total number of contracts that have had transactions in the network",
    gas_24: "24h Gas Cost",
    verified_contracts: "Verified Contracts",
    contract_gas: "Contract Gas Cost",
    quality_power_Cc: "Commited Capacity (CC)",
    quality_power_Dc: "DataCap (DC)"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (home);


/***/ }),

/***/ 4995:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const en = {
    network_title: "Current Network",
    home: "Home",
    contract: "FEVM",
    contract_verify: "Contract Verification",
    token: "Tokens",
    nft: "NFTs",
    contract_list: "Verified Contracts",
    contract_rank: "Contract Rank",
    defi_dashboard: "DeFi Protocol",
    tipset: "BlockChain",
    tipset_chain: "Tipsets",
    tipset_message: "Messages",
    tipset_ranking: "Wealth Ranking",
    tipset_transfer: "Large Amount Transfer",
    tipset_dsn: "Dsn",
    "tipset_pool-message": "Pool Messages",
    ranking: "Ranking",
    statistics: "Statistics",
    statistics_gas: "Gas Fee",
    statistics_base: "Power",
    statistics_fil: "FIL",
    statistics_charts: "Statistics",
    statistics_map: "Charts",
    resources: "Resources",
    resources_tools: "Tools",
    provider: "Storage Provider",
    fvm: "Filecoin Ecosystem",
    account: "Miner Metrics",
    network_overview: "Network Overview",
    develop: "Developer"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (en);


/***/ }),

/***/ 6735:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const rankZh = {
    rank: "Rank",
    rank_title: "Ranking",
    pool: "Storage Pool",
    provider: "Storage Provider",
    growth: "Power Growth Rate",
    rewards: "Rewards",
    "24h": "24H",
    week_days: "7D",
    month: "30D",
    select_rank_all: "All",
    select_rank_32: "32GiB",
    select_rank_64: "64GiB",
    more: "More",
    rank_time: "Latest Update on",
    see_more: "See More",
    // table columns title
    //存储池排行
    ranking: "Rank",
    pool_owner: "Owner ID",
    pool_power: "QualityAdjPower",
    pool_efficiency_24h: "Latest 24h Output Efficiency",
    pool_increase_24h: "24H Power Growth",
    pool_block_count: "Blocks Mined",
    miner: "Miner",
    pool_block_count_24h: "24h Total Block Rewards",
    // 节点排行
    provider_miner: "Storage Provider",
    provider_power_ratio: "QualityAdjPower / Rate",
    provider_block_ratio: "24H Blocks / Rate ",
    provider_rewards_ratio: "24H Wincount Rate",
    balance: "Balance",
    //算力增速
    power_ratio: "Power Growth",
    power_ratio_tip: "Daily total adj. power of the sealed sectors within selected period.",
    quality_power_increase: "Power Growth",
    quality_power_increase_tip: "Node's adjusted storage power increment in the selected period.",
    quality_adj_power: "QualityAdjPower",
    raw_power: "RawBytePower",
    sector_size: "Sector Size",
    //节点收益
    "rewards/ratio": "Rewards/Ratio",
    "rewards/ratio_tip": "The ratio of node's cumulative block reward to the adjusted storage power in the selected period.",
    block_count: "Blocks",
    block_count_tip: "In Filecoin CryptoEconomics, there may be multiple blocks under a tipset, and each block may receive multiple win counts.",
    winning_rate: "Wincount Rate"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (rankZh);


/***/ }),

/***/ 8827:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const statistic = {
    gas_total: "Gas",
    show_more: "More",
    "24h": "24H",
    "7d": "7D",
    "30d": "30D",
    year: "1Y",
    // power
    "power": "Storage Power Trend",
    power_tips: "The network baseline is the scale of network growth required by the Filecoin Network, which was 2.5 EiB when the Mainnet launched, with a growth rate of 100% per year",
    trend_24: "24h Base Fee Variations",
    total_raw_byte_power: "Net RawBytePower",
    base_line_power: "BaseLine",
    power_increase: "Net Power Increase",
    power_decrease: "Net Power Decrease",
    total_quality_adj_power: "QualityAdjPower",
    change_quality_adj_power: "QualityAdjPower Fluctuations",
    gas: "Base Fee Variations",
    base_fee: "Base Fee",
    gas_in_32g: "Gas Cost of Sealing a 32GiB Sector",
    gas_in_64g: "Gas Cost of Sealing a  64GiB Sector",
    //24_gas
    gas_24: "24h Gas Data",
    method_name: "Message Type",
    avg_gas_premium: "Gas Premium",
    avg_gas_limit: "Avg. Gas Limit",
    avg_gas_used: "Avg.Gas Cost",
    avg_gas_fee: "Avg. Gas Fee",
    "sum_gas_fee/ratio": "Total Fees/Percentage",
    "message_count/ratio": "Total Messages/Percentage",
    //fil
    TokenRules: "FIL Allocation",
    FilecoinFoundation: "Filecoin Foundation",
    FundraisingRemainder: "Fundraising-Remainder",
    FundraisingSAFT: "Fundraising-SAFT",
    MiningReserve: "Mining Reserve",
    TokenAllocation: "Storage Mining Allocation",
    ReservedTokens: "Mining Reserve",
    Fundraising: "Fundraising - SAFT 2017",
    Funds: "Fundraising - Remainder",
    protocolLab: "Protocol Labs",
    Contributors: "PL Team &amp; Contributors",
    Allocation: "Allocation",
    value: "Value",
    description: "Description",
    filBase: "FIL BASE",
    filBase_des: "The maximum amount of FIL that will ever be created.",
    ReservedTokens_des: "Tokens reserved for funding mining to support growth of the Filecoin Economy, whose future usage will bedecided by the Filecoin community.",
    TokenAllocation_des: "The amount of FIL allocated tostorage nodes through block rewards, network initialization, etc.",
    Fundraising_des: "2017 TOKEN SALE",
    FilecoinFoundation_des: "Allocated towards long-term community development and the management of the network.",
    Funds_des: "Allocated for ecosystem development, future fundraising",
    protocolLab_des: "Allocated for Protocol Labs",
    Contributors_des: "4.5% for the PL team & contributors",
    //charts
    pie_title: "Chart Statistics",
    block_trend: "Block Rewards",
    block_reward_per_TiB: "Output Efficiency",
    active_nodes: "Active Storage Providers",
    active_miner_count: "Node Counts",
    messages_trend: "Message Trend",
    message_count: "Message Trend of Each Block",
    all_message_count: "Messages Variation per Block",
    all_message_count_tip: "Messages Included per Block",
    acc_block_rewards: "Cumulative Block Rewards",
    pie_title_a: "Current statistics on the distribution of FIL usage",
    pie_title_a_tip: "Total FIL Rewarded + Locked Rewards Released + Reserved FIL Allocated = Currently Released Fil",
    pie_title_b: "Released FIL Usage Statistics",
    mined: "Total FIL Rewarded",
    remaining_mined: "Total FIL to Reward",
    vested: "Locked Rewards Released",
    remaining_vested: "Locked Rewards to Release",
    reserve_disbursed: "Reserved FIL Allocated(Testnet Rewards)",
    remaining_reserved: "Reserved FIL to Allocate",
    locked: "Total Sector Pledge",
    burnt: "Total FIL Burned",
    circulating: "Circulating Supply",
    //chartsnav
    cc_dc_power: "CC/DC PowerTrend",
    static_overview: "Statistics",
    contract_trend: "Contract Transaction",
    fil_overview: "FIL Overview",
    charts_title: "FIL Allocation Guidelines",
    networks_overview: "Network Overview"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (statistic);


/***/ }),

/***/ 7545:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const tipset = {
    rank: "Rank",
    tag: "Tag",
    height: "Height",
    cid: "Message ID",
    block_time: "Time",
    from: "From",
    to: "To",
    value: "Value",
    method_name: "Method",
    "all": "All Methods",
    //chain
    blocks_cid: "Cid",
    blocks_miner: "Storage Provider",
    blocks_messages: "Message",
    blocks_reward: "Reward",
    win_count: "WinCount",
    //cid_details
    message_list_total: "Latest {{value}} Messages",
    chain_cid_detail: "Block details",
    cid_height: "Height",
    parent_weight: "Parent Weight",
    parents_cid: "Parent CID",
    parent_base_fee: "Parent BaseFee",
    ticket_value: "Ticket",
    state_root: "State Root",
    //message
    message_list: "Message List",
    total_list: "Latest {{value}} Messages",
    message_list_all: "All Methods",
    message_list_exit_code: "Status",
    // adress
    address_all: "All Types",
    address_total_list: "Total of {{value}} Accounts",
    account: "account",
    owner: "owner",
    miner: "node",
    payment: "payment",
    multisig: "multisig",
    address_list: "Wealth Ranking",
    account_address: "Address",
    balance_percentage: "Balance/Percentage",
    account_type: "Status",
    latest_transfer_time: "Last Seen Time",
    //transfer
    transfer_list: "Large Amount Transfer",
    transfer_total_list: "Total of {{value}} Message",
    //dsn
    dsn_list: "Order List",
    dsn_total_list: "Total of {{value}} Deals",
    dsn_placeholder: "Search Client/Provider/Deal ID",
    deal_id: "Deal ID",
    piece_cid: "Piece CID",
    piece_size: "PieceSize",
    client_address: "Client",
    provider_id: "Provider",
    service_start_time: "Start Time",
    end_time: "End Time",
    start_height: "Start Height",
    end_height: "End Height",
    storage_price_per_height: "Storage Fee",
    verified_deal: "Verified Deal",
    // pool-message
    pool_list: "Message Pool List",
    gas_fee_cap: "Gas Limit",
    gas_premium: "Gas Premium",
    block_list: "Tipsets List"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (tipset);


/***/ }),

/***/ 1091:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2021);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7987);
/* harmony import */ var _en_nav_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4995);
/* harmony import */ var _zh_nav_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3124);
/* harmony import */ var _kr_nav_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7997);
/* harmony import */ var _zh_home_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3075);
/* harmony import */ var _en_home_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5128);
/* harmony import */ var _kr_home_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3115);
/* harmony import */ var _zh_statistic_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9806);
/* harmony import */ var _en_statistic_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8827);
/* harmony import */ var _kr_statistic_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4547);
/* harmony import */ var _zh_rank_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3074);
/* harmony import */ var _en_rank_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6735);
/* harmony import */ var _kr_rank_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(596);
/* harmony import */ var _zh_tipset_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(3061);
/* harmony import */ var _en_tipset__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(7545);
/* harmony import */ var _kr_tipset_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(9465);
/* harmony import */ var _zh_detail__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(9893);
/* harmony import */ var _en_detail__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(9451);
/* harmony import */ var _kr_detail__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(3341);
/* harmony import */ var _zh_fvm_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(8826);
/* harmony import */ var _en_fvm__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(1475);
/* harmony import */ var _kr_fvm__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(8589);
/* harmony import */ var _zh_contract_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(77);
/* harmony import */ var _en_contract_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(7889);
/* harmony import */ var _kr_contract_js__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(4276);
/* harmony import */ var _zh_domain_js__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(9577);
/* harmony import */ var _en_domain_js__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(8210);
/* harmony import */ var _kr_domain_js__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(9720);
/* harmony import */ var _zh_fevm_js__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(2000);
/* harmony import */ var _en_fevm_js__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(8819);
/* harmony import */ var _kr_fevm_js__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(9429);
/* harmony import */ var _zh_common_js__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(1818);
/* harmony import */ var _en_common_js__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(2329);
/* harmony import */ var _kr_common_js__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(5387);
/* harmony import */ var _zh_account_js__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(9547);
/* harmony import */ var _en_account_js__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(2324);
/* harmony import */ var _kr_account_js__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(2345);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([i18next__WEBPACK_IMPORTED_MODULE_0__, react_i18next__WEBPACK_IMPORTED_MODULE_1__]);
([i18next__WEBPACK_IMPORTED_MODULE_0__, react_i18next__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






































i18next__WEBPACK_IMPORTED_MODULE_0__["default"].use(react_i18next__WEBPACK_IMPORTED_MODULE_1__.initReactI18next).init({
    resources: {
        en: {
            common: _en_common_js__WEBPACK_IMPORTED_MODULE_33__/* ["default"] */ .Z,
            account: _en_account_js__WEBPACK_IMPORTED_MODULE_36__/* ["default"] */ .Z,
            nav: _en_nav_js__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
            home: _en_home_js__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z,
            static: _en_statistic_js__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z,
            rank: _en_rank_js__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z,
            tipset: _en_tipset__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z,
            detail: _en_detail__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z,
            fvm: _en_fvm__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z,
            contract: _en_contract_js__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .Z,
            domain: _en_domain_js__WEBPACK_IMPORTED_MODULE_27__/* ["default"] */ .Z,
            fevm: _en_fevm_js__WEBPACK_IMPORTED_MODULE_30__/* ["default"] */ .Z
        },
        kr: {
            common: _kr_common_js__WEBPACK_IMPORTED_MODULE_34__/* ["default"] */ .Z,
            account: _kr_account_js__WEBPACK_IMPORTED_MODULE_37__/* ["default"] */ .Z,
            nav: _kr_nav_js__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z,
            home: _kr_home_js__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z,
            static: _kr_statistic_js__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z,
            rank: _kr_rank_js__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z,
            tipset: _kr_tipset_js__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z,
            detail: _kr_detail__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z,
            fvm: _kr_fvm__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z,
            contract: _kr_contract_js__WEBPACK_IMPORTED_MODULE_25__/* ["default"] */ .Z,
            domain: _kr_domain_js__WEBPACK_IMPORTED_MODULE_28__/* ["default"] */ .Z,
            fevm: _kr_fevm_js__WEBPACK_IMPORTED_MODULE_31__/* ["default"] */ .Z
        },
        zh: {
            common: _zh_common_js__WEBPACK_IMPORTED_MODULE_32__/* ["default"] */ .Z,
            account: _zh_account_js__WEBPACK_IMPORTED_MODULE_35__/* ["default"] */ .Z,
            nav: _zh_nav_js__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z,
            home: _zh_home_js__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z,
            static: _zh_statistic_js__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z,
            rank: _zh_rank_js__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z,
            tipset: _zh_tipset_js__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z,
            detail: _zh_detail__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z,
            fvm: _zh_fvm_js__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z,
            contract: _zh_contract_js__WEBPACK_IMPORTED_MODULE_23__/* ["default"] */ .Z,
            domain: _zh_domain_js__WEBPACK_IMPORTED_MODULE_26__/* ["default"] */ .Z,
            fevm: _zh_fevm_js__WEBPACK_IMPORTED_MODULE_29__/* ["default"] */ .Z
        }
    },
    fallbackLng: "zh",
    debug: true,
    react: {
        useSuspense: false
    },
    detection: {
        order: [
            "querystring",
            "navigator",
            "localStorage"
        ],
        lookupQuerystring: "lang"
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (i18next__WEBPACK_IMPORTED_MODULE_0__["default"]);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2345:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const account = {
    date: "날짜",
    confirm: "Confirm",
    cancel: "Cancel",
    go_home: "홈으로",
    go_login: "로그인하다",
    back: "뒤로",
    account_title: "节点管家",
    overview: "데이터 개요",
    miners: "노드 관리",
    personal: "Personal",
    logout: "Logout",
    default_group: "기본 그룹",
    welcome: "Welcome to Filscan!",
    welcome_text1: "축하합니다! 회원 가입이 성공적으로 이루어졌습니다. 이메일 주소와 비밀번호를 사용하여 계속해서 로그인하실 수 있습니다.",
    welcome_text2: "계정에 로그인하세요!",
    last_time: " {{value}}마지막 업데이트",
    all: "전체",
    edit: "편집하다",
    miner_add: "추가하다",
    //个人账户
    register_success: "축하합니다! 회원 가입이 성공적으로 완료되었습니다",
    register_btn: "활성화하다",
    //数据概览
    overview_power: "해시파워 개요",
    overview_gas: "Gas 소비",
    overview_expired: "만기 섹터",
    overview_reward: "블록 보상",
    overview_lucky: "행운값",
    overview_balance: "잔액",
    no_node_data: "노드가 아직 추가되지 않았습니다",
    miners_add: "노드 추가",
    group_add: "그룹 추가",
    miners_group_manage: "그룹 설정",
    total_out_come_gas: "일일 비용/Gas 소비량",
    pledge_amount_24: "플레지/일일 변동",
    balance_24: "사용 가능한 잔액/일일 변동",
    quality_power_24: "파워/일일 변동",
    //节点管理
    delete_group: "그룹 삭제",
    delete_record_group: "그룹을 삭제하시겠습니까?",
    delete_group_text: "삭제 후에는 해당 그룹이 목록에 표시되지 않습니다",
    delete_miner: "마이너 삭제",
    delete_record_miner: "마이너 {{value}}를 삭제하시겠습니까?",
    delete_miner_text: "삭제 후에는 해당 노드가 그룹에 표시되지 않습니다",
    //添加节点
    custom_tag: "Tag",
    miner_add_placeholder: "노드 계정 ID를 입력하세요",
    miner_select_group_placeholder: "그룹 선택 (그룹을 선택하지 않으면 추가한 노드는 '기본 그룹'으로 모두 들어갑니다)",
    //分组
    create_group: "그룹 생성",
    create_group_holder: "생성하려는 그룹의 이름을 입력하세요",
    item_value: "해당 그룹에는 {{value}}명의 miner가 있습니다",
    group_name: "그룹 이름",
    //幸运值
    "all": "전체",
    "24h_lucky": "24H 행운값 ",
    "7d_lucky": "7D 행운값",
    "30d_lucky": "30D 행운값",
    "1year_lucky": "1년",
    tag: "Tag",
    miner_id: "Miner ID",
    //地址余额
    miner_balance: "Miner 잔액/일일 변동",
    owner_balance: "Owner 잔액/일일 변동",
    worker_balance: "Worker 잔액/일일 변동",
    controller_0_balance: "Controller0 잔액/일일 변동",
    controller_1_balance: "Controller1 잔액/일일 변동",
    controller_2_balance: "Controller2 잔액/일일 변동",
    beneficiary_balance: "Beneficiary 잔액/일일 변동",
    market_balance: "Market 잔액/일일 변동",
    //奖励
    block_count: "블록 수",
    win_count: "윈 카운트",
    block_reward: "블록 보상",
    total_reward: "전체 블록 보상",
    total_reward_24: "전체 블록 보상 '总奖励/일일 변동今日变化",
    //算力概览
    quality_power: "유효 체굴 파워",
    dc_power: "DC 파워",
    raw_power: "로우바이트 체굴 파워",
    cc_power: "CC 파워",
    sector_size: "섹터 크기",
    sector_power_change: "팬섹터 변화",
    sector_power_count: "Sector Count",
    sector_count_change: "팬섹터 수량 변화",
    pledge_changed: "플레지 변경",
    pledge_changed_per_t: "플레지 변경/T",
    penalty: "벌칙",
    fault_sectors: "오류",
    sector_power_change_tip: "섹터 수/로우바이트 체굴 파워  추가 및 종료의 합계",
    pledge_changed_tip: " 섹터 수 추가 및 종료에 대한 예치금 변동의 합계",
    pledge_changed_per_t_tip: "예치금 변동을 섹터 변동으로 나눈 값.",
    penalty_tip: "처벌받은 FIL 수량",
    fault_sectors_tip: "신규 추가된 오류 섹터의 수/로우바이트 체굴 파워.",
    total_gas_cost_tip: "모든 유형에 대한 가스 소비의 총합",
    seal_gas_cost_tip: "섹터 봉인을 위한 가스 비용의 총합(PreCommitSector+ProveCommitSector+PreCommitSectorBatch+ProveCommitAggregate+PreCommit Net Fee+ProveCommit Net Fee)",
    seal_gas_per_t_tip: "신규 봉인된 섹터당 가스 소비량 (TiB)",
    deal_gas_cost_tip: "DC PublishStorageDeals 의 소비량",
    wd_post_gas_cost_tip: "SubmitWindowedPoSt의 소비량",
    wd_post_gas_per_t_tip: "SubmitWindowedPoSt 비용을 RawBytePower(TiB)로 나눈 값",
    //gas
    total_gas_cost: "가스 총 소비량",
    seal_gas_cost: "Seal Gas",
    seal_gas_per_t: "Seal Gas/T",
    deal_gas_cost: "PublishStorageDeals Gas",
    wd_post_gas_cost: "WindowedPoSt Gas",
    wd_post_gas_per_t: "WindowedPoSt Gas/T",
    //到期扇区 만기 섹터
    exp_month: "{{year}}年{{month}}月到期",
    exp_time: "만료 시간",
    miner_count: "노드 수",
    exp_power: "만료 파워",
    sector_count: "만기 섹터",
    exp_dc: "만료 DC",
    exp_pledge: "만료 플레지",
    //个人中心
    default_user: "일반 사용자",
    last_login: "최근 로그인 시간",
    personal_setting: "계정 설정",
    personal_name: "계정 이름",
    old_placeholder: "기존 비밀번호를 입력하세요",
    old_password: "기존 비밀번호",
    new_password: "새 비밀번호",
    new_placeholder: "새로운 비밀번호를 입력해주세요",
    confirm_password: "비밀번호를 확인해주세요",
    confirm_placeholder: "새 비밀번호를 다시 입력해주세요",
    personal_name_holder: "계정을 입력해주세요"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (account);


/***/ }),

/***/ 5387:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const common = {
    zh: "中",
    en: "En",
    kr: "Kr",
    login: "로그인",
    cancel: "취소",
    confirm: "확인",
    open: "펼치기",
    no_open: "접기",
    lang: "한국어",
    fil: "FIL",
    last_time: "최신 블록 시간",
    base_fee: "기본 수수료",
    last_height: "최신 블록 높이",
    go_home: "홈으로",
    go_login: "로그인하러 가기",
    //search
    "search_holder": "주소/메시지 ID/높이/블록 CID/노드 ID/FNS를 입력하세요",
    all: "모든 필터 유형",
    address: "주소",
    message_id: "메시지 CID",
    height: "블록 높이",
    cid: "블록 CID",
    node: "노드",
    //messages
    no_account: "해당 이메일은 등록되어 있지 않습니다. 먼저 회원 가입을 진행해 주세요.",
    //登录注册
    register: "이메일 등록",
    password_login: "비밀번호 로그인",
    verification_code: "인증 코드 로그인 ",
    email_placeholder: "이메일 주소를 입력하세요",
    password_placeholder: "비밀번호를 입력하세요",
    code_placeholder: "인증 코드를 입력하세요",
    remember_me: "기억하기 및 자동 로그인",
    forgot_password: "비밀번호를 잊으셨나요",
    get_code: "인증 코드 받기",
    retry_code: "다시 보내기",
    no_account: "아직 계정이 없으신가요?",
    have_account: "이미 계정이 있으신가요?",
    go_register: "지금 회원 가입하기",
    new_password: "비밀번호 설정하기",
    confirm_password: "비밀번호 확인",
    agreement: '회원가입은 "약관"과 "개인정보 처리방침"에 동의하는 것을 의미합니다',
    //校验
    email_required: "이메일을 입력해주세요",
    email_rules: "이메일 형식이 잘못되었습니다. 수정해주세요",
    code_rules: "6자리 숫자 인증 코드를 올바르게 입력해주세요",
    password_rules: "8-20자의 비밀번호를 입력하세요. 숫자, 영문자, 특수문자를 모두 포함해야 하며, 비밀번호는 이메일 주소와 동일하면 안 됩니다",
    confirm_password_rules: "입력한 비밀번호가 일치하지 않습니다. 다시 입력해주세요",
    email_exists: "이미 해당 이메일이 존재합니다",
    Export: "Excel 파일을 다운로드하세요",
    //footer
    "footer_des1": "Filscan 브라우저는 Filecoin 블록체인 브라우저 및 데이터 서비스 플랫폼입니다.",
    "footer_des2": "Filecoin 기반의 수익 랭킹, 블록체인 데이터 조회, 시각화 차트 등의 데이터 서비스를 제공합니다"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (common);


/***/ }),

/***/ 4276:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const contract = {
    overview: "개요",
    market: "마켓",
    look_adres: "주소 확인",
    gohome: "홈으로",
    reset_ver: "재검증",
    next: "다음",
    reset: "리셋",
    confirm: "검증 및 발표",
    back: "뒤로 가기",
    file_name: "*.sol 파일 선택",
    config_file_name: "Metadata 파일 선택",
    file_name_json: "*.json 파일 선택",
    config_file_des1: "> 언제 메타데이터 파일을 업로드 할겁니까?",
    config_file_des1_1: "1. 메타데이터 파일에는 다양한 컴파일러 설정이 포함되어 있습니다. 고급 최적화 매개변수를 사용했거나 컴파일 구성 파일(예: Remix의 compiler_config.json)로 코드를 컴파일한 경우 확인을 위해 메타데이터 파일을 업로드해야 합니다.",
    config_file_des1_2: '2. 계약 안에 있는 import 계층 디렉터리는 초기화 형식(예: import "@openzeppelin/contracts/access/Ownable.sol")이며 메타데이터 파일중 sources 아래의 경로와 동일합니다(계약에 있는 import 계층 디렉터리는 현재 폴더이면 메타데이터 파일을 업로드할 필요가 없음)',
    config_file_des2: "> 메타데이터 파일은 어떻게 얻나요?",
    config_file_des2_1: "1. Solidity 컴파일러(solc)를 사용하여 획득: solc --metadata MainContract.sol -o metadata.json",
    config_file_des2_2: "2. Remix IDE를 사용하여 다운로드: Remix 웹 페이지가 게시된 후 metadata.json에 대한 다운로드 버튼이 있을겁니다.",
    verify_title: "컨트랙트 소스 코드 검증 및 발표",
    verify_des: "컴파일러 유형 및 버전 선택",
    verify_content: `소스 코드 검증은 스마트 컨트랙트와 상호작용하는 사용자에게 투명성을 제공합니다. 소스 코드를 업로드를 통하여 Filscan이 컴파일된 코드를 블록체인 상의 코드와 매칭시킵니다. 계약서 처럼 "스마트 컨트랙트"는 최종 사용자에게 "디지털 서명"의 목적에 대한 더 많은 정보를 제공하고 사용자가 코드를 검토하여 그것이 정말로 해야 할 일을 수행했는지 독립적으로 감증할 수 있도록 합니다.`,
    content_des: `소스 코드 검증은 스마트 컨트랙트와 상호작용하는 사용자에게 투명성을 제공합니다. 소스 코드를 업로드를 통하여 Filscan이 컴파일된 코드를 블록체인 상의 코드와 매칭시킵니다. 계약서 처럼 "스마트 컨트랙트"는 최종 사용자에게 "디지털 서명"의 목적에 대한 더 많은 정보를 제공하고 사용자가 코드를 검토하여 그것이 정말로 해야 할 일을 수행했는지 독립적으로 감증할 수 있도록 합니다."artifacts/build-info/" 디렉터리에 JSON 파일을 업로드하면 계약 검증을 빠르게 수행할 수 있습니다.
Hardhat은 컴파일 출력을 프로젝트 내의 "artifacts/build-info/" 디렉토리에 저장합니다. 디렉터리에는 특히 고급 및 자동화 구성에서 Solidity 컴파일러와 상호 작용하는 데 권장되는 접근 방식인 모든 계약에 대한 표준 JSON 입력-출력이 포함된 .json 파일이 포함되어 있습니다. 이 JSON 입출력 인터페이스는 모든 컴파일러 배포에서 균일하게 지원됩니다.`,
    address: "검증할 컨트랙트 주소를 입력하세요",
    address_placeholder: "컨트랙트 주소를 입력하세요",
    verify_address: "검증할 컴파일러 버전을 선택하세요",
    verify_address_placeholder: "선택하세요",
    verify_model: "편집 유형을 선택하십시오",
    verify_model_placeholder: "편집 유형을 선택하십시오",
    license_type: "오픈 소스 라이선스 유형을 입력하세요",
    content_des1: "1. 만약 컨트랙트가 REMIX에서 올바르게 컴파일 된 경우, 여기에도 올바르게 컴파일될 겁니다.",
    content_des2: "2. 다른 컨트랙트에서 생성된 컨트랙트를 검증하는 서포트는 제한되어있습니다. 각 컨트랙트의 컴파일 제한 시간은 최대 45초입니다.",
    content_des3: "3. 프로그래밍 컨트랙트 검증은 컨트랙트 API 엔드포인트를 확인하세요.",
    checkbox_service: "서비스 약관에 동의합니다",
    verify_select_placeholder: "선택하세요",
    //logs
    ver_sucess: "성공: 검증 완료",
    ver_err: "오류: 검증 실패",
    has_been_verified: "오류: 계약이 이미 검증되었습니다",
    byte_code: "컴파일 로그",
    contract_name: "계약 이름",
    local_byte_code: "컨트랙트 바이트 코드",
    compiler: "컴파일러 버전",
    //step1
    address_verify: "계약 주소",
    step1_verify_des: "*.sol 파일을 선택하세요",
    source_code: "컨트랙트 소스 코드",
    compile_version: "컴파일러",
    compile_output: "컴파일러 출력",
    Optimizations: "최적화 매개변수",
    run_optimizer: "실행（옵티마이저）",
    arguments: "Constructor 매개변수",
    optimize: "최적화 활성화",
    optimize_runs: "RUNS",
    // 已验证合约
    Verify_code: "Code",
    Verify_read: "Read Contract",
    Verify_write: "Write Contract",
    contract_verify: "계약 검증",
    contract_verify_tips: "계약 확인은 PC에서 확인하십시오.",
    //token list
    token_list: "전체 토큰",
    token_name: "토큰",
    vol_24: "24시간 거래량",
    transfer_total: "총 {{value}} 건 메시지",
    owner_total: "총 {{value}}명 보유",
    dex_total: "총 {{value}} 건 거래",
    //nft list
    nfts_list: "전체 NFTs",
    trading_volume: "전체 거래량",
    // ft /fns dashborad
    "total_supply": "유통 공급량",
    "total_supply_tip": "이 데이터는 계약 ERC20에 대한 표준 메서드 반환 값입니다",
    "owners": "보유자",
    "transfers": "총 전송 수",
    latest_price: "최신 가격",
    market_value: "시가",
    token_contract: "토큰 계약",
    transfer: "전송",
    owner: "소유자",
    owner_nft: "오너",
    domain: "계약",
    dex: "DEX 거래",
    //list
    message_cid: "메시지ID",
    method: "메소드",
    time: "시간",
    from: "보내는 주소",
    to: "받는 주소",
    amount: "수량",
    //拥有者
    //소유자
    rank: "순위",
    percentage: "비율",
    //DEX
    platform: "거래소",
    Txn_Value: "Txn 값",
    "swapped_Rate": "교환 비율",
    "Token_Amount_in": "Token 수량(들어옴)",
    "Token_Amount_out": "Token 수량(나감)",
    Action: "액션",
    //계약 목록
    contract_list: "검증된 계약",
    contract_address: "주소",
    language: "언어",
    license: "라이선스",
    //合约详情
    contract_list_total: "총 {{value}}개의 계약",
    byte_code_no_verify: "계약이 검증되지 않았습니다. 이동하러 가기",
    go_to_verify: "계약 검증",
    verify_contract: "계약 소스 코드가 검증되었습니다",
    source_code: "계약 소스 코드",
    source_code_create: "계약 생성 코드",
    source_abi: "계약 ABI",
    source_abi_default: "ABI 도출하기",
    nfts_list: "NFT 목록",
    item: "아이템",
    Items: "수량",
    //rcontract_rank_des:'上次更新时间为:{{value}}',
    contract_rank_des: "마지막 업데이트 시간: {{value}}",
    contract_rank_total: "총 {{value}}개의 계약 ",
    contract_rank: "계약 랭킹",
    rank: "랭킹",
    actor_id: "actorID",
    ver_address: "검증 대기중",
    actor_address: "actorAddress",
    transaction_count: "거래 수",
    user_count: "거래 주소",
    actor_balance: "잔액",
    gas_cost: "Gas 소비량",
    see_more: "더보기",
    //log
    epoch: "높이",
    cid: "메시지 ID",
    event_name: "메소드",
    topics: "토픽",
    coompoent_data: "매개변수",
    log_index: "인덱스",
    removed: "제거됨"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (contract);


/***/ }),

/***/ 3341:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// pool-detail
const detail = {
    "24h": "24시간",
    "7d": "7일",
    "30d": "30일",
    "1year": "1년",
    look_all: "전체 데이터 보기",
    //owner
    "owner_title": "스토리지 풀 정보",
    "owner_title_tip": "스토리지 풀 정보: 노드 데이터를 모아 총합한 데이터 정보",
    all: "모든 메소드",
    account: "계정",
    account_title: "계정",
    owner_address: "Owner 주소",
    owned_miners: "소유한 노드",
    owned_active_miners: "액티브한 노드",
    miner: "Miner",
    evm: "EVM",
    ethaddress: "ETH 주소",
    ethaccount: "ETH 계정",
    transfer_records: "이체 기록",
    //account_type
    account_name: "계정",
    latest_transfer_time: "최신 거래 시간",
    multisig: "멀티 사인 계정",
    account_detail: "스토리지 풀 정보",
    from_ath: "발송자",
    to_ath: "수신자",
    account_id: "계정 주소",
    //Overview
    owner_overview_title: "스토리지 풀 개요",
    balance: "계정 잔액",
    available_balance: "사용 가능한 잔액",
    init_pledge: "섹터 저당",
    pre_deposits: "선입금",
    locked_balance: "잠긴 보상",
    balance_tip: "계정 잔액=사용 가능한 잔액+섹터 저당+선입금+잠긴 보상",
    available_balance_tip: "초기 예치금 및 잠긴 보상을 제외한 계정 내 사용 가능한 지출 가능 금액",
    init_pledge_tip: "복제 검증의 두 번째 단계를 성공적으로 완료한 후 실제로 예치된 금액",
    pre_deposits_tip: "예치금액은 두 번째 단계에서 지정된 시간 내에 성공적으로 증명을 제출한 후 각 섹터별로 실제로 예치된 금액에 따라 조정됩니다. 그렇지 않을 경우, 주어진 시간 내에 증명을 제출하지 않을 경우 벌금이 부과됩니다",
    locked_balance_tip: "출출 보상의 미발행 부분은 시간에 따라 선형적으로 해제됩니다",
    sector_count: "전체",
    live_sector_count: "유효",
    fault_sector_count: "오류",
    recover_sector_count: "복구",
    eth_address: "ETH 주소",
    stable_address: "안정 주소",
    tokenList: "보유한 토큰",
    showContract: "계약: {{value}}",
    showAddress: "주소: {{value}}",
    //统计指标
    indicators: "통계 지표",
    power_increase_indicators: "채굴파워 증가량",
    power_ratio: "전력 성장률",
    sector_increase: "섹터 증가량",
    precommit_deposits: "섹터 담보",
    gas_fee: "Gas 소비",
    block_rewards: "블록 보상",
    block_count: "블록 수량",
    block_count_tip: "블록 수 = 블록 (block) 수량 총합",
    mining_efficiency: "효율성",
    mining_efficiency_tip: "선택한 주기 동안, 노드가 채굴한 총 블록 보상과 유효한 채굴 능력 비율",
    lucky: "행운값",
    lucky_tip: "행운 값: 실제 블록 보상 수와 예상 블록 보상 수의 비율입니다. QualityAdjPower가 1 PiB 미만인 경우, 이 값은 상당한 무작위성을 가지며 참고 용도로만 사용되어야 합니다",
    sector_ratio: "섹터 증가 속도",
    sector_ratio_tip: "",
    win_count: "우승자 보상",
    win_count_tip: "Filecoin 경제 모델에서 한 높이 (tipset)하에는 여러 블록 (block)이 있을 수 있으며, 각 블록 (block)은 여러 보상 (win count)을 받을 수 있습니다. 누적 블록 수 =모든 보상 수의 총합",
    net_profit_per_tb: "Gas 소비/T",
    net_profit_per_tb_tip: "선택된 기간 내에 크기가 T인 단일 섹터를 봉인하는 데 필요한 가스 소비",
    //账户变化
    account_change: "계정 변동",
    power: "파워",
    power_increase: "유효 체굴 파워 성장",
    quality_adjust_power: "유효 체굴 파워",
    quality_power_rank: "순위",
    raw_power_percentage: "체굴 파워 비율",
    raw_power: "로우바이트 체굴 파워",
    total_block_count: "30일 블록 수",
    total_block_count_tip: "최근 30일간 해당 노드에서 채굴한 블록 수의 총합",
    total_reward: "30일 보상",
    total_reward_tip: "최근 30일간 해당 노드에서 채굴한 블록의 총 보상",
    total_balance_tip: "계정 잔액=사용 가능한 잔액+섹터 저당+선입금+잠긴 보상",
    total_win_count: "30일 우승 횟수",
    total_win_count_tip: "최근 30일간 해당 노드에서 채굴한 블록의 총 우승 횟수",
    sector_size: "섹터 크기",
    sector_status: "섹터 상태",
    //账户总览
    account_overview: "계정 개요",
    create_time: "계정 생성 시간",
    account_type: "계정 유형",
    peer_id: "노드 표기",
    account_address: "주소",
    owner_address: "소유자",
    area: "지역",
    worker_address: "워커",
    controllers_address: "컨트롤러",
    beneficiary_address: "수혜자",
    code_cid: "코드 CID",
    nonce: "Nonce 값",
    contract_verify: "계약 검증",
    contract_name: "계약 명칭",
    //miner
    //pool_overview_title:'账户',
    // message
    message_overview_detail: "거래 세부 내용",
    trade: "내부 거래",
    message_detail: "개요",
    event_log: "이벤트 로그",
    message_overview: "메시지 개요",
    eth_message: "ETH Hash",
    cid: "메시지 ID",
    height: "블록 높이",
    time: "시간",
    blk_cids: "블록",
    value: "금액",
    from: "발신 주소",
    to: "수신 주소",
    status: "상태",
    method_name: "메소드",
    message_other: "기타 정보",
    version: "버전 번호",
    // eslint-disable-next-line no-dupe-keys
    nonce: "Nonce",
    gas_fee_cap: "수수료 요금 최고 한도",
    gas_premium: "노드 팁 비율 수수료",
    gas_limit: "Gas 한도",
    gas_used: "Gas 실제 사용량",
    base_fee: "기본 수수료 요금",
    all_gas_fee: "수수료",
    params: "매개 변수",
    returns: "반환 값",
    message_tranf: "송금 정보",
    from_tranf: "보내는 사람",
    to_tranf: "받는 사람",
    consume_type: "유형",
    MinerTip: "Miner 수수료",
    BaseFeeBurn: "기초 수수료 폐기",
    Transfer: "송금",
    Burn: "취합 비용 폐기",
    exit_code: "상태",
    //内部交易
    amount: "액수",
    method: "메소드",
    topic: "토픽",
    //通证转移
    message_ERC20Trans: "토큰 전송",
    message_NftTrans: "NFT 전송",
    // 出块列表
    block_cid: "블록 CID",
    block_height: "블록 높이",
    block_time: "블록 생성 시간",
    block_messages_count: "메시지 수",
    block_miner_id: "노드 주소",
    block_mined_reward: "블록 보상",
    //miner
    message_list: "메시지 리스트",
    block_list: "블록 리스트",
    traces_list: "대체 리스트",
    message_list_total: "총 {{value}}개 메시지",
    block_list_total: "총 {{value}}개 블록",
    traces_list_total: "총 {{value}}개 메시지",
    contract_token_list_total: "총 {{value}}개 토큰",
    //general
    general_overview_title: "계정 개요",
    base_account_id: "계정 ID",
    //dns detail
    //dns detail
    deal_details: "거래 상세 정보",
    deal_id: "거래 ID",
    epoch: "블록",
    service_start_time: "생성 시간",
    message_cid: "소속 메시지",
    piece_cid: "Piece CID",
    verified_deal: "검증됨",
    deal_hosting: "호스팅 정보",
    deal_left_title: "클라이언트",
    deal_right_title: "호스팅 노드",
    deal_value: "담보 금액",
    deal_cash: "호스팅 비용",
    deal_time: " ~ ",
    user_count: "거래 주소",
    transfer_count: "거래 횟수",
    go_verify: "검증하러 가기",
    contract_token_list: "토큰",
    token_name: "토큰 이름",
    contract_id: "계약 ID",
    amount: "금액",
    platform: "거래 플랫폼",
    erc20_transfer: "토큰 거래",
    erc20_transfer_total: "총 {{value}}개 송금",
    power_change: "Power Change",
    owned_active_miners: "Active Miners",
    //height
    blcok_time: "블록 시간",
    message_count_deduplicate: "블록 메시지(중복 제거)",
    miner_id: "Miner",
    messages_count: "메시지",
    reward: "보상",
    //cid detail
    block_list: "Block List",
    blocks_cid: "Cid",
    blocks_miner: "Miner",
    blocks_messages: " 메시지",
    blocks_reward: "보상",
    win_count: "윈 카운트",
    //cid_details
    message_list_total: "Total of {{value}} Messages",
    chain_cid_detail: "区块详情",
    cid_height: "높이",
    parent_weight: "Parent Block 무게",
    parents_cid: "Parent CID",
    parent_base_fee: "Parent Block 기본 수수료",
    ticket_value: "티켓 값",
    state_root: "스테이트 루트",
    message_count: "메시지 개수"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (detail);


/***/ }),

/***/ 9720:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const domain = {
    domain_title: "개요",
    resolved_address: "해석된 주소",
    expired_at: "만료일",
    registrant: "등록자",
    controller: "컨트롤러",
    allDomains: "이 주소가 소유한 도메인 총 {{value}}개",
    Result_for: "검색 결과"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (domain);


/***/ }),

/***/ 9429:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const fevm = {
    tp_token: "토큰 포켓에 토큰 추가하기",
    rank: "순위",
    defi_overview: "DeFi 프로토콜",
    fevm_staked: "FEVM 스테이킹 양",
    staked_change_in_24h: "24시간 스테이킹 변경량",
    total_user: "전체 사용자 수",
    user_change_in_24h: "24시간 사용자 변경량",
    fil_staked: "FIL 스테이킹 양",
    defi_list: "DeFi Protocol",
    Protocol: "프로토콜",
    defi_list_time: "마지막 업데이트 시간: {{value}}",
    tvl: "총 잠금 가치(TVL)",
    tvl_change_rate_in_24h: "24시간 TVL 변화",
    tvl_change_in_24h: "24시간 TVL 변경량",
    tokens: "톱 토큰즈",
    tokens_tip: "계약에서 각 토큰의 담보 비율",
    users: "사용자 수"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (fevm);


/***/ }),

/***/ 8589:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const fvm = {
    hot: "Explore FVM on FIlscan",
    all: "FVM 생태 프로젝트 개요",
    Defi: "Defi",
    Dex: "Dex",
    DID: "DID",
    NFT: "NFT",
    MarketPlace: "MarketPlace",
    Launchpad: "Launchpad",
    see_more: "더보기"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (fvm);


/***/ }),

/***/ 3115:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const home = {
    seconds: "초",
    minutes: "분",
    hours: "시간",
    day: "일",
    //meta
    meta_title: "전체 네트워크 데이터 지표",
    mata_show: "펼치기",
    mata_show_false: "접기",
    latest_height: "최신 블록 높이",
    latest_block_time: "최신 블록 시간",
    total_blocks: "전체 블록 생성 수",
    total_rewards: "전체 블록 보상",
    total_quality_power: "전체 유효 체굴파워",
    total_quality_power_tip: "현재 전체 유효 컴퓨팅 파워(유효 저장 공간)의 총합",
    base_fee: "현재 기본 요금",
    miner_initial_pledge: "현재 섹터 저당 양",
    power_increase_24h: "최근 24시간 동안 파워 증가량",
    rewards_increase_24h: "최근 24시간 동안 생성된 블록 보상",
    fil_per_tera_24h: "최근 24시간 동안 생성 효율",
    fil_per_tera_24h_tip: "최근 24시간 동안 전체 블록 보상과 유효 체굴 파워의 비율",
    gas_in_32g: " 최근 24시간 동안 1TiB 용량의 32GiB 섹터를 봉인하기 위해 필요한 가스입니다",
    gas_in_32g_meta: "32GiB 섹터의 가스 소비량",
    gas_in_32g_tip: "최근 24시간 동안 밀봉된 32G 섹터당 소비된 가스량(TB당)",
    add_power_in_32g: "32GiB 섹터 새로 추가한 파워 비용",
    add_power_in_32g_tip: "최근 24시간 동안 32G 섹터 새로 추가한 파워를 위해 필요한 비용(섹토 저당 및 밀봉 수수료 포함)",
    gas_in_64g: "지난 24시간 동안 1TiB 용량의 64GiB 섹터를 봉인하기 위해 필요한 가스입니다",
    gas_in_64g_meta: "64GiB 섹터의 가스 소비량",
    gas_in_64g_tip: "최근 24시간 동안 밀봉된 64G 섹터당 소비된 가스량(TB당)",
    add_power_in_64g: "64GiB 섹터 새로 추가한 파워 비용",
    add_power_in_64g_tip: "최근 24시간 동안 64G 섹터 새로 추가한 파워를 위해 필요한 비용(섹토 저당 및 밀봉 수수료 포함)",
    win_count_reward: "각 티켓당 블록 보상",
    win_count_reward_tip: "최신 높이에서 각 블록의 보상 (높이마다 여러 블록이 있으며 모두 보상을 획득할 수 있음)",
    avg_block_count: "한 높이당 평균 블록 수",
    avg_block_count_tip: "최근 24시간 동안 한 높이당 평균 블록 수",
    avg_message_count: "한 높이당 평균 메시지 수",
    avg_message_count_tip: "최근 24시간 동안 한 높이당 평균 메시지 수",
    active_miners: "액티브한 노드 수",
    burnt: "소각된 토큰 수",
    circulating_percent: "유통 비율",
    rank: "순위",
    footer_text: "Filscan 브라우저는 Filecoin 블록체인 브라우저 및 데이터 서비스 플랫폼입니다. Filecoin 기반의 수익 랭킹, 블록체인 데이터 조회, 시각화 차트 등의 데이터 서비스를 제공합니다.",
    footer_outlook: "이메일",
    footer_detail_a: "판권 소유 \xa9 Filecoin 개발 보조 계획을 따르며 ",
    footer_detail_b: " 및 ",
    footer_detail_c: "저작권 계약",
    search_notFound: "검색 결과 없음",
    warn_text: "Oops! 입력한 검색어:",
    warn_details: "죄송합니다. 유효하지 않은 문자열입니다.",
    go_home: "홈으로 돌아가기",
    blockchain_browser: "블록 탐색기",
    "quality_power/increase_24h": "전체 유효 체굴파워",
    "total_contract": "활성 계약",
    "total_contract_24h_contract": "활성 계약 수/24시간",
    "total_contract/24h_contract": "활성 계약 수/24시간",
    verified_contracts: "검증된 스마트 계약 리스트",
    "contract_transaction": "계약 거래 수",
    "contract_transaction_24h_change": "활성 계약 수 24시간 변동",
    "contract_transaction/24h_change": "계약 거래 수 24시간 변동",
    "contract_address": "거래 주소",
    "contract_address/24h_change": "계약 거래 주소 24시간 ",
    "contract_address/24h_change": "계약 거래 주소 /24시간 ",
    "total_contract/24h_contract_tip": "네트워크에서 거래가 이루어진 계약의 총 수",
    gas_24: "24시간 Gas 사용",
    contract_gas: "계약 가스 비용",
    quality_power_Cc: "Commited Capacity (CC)",
    quality_power_Dc: "DataCap (DC)"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (home);


/***/ }),

/***/ 7997:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const zh = {
    network_title: "현재 네트워크",
    home: "홈페이지",
    contract: "FEVM",
    contract_verify: "스마트 계약 검증",
    contract_list: "검증된 스마트 계약 리스트",
    contract_rank: "스마트 계약 랭킹",
    defi_dashboard: "DeFi Protocol",
    token: "토큰",
    nft: "NFT",
    tipset: "블록체인",
    tipset_chain: "블록",
    tipset_message: "메시지",
    tipset_ranking: "자산 순위",
    tipset_transfer: "거액 이체",
    tipset_dsn: "주문",
    "tipset_pool-message": "메시지 풀",
    ranking: "랭킹",
    statistics: "통계",
    statistics_gas: "가스 요금 추세",
    statistics_base: "해싱 파워 추세",
    statistics_fil: "FIL",
    statistics_charts: "통계",
    statistics_map: "노드 맵",
    resources: "자원",
    resources_tools: "자주 쓰는 도구",
    provider: "스토리지 공급자",
    fvm: "FVM 생태계 개요",
    account: "Miner Metrics",
    develop: "Developer"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (zh);


/***/ }),

/***/ 596:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const rankZh = {
    rank_title: "Ranking",
    rank: "Rank",
    pool: "스토리지 풀 랭킹",
    provider: "노드 랭킹",
    growth: "파워 증가율",
    rewards: "노드 수익",
    "24h": "24시간",
    week_days: "7일",
    month: "30일",
    select_rank_all: "모든 섹터",
    select_rank_32: "32G 섹터",
    select_rank_64: "64G 섹터",
    more: "더보기",
    rank_time: "마지막 업데이트 시간:",
    see_more: "더보기",
    //存储池排行
    ranking: "순위",
    pool_owner: "Owner ID",
    pool_power: "유효 해시파워",
    pool_efficiency_24h: "최근 24시간 생산 효율",
    pool_increase_24h: "최근 24시간 채굴파워 증가량",
    pool_block_count: "총 블록 수",
    pool_block_count_24h: "최근 24시간 블록 수",
    miner: "노드",
    // 节点排行
    provider_miner: "스토리지 제공자",
    provider_power_ratio: "유효 채굴파워 / 비율",
    provider_block_ratio: "최근 24시간 블록 / 비율",
    provider_rewards_ratio: "최근 24시간 보상 / 비율",
    balance: "잔액",
    //算力增速
    power_ratio: "채굴파워 증가 속도",
    power_ratio_tip: "선택한 주기 내에서, 매일 평균 패키징된 섹터의 유효 해시파워 총합",
    quality_power_increase: "채굴파워 증가량",
    quality_power_increase_tip: "선택한 주기 내에서, 노드의 유효 채굴파워 증가량",
    quality_adj_power: "유효 체굴 파워",
    raw_power: "로우바이트 체굴 파워",
    sector_size: "섹터 크기",
    //节点收益
    "rewards/ratio": "블록 보상 / 비율",
    "rewards/ratio_tip": "선택한 주기 내에서, 노드 블록 보상과 누적 블록 생성 보상의 비율",
    block_count: "블록 수",
    winning_rate: "윈 카운트 확률",
    block_count_tip: "Filecoin 경제 모델에서, 높이 (tipset) 당 여러 블록 (block)이 있을 수 있으며 각 블록은 여러 보상 (win count)을 받을 수 있습니다."
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (rankZh);


/***/ }),

/***/ 4547:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const statistic = {
    gas_total: "Gas",
    show_more: "더 보기",
    "24h": "24시간",
    "7d": "7일",
    "30d": "30일",
    year: "1년",
    // power
    "power": "스토리지 파워 추세",
    power_tips: "기준선은 Filecoin 네트워크가 요구하는 네트워크 성장 규모이며, 메인넷 출시 때는 2.5EiB이며, 연간 증가율은 100% 입니다.",
    trend_24: "24시간 기본 수수료 추세",
    total_raw_byte_power: "원래 로우바이트 파워",
    base_line_power: "기준선 추세",
    change_quality_adj_power: "연쇄 유효 체굴파워 변화",
    total_quality_adj_power: "유효 체굴파워",
    gas: "기본 수수료 추세",
    base_fee: "기본 수수료",
    gas_in_32g: "32GiB 섹터 Gas 소비",
    gas_in_64g: "64GiB 섹터 Gas 소비",
    //24_gas
    gas_24: "24시간 Gas 데이터",
    method_name: "메시지 유형",
    avg_gas_premium: "Gas 프리미엄",
    avg_gas_limit: "평균 Gas 한도",
    avg_gas_used: "평균 가스 소비",
    avg_gas_fee: "평균 수수료",
    "sum_gas_fee/ratio": "수수료 합계/비율",
    "message_count/ratio": "메시지 수 합계/비율",
    //fil
    TokenRules: "Filecoin 토큰 할당 규칙",
    FilecoinFoundation: "Filecoin 재단",
    FundraisingRemainder: "모금 - 잔여 토큰",
    FundraisingSAFT: "모금 - 미래 토큰 간단 계약",
    MiningReserve: "스토리지 서비스 제공자를 위한 예비 토큰",
    TokenAllocation: "스토리지 제공자 토큰 할당",
    ReservedTokens: "스토리지 제공자 예비 토큰",
    Fundraising: "모금 방식 - 미래 토큰 간단 계약 2017",
    Funds: "모금 방식 - 잔여 자금",
    protocolLab: "프로토콜 실험실",
    Contributors: "프로토콜 실험실 팀 및 기여자",
    Allocation: "항목 배치",
    value: "금액",
    description: "구체적 용도",
    filBase: "FIL 기본 발급",
    filBase_des: "네트워크에서 FIL 생선 상한",
    ReservedTokens_des: "미래 Filecoin 경제 성장을 위해 예비 토큰 저장, 구체적인 사용 방안은 Filecoin 커뮤니티에서 결정됩니다.",
    TokenAllocation_des: "블록 보상, 네트워크 초기화 등을 통해 스토리자 제공자에게 발급한 토큰 보상",
    FilecoinFoundation_des: "장기적인 커뮤니티 발전과 네트워크 관리를 위해 할당되었습니다",
    Fundraising_des: "2017년 판매된 토큰",
    Funds_des: "생태계 발전 및 후속 자금 용자로 쓰인다",
    protocolLab_des: "프로토콜 실험실 관련 작업용",
    Contributors_des: "4.5%는 프로토콜 실험실 팀 및 기여자에게 지급됩니다.",
    //charts
    pie_title: "차트 통계",
    block_trend: "블록 보상",
    block_reward_per_TiB: "생산 효율",
    acc_block_rewards: "누적 블록 보상",
    active_nodes: "액티브한 노드 수",
    active_miner_count: "노드 수",
    messages_trend: "메시지 수 추이 그래프",
    message_count: "블록 평균 메시지 추세",
    all_message_count: "총 메시지 추세",
    pie_title_a: "현재 FIL의 용도 분포 통계",
    pie_title_a_tip: "제공된 스토리지 제공자 보상 FIL + 해제된 잠긴 블록 보상 FIL + 배치된 보류 부분 FIL = 현재 이미 방출된 FIL",
    pie_title_b: "현재 이미 방출된 FIL 용도 통계",
    mined: "제공된 스토리지 제공자 보상 FIL",
    remaining_mined: "잔여 스토리지 제공자 보상 FIL",
    vested: "해제된 잠긴 블록 보상 FIL",
    remaining_vested: "잔여 잠긴 블록 보상 FIL",
    reserve_disbursed: "배치된 보류 부분 FIL(테스트넷 보상)",
    remaining_reserved: "잔여 보류 부분 FIL",
    locked: "섹터 담보 FIL",
    burnt: "폐기된 FIL",
    circulating: "거래 가능한 유통 FIL",
    power_increase: "순 전력 증가",
    power_decrease: "순 전력 감소",
    //chartsnav
    cc_dc_power: "CC/DC 전력 추세",
    static_overview: "图表统计",
    contract_trend: "계약 거래",
    charts_title: "FIL 할당 지침",
    networks_overview: "전체 네트워크 데이터 지표"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (statistic);


/***/ }),

/***/ 9465:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const tipset = {
    rank: "순위",
    tag: "태그",
    height: "블록 높이",
    cid: "메시지 CID",
    block_time: "시간",
    from: "보내는 주소",
    to: "받는 주소",
    value: "액수",
    method_name: "매소드",
    all: "모든 메소드",
    //chain
    blocks_cid: "CID",
    blocks_miner: "Miner",
    blocks_messages: "메시지",
    blocks_reward: "보상",
    win_count: "윈 카운트",
    //cid_details
    message_list_total: "총 {{value}}개 메시지",
    chain_cid_detail: "블록 정보",
    cid_height: "높이",
    parent_weight: "Parent Block 무게",
    parents_cid: "Parent Block CID",
    parent_base_fee: "Parent Block 기본 수수료",
    ticket_value: "티켓 값",
    state_root: "스테이트 루트",
    //message
    message_list: "모든 매소드",
    total_list: "총 {{value}}개 메시지",
    message_list_all: "전체 유형",
    message_list_exit_code: "상태",
    message_list_method_name: "매소드 명칭",
    // adress
    address_total_list: "총 {{value}}개 계정",
    address_list: "자산 순위",
    address_all: "전체 유형",
    account: "일반 계정",
    owner: "소유자 계정",
    miner: "노드 계정",
    payment: "지불 채널",
    multisig: "다중 서명 계정",
    account_address: "주소",
    balance_percentage: "잔액/비율",
    account_type: "유형",
    latest_transfer_time: "최근 거래 시간",
    //transfer
    transfer_list: "거액 이체 기록",
    transfer_total_list: "총 {{value}}개 기록",
    //dsn
    dsn_list: "거래 목록",
    dsn_total_list: "총 {{value}}개 거래",
    dsn_placeholder: "검색 고객/호스팅자/Deal ID",
    deal_id: "거래 ID",
    piece_cid: "파일 ID",
    piece_size: "파일 크기",
    client_address: "고객",
    provider_id: "호스팅자",
    service_start_time: "시작 시간",
    end_time: "종료 시간",
    start_height: "스타트 높이",
    end_height: "앤드 높이",
    storage_price_per_height: "저장 요금",
    verified_deal: "검증된 거래",
    // pool-message
    pool_list: "메시지 풀 목록",
    gas_fee_cap: "Gas 한도",
    gas_premium: "Gas 프리미엄",
    block_list: "Block List"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (tipset);


/***/ }),

/***/ 9547:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const account = {
    date: "日期",
    confirm: "确认",
    cancel: "取消",
    go_home: "返回首页",
    go_login: "去登录",
    back: "返回",
    account_title: "节点管家",
    overview: "数据概览",
    miners: "节点管理",
    personal: "账号信息",
    logout: "退出登录",
    default_group: "默认分组",
    welcome: "欢迎来到Filscan!",
    welcome_text1: "恭喜！您的账户已成功注册,您可以使用您的邮箱号和密码继续登录。",
    welcome_text2: "请登录您的账户并享受您的Filscan服务!",
    last_time: "最新更新时间",
    all: "全部",
    edit: "操作",
    miner_add: "添加",
    //个人账户
    register_success: "恭喜！您的账户已注册成功，快来开启您的专属服务!",
    register_btn: "开启服务",
    //数据概览
    overview_power: "算力概览",
    overview_gas: "Gas 消耗",
    overview_expired: "到期扇区",
    overview_reward: "出块奖励",
    overview_lucky: "幸运值",
    overview_balance: "地址余额",
    no_node_data: "暂未添加节点，去",
    miners_add: "添加节点",
    group_add: "添加分组",
    miners_group_manage: "分组设置",
    //total_out_come_gas: '总支出/Gas消耗',
    total_out_come_gas: "支出/Gas消耗",
    pledge_amount_24: "质押FIL/今日变化",
    balance_24: "可用余额/今日变化",
    quality_power_24: "有效算力/今日变化",
    //节点管理
    delete_group: "删除分组",
    delete_record_group: "确定删除分组“{{value}}”吗？",
    delete_group_text: "删除后该分组将不在列表中显示",
    delete_miner: "删除节点",
    delete_record_miner: "确定删除节点“{{value}}”吗？",
    delete_miner_text: "删除后该节点将不在分组中显示",
    //添加节点
    custom_tag: "自定义标签",
    miner_add_placeholder: "输入您要添加的节点账户ID",
    miner_select_group_placeholder: "选择分组（如未选择组，添加的节点将全部进入“默认分组”中",
    //分组
    create_group: "创建分组",
    create_group_holder: "输入您要创建组的名称",
    item_value: "组内 {{value}} 个节点",
    group_name: "分组名称",
    //幸运值
    "all": "全部",
    "24h_lucky": "24时幸运值	",
    "7d_lucky": "7天的幸运值",
    "30d_lucky": "30天幸运值",
    "1year_lucky": "1年的幸运值",
    tag: "标签",
    miner_id: "节点ID",
    //地址余额
    miner_balance: "节点余额/今日变化",
    owner_balance: "Owner余额/今日变化",
    worker_balance: "Worker余额/今日变化",
    controller_0_balance: "Controller0余额/今日变化",
    controller_1_balance: "Controller1余额/今日变化",
    controller_2_balance: "Controller2余额/今日变化",
    beneficiary_balance: "Beneficiary余额/今日变化",
    market_balance: "MarketBalance余额/今日变化",
    //奖励
    block_count: "爆块",
    win_count: "赢票",
    block_reward: "奖励",
    total_reward: "总奖励",
    total_reward_24: "出块奖励",
    //total_reward_24:'奖励/今日变化',
    //算力概览
    quality_power: "有效算力",
    dc_power: "DC算力",
    raw_power: "原值算力",
    cc_power: "CC算力",
    sector_size: "扇区大小",
    sector_power_change: "扇区变化",
    sector_power_count: "Sector数量",
    sector_count_change: "扇区数量变化",
    pledge_changed: "质押变化",
    pledge_changed_per_t: "质押变化/T",
    penalty: "惩罚",
    fault_sectors: "错误扇区",
    sector_power_change_tip: "Sector数量/原值算力的新增及终止的总和",
    pledge_changed_tip: "Sector数量的新增及终止对应的质押变化总和",
    pledge_changed_per_t_tip: "质押变化\xf7扇区变化(TiB)",
    penalty_tip: "被惩罚的FIL数量",
    fault_sectors_tip: "新增的错误扇区数量/原值算力",
    total_gas_cost_tip: "所有类型消耗Gas的总和",
    seal_gas_cost_tip: "扇区封装消耗的Gas总和（PreCommitSector+ProveCommitSector+PreCommitSectorBatch+ProveCommitAggregate+PreCommit 聚合费+ProveCommit 聚合费",
    seal_gas_per_t_tip: "封装Gas\xf7新增扇区(TiB)",
    deal_gas_cost_tip: "真实数据PublishStorageDeals消耗",
    wd_post_gas_cost_tip: "时空证明SubmitWindowedPoSt消耗",
    wd_post_gas_per_t_tip: "时空证明Gas\xf7原值算力(TiB)",
    //gas
    total_gas_cost: "Gas总消耗",
    seal_gas_cost: "封装Gas",
    seal_gas_per_t: "封装Gas/T",
    deal_gas_cost: "发单Gas",
    wd_post_gas_cost: "时空证明Gas",
    wd_post_gas_per_t: "时空证明Gas/T",
    //到期扇区
    exp_month: "{{year}}年{{month}}月到期",
    exp_time: "到期时间",
    miner_count: "节点数",
    exp_power: "到期算力",
    sector_count: "到期扇区数",
    exp_dc: "到期DC",
    exp_pledge: "到期抵押",
    //个人中心
    default_user: "普通用户",
    last_login: "上次登录时间",
    personal_setting: "账户设置",
    personal_name: "账户名称",
    old_placeholder: "输入旧密码",
    old_password: "旧密码",
    new_password: "新密码",
    new_placeholder: "输入新密码",
    confirm_password: "确认密码",
    confirm_placeholder: "重新输入新密码",
    personal_name_holder: "请输入账户名称",
    name_length: "名称长度小于10",
    //下载
    out_come_gas: "支出"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (account);


/***/ }),

/***/ 1818:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const common = {
    zh: "中",
    en: "En",
    kr: "Kr",
    login: "登录",
    cancel: "取消",
    confirm: "确认",
    open: "展开",
    no_open: "收起",
    lang: "中",
    fil: "FIL",
    last_time: "最新区块时间",
    base_fee: "Base Fee",
    last_height: "最新区块高度",
    go_home: "返回首页",
    go_login: "去登录",
    //search
    "search_holder": "请输入地址/消息ID/高度/区块Cid/节点ID/FNS",
    all: "全部筛选类型",
    address: "地址",
    message_id: "消息ID",
    height: "高度",
    cid: "区块CID",
    node: "节点",
    //messages
    no_account: "该邮箱未注册,请先注册",
    //登录注册
    register: "邮箱注册",
    password_login: "密码登录",
    reset_password: "重置密码",
    verification_code: "验证码登录",
    email_placeholder: "输入邮箱号",
    password_placeholder: "输入密码",
    code_placeholder: "输入验证码",
    remember_me: "记住并自动登录",
    forgot_password: "忘记密码",
    get_code: "获取验证码",
    retry_code: "重新发送",
    no_account: "还没有账号?",
    have_account: "已有账号?",
    go_register: "立即注册",
    new_password: "设置密码",
    confirm_password: "确认密码",
    agreement: "注册即代表同意《协议》、《隐私政策》",
    //校验
    email_required: "请输入您的邮箱",
    email_rules: "邮箱格式有误,请修改",
    code_rules: "请正确输入6位数字验证码",
    password_rules: "请输入 8-20 个字符，需同时包含数字、字母以及特殊符号,密码不能与您的邮箱地址相同",
    confirm_password_rules: "两次输入的密码不一致，请重新输入",
    email_exists: "邮箱已存在",
    Export: "下载Excel",
    //footer
    "footer_des1": "Filscan 是 Filecoin 区块链浏览器及其数据服务平台",
    "footer_des2": "提供基于 Filecoin 的各类数据查询、可视化图表以及FVM生态数据统计分析的一站式数据服务"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (common);


/***/ }),

/***/ 77:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/*

什么时候需要上传MetaData文件?
1. 多文件合约
2. 合约内import的层级目录为原生状态且与metadata文件中sources下的路径相同 (若合约内import的层级目录为当前文件夹则不需要上传metadata文件)
如何获取metaData文件？
1. 通过使用Solidity编译器（solc）获取：
    solc --metadata MainContract.sol -o metadata.json
2. 通过使用Remix IDE下载：
    在Remix网页端发布之后有提供metadata.json的下载按钮
*/ const contract = {
    overview: "概览",
    market: "Market",
    look_adres: "查看地址",
    gohome: "返回首页",
    reset_ver: "重新验证",
    next: "下一步",
    reset: "重置",
    confirm: "验证并发布",
    back: "返回",
    file_name: "选择 *.sol 文件",
    file_name_json: "选择 *.json 文件",
    config_file_name: "选择 Metadata 文件",
    config_file_des1: "> 什么时候需要上传metadata文件?",
    config_file_des1_1: "1. metadata文件包含了编译器的各种设置，如果您使用了高级优化参数，或者编译时使用了编译配置文件（e.g. remix中编译时的compiler_config.json文件），那么您需要上传metadata文件进行验证",
    config_file_des1_2: '2. 合约内import的层级目录为初始格式(e.g. import "@openzeppelin/contracts/access/Ownable.sol")并与metadata文件中sources下的路径相同 (若合约内import的层级目录为当前文件夹则不需要上传metadata文件)',
    config_file_des2: "> 如何获取metadata文件?",
    config_file_des2_1: "1. 通过使用Solidity编译器（solc）获取：solc --metadata MainContract.sol -o metadata.json",
    config_file_des2_2: "2. 通过使用Remix IDE下载：在Remix网页端发布之后有提供metadata.json的下载按钮",
    verify_title: "验证并发布合约源代码",
    verify_des: "编译器类型和版本选择",
    verify_content: "源代码验证为与智能合约交互的用户提供了透明度。通过上传源代码，filscan 将编译后的代码与区块链上的代码进行匹配。就像合同一样，“智能合同”应该为最终用户提供更多关于他们“数字签名”的目的的信息，并让用户有机会审核代码以独立验证它是否确实做了它应该做的事情。",
    content_des: `源代码验证为与智能合约交互的用户提供了透明度。通过上传源代码，Filscan 将编译后的代码与区块链上的代码进行匹配。就像合同一样，“智能合同”应该为最终用户提供更多关于他们“数字签名”的目的的信息，并让用户有机会审核代码以独立验证它是否确实做了它应该做的事情。通过上传hardhat “artifacts/build-info/”目录中的json文件，可以快速进行合约验证。
Hardhat 将编译输出存储在项目内的“artifacts/build-info/”目录中。 该目录包含一个 .json 文件，其中包含所有合约的Standard JSON Input-Outpu，这是与 Solidity 编译器交互的推荐方法，特别是在高级和自动化配置中。 所有编译器发行版都统一支持此 JSON 输入输出接口`,
    address: "请输入您要验证的合约地址",
    address_placeholder: "请输入您要验证的合约地址",
    verify_address: "请选择编译版本",
    verify_address_placeholder: "请选择",
    verify_model: "请选择编译类型",
    verify_model_placeholder: "请选择编译类型",
    license_type: "请输入开源许可证类型",
    content_des1: "1. 如果合同在 REMIX 处编译正确，则此处也应编译正确",
    content_des2: "2. 我们对验证由另一个合约创建的合约的支持有限，编译的每个合约的超时时间最多为45秒",
    content_des3: "3. 对于编程合同验证，请查看合同 API 端点",
    checkbox_service: "我同意服务条款",
    verify_select_placeholder: "请选择",
    //logs
    ver_sucess: "Success: 验证成功",
    ver_err: "Error: 验证失败",
    has_been_verified: "Error:合约已验证",
    byte_code: "编译日志",
    contract_name: "合约名",
    local_byte_code: "合约字节码",
    compiler: "编译器版本",
    contract_abi: "合约ABI",
    //step1
    address_verify: "合约地址",
    step1_verify_des: "请选择单个或多个 *.SOL 文件",
    source_code: "合约源码",
    compile_version: "编译器",
    compile_output: "编译输出",
    Optimizations: "优化参数",
    run_optimizer: "运行(优化器)",
    arguments: "构造函数参数",
    optimize: "优化开启",
    optimize_runs: "RUNS",
    // 已验证合约
    Verify_code: "Code",
    Verify_read: "Read Contract",
    Verify_write: "Write Contract",
    contract_verify: "合约验证",
    contract_verify_tips: "合约验证请前往PC端查看",
    //token list
    token_list: "全部通证",
    token_name: "Token",
    vol_24: "成交量(24h)",
    transfer_total: "共 {{value}} 条消息",
    owner_total: "总共 {{value}} 人持有",
    dex_total: "共 {{value}} 条交易",
    nfts_total: "共 {{value}} 条 NFTs",
    //nft list
    nfts_list: "全部 NFTs",
    trading_volume: "全部成交量",
    nfts_trans: "NFT转移",
    // ft /fns dashborad
    "total_supply": "供应量",
    "total_supply_tip": "该数据为合约ERC20标准方法返回值",
    "owners": "持有人",
    "transfers": "总共转移",
    latest_price: "价格",
    market_value: "市值",
    token_contract: "通证合约",
    transfer: "转移",
    owner: "拥有者",
    owner_nft: "拥有者",
    domain: "合约",
    dex: "DEX 交易",
    //list
    message_cid: "消息ID",
    method: "Method",
    time: "时间",
    from: "发送地址",
    to: "接收地址",
    amount: "数量",
    //拥有者
    rank: "排行",
    percentage: "占比",
    //dex
    platform: "交易平台",
    Txn_Value: "Txn Value",
    "swapped_Rate": "Swapped Rate",
    "Token_Amount_in": "Token Amount(In)",
    "Token_Amount_out": "Token Amount(Out)",
    Action: "Action",
    //合约列表
    contract_list: "已验证合约",
    contract_address: "地址",
    language: "语言",
    license: "许可证",
    //合约详情
    contract_list_total: "共 {{value}} 个合约",
    byte_code_no_verify: "合约未验证，去",
    go_to_verify: "验证合约",
    verify_contract: "合约源代码已通过验证",
    source_code: "合约源代码",
    source_code_create: "合约创建代码",
    source_abi: "合约ABI",
    source_abi_default: "导出ABI",
    nfts_list: "NFTs List",
    item: "Item",
    Items: "数量",
    controller: "域名注册人",
    //rank
    contract_rank_des: "上次更新时间为:{{value}}",
    contract_rank_total: "共 {{value}} 个合约 ",
    contract_rank: "合约排行",
    rank: "排名",
    actor_id: "actorID",
    ver_address: "待验证",
    actor_address: "actorAddress",
    transaction_count: "交易数量",
    user_count: "交易地址",
    actor_balance: "Balance",
    gas_cost: "Gas消耗",
    see_more: "查看更多",
    //log
    epoch: "高度",
    cid: "消息ID",
    event_name: "方法",
    topics: "主题",
    coompoent_data: "参数",
    log_index: "序号",
    removed: "移除"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (contract);


/***/ }),

/***/ 9893:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// pool-detail
const detail = {
    "24h": "24时",
    "7d": "7天",
    "30d": "30天",
    "1year": "1年",
    look_all: "查看全部数据",
    "all": "全部方法",
    //owner
    "owner_title": "存储池详情",
    "owner_title_tip": "存储池详情：存储池数据由名下节点数据,汇总而成",
    all_method: "全部方法",
    account: "一般账户",
    account_title: "账户",
    owner_address: "Owner地址",
    owned_miners: "名下节点",
    owned_active_miners: "名下活跃节点",
    miner: "Miner",
    evm: "EVM",
    ethaddress: "ETHAddress",
    ethaccount: "ETHAccount",
    transfer_records: "转账记录",
    //account_type
    account_name: "账户",
    latest_transfer_time: "最新交易时间",
    multisig: "多签账户",
    account_detail: "储存池详情",
    from_ath: "发送方",
    to_ath: "接受方",
    account_id: "账户地址",
    //概览
    owner_overview_title: "存储池概览",
    balance: "账户余额",
    available_balance: "可用余额",
    init_pledge: "扇区质押",
    pre_deposits: "预质押",
    locked_balance: "锁仓奖励",
    balance_tip: "账户余额 = 可用余额 + 扇区质押 + 预质押 + 锁仓奖励",
    available_balance_tip: "账户中除质押、锁仓之外的可支出金额",
    init_pledge_tip: "复制证明第二阶段成功后实际质押的金额",
    pre_deposits_tip: "复制证明第一阶段预质押金额，待第二阶段按时提交证明成功后按扇区实际质押多退少补；反之超时未提交，则会被罚没",
    locked_balance_tip: "出块奖励未释放的部分，随着时间线性释放",
    sector_count: "全部",
    live_sector_count: "有效",
    fault_sector_count: "错误",
    recover_sector_count: "恢复",
    eth_address: "ETH Address",
    stable_address: "稳定地址",
    tokenList: "名下资产",
    showContract: "合约: {{value}}",
    showAddress: "地址: {{value}}",
    //统计指标
    indicators: "统计指标",
    power_increase_indicators: "算力增量",
    power_ratio: "算力增速",
    sector_increase: "扇区增量",
    precommit_deposits: "质押增量",
    gas_fee: "Gas消耗",
    block_rewards: "出块奖励",
    block_count: "出块数量",
    block_count_tip: "出块数 = 出块数量（block）的总和",
    mining_efficiency: "效率",
    mining_efficiency_tip: "选定周期内，节点累计出块奖励与有效算 力的比值",
    lucky: "幸运值",
    lucky_tip: "实际爆块数量和理论爆块数量的比值。若有效算力低于1PiB，则该值存在较大随机性， 仅供参考",
    sector_ratio: "扇区增速",
    sector_ratio_tip: "",
    win_count: "赢票数量",
    win_count_tip: "Filecoin经济模型中，一个高度 （tipset）下可能有多个区块（block），每 个区块可能获得多份奖励（win count）。 累计出块份数=每次出块获得奖励份数的总和",
    net_profit_per_tb: "单T消耗",
    net_profit_per_tb_tip: "选定周期内单T封装扇区大小Gas消耗",
    //账户变化
    account_change: "账户变化",
    power: "有效算力",
    power_increase: "有效算力增长",
    quality_adjust_power: "有效算力",
    quality_power_rank: "排名",
    raw_power_percentage: "算力占比",
    raw_power: "原值算力",
    total_block_count: "30天出块数",
    total_block_count_tip: "近30天总出块数",
    total_reward: "30天奖励",
    total_reward_tip: "近30天奖励",
    total_win_count: "30天赢票",
    total_win_count_tip: "近30天总赢票",
    sector_size: "扇区大小",
    sector_status: "扇区状态",
    //账户总览
    account_overview: "账户总览",
    create_time: "创建时间",
    account_type: "账户类型",
    peer_id: "节点标识",
    account_address: "地址",
    // eslint-disable-next-line no-dupe-keys
    owner_address: "Owner",
    area: "地区",
    worker_address: "Worker",
    controllers_address: "Controller",
    beneficiary_address: "Beneficiary",
    code_cid: "代码 CID",
    nonce: "Nonce 数",
    contract_verify: "合约",
    contract_name: "合约名称",
    //miner
    //pool_overview_title:'账户',
    //power_change
    power_change: "算力变化",
    owned_active_miners: "实际工作节点",
    // message
    message_overview_detail: "交易明细",
    trade: "内部交易",
    message_detail: "概况",
    event_log: "事件日志",
    message_overview: "消息概览",
    eth_message: "ETH Hash",
    cid: "消息ID",
    height: "高度",
    time: "时间",
    blk_cids: "区块",
    value: "金额",
    from: "发送地址",
    to: "接收地址",
    status: "状态",
    method_name: "方法",
    message_other: "其他信息",
    version: "版本编号",
    // eslint-disable-next-line no-dupe-keys
    nonce: "Nonce",
    gas_fee_cap: "手续费率上限",
    gas_premium: "节点小费费率",
    gas_limit: "Gas用量上限",
    gas_used: "Gas实际用量",
    base_fee: "基础手续费率",
    all_gas_fee: "手续费",
    params: "参数",
    returns: "返回值",
    message_tranf: "转账信息",
    from_tranf: "发送方",
    to_tranf: "接受方",
    consume_type: "类型",
    MinerTip: "节点手续费",
    BaseFeeBurn: "销毁手续费",
    // Transfer: '转账',
    // Burn: '销毁聚合费用',
    exit_code: "状态",
    //内部交易
    amount: "价值",
    method: "方法",
    topic: "主题",
    //通证转移
    message_ERC20Trans: "通证转移",
    message_NftTrans: "NFTs 转移",
    // 出块列表
    block_cid: "区块Cid",
    block_height: "区块高度",
    block_time: "出块时间",
    block_messages_count: "消息数",
    block_miner_id: "节点地址",
    block_mined_reward: "出块奖励",
    //miner
    message_list: "消息列表",
    block_list: "出块列表",
    traces_list: "转账列表",
    event_log: "事件日志",
    blk_cids_message: "区块消息",
    message_list_total: "共 {{value}} 条消息",
    block_list_total: "总计 {{value}} 区块",
    traces_list_total: "总计 {{value}} 条消息",
    contract_token_list_total: "总计 {{value}} 条Token",
    erc20_transfer_total: "总计 {{value}} 条交易",
    //general
    general_overview_title: "账户概览",
    base_account_id: "账户ID",
    message_count: "消息数",
    //dns detail
    deal_details: "订单详情",
    deal_id: "交易ID",
    epoch: "所属区块",
    service_start_time: "创建时间",
    message_cid: "所属消息",
    piece_cid: "Piece CID",
    verified_deal: "已验证",
    deal_hosting: "托管详情",
    deal_left_title: "客户",
    deal_right_title: "托管节点",
    deal_value: "质押金额",
    deal_cash: "托管费用",
    deal_time: "至",
    user_count: "交易地址",
    transfer_count: "交易次数",
    go_verify: "去验证",
    contract_token_list: "Token",
    token_name: "Token Name",
    contract_id: "Contract Id",
    amount: "Amount",
    //erc20 transfer
    erc20_transfer: "Token交易",
    platform: "交易平台",
    //height
    blcok_time: "区块时间",
    message_count_deduplicate: "区块消息 (去重)",
    miner_id: "节点",
    messages_count: "消息",
    reward: "奖励",
    //cid detail
    block_list: "区块列表",
    blocks_cid: "Cid",
    blocks_miner: "节点",
    blocks_messages: "消息",
    blocks_reward: "奖励",
    win_count: "赢票",
    //cid_details
    message_list_total: "共 {{value}} 条消息",
    chain_cid_detail: "区块详情",
    cid_height: "高度",
    parent_weight: "父块重量",
    parents_cid: "父块CID",
    parent_base_fee: "父基础费率",
    ticket_value: "票值",
    state_root: "根",
    total_balance_tip: "可用余额 + 扇区质押 + 预质押 + 锁仓奖励"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (detail);


/***/ }),

/***/ 9577:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const domain = {
    domain_title: "概览",
    resolved_address: "解析地址",
    expired_at: "过期时间",
    registrant: "注册人",
    controller: "控制人",
    allDomains: "此地址拥有的域名 共{{value}} 个",
    Result_for: "查询结果"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (domain);


/***/ }),

/***/ 2000:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const fevm = {
    tp_token: "添加Token到TokenPocket",
    rank: "排行",
    defi_overview: "DeFi 协议",
    fevm_staked: "FEVM 质押量",
    staked_change_in_24h: "24小时质押",
    total_user: "总用户数",
    user_change_in_24h: "24小时用户数",
    fil_staked: "FIL 质押量",
    defi_list: "DeFi Protocol",
    Protocol: "协议",
    defi_list_time: "上次更新时间: {{value}}",
    tvl: "总锁仓价值",
    tvl_change_rate_in_24h: "24小时变化",
    tvl_change_in_24h: "24小时质押",
    tokens: "占比",
    tokens_tip: "质押在该协议的各Token占比",
    users: "用户数",
    see_more: "查看更多"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (fevm);


/***/ }),

/***/ 8826:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const fvm = {
    hot: "All",
    all: "FVM生态项目总览",
    Defi: "Defi",
    Dex: "Dex",
    DID: "DID",
    NFT: "NFT",
    MarketPlace: "MarketPlace",
    Launchpad: "Launchpad",
    share: "分享FVM生态信息"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (fvm);


/***/ }),

/***/ 3075:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const home = {
    seconds: "秒",
    minutes: "分",
    hours: "时",
    day: "天",
    //mata
    "quality_power/increase_24h": "全网有效算力/24h变化",
    add_power_in_32g: "32GiB扇区新增成本",
    miner_initial_pledge: "当前扇区质押量",
    fil_per_tera_24h: "近24h产出效率",
    total_contract: "活跃合约数",
    "total_contract_24h_contract": "活跃合约数24h变化",
    "total_contract/24h_contract": "活跃合约数/24h变化",
    "contract_transaction": "合约交易数",
    "contract_transaction_24h_change": "合约交易数24h变化",
    "contract_transaction/24h_change": "合约交易数/24h变化",
    "contract_address": "合约交易地址",
    "contract_address_24h_change": "合约交易地址24h变化",
    "contract_address/24h_change": "合约交易地址/24h变化",
    "total_contract/24h_contract_tip": "网络中曾有过交易的合约总数",
    gas_24: "24h Gas消耗",
    verified_contracts: "已验证合约",
    contract_gas: "合约Gas消耗",
    //meta
    meta_title: "全网数据指标",
    mata_show: "展开",
    mata_show_false: "收起",
    latest_height: "最新区块高度",
    latest_block_time: "最新区块时间",
    total_blocks: "全网出块数量",
    total_rewards: "全网出块奖励",
    total_quality_power: "全网有效算力",
    total_quality_power_tip: "当前全网有效算力（有效存储空间）的总和",
    base_fee: "当前基础费率",
    power_increase_24h: "近24h增长算力",
    rewards_increase_24h: "近24h出块奖励",
    fil_per_tera_24h_tip: "最近24小时的总出块奖励与有效算力的比值",
    gas_in_32g: "24小时32G扇区封装每T所需Gas",
    gas_in_32g_meta: "32GiB扇区Gas消耗",
    gas_in_32g_tip: "近24小时密封32G扇区每T所要消耗的Gas值",
    add_power_in_32g_tip: "近24小时32G扇区新增算力所需要花费的成本，包括扇区质押和封装手续费",
    gas_in_64g: "24小时64G扇区封装每T所需Gas",
    gas_in_64g_meta: "64GiB扇区Gas消耗",
    gas_in_64g_tip: "近24小时密封64G扇区每T所要消耗的Gas值",
    add_power_in_64g: "预估64GiB扇区新增算力成本",
    add_power_in_64g_tip: "近24小时64G扇区新增算力所需要花费的成本，包括扇区质押和封装手续费",
    win_count_reward: "每赢票奖励",
    win_count_reward_tip: "最新高度的单位出块奖励，每个高度有多个区块，每个区块均可获得该奖励",
    avg_block_count: "平均每高度区块数量",
    avg_block_count_tip: "最近24h平均每个高度下的区块数量",
    avg_message_count: "平均每高度消息数",
    avg_message_count_tip: "最近24h平均每个高度下的消息数量",
    active_miners: "活跃节点数",
    burnt: "销毁量",
    circulating_percent: "流通率",
    rank: "排行榜",
    footer_text: "Filscan浏览器是 Filecoin 区块链浏览器及数据服务平台.提供基于 Filecoin 的各类节点收益排行榜、区块链数据查询、可视化图表等一站式数据服务.",
    footer_outlook: "邮箱",
    footer_detail_a: "版权所有 \xa9 Filecoin开发补助计划 遵循",
    footer_detail_b: " 和 ",
    footer_detail_c: "版权协议",
    search_notFound: "搜索无结果",
    warn_text: "Oops! 您输入的搜索字符:",
    warn_details: "对不起！这是一个无效的字符串",
    go_home: "返回首页",
    quality_power_Cc: "Commited Capacity (CC)",
    quality_power_Dc: "DataCap (DC)",
    base_gas: "24h基础手续费走势",
    rank: "排行榜",
    contract_rank: "合约排行",
    defi_list: "Defi Protocol",
    blockchain_browser: "区块浏览器"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (home);


/***/ }),

/***/ 3124:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const zh = {
    network_title: "当前网络",
    home: "首页",
    contract: "FEVM",
    contract_verify: "合约验证",
    contract_list: "已验证合约",
    contract_rank: "合约排行",
    defi_dashboard: "DeFi Protocol",
    token: "Tokens",
    nft: "NFTs",
    tipset: "区块链",
    tipset_chain: "区块",
    tipset_message: "消息",
    tipset_ranking: "富豪榜",
    tipset_transfer: "大额转账",
    tipset_dsn: "订单",
    "tipset_pool-message": "消息池",
    ranking: "排行榜",
    network_overview: "网络概览",
    statistics: "统计",
    statistics_gas: "Gas费趋势",
    statistics_base: "算力走势",
    statistics_fil: "FIL",
    statistics_charts: "图表统计",
    statistics_map: "节点地图",
    develop: "开发者",
    resources: "资源",
    resources_tools: "常用工具",
    provider: "存储提供者",
    fvm: "FVM生态总览",
    account: "节点管家"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (zh);


/***/ }),

/***/ 3074:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const rankZh = {
    rank_title: "排行榜",
    rank: "排行榜",
    pool: "存储池排行",
    provider: "节点排行",
    growth: "算力增速",
    rewards: "节点收益",
    "24h": "24时",
    week_days: "7天",
    month: "30天",
    select_rank_all: "全部扇区",
    select_rank_32: "32G 扇区",
    select_rank_64: "64G 扇区",
    more: "更多",
    rank_time: "上次更新时间为",
    see_more: "查看更多",
    //存储池排行
    ranking: "排名",
    pool_owner: "Owner ID",
    pool_power: "有效算力",
    pool_efficiency_24h: "近24h产出效率",
    pool_increase_24h: "近24h算力增量",
    pool_block_count: "出块总数",
    pool_block_count_24h: "近24h出块总数",
    miner: "节点",
    // 节点排行
    provider_miner: "节点",
    provider_power_ratio: "有效算力/占比",
    provider_block_ratio: "近24h 出块/占比",
    provider_rewards_ratio: "近24h 奖励/占比",
    balance: "余额",
    //算力增速
    power_ratio: "算力增速",
    power_ratio_tip: "选定周期内，平均每天完成封装扇区的有效算力总和",
    quality_power_increase: "算力增量",
    quality_power_increase_tip: "选定周期内，节点的有效算力增量",
    quality_adj_power: "有效算力",
    raw_power: "原值算力",
    sector_size: "扇区大小",
    //节点收益
    "rewards/ratio": "出块奖励/占比",
    "rewards/ratio_tip": "在选定周期内，节点获得出块奖励与累计产出区块奖励的比值。",
    block_count: "出块数",
    winning_rate: "赢票率",
    block_count_tip: "Filecoin经济模型中，一个高度（tipset）下可能有多个区块（block），每个区块可能获得多份奖励（win count）。"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (rankZh);


/***/ }),

/***/ 9806:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const statistic = {
    gas_total: "Gas 统计",
    show_more: "更多",
    "24h": "24时",
    "7d": "7天",
    "30d": "30天",
    "1year": "1年",
    // power
    "power": "算力走势",
    power_tips: "基线标准即是Filecoin网络要求的网络增长规模，主网上线时2.5EiB，每年100%增长率。",
    trend_24: "24h基础手续费走势",
    total_raw_byte_power: "原值算力",
    base_line_power: "基线走势",
    power_increase: "算力净增",
    power_decrease: "算力损失",
    change_quality_adj_power: "环比有效算力变化",
    total_quality_adj_power: "有效算力",
    gas: "基础手续费走势",
    base_fee: "基础手续费",
    gas_in_32g: "32GiB 扇区Gas消耗",
    gas_in_64g: "64GiB 扇区Gas消耗",
    //24_gas
    gas_24: "24h Gas 数据",
    method_name: "消息类型",
    avg_gas_premium: "Gas Premium",
    avg_gas_limit: "平均Gas限额",
    avg_gas_used: "平均Gas消耗",
    avg_gas_fee: "平均手续费",
    "sum_gas_fee/ratio": "手续费合计/占比",
    "message_count/ratio": "消息数合计/占比",
    //fil
    TokenRules: "Filecoin通证分配细则",
    FilecoinFoundation: "Filecoin基金会",
    FundraisingRemainder: "募资 – 剩余通证",
    FundraisingSAFT: "募资 – 未来通证简单协议",
    MiningReserve: "为存储服务提供者预留通证",
    TokenAllocation: "存储提供者通证分配",
    ReservedTokens: "存储提供者预留通证",
    Fundraising: "募资形式 – 未来通证简单协议 2017",
    Funds: "募资形式 – 剩余资金",
    protocolLab: "协议实验室",
    Contributors: "协议实验室团队和贡献者",
    Allocation: "分配项目",
    value: "数额",
    description: "具体用途",
    filBase: "FIL的基础发放",
    filBase_des: "网络FIL铸造上限",
    ReservedTokens_des: "为未来Filecoin经济增长而预留的通证储备，具体未来使用方案由Filecoin社区决定",
    TokenAllocation_des: "通过区块奖励、网络初始化等方式分给存储提供者的通证奖励",
    FilecoinFoundation_des: "作为长期社区建设，网络管理费用等",
    Fundraising_des: "2017年出售的通证",
    Funds_des: "用作生态发展和后续融资",
    protocolLab_des: "用作协议实验室的相关工作",
    Contributors_des: "4.5%给协议实验室团队和贡献者",
    //chartsnav
    cc_dc_power: "CC/DC算力走势",
    static_overview: "图表统计",
    contract_trend: "合约交易",
    //charts
    pie_title: "图表统计",
    fil_overview: "FIL概览",
    block_trend: "区块奖励",
    block_reward_per_TiB: "产出效率",
    acc_block_rewards: "累计区块奖励",
    active_nodes: "活跃节点数",
    active_miner_count: "节点数量",
    messages_trend: "消息数走势图",
    message_count: "区块平均消息走势",
    all_message_count: "总消息走势",
    pie_title_a: "当前FIL的用途分布统计",
    pie_title_a_tip: "已提供存储者奖励的Fil + 已释放锁仓奖励的Fil + 已分配保留部分的Fil = 当前已释放的Fil",
    pie_title_b: "当前已释放的Fil用途统计",
    charts_title: "Fil分配细则",
    mined: "已提供存储者奖励的Fil",
    remaining_mined: "剩余存储者奖励的Fil",
    vested: "已释放锁仓奖励的Fil	",
    remaining_vested: "剩余锁仓奖励的Fil",
    reserve_disbursed: "已分配保留部分的Fil(测试网奖励)",
    remaining_reserved: "剩余保留部分的Fil",
    locked: "扇区抵押的Fil",
    burnt: "已销毁的Fil",
    circulating: "可交易流通的Fil",
    dc_trend: "DC",
    cc_trend: "CC",
    networks_overview: "全网指标"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (statistic);


/***/ }),

/***/ 3061:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const tipset = {
    rank: "排名",
    tag: "标签",
    height: "区块高度",
    cid: "消息ID",
    block_time: "时间",
    from: "发送地址",
    to: "接收地址",
    value: "数额",
    method_name: "方法",
    all: "全部方法",
    //chain
    block_list: "区块列表",
    blocks_cid: "Cid",
    blocks_miner: "节点",
    blocks_messages: "消息",
    blocks_reward: "奖励",
    win_count: "赢票",
    //cid_details
    message_list_total: "共 {{value}} 条消息",
    chain_cid_detail: "区块详情",
    cid_height: "高度",
    parent_weight: "父块重量",
    parents_cid: "父块CID",
    parent_base_fee: "父基础费率",
    ticket_value: "票值",
    state_root: "根",
    //message
    message_list: "消息列表",
    total_list: "共 {{value}} 条消息",
    message_list_all: "全部方法",
    message_list_exit_code: "状态",
    message_list_method_name: "方法名称",
    // adress
    address_total_list: "共有 {{value}} 账户",
    address_list: "富豪榜",
    address_all: "全部类型",
    account: "一般账户",
    owner: "所有者账户",
    miner: "节点账户",
    payment: "支付通道",
    multisig: "多签账户",
    account_address: "地址",
    balance_percentage: "余额/占比",
    account_type: "类型",
    latest_transfer_time: "最新交易时间",
    //transfer
    transfer_list: "大额转账",
    transfer_total_list: "共有 {{value}} 条信息",
    //dsn
    dsn_list: "订单列表",
    dsn_total_list: "共 {{value}} 条交易",
    dsn_placeholder: "搜索 客户/托管者/交易ID",
    deal_id: "交易ID",
    piece_cid: "文件ID",
    piece_size: "文件大小",
    client_address: "客户",
    provider_id: "托管者",
    service_start_time: "开始时间",
    end_time: "结束时间",
    start_height: "开始高度",
    end_height: "结束高度",
    storage_price_per_height: "存储费用",
    verified_deal: "已验证",
    // pool-message
    pool_list: "消息池列表",
    gas_fee_cap: "Gas限额",
    gas_premium: "Gas Premium"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (tipset);


/***/ }),

/***/ 275:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7947);
/* harmony import */ var antd_lib_message__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7369);
/* harmony import */ var antd_lib_message__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd_lib_message__WEBPACK_IMPORTED_MODULE_2__);
/** @format */ 


// 创建一个全局的消息管理器
const messageManager = {
    hideMessage: null,
    showMessage: ({ type, duration = 10, content, icon, suffix })=>{
        if (messageManager.hideMessage) {
            messageManager.hideMessage();
        }
        const show_config = {};
        if (icon) {
            show_config.icon = icon;
        }
        messageManager.hideMessage = antd_lib_message__WEBPACK_IMPORTED_MODULE_2___default().open({
            content: suffix ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: "flex gap-x-4 items-center",
                children: [
                    content,
                    " ",
                    suffix
                ]
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: "flex gap-x-4 items-center",
                children: [
                    content,
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "cursor-pointer",
                        onClick: ()=>{
                            messageManager.hide();
                        },
                        children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)("closeIcon")
                    })
                ]
            }),
            duration,
            type,
            ...show_config
        });
    },
    hide: ()=>{
        if (messageManager.hideMessage) {
            messageManager.hideMessage();
            messageManager.hideMessage = null;
        }
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (messageManager);


/***/ }),

/***/ 6423:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2881);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7947);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__]);
_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/** @format */ 



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ options, ns = "home", onChange, header, wrapClassName, className, value, suffix })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns
    });
    const [showLabel, setShowLabel] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("");
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(value);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (value) {
            const file = options.find((v)=>v.value === value);
            setActive(value);
            if (file) setShowLabel(file?.label);
        } else if (options.length > 0) {
            setShowLabel(options[0]?.label);
            setActive(options[0]?.value);
        }
    }, [
        options,
        value
    ]);
    const handleClick = (item)=>{
        setShowLabel(item.label);
        setActive(item.value);
        onChange(item.value);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `group h-fit flex cursor-pointer items-center relative rounded-[5px] w-fit  ${wrapClassName}`,
        children: [
            header ? header : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: "flex justify-between items-center font-PingFang des_bg_color rounded-[5px] font-medium text-xs gap-x-2 px-2 w-full border border_color  min-w-[82px] !h-8",
                children: [
                    tr(showLabel),
                    (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_3__/* .getSvgIcon */ .a)("downIcon")
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                className: `invisible group-hover:visible absolute z-10 inset-y-full h-fit w-max list-none p-4  border rounded-[5px]  select_shadow  border_color ${className}`,
                children: options?.map((item)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                        onClick: ()=>handleClick(item),
                        className: `p-2 rounded-[5px] hover:text-primary ${item.value === active ? "bg-bg_hover text-primary" : ""}`,
                        children: tr(item.label)
                    }, item.value);
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4178:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6764);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styles_common_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7526);
/* harmony import */ var _styles_common_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_common_scss__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_custom_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6333);
/* harmony import */ var _styles_custom_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_custom_scss__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var antd_lib_config_provider__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2616);
/* harmony import */ var antd_lib_config_provider__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(antd_lib_config_provider__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var antd_lib_locale_zh_CN__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9353);
/* harmony import */ var antd_lib_locale_zh_CN__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(antd_lib_locale_zh_CN__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var antd_lib_locale_en_US__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4946);
/* harmony import */ var antd_lib_locale_en_US__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(antd_lib_locale_en_US__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8804);
/* harmony import */ var _components_header__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3340);
/* harmony import */ var _components_Bounday__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8980);
/* harmony import */ var _store_UserStore__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9821);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6641);
/* harmony import */ var next_seo__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_seo__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _components_footer__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(4753);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(9676);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _components_mobile_search__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(8825);
/* harmony import */ var _app_module_scss__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(6209);
/* harmony import */ var _app_module_scss__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(_app_module_scss__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(7987);
/* harmony import */ var _store_DeviceContext__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(2707);
/* harmony import */ var _store_wallet__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(9380);
/* harmony import */ var _i18n__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(1091);
/* harmony import */ var next_app__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(7544);
/* harmony import */ var next_app__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(next_app__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _contents_common__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(5934);
/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(4298);
/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(next_script__WEBPACK_IMPORTED_MODULE_24__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_header__WEBPACK_IMPORTED_MODULE_9__, _components_footer__WEBPACK_IMPORTED_MODULE_14__, _components_mobile_search__WEBPACK_IMPORTED_MODULE_17__, react_i18next__WEBPACK_IMPORTED_MODULE_18__, _store_wallet__WEBPACK_IMPORTED_MODULE_20__, _i18n__WEBPACK_IMPORTED_MODULE_21__, _contents_common__WEBPACK_IMPORTED_MODULE_23__]);
([_components_header__WEBPACK_IMPORTED_MODULE_9__, _components_footer__WEBPACK_IMPORTED_MODULE_14__, _components_mobile_search__WEBPACK_IMPORTED_MODULE_17__, react_i18next__WEBPACK_IMPORTED_MODULE_18__, _store_wallet__WEBPACK_IMPORTED_MODULE_20__, _i18n__WEBPACK_IMPORTED_MODULE_21__, _contents_common__WEBPACK_IMPORTED_MODULE_23__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 

























App.getInitialProps = async (context)=>{
    const initialProps = await next_app__WEBPACK_IMPORTED_MODULE_22___default().getInitialProps(context);
    const regex = RegExp("Android|iPhone");
    if (context.ctx.req) {
        return {
            ...initialProps,
            isMobile: regex.test(context.ctx.req.headers["user-agent"])
        };
    }
    return {
        isMobile: window.innerWidth < 1000,
        ...initialProps
    };
};
//@ts-ignore
function App({ Component, pageProps, isMobile }) {
    const { t } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_18__.useTranslation)("home");
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_13__.useRouter)();
    const [userInfo, setUserInfo] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)();
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)(true);
    const [lang, setLang] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)("zh");
    const [theme, setTheme] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)("light");
    const [wallet, setWallet] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({
        wallet: "",
        account: ""
    });
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        const theme_Local = localStorage.getItem("theme");
        let lang_Local = localStorage.getItem("lang");
        const wallet_local = localStorage.getItem("wallet");
        const wallet_store = JSON.parse(wallet_local || "{}");
        if (!wallet?.account) {
            setWallet(wallet_store);
        }
        if (router.locale) {
            lang_Local = router.locale;
        }
        if (!lang_Local) {
            lang_Local = navigator.language.startsWith("zh") ? "zh" : "en";
        }
        loadTheme(theme_Local);
        if (theme_Local) setTheme(theme_Local);
        _i18n__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z.changeLanguage(lang_Local); // 更改i18n语言
        if (lang_Local) setLang(lang_Local);
        setLoading(false);
    }, []);
    const loadTheme = (theme_Local)=>{
        if (theme_Local === "dark") {
            document.documentElement.setAttribute("theme", "dark");
        } else {
            document.documentElement.setAttribute("theme", "light");
        }
    };
    // useEffect(() => {
    //   if (localStorage?.getItem('userInfo')) {
    //     const lastUser = JSON.parse(localStorage?.getItem('userInfo') || '');
    //     if (lastUser) {
    //       setUserInfo(lastUser);
    //     }
    //   }
    // }, []);
    if (loading) {
        return null;
    }
    const { locale } = router;
    const seo = _contents_common__WEBPACK_IMPORTED_MODULE_23__/* .SEO */ .HJ[lang];
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_seo__WEBPACK_IMPORTED_MODULE_12__.NextSeo, {
                title: seo.title,
                description: seo.description,
                canonical: seo.url,
                additionalMetaTags: [
                    {
                        name: "keywords",
                        content: seo.keywords
                    }
                ],
                languageAlternates: [
                    {
                        hrefLang: "en",
                        href: "https://www.example.com/en-US"
                    },
                    {
                        hrefLang: "zh",
                        href: "https://www.example.com/zh-CN"
                    }
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_script__WEBPACK_IMPORTED_MODULE_24___default()), {
                src: "https://www.googletagmanager.com/gtag/js?id=G-VZ0MMF5MLC"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_script__WEBPACK_IMPORTED_MODULE_24___default()), {
                id: "google-analytics",
                children: `
         window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'G-VZ0MMF5MLC');
        `
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Bounday__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_store_DeviceContext__WEBPACK_IMPORTED_MODULE_19__/* .DeviceContext */ .T.Provider, {
                    value: {
                        isMobile
                    },
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_store_FilscanStore__WEBPACK_IMPORTED_MODULE_8__/* .FilscanStoreContext */ .k.Provider, {
                        value: {
                            theme,
                            setTheme: (value)=>{
                                loadTheme(value);
                                setTheme(value);
                            },
                            lang,
                            setLang
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_store_UserStore__WEBPACK_IMPORTED_MODULE_11__/* .UserStoreContext */ ._.Provider, {
                            value: {
                                ...userInfo,
                                setUserInfo
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_store_wallet__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .ZP.Provider, {
                                value: {
                                    wallet,
                                    setWallet: (walletItem)=>{
                                        setWallet(walletItem);
                                    }
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_config_provider__WEBPACK_IMPORTED_MODULE_4___default()), {
                                    locale: lang === "zh" ? (antd_lib_locale_zh_CN__WEBPACK_IMPORTED_MODULE_5___default()) : (antd_lib_locale_en_US__WEBPACK_IMPORTED_MODULE_6___default()),
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: classnames__WEBPACK_IMPORTED_MODULE_16___default()(`container_body text-sm ${theme}`),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_header__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {}),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_15__/* .MobileView */ .$, {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_mobile_search__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                                    className: (_app_module_scss__WEBPACK_IMPORTED_MODULE_25___default().search)
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: classnames__WEBPACK_IMPORTED_MODULE_16___default()((_app_module_scss__WEBPACK_IMPORTED_MODULE_25___default().home), (_app_module_scss__WEBPACK_IMPORTED_MODULE_25___default().component)),
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                                                    ...pageProps
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_footer__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {})
                                        ]
                                    })
                                })
                            })
                        })
                    })
                })
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_router__WEBPACK_IMPORTED_MODULE_13__.withRouter)(App));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3162:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ant_design_cssinjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2727);
/* harmony import */ var _ant_design_cssinjs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_ant_design_cssinjs__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6859);
/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_document__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4298);
/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_script__WEBPACK_IMPORTED_MODULE_4__);





const MyDocument = ()=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(next_document__WEBPACK_IMPORTED_MODULE_3__.Html, {
        lang: "en",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(next_document__WEBPACK_IMPORTED_MODULE_3__.Head, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: "Filscan Filecoin Explorer"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        httpEquiv: "X-UA-Compatible",
                        content: "IE=edge,chrome=1"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=0, minimum-scale=1,user-scalable=no"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: "Filscan.io is a Filecoin blockchain explorer and data service platform.It offers a range of one-stop data services, including mining ranking, blockchain data query, visualization charts, and FVM ecosystem data analysis."
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "keywords",
                        content: "Filecoin官方区块浏览器,Filecoin官方浏览器, Filecoin Explorer,fvm,Filscan,Filecoin, blockchain, crypto, currency,最新区块,FIL,IPFS，FIL,Filecoin区块链查询浏览器,FIL浏览器,Filecoin浏览器,Filecoin区块查询,区块链搜索引擎,区块高度,区块链交易"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "alternate",
                        href: "https://filscan.io/kr",
                        hrefLang: "kr-US"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "alternate",
                        href: "https://filscan.io/en",
                        hrefLang: "en-US"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "alternate",
                        href: "https://filscan.io",
                        hrefLang: "zh-CN"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                        rel: "icon",
                        href: "https://filscan-v2.oss-accelerate.aliyuncs.com/client/logo.ico"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_script__WEBPACK_IMPORTED_MODULE_4___default()), {
                        src: "https://hm.baidu.com/hm.js?db68ddd1d28effdabb6dfc9f07258667",
                        strategy: "lazyOnload"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("script", {
                        async: true,
                        src: "https://www.googletagmanager.com/gtag/js?id=G-VZ0MMF5MLC"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("script", {
                        dangerouslySetInnerHTML: {
                            __html: `
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());

            gtag('config', 'G-VZ0MMF5MLC');
            `
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_script__WEBPACK_IMPORTED_MODULE_4___default()), {
                        src: "https://hm.baidu.com/hm.js?db68ddd1d28effdabb6dfc9f07258667",
                        strategy: "lazyOnload"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("body", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_document__WEBPACK_IMPORTED_MODULE_3__.Main, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_document__WEBPACK_IMPORTED_MODULE_3__.NextScript, {})
                ]
            })
        ]
    });
MyDocument.getInitialProps = async (ctx)=>{
    const cache = (0,_ant_design_cssinjs__WEBPACK_IMPORTED_MODULE_2__.createCache)();
    const originalRenderPage = ctx.renderPage;
    ctx.renderPage = ()=>originalRenderPage({
            enhanceApp: (App)=>(props)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ant_design_cssinjs__WEBPACK_IMPORTED_MODULE_2__.StyleProvider, {
                        cache: cache,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(App, {
                            ...props
                        })
                    })
        });
    const initialProps = await next_document__WEBPACK_IMPORTED_MODULE_3___default().getInitialProps(ctx);
    const style = (0,_ant_design_cssinjs__WEBPACK_IMPORTED_MODULE_2__.extractStyle)(cache, true);
    return {
        ...initialProps,
        styles: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                initialProps.styles,
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("style", {
                    dangerouslySetInnerHTML: {
                        __html: style
                    }
                })
            ]
        })
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyDocument);


/***/ }),

/***/ 2707:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   T: () => (/* binding */ DeviceContext)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const DeviceContext = react__WEBPACK_IMPORTED_MODULE_0___default().createContext({
    isMobile: false
});


/***/ }),

/***/ 8804:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   J: () => (/* binding */ useFilscanStore),
/* harmony export */   k: () => (/* binding */ FilscanStoreContext)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/** @format */ 
const FilscanStoreContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)(null);
// export const FilscanStoreProvider = ({
//   children,
// }: {
//   //children: JSX.Element;
// }) => {
//   const [theme, setTheme] = useState<string>('light');
//   const [lang, setLang] = useState<string>('zh');
//   // useEffect(() => {
//   //   const theme_Local = localStorage.getItem('theme');
//   //   const lang_Local = localStorage.getItem('lang');
//   //   if (theme_Local) setTheme(theme_Local);
//   //   if (lang_Local) setLang(lang_Local);
//   //   loadTheme(theme_Local);
//   // }, []);
//   // const loadTheme = (theme_Local: any) => {
//   //   if (theme_Local === 'dark') {
//   //     document.documentElement.setAttribute('theme', 'dark');
//   //   } else {
//   //     document.documentElement.setAttribute('theme', 'light');
//   //   }
//   // };
//   const value = {
//     theme,
//     setTheme,
//     lang,
//     setLang,
//   };
//   return (
//     <FilscanStoreContext.Provider
//       value={{
//         theme,
//         setTheme: (value: any) => {
//           //loadTheme(value);
//           setTheme(value);
//         },
//         lang,
//         setLang,
//       }}>
//       {children}
//     </FilscanStoreContext.Provider>
//   );
// };
const useFilscanStore = ()=>{
    const context = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(FilscanStoreContext);
    if (!context) {
        throw new Error("useFilscanStore must be used within a FilscanStoreProvider");
    }
    return context;
};


/***/ }),

/***/ 9821:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _: () => (/* binding */ UserStoreContext),
/* harmony export */   a: () => (/* binding */ UserInfo)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/** @format */ 
const UserStoreContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)(null);
const UserInfo = ()=>{
    const context = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(UserStoreContext);
    if (!context) {
        throw new Error("useFilscanStore must be used within a FilscanStoreProvider");
    }
    return context;
};


/***/ }),

/***/ 785:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/** @format */ async function fetchData(url, body, options = {
    maxRetries: 3,
    timeout: 0
}) {
    const { maxRetries, timeout } = options;
    const newBody = body || {};
    let retries = 0;
    let error = null;
    let data = null;
    const token = localStorage.getItem("token"); // 从 localStorage 获取 token
    while(retries < maxRetries){
        try {
            const controller = new AbortController();
            let timeoutId;
            if (timeout > 0) {
                timeoutId = setTimeout(()=>controller.abort(), timeout);
            }
            const response = await fetch(url, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `${token}`
                },
                body: JSON.stringify(newBody),
                signal: controller.signal
            });
            if (response.status === 401) {
                //message.warning('please login ');
                // Router.push('/account/login');
                return {
                    result: null,
                    error: "Invalid credentials"
                };
            }
            data = await response.json();
            if (timeoutId) {
                clearTimeout(timeoutId);
            }
            break; // 请求成功，跳出循环
        } catch (err) {
            error = err;
            retries += 1;
        }
    }
    if (data) {
        return data?.result || data || {};
    } else {
        return {
            result: null,
            error: error ? error.message : "请求失败"
        };
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (fetchData);


/***/ }),

/***/ 8108:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
/* harmony import */ var use_deep_compare_effect__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4612);
/* harmony import */ var use_deep_compare_effect__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(use_deep_compare_effect__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _packages_message__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(275);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__]);
axios__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const DefaultOptions = {
    method: "post",
    maxRetries: 3,
    timeout: 0,
    isCancel: true
};
// 用于存储每个 URL 和方法的取消令牌
const cancelTokenSources = {};
let current = {};
function useAxiosData(initialUrl, initialPayload = {}, initialOptions) {
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const axiosData = async (url, payload, options = DefaultOptions)=>{
        const { method = "post", maxRetries = 3, timeout = 0, flag, isCancel = true, loading = true } = {
            ...DefaultOptions,
            ...options
        };
        const body = payload || {};
        let error = null;
        let data = null;
        const token = localStorage.getItem("token"); // 从 localStorage 获取 token
        if (loading) {
            setLoading(true);
        }
        // 创建一个键，包含 URL 和方法
        let key = "";
        if (isCancel) {
            key = flag ? `${method}:${url}_${flag}` : `${method}:${url}`;
        }
        // 如果这个 URL 和方法已经有一个正在进行的请求，取消它
        if (cancelTokenSources[key]) {
            cancelTokenSources[key].cancel("Cancelled because of new request");
        }
        // 创建一个新的取消令牌
        const cancelTokenSource = axios__WEBPACK_IMPORTED_MODULE_1__["default"].CancelToken.source();
        if (key) {
            cancelTokenSources[key] = cancelTokenSource;
        }
        let currentKey = `${method}:${url}`;
        if (currentKey) {
            current[currentKey] = current[currentKey] || 1;
        }
        if (currentKey) {
            while(Number(current[currentKey]) < maxRetries){
                try {
                    const response = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].request({
                        url,
                        method,
                        data: body,
                        headers: {
                            "Content-Type": "application/json",
                            Authorization: `${token}`
                        },
                        timeout: timeout,
                        cancelToken: cancelTokenSource.token
                    });
                    if (response.status === 401) {
                        next_router__WEBPACK_IMPORTED_MODULE_3___default().push("/account/login");
                        current[currentKey] = 100;
                        setData({
                            result: null,
                            error: "Invalid credentials"
                        });
                        setLoading(false);
                        current[currentKey] = 0;
                        return response.data;
                    }
                    if (response.data && response.data.code) {
                        current[currentKey] = 0;
                        return _packages_message__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z.showMessage({
                            type: "error",
                            content: response.data.message
                        });
                    }
                    data = response.data || response || {};
                    setData(data?.result || data || {});
                    setLoading(false);
                    current[currentKey] = 0;
                    return data?.result || data // 请求成功，跳出循环
                    ;
                } catch (thrown) {
                    current[currentKey] = current[currentKey] + 1;
                    if (axios__WEBPACK_IMPORTED_MODULE_1__["default"].isCancel(thrown)) {
                        console.log("Request canceled", thrown.message);
                        break; //取消请求，跳出循环
                    } else {
                        if (current[currentKey] < maxRetries) {
                            return axiosData(url, payload, options);
                        } else {
                            setError(thrown);
                            setLoading(false);
                            setData({
                                result: null,
                                error: "Error"
                            });
                            if (current[currentKey] === maxRetries) {
                                current[currentKey] = 0;
                                if (thrown?.response?.status === 401) {
                                    setData({
                                        result: null,
                                        error: "Invalid credentials"
                                    });
                                    return null;
                                }
                                setData({
                                    result: null,
                                    error: "Invalid credentials"
                                });
                                return null;
                            }
                        // return notification.error({
                        //   className: 'custom-notification',
                        //   message: 'Error',
                        //   duration: 100,
                        //   description: thrown?.message || 'Network Error'
                        // })
                        }
                    }
                }
            }
        }
    };
    use_deep_compare_effect__WEBPACK_IMPORTED_MODULE_2___default()(()=>{
        if (initialUrl) {
            axiosData(initialUrl, initialPayload, initialOptions);
        }
    }, [
        initialUrl,
        initialPayload,
        initialOptions
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        // 组件卸载时取消所有请求
        return ()=>{
            current = {};
            Object.values(cancelTokenSources).forEach((source)=>source.cancel("Component unmounted"));
        };
    }, []);
    return {
        data,
        loading,
        error,
        axiosData
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useAxiosData);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9380:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ZP: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports getNetWork, addNetwork, connect_account */
/* harmony import */ var web3__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4325);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([web3__WEBPACK_IMPORTED_MODULE_0__]);
web3__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

async function getNetWork() {
    const web3 = new Web3(window.ethereum);
    const chainId = await web3.eth.getChainId();
    return Number(chainId) === 314;
}
const addNetwork = async ()=>{
    if (window.ethereum) {
        try {
            const res = await window.ethereum.request({
                method: "wallet_switchEthereumChain",
                params: [
                    {
                        chainId: "0x13a"
                    }
                ]
            });
            return true;
        } catch (e) {
            if (e.code === 4902) {
                try {
                    //添加网络
                    const res = await window.ethereum.request({
                        method: "wallet_addEthereumChain",
                        params: [
                            {
                                chainId: "0x13a",
                                chainName: "Filecoin - Mainnet",
                                nativeCurrency: {
                                    name: "Mainnet",
                                    symbol: "FIL",
                                    decimals: 18
                                },
                                rpcUrls: [
                                    "https://api.node.glif.io/"
                                ],
                                blockExplorerUrls: [
                                    "https://filscan.io"
                                ]
                            }
                        ]
                    });
                    return true;
                } catch (addError) {
                    console.error(addError);
                }
            }
        }
    } else {
        // if no window.ethereum then MetaMask is not installed
        alert("MetaMask is not installed. Please consider installing it: https://metamask.io/download.html");
    }
};
const connect_account = ()=>{
    return new Promise((resolve, reject)=>{
        window.ethereum.request({
            method: "eth_requestAccounts"
        }).then((res)=>{
            if (res) {
                resolve(res[0]);
            }
        }).catch((error)=>{
            if (error.code === 4001) {
                console.log("Please connect to TokenPocket Extension.");
            } else {
                console.error(error);
            }
        });
    });
};

const WalletState = (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({
    wallet: "",
    account: "zh-CN"
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WalletState);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7947:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ getSvgIcon)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/** @format */ 
const moon = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
    width: "28px",
    height: "28px",
    viewBox: "0 0 28 28",
    version: "1.1",
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    children: [
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("defs", {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("filter", {
                id: "filter-1",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feColorMatrix", {
                    in: "SourceGraphic",
                    type: "matrix",
                    values: "0 0 0 0 0.002548 0 0 0 0 0.002367 0 0 0 0 0.002367 0 0 0 1.000000 0"
                })
            })
        }),
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "页面-1",
            stroke: "none",
            strokeWidth: "1",
            fill: "none",
            fillRule: "evenodd",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                id: "月亮",
                transform: "translate(-878.000000, -22.000000)",
                filter: "url(#filter-1)",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                    transform: "translate(878.000000, 22.000000)",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                        id: "编组-16",
                        transform: "translate(0.008511, 0.001793)",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                d: "M15.678042,7 C18.7357203,7.7699021 21,10.5385734 21,13.8359161 C21,17.7288951 17.844028,20.8848671 13.951049,20.8848671 C10.4586853,20.8848671 7.55960839,18.3452867 7,15.0119161 C7.70293706,15.2645035 8.46109091,15.4023497 9.25174825,15.4023497 C12.9285594,15.4023497 15.9090909,12.4218182 15.9090909,8.74500699 C15.9090909,8.15367832 15.8319441,7.57958042 15.687049,7.03367832 L15.6776503,7 L15.678042,7 Z M17.1489231,8.90634965 L17.0823497,8.86405594 L17.0827413,8.87972028 C17.0106853,13.1431608 13.5324196,16.5771748 9.25174825,16.5771748 C9.11116084,16.5771748 8.97135664,16.5732587 8.83194406,16.5662098 L8.74422378,16.5599441 L8.78064336,16.6284755 C9.78540167,18.4848414 11.708006,19.6603143 13.8182937,19.7084755 L13.951049,19.710042 C17.1951329,19.710042 19.8251748,17.08 19.8251748,13.8359161 C19.8251748,11.7944615 18.7748811,9.96290909 17.1489231,8.90634965 L17.1489231,8.90634965 Z",
                                id: "形状",
                                fill: "currentColor",
                                fillRule: "nonzero"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                                id: "矩形备份-2",
                                strokeOpacity: "0.2",
                                stroke: "currentColor",
                                strokeWidth: "0.5",
                                x: "0.25",
                                y: "0.25",
                                width: "27.5",
                                height: "27.5",
                                rx: "5"
                            })
                        ]
                    })
                })
            })
        })
    ]
});
const sun = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "28px",
    height: "28px",
    viewBox: "0 0 28 28",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "页面-1",
        stroke: "none",
        strokeWidth: "1",
        fill: "#ffffff",
        fillRule: "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "切图",
            transform: "translate(-801.000000, -94.000000)",
            fill: "#ffffff",
            fillRule: "nonzero",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                fill: "#ffffff",
                d: "M814.924528,113.584906 C815.237087,113.584906 815.490566,113.838384 815.490566,114.150943 L815.490566,115.283019 C815.490566,115.595578 815.237087,115.849057 814.924528,115.849057 C814.611969,115.849057 814.358491,115.595578 814.358491,115.283019 L814.358491,114.150943 C814.358491,113.838384 814.611969,113.584906 814.924528,113.584906 Z M819.893455,112.092866 L820.528125,112.727535 C820.749233,112.948644 820.749233,113.30684 820.528125,113.527948 C820.422046,113.634254 820.278009,113.693956 820.12783,113.693868 C819.98296,113.693868 819.83809,113.638679 819.727712,113.527948 L819.093042,112.893278 C818.871934,112.67217 818.871934,112.313974 819.093042,112.092866 C819.314151,111.871757 819.672347,111.871757 819.893455,112.092866 Z M810.756191,112.092866 C810.9773,112.313974 810.9773,112.67217 810.756191,112.893278 L810.121521,113.527948 C810.015479,113.634311 809.871419,113.694023 809.721226,113.693868 C809.576356,113.693868 809.431486,113.638679 809.321108,113.527948 C809.1,113.30684 809.1,112.948644 809.321108,112.727535 L809.955778,112.092866 C810.176887,111.871757 810.535083,111.871757 810.756191,112.092866 Z M814.924528,103.396226 C817.425531,103.396226 819.45283,105.423703 819.45283,107.924528 C819.45283,110.425354 817.425531,112.45283 814.924528,112.45283 C812.423526,112.45283 810.396226,110.425354 810.396226,107.924528 C810.396226,105.423703 812.423526,103.396226 814.924528,103.396226 Z M814.924528,104.528302 C813.051828,104.528302 811.528302,106.051828 811.528302,107.924528 C811.528302,109.797229 813.051828,111.320755 814.924528,111.320755 C816.797229,111.320755 818.320755,109.797229 818.320755,107.924528 C818.320755,106.051828 816.797229,104.528302 814.924528,104.528302 Z M808.698113,107.358491 C809.010672,107.358491 809.264151,107.611969 809.264151,107.924528 C809.264151,108.237087 809.010672,108.490566 808.698113,108.490566 L807.566038,108.490566 C807.253479,108.490566 807,108.237087 807,107.924528 C807,107.611969 807.253479,107.358491 807.566038,107.358491 L808.698113,107.358491 Z M822.283019,107.358491 C822.595578,107.358491 822.849057,107.611969 822.849057,107.924528 C822.849057,108.237087 822.595578,108.490566 822.283019,108.490566 L821.150943,108.490566 C820.838384,108.490566 820.584906,108.237087 820.584906,107.924528 C820.584906,107.611969 820.838384,107.358491 821.150943,107.358491 L822.283019,107.358491 Z M810.121521,102.320932 L810.756191,102.955601 C810.9773,103.17671 810.9773,103.534906 810.756191,103.756014 C810.65013,103.862348 810.506082,103.922056 810.355896,103.921934 C810.211026,103.921934 810.066156,103.866745 809.955778,103.756014 L809.321108,103.121344 C809.1,102.900236 809.1,102.54204 809.321108,102.320932 C809.542217,102.099823 809.900413,102.099823 810.121521,102.320932 Z M820.528125,102.320932 C820.749233,102.54204 820.749233,102.900236 820.528125,103.121344 L819.893455,103.756014 C819.787413,103.862377 819.643353,103.922089 819.49316,103.921934 C819.34829,103.921934 819.20342,103.866745 819.093042,103.756014 C818.871934,103.534906 818.871934,103.17671 819.093042,102.955601 L819.727712,102.320932 C819.948821,102.099823 820.307017,102.099823 820.528125,102.320932 Z M814.924528,100 C815.237087,100 815.490566,100.253479 815.490566,100.566038 L815.490566,101.698113 C815.490566,102.010672 815.237087,102.264151 814.924528,102.264151 C814.611969,102.264151 814.358491,102.010672 814.358491,101.698113 L814.358491,100.566038 C814.358491,100.253479 814.611969,100 814.924528,100 Z",
                id: "形状结合"
            })
        })
    })
});
const network = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "28px",
    height: "28px",
    viewBox: "0 0 28 28",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "页面-1",
        stroke: "none",
        strokeWidth: "1",
        fill: "currentColor",
        fillRule: "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "切图",
            transform: "translate(-761.000000, -94.000000)",
            fill: "currentColor",
            fillRule: "nonzero",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M774.981383,101 C771.124867,101 768,104.124867 768,107.981383 C768,111.837899 771.124867,114.962766 774.981383,114.962766 C778.837899,114.962766 781.962766,111.837899 781.962766,107.981383 C781.962766,104.124867 778.837899,101 774.981383,101 Z M780.998404,107.515957 L779.154388,107.515957 C779.074335,105.500665 778.486037,103.719947 777.596144,102.53125 C779.492287,103.442553 780.828059,105.314495 780.998404,107.515957 Z M778.21609,107.515957 L775.446809,107.515957 L775.446809,101.999734 C776.942686,102.398138 778.098803,104.684309 778.21609,107.515957 Z M774.515957,101.999734 L774.515957,107.515957 L771.746676,107.515957 C771.863963,104.684309 773.02008,102.398138 774.515957,101.999734 Z M772.367553,102.53125 C771.476729,103.719947 770.889362,105.500665 770.809309,107.515957 L768.964362,107.515957 C769.134707,105.314495 770.470479,103.442553 772.367553,102.53125 Z M768.964362,108.446809 L770.808378,108.446809 C770.888431,110.462101 771.476729,112.242819 772.366622,113.431516 C770.470479,112.520213 769.134707,110.648271 768.964362,108.446809 Z M771.746676,108.446809 L774.515957,108.446809 L774.515957,113.963032 C773.02008,113.564628 771.863963,111.278457 771.746676,108.446809 Z M775.446809,113.963032 L775.446809,108.446809 L778.21609,108.446809 C778.098803,111.278457 776.942686,113.564628 775.446809,113.963032 Z M777.595213,113.431516 C778.486037,112.242819 779.073404,110.462101 779.153457,108.446809 L780.997473,108.446809 C780.828059,110.648271 779.492287,112.520213 777.595213,113.431516 Z",
                id: "形状",
                fill: "currentColor"
            })
        })
    })
});
const downIcon = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    width: "12px",
    height: "8px",
    viewBox: "0 0 10 6",
    version: "1.1",
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "页面-1",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        opacity: "0.6",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "切图",
            transform: "translate(-706.000000, -87.000000)",
            stroke: "currentColor",
            strokeWidth: "1.3",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("polyline", {
                id: "路径-2",
                points: "707 88 710.94397 92 715 88"
            })
        })
    })
});
const uploadIcon = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "14px",
    height: "14px",
    viewBox: "0 0 14 14",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "页面-1",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "所需icon",
            transform: "translate(-12.000000, -62.000000)",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                id: "上传icon",
                transform: "translate(12.000000, 62.000000)",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                        id: "矩形",
                        x: "0",
                        y: "0",
                        width: "14",
                        height: "14"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M7.44997704,7.82275886 L9.24986364,9.62264545 C9.49837671,9.87115853 9.49837671,10.2740778 9.24986364,10.5225909 C9.00133464,10.7711199 8.59840311,10.771164 8.34981973,10.5226894 L7.63636364,9.80954545 L7.63636364,12.7272727 C7.63636364,13.0787267 7.35145393,13.3636364 7,13.3636364 C6.64854607,13.3636364 6.36363636,13.0787267 6.36363636,12.7272727 L6.36363636,9.80827273 L5.64992037,10.5224454 C5.42640008,10.7461087 5.07778549,10.7685794 4.82913048,10.5897855 L4.75011409,10.5225909 L4.75011409,10.5225909 C4.52645259,10.298931 4.50408528,9.9502019 4.68301297,9.70152686 L4.75011462,9.62264598 L4.75011462,9.62264598 L6.55002084,7.82275674 C6.79853876,7.5742454 7.20146029,7.57424635 7.44997704,7.82275886 Z M7,0.636363636 C9.22812685,0.636363636 11.1168375,2.25177142 11.5737502,4.44325021 L11.5842746,4.50163636 L11.6335958,4.52125169 C12.9947944,5.09534487 13.9356156,6.44585801 13.9968246,7.99905299 L14,8.16042781 C14,10.3311727 12.2949704,12.0909091 10.1917098,12.0909091 C9.85118194,12.0909091 9.57512953,11.8059994 9.57512953,11.4545455 C9.57512953,11.1030915 9.85118194,10.8181818 10.1917098,10.8181818 C11.6139146,10.8181818 12.7668394,9.62826482 12.7668394,8.16042781 C12.7668394,6.99974908 12.0394719,5.98711253 10.9948271,5.63408188 L10.8729065,5.59630393 L10.4704891,5.48273419 L10.4229694,5.05495967 C10.2247798,3.27084899 8.75512838,1.90909091 7,1.90909091 C5.29226976,1.90909091 3.85491264,3.19825644 3.59619078,4.91123361 L3.57737842,5.05494421 L3.52991371,5.48286195 L3.12735575,5.59641601 C2.01759469,5.90945882 1.23316062,6.95505583 1.23316062,8.16042781 C1.23316062,9.62826482 2.38608539,10.8181818 3.80829016,10.8181818 C4.14881806,10.8181818 4.42487047,11.1030915 4.42487047,11.4545455 C4.42487047,11.8059994 4.14881806,12.0909091 3.80829016,12.0909091 C1.70502958,12.0909091 0,10.3311727 0,8.16042781 C0,6.53982126 0.958360642,5.11506416 2.36673733,4.52128609 L2.41510881,4.50163636 L2.42650167,4.44343195 C2.87247264,2.30284002 4.68471416,0.711815178 6.84510781,0.638971725 L7,0.636363636 Z",
                        id: "形状",
                        fill: "currentColor",
                        fillRule: "nonzero"
                    })
                ]
            })
        })
    })
});
const closeIcon = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "12px",
    height: "12px",
    viewBox: "0 0 12 12",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "20220814",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        opacity: "0.6",
        "stroke-linecap": "square",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "切图",
            transform: "translate(-76.000000, -330.000000)",
            stroke: "#000000",
            strokeWidth: "1.2",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                id: "编组-3",
                transform: "translate(77.000000, 331.000000)",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M9.5,0.5 L0.5,9.5 M0.5,0.5 L9.5,9.5",
                    id: "形状结合"
                })
            })
        })
    })
});
const addIcon = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "13px",
    height: "14px",
    viewBox: "0 0 13 14",
    version: "1.1",
    children: [
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
            children: "形状结合"
        }),
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "20220814",
            stroke: "none",
            strokeWidth: "1",
            fill: "currentColor",
            fillRule: "evenodd",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                id: "切图",
                transform: "translate(-46.000000, -273.000000)",
                fill: "currentColor",
                fillRule: "nonzero",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M56.8981,273 C58.0576062,273 59,273.942394 59,275.1019 L59,283.923272 C59,285.081205 58.0576062,286.023599 56.8981,286.023599 L48.1019,286.023599 C46.9423938,286.023599 46,285.081205 46,283.923272 L46,275.1019 C46,273.942394 46.9423938,273 48.1019,273 L56.8981,273 Z M56.8981,274.408084 L48.1019,274.408084 C47.7195934,274.408084 47.4080842,274.719593 47.4080842,275.1019 L47.4080842,283.923272 C47.4080842,284.305579 47.7195934,284.617088 48.1019,284.617088 L56.8981,284.617088 C57.2804066,284.617088 57.5919158,284.305579 57.5919158,283.923272 L57.5919158,275.1019 C57.5919158,274.719593 57.2804066,274.408084 56.8981,274.408084 Z M52.5306789,276.181169 C52.9192787,276.181169 53.2339403,276.495825 53.2339403,276.884425 L53.233,278.709 L55.0589374,278.709428 C55.4475372,278.709428 55.7621929,279.024083 55.7621929,279.412683 C55.7621929,279.801283 55.4475372,280.115939 55.0589374,280.115939 L53.233,280.115 L53.2339403,281.939368 C53.2355077,282.327968 52.9192787,282.642624 52.5306789,282.642624 C52.1420791,282.642624 51.8274235,282.327968 51.8274235,281.939368 L51.827,280.115 L50.0039937,280.115939 C49.6153939,280.115939 49.3007382,279.801283 49.3007382,279.412683 C49.3007382,279.024083 49.6153939,278.709428 50.0039937,278.709428 L51.827,278.709 L51.8274235,276.884425 C51.8274235,276.495825 52.1420791,276.181169 52.5306789,276.181169 Z",
                    id: "形状结合"
                })
            })
        })
    ]
});
const successIcon = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "14px",
    height: "14px",
    viewBox: "0 0 14 14",
    version: "1.1",
    children: [
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
            children: "成功icon"
        }),
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "页面-1",
            stroke: "none",
            strokeWidth: "1",
            fill: "none",
            fillRule: "evenodd",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                id: "所需icon",
                transform: "translate(-12.000000, -9.000000)",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                    id: "成功",
                    transform: "translate(12.000000, 9.000000)",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                            id: "椭圆形",
                            fill: "#40A291",
                            cx: "7",
                            cy: "7",
                            r: "7"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                            d: "M6.14630333,9.95510386 C5.96024123,9.95510386 5.78199687,9.88161715 5.65065892,9.7502792 L3.47732857,7.57694885 C3.20370784,7.30332812 3.20370784,6.86084432 3.47732857,6.58722359 C3.7509493,6.31360286 4.1934331,6.31360286 4.46705383,6.58722359 L6.14630333,8.26490954 L9.53294617,4.8782667 C9.8065669,4.60464597 10.2490507,4.60464597 10.5226714,4.8782667 C10.7962922,5.15188742 10.7962922,5.59437123 10.5226714,5.86799196 L6.64038419,9.7502792 C6.50904624,9.88161715 6.33236542,9.95510386 6.14630333,9.95510386 Z",
                            id: "路径",
                            fill: "#FFFFFF",
                            fillRule: "nonzero"
                        })
                    ]
                })
            })
        })
    ]
});
const pendingIcon = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "14px",
    height: "14px",
    viewBox: "0 0 14 14",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "页面-1",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "所需icon",
            transform: "translate(-183.000000, -9.000000)",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                id: "编组-3",
                transform: "translate(183.000000, 9.000000)",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                        id: "椭圆形",
                        fill: "#000000",
                        opacity: "0.1",
                        cx: "7",
                        cy: "7",
                        r: "7"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M7,3.3 C7.35438271,3.3 7.64725823,3.56334362 7.69360983,3.90501415 L7.7,4 L7.699,6.798 L10.727887,6.79829608 C11.0822697,6.79829608 11.3751452,7.0616397 11.4214968,7.40331023 L11.427887,7.49829608 C11.427887,7.8526788 11.1645434,8.14555431 10.8228728,8.19190591 L10.727887,8.19829608 L7.6,8.19829608 C6.92690296,8.19829608 6.37328475,7.68674643 6.30671175,7.03121353 L6.3,6.89829608 L6.3,4 C6.3,3.61340068 6.61340068,3.3 7,3.3 Z",
                        id: "路径-5",
                        fill: "#FFFFFF",
                        fillRule: "nonzero"
                    })
                ]
            })
        })
    })
});
const errorIcon = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "14px",
    height: "14px",
    viewBox: "0 0 14 14",
    version: "1.1",
    children: [
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
            children: "失败icon"
        }),
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "页面-1",
            stroke: "none",
            strokeWidth: "1",
            fill: "none",
            fillRule: "evenodd",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                id: "所需icon",
                transform: "translate(-72.000000, -62.000000)",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                    id: "失败icon",
                    transform: "translate(72.000000, 62.000000)",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                            id: "矩形",
                            fill: "#FFFFFF",
                            x: "0",
                            y: "0",
                            width: "14",
                            height: "14"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                            d: "M7,0 C10.86596,0 14,3.134005 14,7 C14,10.86596 10.86596,14 7,14 C3.134005,14 0,10.86596 0,7 C0,3.134005 3.134005,0 7,0 Z",
                            id: "路径",
                            fill: "#E15252",
                            fillRule: "nonzero"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                            d: "M7,6.10005455 L8.34991977,4.75011568 C8.59842933,4.50160261 9.00134579,4.50159976 9.24985886,4.75010932 C9.24986045,4.75011091 9.24986205,4.7501125 9.24986364,4.75011409 C9.49837735,4.99862957 9.49837771,5.40155079 9.24986443,5.6500667 L7.89994545,7 L7.89994545,7 L9.24986364,8.34991818 C9.49837671,8.59843126 9.49837671,9.00135056 9.24986364,9.24986364 C9.00135056,9.49837671 8.59843126,9.49837671 8.34991818,9.24986364 L7,7.89994545 L7,7.89994545 L5.6500667,9.24986443 C5.40155079,9.49837771 4.99862957,9.49837735 4.75011409,9.24986364 C4.50160189,9.0013532 4.50160047,8.59843674 4.75011091,8.34992455 C4.7501125,8.34992295 4.75011409,8.34992136 4.75011568,8.34991977 L6.10005455,7 L6.10005455,7 L4.75011489,5.65006511 C4.50160005,5.40155116 4.50159934,4.99862972 4.7501133,4.75011489 C4.75011356,4.75011462 4.75011383,4.75011436 4.75011409,4.75011409 C4.99862848,4.5015997 5.40154993,4.5015997 5.65006432,4.75011409 C5.65006458,4.75011436 5.65006485,4.75011462 5.65006511,4.75011489 L7,6.10005455 L7,6.10005455 Z",
                            id: "路径",
                            fill: "#FFFFFF",
                            fillRule: "nonzero"
                        })
                    ]
                })
            })
        })
    ]
});
const account_overview = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "14px",
    height: "14px",
    viewBox: "0 0 16 16",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "页面-1",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "切图",
            transform: "translate(-39.000000, -98.000000)",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                id: "编组-6备份",
                transform: "translate(39.000000, 98.000000)",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                        id: "矩形",
                        fill: "currentColor",
                        opacity: "0",
                        x: "0",
                        y: "0",
                        width: "16",
                        height: "16"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M13.6217391,13.8363478 C14.0462609,13.8363478 14.3904348,14.1805217 14.3904348,14.6050435 C14.3904348,15.0295652 14.046087,15.3737391 13.6215652,15.3737391 L2.37878261,15.3737391 C1.95426087,15.3737391 1.61008696,15.0295652 1.61008696,14.6050435 C1.61008696,14.1805217 1.95426087,13.8363478 2.37878261,13.8363478 L13.6217391,13.8363478 Z M12.8852174,2.55795385e-14 C14.1613913,2.55795385e-14 15.2,1.03843478 15.2,2.3146087 L15.2,10.1532174 C15.2,11.4293913 14.1613913,12.468 12.8852174,12.468 L3.11478261,12.468 C1.8386087,12.468 0.8,11.4293913 0.8,10.1532174 L0.8,2.3146087 C0.8,1.03843478 1.8386087,2.55795385e-14 3.11478261,2.55795385e-14 L12.8852174,2.55795385e-14 Z M12.8852174,1.5373913 L3.11478261,1.5373913 C2.68608696,1.53756522 2.3373913,1.88608696 2.3373913,2.31478261 L2.3373913,10.1533913 C2.3373913,10.582087 2.68608696,10.9307826 3.11478261,10.9307826 L12.8852174,10.9307826 C13.313913,10.9307826 13.6626087,10.582087 13.6626087,10.1533913 L13.6626087,2.3146087 C13.6626087,1.88591304 13.313913,1.5373913 12.8852174,1.5373913 Z M11.7175652,4.24052174 C12.017913,4.54034783 12.017913,5.02730435 11.7175652,5.32747826 L8.81808696,8.22730435 C8.67396109,8.37147632 8.47846606,8.45252174 8.2746087,8.45252174 C8.07078261,8.45252174 7.87530435,8.37147826 7.73113043,8.22730435 L6.30817391,6.80434783 L5.3693913,7.74313043 C5.06904348,8.04347826 4.5826087,8.04347826 4.28243478,7.74313043 C3.98208696,7.44278261 3.98208696,6.95634783 4.28243478,6.65617391 L5.76469565,5.17391304 C6.06504348,4.87356522 6.55147826,4.87356522 6.85165217,5.17391304 L8.2746087,6.59686957 L10.6306087,4.24052174 C10.9309565,3.94017391 11.4173913,3.94017391 11.7175652,4.24052174 Z",
                        id: "形状结合",
                        fill: "currentColor",
                        fillRule: "nonzero"
                    })
                ]
            })
        })
    })
});
const account_miners = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "14px",
    height: "14px",
    viewBox: "0 0 16 16",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "页面-1",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "切图",
            transform: "translate(-77.000000, -98.000000)",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                id: "编组-9备份",
                transform: "translate(77.000000, 98.000000)",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                        id: "矩形",
                        fill: "currentColor",
                        opacity: "0",
                        x: "0",
                        y: "0",
                        width: "16",
                        height: "16"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M12.5775785,8.59372197 C14.464574,8.59372197 16,10.129148 16,12.0161435 C16,13.903139 14.464574,15.438565 12.5793722,15.438565 L3.42242152,15.438565 C1.53542601,15.438565 0,13.903139 0,12.0161435 C0,10.129148 1.53542601,8.59372197 3.42242152,8.59372197 L12.5775785,8.59372197 Z M12.5775785,10.1955157 L3.42242152,10.1955157 C2.41793722,10.1955157 1.6,11.0134529 1.6,12.0179372 C1.6,13.0224215 2.41793722,13.8403587 3.42242152,13.8403587 L12.5775785,13.8403587 C13.5820628,13.8403587 14.4,13.0224215 14.4,12.0179372 C14.4,11.0134529 13.5820628,10.1955157 12.5775785,10.1955157 Z M12.5058296,10.9112108 C13.1160671,10.9112108 13.6107623,11.405906 13.6107623,12.0161435 C13.6107623,12.626381 13.1160671,13.1210762 12.5058296,13.1210762 C11.8955921,13.1210762 11.4008969,12.626381 11.4008969,12.0161435 C11.4008969,11.405906 11.8955921,10.9112108 12.5058296,10.9112108 Z M12.5775785,0.8 C14.464574,0.8 16,2.33542601 16,4.22242152 C16,6.10941704 14.464574,7.64484305 12.5793722,7.64484305 L3.42242152,7.64484305 C1.53542601,7.64484305 0,6.10941704 0,4.22242152 C0,2.33542601 1.53542601,0.8 3.42242152,0.8 L12.5775785,0.8 Z M12.5775785,2.40179372 L3.42242152,2.40179372 C2.41793722,2.40179372 1.6,3.21973094 1.6,4.22421525 C1.6,5.22869955 2.41793722,6.04663677 3.42242152,6.04663677 L12.5775785,6.04663677 C13.5820628,6.04663677 14.4,5.22869955 14.4,4.22421525 C14.4,3.21973094 13.5820628,2.40179372 12.5775785,2.40179372 Z M3.46188341,3.11210762 C4.07212091,3.11210762 4.56681614,3.60680286 4.56681614,4.21704036 C4.56681614,4.82727786 4.07212091,5.32197309 3.46188341,5.32197309 C2.85164591,5.32197309 2.35695067,4.82727786 2.35695067,4.21704036 C2.35695067,3.60680286 2.85164591,3.11210762 3.46188341,3.11210762 Z",
                        id: "形状结合",
                        fill: "currentColor",
                        fillRule: "nonzero"
                    })
                ]
            })
        })
    })
});
const account_personal = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "14px",
    height: "14px",
    viewBox: "0 0 16 16",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "页面-1",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "切图",
            transform: "translate(-115.000000, -98.000000)",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                id: "编组-7备份",
                transform: "translate(115.000000, 98.000000)",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                        id: "矩形",
                        fill: "currentColor",
                        opacity: "0",
                        x: "0",
                        y: "0",
                        width: "16",
                        height: "16"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M8.10303126,0 C11.2142915,0 13.7458804,2.53158895 13.7458804,5.64284916 C13.7458804,7.32979868 13.0016204,8.84633107 11.8242424,9.88130422 C13.5164132,10.3467299 14.8721868,11.6168748 15.3292417,13.2805546 C15.5027853,13.91211 15.3721803,14.5776585 14.9696308,15.1036565 C14.5420338,15.6654367 13.8532269,16 13.1268488,16 L3.07921375,16 C2.35104647,16 1.66223958,15.6654367 1.23464258,15.1054456 C0.832093098,14.5776585 0.701488155,13.9138991 0.875031709,13.2823437 C1.33217675,11.6169292 2.68839506,10.3463107 4.38116049,9.87912387 C3.20401776,8.84546619 2.46018211,7.32931766 2.46018211,5.64284916 C2.46018211,2.53158895 4.99177106,0 8.10303126,0 Z M10.3787777,11.2856983 L5.82549576,11.2856983 C4.20993051,11.2856983 2.80905832,12.2804428 2.41724349,13.7063625 C2.36535934,13.8960081 2.43692369,14.0445041 2.50669893,14.1357486 C2.63372566,14.3021357 2.84662961,14.4005367 3.07742464,14.4005367 L13.1268488,14.4005367 C13.3576438,14.4005367 13.5723369,14.3021357 13.6975745,14.1357486 C13.7673497,14.0445041 13.8389141,13.8960081 13.7870299,13.7063625 C13.3952151,12.2804428 11.9943429,11.2856983 10.3787777,11.2856983 Z M8.10303126,1.59946327 C5.8738017,1.59946327 4.06143448,3.41361959 4.06143448,5.64284916 C4.06143448,7.87207872 5.87559081,9.68444594 8.10303126,9.68444594 C10.3304717,9.68444594 12.1464172,7.87028961 12.1464172,5.64284916 C12.144628,3.41361959 10.3322608,1.59946327 8.10303126,1.59946327 Z M7.21742241,6.14558873 C7.39812239,6.46226099 7.73805307,6.66085206 8.10303126,6.66085206 C8.45906391,6.66085206 8.78468171,6.47836297 8.97253814,6.17421447 C9.20333317,5.79850162 9.69533809,5.67863133 10.0728401,5.91121548 C10.450342,6.14201051 10.5666341,6.63580454 10.335839,7.01151739 C9.85456878,7.79335793 9.01905497,8.26031533 8.10303126,8.26031533 C7.16553825,8.26031533 6.29245316,7.75399754 5.82728487,6.93816393 C5.60901359,6.55350554 5.74140765,6.06507883 6.12606604,5.84680756 C6.51072443,5.62853629 6.99915113,5.76093034 7.21742241,6.14558873 Z",
                        id: "形状结合",
                        fill: "currentColor",
                        fillRule: "nonzero"
                    })
                ]
            })
        })
    })
});
const account_logout = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "12px",
    height: "13px",
    viewBox: "0 0 12 13",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "页面-1",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
            id: "切图",
            transform: "translate(-882.000000, -464.000000)",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                    id: "矩形",
                    fill: "transparent",
                    x: "0",
                    y: "0",
                    width: "1507",
                    height: "1024"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M888.05,464 C888.139,464 888.224,464.034 888.288,464.097 C888.351,464.161 888.386,464.247 888.386,464.335 L888.386,464.335 L888.386,464.906 C888.386,464.994 888.351,465.081 888.289,465.143 C888.224,465.207 888.139,465.242 888.05,465.242 L888.05,465.242 L883.194,465.242 L883.243,474.906 L888.05,474.856 C888.139,474.856 888.224,474.891 888.288,474.955 C888.351,475.017 888.386,475.104 888.386,475.192 L888.386,475.192 L888.386,475.763 C888.386,475.851 888.351,475.938 888.288,476.001 C888.224,476.064 888.139,476.099 888.05,476.099 L888.05,476.099 L883.194,476.099 C882.557,476.099 882.033,475.601 882.002,474.965 L882.002,474.965 L882,465.192 C882,464.555 882.498,464.033 883.133,464.001 L883.133,464.001 Z M890.4557,466.8557 C890.5437,466.8557 890.6277,466.8907 890.6917,466.9547 L890.6917,466.9547 L893.1447,469.4077 C893.4817,469.7437 893.4987,470.2887 893.1867,470.6467 L893.1867,470.6467 L890.6917,473.1427 C890.6277,473.2067 890.5437,473.2417 890.4557,473.2417 C890.3657,473.2417 890.2817,473.2067 890.2177,473.1427 L890.2177,473.1427 L889.8137,472.7387 C889.6827,472.6087 889.6827,472.3957 889.8137,472.2647 L889.8137,472.2647 L891.4927,470.5857 L885.7647,470.6707 C885.6757,470.6707 885.5907,470.6357 885.5277,470.5727 C885.4637,470.5097 885.4297,470.4257 885.4297,470.3347 L885.4297,470.3347 L885.4297,469.7627 C885.4297,469.6737 885.4637,469.5897 885.5277,469.5257 C885.5907,469.4627 885.6747,469.4277 885.7647,469.4277 L885.7647,469.4277 L891.5277,469.4277 L889.8137,467.8327 C889.6827,467.7027 889.6827,467.4897 889.8137,467.3587 L889.8137,467.3587 L890.2177,466.9547 C890.2817,466.8907 890.3657,466.8557 890.4557,466.8557 Z",
                    id: "形状结合",
                    fill: "currentColor"
                })
            ]
        })
    })
});
const legendIcon = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    width: "20px",
    height: "8px",
    viewBox: "0 0 20 8",
    version: "1.1",
    children: [
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
            children: "2"
        }),
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "页面-1",
            stroke: "none",
            strokeWidth: "1",
            fill: "none",
            fillRule: "evenodd",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                id: "切图",
                transform: "translate(-302.000000, -130.000000)",
                fill: "currentColor",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                    id: "2",
                    transform: "translate(302.000000, 131.000000)",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("polygon", {
                            id: "矩形",
                            points: "-4.37150316e-16 2 20 2 20 3.5 -4.37150316e-16 3.5"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                            id: "椭圆形",
                            stroke: "#FFFFFF",
                            strokeWidth: "2",
                            cx: "10",
                            cy: "3",
                            r: "3"
                        })
                    ]
                })
            })
        })
    ]
});
const no_nodes = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "92px",
    height: "80px",
    viewBox: "0 0 92 80",
    version: "1.1",
    children: [
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
            children: "形状结合"
        }),
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("defs", {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("linearGradient", {
                x1: "50%",
                y1: "0%",
                x2: "50%",
                y2: "100%",
                id: "linearGradient-1",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                        stopColor: "#000000",
                        offset: "0%"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                        stopColor: "#000000",
                        offset: "100%"
                    })
                ]
            })
        }),
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "20220814",
            stroke: "none",
            strokeWidth: "1",
            fill: "none",
            fillRule: "evenodd",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                id: "切图",
                transform: "translate(-144.000000, -214.000000)",
                fill: "currentColor",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M228.347553,214.043156 C231.329471,214.168236 233.529946,215.579465 234.888023,218.237834 C235.127941,218.7067 235.289594,219.24798 235.460756,219.820713 C235.529025,220.049416 235.599245,220.284702 235.676292,220.520232 L235.676292,228.886182 C235.640695,228.960059 235.605585,229.048322 235.580227,229.150726 C234.529851,233.408066 231.907324,235.478341 227.563184,235.479073 L196.861623,235.47956 L199.667015,237.276269 C202.126671,238.851346 203.991649,240.571496 205.535761,242.689072 C205.948792,243.25449 206.718287,243.298865 206.944552,243.298865 L208.262887,243.299353 C210.591855,243.299353 212.920822,243.296671 215.249547,243.293989 C217.577783,243.291307 219.90602,243.288625 222.234012,243.288625 C224.233092,243.288625 226.23144,243.290575 228.231007,243.296427 C230.115979,243.301547 231.828326,243.976441 233.319773,245.301602 C234.456949,246.312236 235.207427,247.665924 235.676292,249.556016 L235.676292,258.140428 C235.627528,258.234055 235.576326,258.35182 235.544142,258.49031 C234.638351,262.393135 231.702028,264.72893 227.689239,264.738683 C226.514759,264.741609 225.33979,264.743072 224.16531,264.743072 C222.96596,264.743072 221.766853,264.741609 220.567259,264.738683 C219.376443,264.736001 218.185382,264.732344 216.994566,264.728686 C214.591964,264.721372 212.189363,264.714057 209.786761,264.714057 C208.81075,264.714057 207.834983,264.715276 206.859215,264.718202 C206.242351,264.72064 205.645236,265.137572 205.326807,265.549628 C203.826095,267.493117 202.165194,269.044055 200.249501,270.291438 C200.076633,270.403839 199.948383,270.525993 199.812576,270.655705 C199.756253,270.709345 199.692129,270.770544 199.614106,270.840033 L197.712798,272.54214 L216.637857,272.539945 C220.401705,272.539945 224.16531,272.541164 227.929158,272.545553 C231.233406,272.549454 233.912743,274.279113 235.096732,277.172036 C235.263261,277.579459 235.388097,278.019798 235.520004,278.485738 C235.571206,278.666409 235.622408,278.847079 235.676292,279.027018 L235.676292,287.418569 C235.65825,287.462212 235.640939,287.510733 235.626553,287.563885 C234.375269,292.135021 231.934144,294 227.201112,294 L151.745915,294 C149.353798,294 147.419574,293.1498 145.833038,291.40088 C144.813871,290.27687 144.344518,288.885389 144,287.538284 L144,279.124302 C144.03194,279.055789 144.063881,278.974353 144.088019,278.881214 C145.209591,274.557068 147.817489,272.542627 152.295242,272.542383 L181.972515,272.54214 L179.793253,270.804435 C179.419477,270.506243 179.053747,270.225607 178.697282,269.952041 C177.944366,269.374187 177.2329,268.828031 176.604576,268.234329 C176.076462,267.73523 175.59638,267.182246 175.087528,266.597322 C174.717166,266.171125 174.334369,265.730542 173.928408,265.308978 C173.459786,264.822313 172.739055,264.74868 172.351137,264.747948 L169.747384,264.74551 L169.747384,264.74551 C168.15841,264.74551 166.568948,264.747704 164.979973,264.750142 C163.39173,264.752337 161.803731,264.754531 160.215976,264.754531 L158.960461,264.754013 C156.111709,264.751583 153.807931,264.740542 151.618397,264.719421 C148.434841,264.688456 146.086611,263.138005 144.63954,260.110981 C144.450823,259.716724 144.315503,259.27029 144.172381,258.797767 C144.115814,258.611976 144.059736,258.426429 144,258.242589 L144,249.655495 C144.04657,249.550652 144.098259,249.411675 144.12191,249.246852 C144.548107,246.27737 147.314488,243.270826 151.776637,243.270826 L151.84003,243.27107 C154.81829,243.290575 157.714871,243.293257 160.155508,243.293257 L166.637949,243.290575 C168.526334,243.290575 170.413744,243.292526 172.301642,243.299353 C173.131605,243.299353 173.716041,243.002624 174.208557,242.33724 C175.522503,240.562474 177.152195,239.026896 179.051796,237.77293 C179.218813,237.66248 179.353402,237.547153 179.509203,237.41354 C179.579423,237.353316 179.658177,237.285534 179.751803,237.208731 L181.857189,235.47956 L162.947978,235.481998 C159.213632,235.481998 155.479774,235.480779 151.745184,235.475903 C148.494089,235.472002 145.748677,233.698456 144.57956,230.847957 C144.412543,230.440778 144.287951,230.000927 144.155801,229.534987 C144.104599,229.35456 144.05364,229.174377 144,228.994682 L144,220.573385 C144.012679,220.540226 144.02487,220.504384 144.035842,220.466104 C145.367098,215.828406 147.759216,214.022188 152.567345,214.022188 L222.359823,214.022431 C222.963521,214.022431 223.567707,214.017067 224.171649,214.011216 C224.769739,214.005852 225.36783,214 225.96592,214 C226.889754,214 227.646571,214.013898 228.347553,214.043156 Z M227.500523,276.44399 L170.84238,276.443258 C164.529882,276.443258 158.219334,276.443746 151.906836,276.445697 C149.368427,276.446184 147.908921,277.907397 147.902094,280.454096 C147.898437,281.760727 147.899492,283.067846 147.900387,284.374721 L147.901119,285.758886 C147.90185,288.759578 149.234814,290.097906 152.222583,290.097906 L194.818168,290.09815 L211.317219,290.098637 C216.816577,290.098637 222.316423,290.09815 227.816026,290.096199 C230.288116,290.095468 231.767859,288.61353 231.774198,286.131687 C231.777612,284.839929 231.776619,283.547927 231.776619,282.256413 L231.775174,280.735708 C231.774198,277.807919 230.416121,276.444234 227.500523,276.44399 Z M163.65369,281.315293 L163.859718,281.317975 L163.859718,281.317975 C163.939447,281.319194 164.01942,281.320657 164.098906,281.320657 L178.857082,281.320413 C188.16954,281.320413 197.480292,281.320901 206.79275,281.322363 L207.116543,281.321388 C207.383769,281.321388 207.59955,281.32919 207.782415,281.366007 C208.752818,281.562038 209.434295,282.484653 209.334329,283.466272 C209.232412,284.467397 208.410739,285.202026 207.380844,285.212754 C206.44555,285.222751 205.430772,285.227627 204.187046,285.227627 C203.45705,285.227627 202.727053,285.226164 201.9973,285.224458 C201.266084,285.222995 200.534868,285.221532 199.803408,285.221532 L185.449973,285.221532 L173.473782,285.223482 C170.213422,285.223482 166.953549,285.222263 163.693433,285.216899 C162.913941,285.21568 162.244411,284.887498 161.856737,284.317204 C161.509294,283.805669 161.45029,283.189293 161.689965,282.581206 C161.990595,281.819512 162.528705,281.421354 163.383294,281.326996 C163.455465,281.319194 163.541289,281.315293 163.65369,281.315293 Z M154.814023,281.226786 C155.938033,281.227517 156.758,282.017982 156.765558,283.106394 C156.768971,283.625243 156.571234,284.112639 156.207942,284.478369 C155.838555,284.850438 155.340918,285.055247 154.807196,285.055247 L154.79208,285.055247 C153.741459,285.047688 152.888577,284.176763 152.89101,283.114196 C152.89321,282.020664 153.701961,281.226786 154.814023,281.226786 Z M216.323573,281.211937 C217.402964,281.233881 218.268525,282.09676 218.25292,283.135433 C218.236828,284.193855 217.353225,285.054539 216.283343,285.054539 L216.229703,285.053808 C215.170305,285.026012 214.353021,284.154112 214.368625,283.06887 C214.383742,282.010204 215.205415,281.21145 216.279442,281.21145 L216.323573,281.211937 Z M225.115013,281.211937 C226.23122,281.217789 227.062646,282.037268 227.059728,283.118609 C227.057039,284.178982 226.191965,285.047225 225.131593,285.053808 L225.117939,285.053808 C224.060735,285.053808 223.186153,284.204096 223.168355,283.159327 C223.159577,282.631701 223.349269,282.143086 223.703052,281.783207 C224.065368,281.414796 224.566662,281.211937 225.115013,281.211937 Z M189.726233,238.451969 C185.592266,238.451969 181.702607,240.068983 178.773598,243.004818 C175.845321,245.940167 174.232939,249.838116 174.233427,253.980372 C174.234402,262.525773 181.183758,269.478055 189.72477,269.478055 C193.871659,269.477323 197.768633,267.863235 200.702031,264.933983 C203.63616,262.003999 205.250735,258.11312 205.248786,253.97769 C205.244884,245.416929 198.28163,238.451969 189.726233,238.451969 Z M189.862748,243.284748 C190.899958,243.296939 191.741624,244.133973 191.779172,245.189957 C191.803067,245.870702 191.797946,246.57461 191.792826,247.255112 C191.790632,247.560374 191.788194,247.865637 191.788437,248.170899 L191.788681,252.061778 L192.763961,252.061778 C193.37156,252.061778 193.972576,252.059827 194.568716,252.057877 C195.153884,252.055926 195.734175,252.053976 196.312516,252.053976 C197.21465,252.053976 197.953912,252.058852 198.63929,252.068605 C199.549226,252.081771 200.265325,252.651822 200.507194,253.556394 C200.719561,254.34954 200.370411,255.226317 199.69503,255.596192 C199.330519,255.79588 198.814596,255.924617 198.315741,255.940953 C197.629631,255.963384 196.87574,255.973625 195.943373,255.973625 C195.433058,255.973625 194.919329,255.970699 194.398774,255.967773 C193.861394,255.964603 193.317432,255.961678 192.763961,255.961678 L191.788681,255.961678 L191.788681,261.344246 C191.788681,261.493952 191.789657,261.643657 191.790876,261.79385 C191.793314,262.13276 191.795752,262.452895 191.784536,262.771324 C191.744794,263.889482 190.908979,264.734319 189.84056,264.736513 L189.836903,264.736513 C188.767265,264.736513 187.91487,263.885338 187.896584,262.798632 C187.874152,261.480785 187.879273,260.174154 187.884393,258.790476 C187.886831,258.182633 187.889269,257.566013 187.889269,256.936957 L187.889269,255.961678 L182.798553,255.961434 C182.605691,255.961434 182.424289,255.96314 182.242887,255.964603 L181.716724,255.968017 L181.716724,255.968017 C181.442183,255.968017 181.219331,255.963872 181.01501,255.954607 C179.956832,255.90755 179.121261,255.061007 179.113147,254.027454 C179.104437,252.950258 179.945616,252.090549 181.027445,252.070312 C181.693073,252.057877 182.410879,252.052025 183.286437,252.052025 C183.863802,252.052025 184.446532,252.054219 185.038283,252.056901 C185.652465,252.059583 186.2764,252.062265 186.914965,252.062265 L187.890244,252.062265 L187.890244,251.086986 C187.890244,250.464026 187.887562,249.850087 187.88488,249.242244 C187.878785,247.844668 187.872689,246.524871 187.899022,245.18825 C187.919747,244.120563 188.771653,243.284504 189.838122,243.284504 L189.862748,243.284748 Z M220.056147,247.182692 L215.55069,247.182933 C215.46905,247.182966 215.386684,247.183 215.30373,247.183035 L213.271303,247.183952 C213.187856,247.183991 213.104935,247.184031 213.022679,247.18407 L211.247438,247.18495 C211.184726,247.184982 211.123792,247.185013 211.064776,247.185043 L209.998397,247.185599 L209.998397,247.185599 C209.819677,247.185599 209.655586,247.199496 209.481742,247.21437 C209.404451,247.220709 209.321553,247.228023 209.230364,247.234119 L208.031501,247.316774 L208.358952,248.472968 C209.401526,252.154405 209.397868,255.86632 208.348224,259.505576 L208.070513,260.466958 L209.039209,260.719799 C209.072125,260.728333 209.100408,260.737598 209.125278,260.7454 C209.232315,260.779291 209.393967,260.830249 209.598776,260.830249 L213.929018,260.834151 C215.963208,260.836345 217.997397,260.838539 220.031343,260.838539 L221.341911,260.838196 C223.899218,260.836823 226.08682,260.831329 228.143476,260.821716 C230.150114,260.811719 231.741526,259.194462 231.767128,257.13906 C231.789071,255.352835 231.782102,253.540034 231.775661,251.787212 L231.771272,250.547876 C231.767371,249.230516 231.073947,248.171607 229.868502,247.641786 C229.226036,247.359442 228.495796,247.202179 227.812368,247.199253 C225.489395,247.189615 223.039758,247.184276 220.056147,247.182692 Z M154.824142,247.177309 C153.57871,247.177309 152.558567,247.181698 151.614252,247.191207 C149.328197,247.214613 147.905508,248.660953 147.90185,250.966027 C147.898437,252.885865 147.898681,254.805947 147.90185,256.725785 C147.905751,259.337828 149.41329,260.836345 152.038012,260.83732 L155.578886,260.838417 L155.578886,260.838417 L159.119761,260.838783 C162.485208,260.838783 165.849923,260.837808 169.215369,260.836589 C169.437245,260.836345 169.646687,260.824154 169.868807,260.811719 C169.970236,260.805624 170.076054,260.799528 170.187723,260.794408 L171.342454,260.741255 L170.364005,256.26082 L169.829308,256.088927 C169.813703,256.084051 169.800781,256.078443 169.789077,256.074298 C169.700571,256.039676 169.535261,255.975795 169.317774,255.974819 C168.588021,255.972137 167.858755,255.971162 167.12949,255.970187 C166.002066,255.96848 164.874399,255.966773 163.746976,255.959703 C162.452048,255.951657 161.551865,255.1451 161.557961,253.998659 C161.564056,252.845878 162.454486,252.067361 163.773552,252.061997 C164.515252,252.058828 165.256709,252.058096 166.003042,252.058096 L170.294029,252.060291 L171.334408,247.183648 L159.363581,247.183648 C158.607739,247.183648 157.851654,247.182185 157.095812,247.180479 C156.338507,247.178772 155.581447,247.177309 154.824142,247.177309 Z M154.794957,252.074773 C155.367933,252.074773 155.869715,252.277144 156.232519,252.645068 C156.583376,253.000558 156.772336,253.482346 156.765509,254.001195 C156.75088,255.04962 155.857524,255.935662 154.814462,255.93615 C153.779934,255.93615 152.899257,255.046938 152.890967,253.99388 C152.882839,252.963102 153.624859,252.16564 154.640181,252.081919 L154.794957,252.074773 Z M225.105626,252.068678 C226.214519,252.068678 227.049114,252.880842 227.059842,253.958039 C227.064963,254.460795 226.852596,254.966478 226.476869,255.346105 C226.105287,255.721344 225.610089,255.936393 225.118061,255.936393 L225.09246,255.93615 C224.049154,255.921033 223.167989,255.022069 223.16872,253.973399 C223.169452,252.893765 224.002097,252.075017 225.105626,252.068678 Z M216.291048,252.067971 C217.379216,252.067971 218.238925,252.901347 218.252823,253.965378 C218.259406,254.448872 218.046064,254.946021 217.667655,255.32955 C217.28754,255.714786 216.790391,255.935686 216.30397,255.935686 L216.274224,255.935443 C215.201417,255.915693 214.363895,255.051839 214.368267,253.968791 C214.372429,252.869895 215.181423,252.070165 216.291048,252.067971 Z M170.879196,217.923306 C164.556946,217.923306 158.234695,217.923794 151.912444,217.925501 C149.371109,217.926232 147.909409,219.385495 147.902094,221.929024 C147.898193,223.224927 147.899407,224.52083 147.900387,225.816733 L147.901119,227.234058 C147.90185,230.237919 149.233351,231.57771 152.218194,231.577954 L191.522454,231.578198 L209.666558,231.578685 C215.714511,231.578685 221.762464,231.578198 227.810662,231.576247 C230.285678,231.575516 231.767615,230.095285 231.774198,227.616855 C231.777612,226.324853 231.776619,225.033096 231.776619,223.741094 L231.775174,222.220876 C231.774198,219.289429 230.41734,217.924038 227.505155,217.924038 L170.879196,217.923306 Z M154.867883,222.880873 C155.974826,222.910131 156.790159,223.739363 156.765046,224.809732 C156.739201,225.895218 155.909238,226.713234 154.833992,226.713234 L154.813999,226.713234 C153.739484,226.702994 152.894405,225.854744 152.890492,224.78218 C152.888797,224.26065 153.07922,223.7813 153.427395,223.431906 C153.781909,223.076172 154.272231,222.880141 154.808635,222.880141 L154.867883,222.880873 Z M216.285099,222.862854 C217.401062,222.87407 218.255164,223.715249 218.252488,224.77806 C218.249556,225.826729 217.350835,226.712771 216.290219,226.712771 L216.248282,226.712283 C215.163283,226.68912 214.355264,225.846966 214.368674,224.75319 C214.38184,223.675506 215.205708,222.862854 216.285099,222.862854 Z M225.10153,222.862586 L225.151025,222.863074 C226.257968,222.888919 227.078665,223.724002 227.060135,224.805831 C227.041605,225.874981 226.18726,226.712747 225.115184,226.712747 L225.101286,226.712747 C224.021164,226.705676 223.172183,225.86084 223.168511,224.789251 C223.166575,224.268939 223.36285,223.784469 223.720777,223.425566 C224.082362,223.062275 224.572684,222.862586 225.10153,222.862586 Z M166.085038,222.797535 C166.451743,222.798998 166.818692,222.800217 167.185641,222.800217 L178.624453,222.800217 C188.006888,222.800217 197.388591,222.800461 206.771269,222.802411 L207.138218,222.800705 C207.354487,222.800705 207.580995,222.805825 207.769468,222.842398 C208.707443,223.023556 209.396235,223.915693 209.338206,224.873174 C209.277738,225.866253 208.461429,226.663056 207.480054,226.687194 C206.808818,226.703774 206.079308,226.711576 205.183514,226.711576 C204.659545,226.711576 204.135332,226.708894 203.611363,226.706456 C203.084225,226.704018 202.557086,226.701336 202.029947,226.701336 L173.3616,226.70353 C170.145615,226.70353 166.930606,226.702311 163.714865,226.697435 C162.931471,226.696459 162.258528,226.372423 161.869148,225.808955 C161.518047,225.301322 161.45246,224.682019 161.684332,224.065155 C161.979842,223.279079 162.657905,222.819723 163.545166,222.805337 C164.026954,222.797047 164.50923,222.795097 164.991262,222.795097 C165.355773,222.795097 165.720284,222.796072 166.085038,222.797535 Z",
                    id: "形状结合"
                })
            })
        })
    ]
});
const editIcon = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "28px",
    height: "28px",
    viewBox: "0 0 28 28",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "20220814",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "切图",
            transform: "translate(-41.000000, -393.000000)",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                id: "编组-4备份-2",
                transform: "translate(41.000000, 393.000000)",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M17.8221813,7.31303085 L20.6883098,10.1791594 C21.1324022,10.6232518 21.0977567,11.3807286 20.6111448,11.8673405 L18.6753706,13.8044691 C18.6664099,13.8146207 18.6570778,13.8245571 18.6473743,13.8342606 L13.7308616,18.7476238 C13.4473983,19.031087 13.0820457,19.2263617 12.7009451,19.2988023 L9.0552926,19.9854133 C8.99859995,19.9964369 8.9419073,20.0027361 8.88521464,20.0027361 C8.64899526,20.0027361 8.42222465,19.9113979 8.25687109,19.7444696 C8.05057282,19.5381713 7.96080946,19.2389601 8.01592732,18.9444733 L8.70253832,15.3003956 C8.77497893,14.9177202 8.97025362,14.5523675 9.25371688,14.2689043 L14.1605635,9.36214986 C14.1627168,9.3599352 14.1648889,9.35773222 14.16708,9.35554111 L16.1340001,7.38862105 C16.620612,6.90200912 17.3780888,6.86736361 17.8221813,7.31303085 Z M14.661,10.703 L10.1733977,15.1901599 C10.0726107,15.2909468 10.0048945,15.4153557 9.98127258,15.5429141 L9.40489729,18.5980182 L12.4600013,18.0216429 C12.5875598,17.9980209 12.7119686,17.9287299 12.8127556,17.8295178 L17.3,13.342 L14.661,10.703 Z M17.0190354,8.34767175 L15.58,9.783 L18.218,12.42 L19.6552437,10.9838801 L17.0190354,8.34767175 Z",
                        id: "形状结合",
                        fill: "currentColor",
                        fillRule: "nonzero"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                        id: "矩形备份-2",
                        strokeOpacity: "0.2",
                        stroke: "currentColor",
                        strokeWidth: "0.5",
                        x: "0.25",
                        y: "0.25",
                        width: "27.5",
                        height: "27.5",
                        rx: "5"
                    })
                ]
            })
        })
    })
});
const downloadIcon = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "12px",
    height: "12px",
    viewBox: "0 0 12 12",
    version: "1.1",
    children: [
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
            children: "形状结合"
        }),
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "20220814",
            stroke: "none",
            strokeWidth: "1",
            fill: "none",
            fillRule: "evenodd",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                id: "切图",
                transform: "translate(-80.000000, -226.000000)",
                fill: "currentColor",
                fillRule: "nonzero",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M91.4004672,233.168812 C91.7324936,233.168812 92,233.437659 92,233.768341 L92,235.43385 C92.0013408,236.362717 91.2082415,237.119522 90.232326,237.119522 L81.7690148,237.119522 C80.7930994,237.119522 80,236.362717 80,235.43385 L80,233.768341 C80,233.436315 80.2688472,233.168812 80.5995293,233.168812 C80.9302115,233.168812 81.1990587,233.437659 81.1990587,233.768341 L81.1990587,235.43385 C81.1990587,235.701353 81.4544636,235.919119 81.7690148,235.919119 L90.232326,235.919119 C90.545533,235.919119 90.8009379,235.701353 90.8009379,235.43385 L90.8009379,233.768341 C90.8009379,233.436315 91.0697851,233.168812 91.4004672,233.168812 Z M87.0357323,226 C87.8866338,226 88.5789155,226.754117 88.5789155,227.680295 L88.5789155,229.876777 L89.139462,229.876777 C89.5669291,229.876777 89.9406267,230.133526 90.1140332,230.546207 C90.300882,230.991149 90.209474,231.495238 89.8801361,231.832641 L87.0935344,234.678389 C86.8031794,234.974121 86.4241048,235.138118 86.0248667,235.138118 C86.0235224,235.139462 86.0235224,235.139462 86.0221782,235.139462 C85.6242843,235.139462 85.2452097,234.976809 84.9548546,234.682422 L82.1292701,231.817854 C81.798588,231.481795 81.7044915,230.976362 81.8913403,230.53142 C82.0647468,230.117395 82.4384445,229.860646 82.8659116,229.860646 L83.4210811,229.860646 L83.4210811,227.680295 C83.4210811,226.754117 84.1133628,226 84.9642643,226 L87.0357323,226 Z M87.0370765,227.200403 L84.9656085,227.200403 C84.7827924,227.200403 84.6228283,227.42489 84.6228283,227.680295 L84.6228283,230.458831 C84.6228283,230.790858 84.3539811,231.058361 84.023299,231.058361 L83.0648585,231.058361 L83.0648585,231.059705 L85.8097889,233.839586 C85.8743122,233.904109 85.946901,233.939059 86.0221782,233.939059 C86.0974554,233.939059 86.1713884,233.904109 86.2345675,233.839586 L88.9391708,231.078524 L87.9793861,231.078524 C87.6473598,231.078524 87.3798568,230.809677 87.3798568,230.478995 L87.3798568,227.680295 C87.3798568,227.42489 87.2198927,227.200403 87.0370765,227.200403 Z",
                    id: "形状结合"
                })
            })
        })
    ]
});
const dateArrowIcon = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "10px",
    height: "4px",
    viewBox: "0 0 10 4",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "20220814",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "切图",
            transform: "translate(-82.000000, -252.000000)",
            stroke: "currentColor",
            strokeWidth: "1.2",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("polyline", {
                id: "路径-5",
                points: "82 254.860465 90 254.860465 88.0668178 253"
            })
        })
    })
});
const dateIcon = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "12px",
    height: "12px",
    viewBox: "0 0 12 12",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "20220814",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "切图",
            transform: "translate(-46.000000, -248.000000)",
            fill: "currentColor",
            fillRule: "nonzero",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M54.5113689,248 C54.8426914,248 55.1113689,248.268677 55.1113689,248.6 L55.111,248.868 L55.7726218,248.868677 C56.7540603,248.868677 57.5531323,249.667749 57.5531323,250.649188 L57.5531323,258.21949 C57.5531323,259.200928 56.7540603,260 55.7726218,260 L47.7805104,260 C46.7990719,260 46,259.200928 46,258.21949 L46,250.649188 C46,249.667749 46.7990719,248.868677 47.7805104,248.868677 L48.586,248.868 L48.5865429,248.6 C48.5865429,248.268677 48.8552204,248 49.1865429,248 C49.5178654,248 49.7865429,248.268677 49.7865429,248.6 L49.786,248.868 L53.911,248.868 L53.9113689,248.6 C53.9113689,248.268677 54.1800464,248 54.5113689,248 Z M56.353,253.106 L47.2,253.106 L47.2,258.21949 C47.2,258.539675 47.4603248,258.8 47.7805104,258.8 L55.7726218,258.8 C56.0928074,258.8 56.3531323,258.539675 56.3531323,258.21949 L56.353,253.106 Z M52.0723898,256.287239 C52.4037123,256.287239 52.6723898,256.555916 52.6723898,256.887239 C52.6723898,257.218561 52.4037123,257.487239 52.0723898,257.487239 L51.4793503,257.487239 C51.1480278,257.487239 50.8793503,257.218561 50.8793503,256.887239 C50.8793503,256.555916 51.1480278,256.287239 51.4793503,256.287239 L52.0723898,256.287239 Z M49.2700696,256.287239 C49.6013921,256.287239 49.8700696,256.555916 49.8700696,256.887239 C49.8700696,257.218561 49.6013921,257.487239 49.2700696,257.487239 L48.6770302,257.487239 C48.3457077,257.487239 48.0770302,257.218561 48.0770302,256.887239 C48.0770302,256.555916 48.3457077,256.287239 48.6770302,256.287239 L49.2700696,256.287239 Z M52.0723898,254.218561 C52.4037123,254.218561 52.6723898,254.487239 52.6723898,254.818561 C52.6723898,255.149884 52.4037123,255.418561 52.0723898,255.418561 L51.4793503,255.418561 C51.1480278,255.418561 50.8793503,255.149884 50.8793503,254.818561 C50.8793503,254.487239 51.1480278,254.218561 51.4793503,254.218561 L52.0723898,254.218561 Z M49.2700696,254.218561 C49.6013921,254.218561 49.8700696,254.487239 49.8700696,254.818561 C49.8700696,255.149884 49.6013921,255.418561 49.2700696,255.418561 L48.6770302,255.418561 C48.3457077,255.418561 48.0770302,255.149884 48.0770302,254.818561 C48.0770302,254.487239 48.3457077,254.218561 48.6770302,254.218561 L49.2700696,254.218561 Z M54.8064965,254.218561 C55.137819,254.218561 55.4064965,254.487239 55.4064965,254.818561 C55.4064965,255.149884 55.1392111,255.418561 54.8064965,255.418561 L54.2134571,255.418561 C53.8821346,255.418561 53.6134571,255.149884 53.6134571,254.818561 C53.6134571,254.487239 53.8821346,254.218561 54.2134571,254.218561 L54.8064965,254.218561 Z M55.7726218,250.068677 L55.111,250.068 L55.1113689,250.334571 C55.1113689,250.667285 54.8426914,250.935963 54.5113689,250.935963 C54.1800464,250.935963 53.9113689,250.667285 53.9113689,250.335963 L53.911,250.068 L49.786,250.068 L49.7865429,250.334571 C49.7865429,250.667285 49.5178654,250.935963 49.1865429,250.935963 C48.8552204,250.935963 48.5865429,250.667285 48.5865429,250.335963 L48.586,250.068 L47.7805104,250.068677 C47.4603248,250.068677 47.2,250.329002 47.2,250.649188 L47.2,251.906 L56.353,251.906 L56.3531323,250.649188 C56.3531323,250.329002 56.0928074,250.068677 55.7726218,250.068677 Z",
                id: "形状结合"
            })
        })
    })
});
const openAllIcon = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "14px",
    height: "14px",
    viewBox: "0 0 14 14",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "节点仪表盘",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "切图",
            transform: "translate(-53.000000, -439.000000)",
            fill: "currentColor",
            fillRule: "nonzero",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M60.0037631,447.731199 C60.3279685,447.731199 60.5901117,447.993342 60.5901117,448.317548 L60.59,451.432 L61.2866902,450.737046 C61.5154866,450.50825 61.8878596,450.50825 62.116656,450.737046 C62.3454524,450.965843 62.3445261,451.337289 62.1157297,451.566086 L61.157008,452.524808 C60.8454663,452.836349 60.4372819,452.994479 60.0276626,452.998864 C60.0201038,452.999743 60.0119535,452.999953 60.0037631,453 L59.9764596,452.998612 C59.5725745,452.990301 59.1711516,452.832473 58.8634863,452.524808 L57.9056909,451.567012 C57.6768946,451.338216 57.6768946,450.965843 57.9056909,450.737046 C58.1344873,450.50825 58.5068604,450.50825 58.7356568,450.737046 L59.417,451.418 L59.4174144,448.317548 C59.4174144,447.993342 59.680484,447.730273 60.0037631,447.731199 Z M65.5745382,443.898165 L66.5332599,444.856887 C66.8441991,445.167826 67.0018706,445.575034 67.0064953,445.983745 C67.0073031,445.992197 67.0075261,446.001602 67.0075261,446.011058 L67.0060541,446.044552 C66.9956879,446.44587 66.8377113,446.844104 66.5323336,447.149482 L65.5736119,448.108204 C65.3448156,448.337 64.9724425,448.337 64.7436461,448.108204 C64.5148497,447.879407 64.5148497,447.507034 64.7436461,447.278238 L65.425,446.596 L62.3139582,446.591849 C61.9897528,446.591849 61.7276095,446.327853 61.7276095,446.003647 C61.7276095,445.679442 61.9916054,445.417299 62.3148845,445.418225 L65.438,445.421 L64.7445724,444.728131 C64.515776,444.499334 64.515776,444.126961 64.7445724,443.898165 C64.9733688,443.669368 65.3457419,443.669368 65.5745382,443.898165 Z M55.2694378,443.891681 C55.4982342,444.120477 55.4982342,444.49285 55.2694378,444.721647 L54.581,445.409 L57.6898628,445.413594 C58.0140682,445.413594 58.2762114,445.677589 58.2762114,446.001795 C58.2762114,446.162971 58.210444,446.310253 58.1048457,446.415851 C57.9983211,446.522376 57.8510392,446.588143 57.6898628,446.588143 L54.582,446.583 L55.2694378,447.270827 C55.4982342,447.499624 55.4982342,447.871997 55.2694378,448.100793 C55.0406415,448.32959 54.6682684,448.32959 54.439472,448.100793 L53.4816766,447.142998 C53.1933838,446.854705 53.0364606,446.484282 53.0109068,446.10658 C53.0036924,446.070491 53,446.032861 53,445.994384 C53,445.955195 53.0038574,445.916912 53.0112108,445.879891 C53.0378506,445.504918 53.1946583,445.136494 53.4816766,444.849476 L54.439472,443.891681 C54.6682684,443.662884 55.0406415,443.662884 55.2694378,443.891681 Z M60.0037631,438.999884 L60.0174719,439.000056 C60.4281069,439.003468 60.8377607,439.161387 61.1505239,439.47415 L62.1092456,440.432872 C62.338042,440.661669 62.3371157,441.033115 62.1083193,441.261912 C61.8795229,441.490708 61.5071498,441.490708 61.2783535,441.261912 L60.59,440.574 L60.5901117,443.693452 C60.5901117,443.854629 60.5243443,444.001911 60.418746,444.107509 C60.3122214,444.214034 60.1658658,444.278875 60.0037631,444.279801 C59.6795577,444.279801 59.4174144,444.017658 59.4174144,443.693452 L59.417,440.573 L58.7282464,441.262838 C58.49945,441.491634 58.1270769,441.491634 57.8982805,441.262838 C57.6694841,441.034042 57.6694841,440.661669 57.8982805,440.432872 L58.8570022,439.47415 C59.1693075,439.161845 59.5787298,439.003705 59.9893596,439.000064 C59.994221,438.999941 59.9989853,438.999884 60.0037631,438.999884 Z",
                id: "形状结合"
            })
        })
    })
});
const deleteIcon = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "28px",
    height: "28px",
    viewBox: "0 0 28 28",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "节点仪表盘",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "切图",
            transform: "translate(-89.000000, -393.000000)",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                id: "编组-4备份-6",
                transform: "translate(89.000000, 393.000000)",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                        id: "矩形备份-2",
                        strokeOpacity: "0.2",
                        stroke: "currentColor",
                        strokeWidth: "0.5",
                        x: "0.25",
                        y: "0.25",
                        width: "27.5",
                        height: "27.5",
                        rx: "5"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M13.5040232,7 C14.8654293,7 15.9798656,8.07661043 16.0407426,9.42324165 L18.2525704,9.42355834 L18.284,9.425 L19.3039785,9.42512293 C19.6919982,9.42512293 20.0064819,9.73960662 20.0064819,10.1276263 C20.0064819,10.515646 19.6935628,10.8301296 19.3055431,10.8301296 L18.955,10.83 L18.9550754,18.459097 C18.9566384,19.8609745 17.8176129,21 16.4173,21 L10.5891819,21 C9.18886902,21 8.04984354,19.8609745 8.04984354,18.4606616 L8.049,10.83 L7.70250335,10.8301296 C7.31448368,10.8301296 7,10.515646 7,10.1276263 C7,9.73960662 7.31448368,9.42512293 7.70250335,9.42512293 L8.71985071,9.42429639 C8.73062127,9.42380613 8.74145511,9.42355834 8.75234689,9.42355834 L10.968,9.423 L10.970096,9.3726112 C11.0562249,8.04972588 12.1597228,7 13.5040232,7 Z M17.5500671,10.8301296 L9.45641484,10.8301296 L9.45641484,18.4606616 C9.45641484,19.0849352 9.96490836,19.5934287 10.5891819,19.5934287 L16.4173,19.5934287 C17.0415735,19.5934287 17.5500671,19.0849352 17.5500671,18.4606616 L17.5500671,10.8301296 Z M11.9894949,13.0925346 C12.3775145,13.0925346 12.692004,13.4070183 12.692004,13.795038 L12.692004,16.6598122 C12.6935628,17.0478319 12.3790791,17.3623156 11.9894949,17.3623156 C11.6014752,17.3623156 11.2869915,17.0478319 11.2869915,16.6598122 L11.2869915,13.795038 C11.2869915,13.4070183 11.6014752,13.0925346 11.9894949,13.0925346 Z M15.016987,13.0925346 C15.4050067,13.0925346 15.7194962,13.4070183 15.7194962,13.795038 L15.7194962,16.6598122 C15.721055,17.0478319 15.4065713,17.3623156 15.016987,17.3623156 C14.6289674,17.3623156 14.3144837,17.0478319 14.3144837,16.6598122 L14.3144837,13.795038 C14.3144837,13.4070183 14.6289674,13.0925346 15.016987,13.0925346 Z M13.5040232,8.4065713 C12.9173,8.4065713 12.43384,8.852481 12.3759499,9.42355834 L14.630532,9.42355834 C14.5726419,8.852481 14.0891819,8.4065713 13.5040232,8.4065713 Z",
                        id: "形状结合",
                        fill: "currentColor",
                        fillRule: "nonzero"
                    })
                ]
            })
        })
    })
});
const tip = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
    viewBox: "64 64 896 896",
    focusable: "false",
    "data-icon": "exclamation-circle",
    width: "1em",
    height: "1em",
    fill: "currentColor",
    "aria-hidden": "true",
    children: [
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            d: "M512 64C264.6 64 64 264.6 64 512s200.6 448 448 448 448-200.6 448-448S759.4 64 512 64zm0 820c-205.4 0-372-166.6-372-372s166.6-372 372-372 372 166.6 372 372-166.6 372-372 372z"
        }),
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            d: "M464 688a48 48 0 1096 0 48 48 0 10-96 0zm24-112h48c4.4 0 8-3.6 8-8V296c0-4.4-3.6-8-8-8h-48c-4.4 0-8 3.6-8 8v272c0 4.4 3.6 8 8 8z"
        })
    ]
});
const fileIcon = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "14px",
    height: "14px",
    viewBox: "0 0 14 14",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "页面-1",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        opacity: "0.6",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "所需icon",
            transform: "translate(-33.000000, -62.000000)",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                id: "文件icon",
                transform: "translate(33.000000, 62.000000)",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                        id: "矩形",
                        x: "0",
                        y: "0",
                        width: "14",
                        height: "14"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M10.8181818,0.636363636 C11.8725436,0.636363636 12.7272727,1.49109275 12.7272727,2.54545455 L12.7272727,2.54545455 L12.7272727,11.4545455 C12.7272727,12.5089072 11.8725436,13.3636364 10.8181818,13.3636364 L10.8181818,13.3636364 L3.18181818,13.3636364 C2.12745639,13.3636364 1.27272727,12.5089072 1.27272727,11.4545455 L1.27272727,11.4545455 L1.27272727,2.54545455 C1.27272727,1.49109275 2.12745639,0.636363636 3.18181818,0.636363636 L3.18181818,0.636363636 Z M10.8181818,1.90909091 L3.18181818,1.90909091 C2.83036425,1.90909091 2.54545455,2.19400061 2.54545455,2.54545455 L2.54545455,2.54545455 L2.54545455,11.4545455 C2.54545455,11.8059994 2.83036425,12.0909091 3.18181818,12.0909091 L3.18181818,12.0909091 L10.8181818,12.0909091 C11.1696357,12.0909091 11.4545455,11.8059994 11.4545455,11.4545455 L11.4545455,11.4545455 L11.4545455,2.54545455 C11.4545455,2.19400061 11.1696357,1.90909091 10.8181818,1.90909091 L10.8181818,1.90909091 Z M8.90909091,8.90909091 C9.26054484,8.90909091 9.54545455,9.19400061 9.54545455,9.54545455 C9.54545455,9.89690848 9.26054484,10.1818182 8.90909091,10.1818182 L5.09090909,10.1818182 C4.73945516,10.1818182 4.45454545,9.89690848 4.45454545,9.54545455 C4.45454545,9.19400061 4.73945516,8.90909091 5.09090909,8.90909091 L8.90909091,8.90909091 Z M8.90909091,6.36363636 C9.26054484,6.36363636 9.54545455,6.64854607 9.54545455,7 C9.54545455,7.35145393 9.26054484,7.63636364 8.90909091,7.63636364 L5.09090909,7.63636364 C4.73945516,7.63636364 4.45454545,7.35145393 4.45454545,7 C4.45454545,6.64854607 4.73945516,6.36363636 5.09090909,6.36363636 L8.90909091,6.36363636 Z M7,3.81818182 C7.35145393,3.81818182 7.63636364,4.10309152 7.63636364,4.45454545 C7.63636364,4.80599939 7.35145393,5.09090909 7,5.09090909 L5.09090909,5.09090909 C4.73945516,5.09090909 4.45454545,4.80599939 4.45454545,4.45454545 C4.45454545,4.10309152 4.73945516,3.81818182 5.09090909,3.81818182 L7,3.81818182 Z",
                        id: "形状结合",
                        fill: "currentColor",
                        fillRule: "nonzero"
                    })
                ]
            })
        })
    })
});
const outlook = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "28px",
    height: "28px",
    viewBox: "0 0 28 28",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "页面-1",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "切图",
            transform: "translate(-840.000000, -204.000000)",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                id: "编组-10",
                transform: "translate(840.000000, 204.000000)",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                        id: "矩形",
                        fill: "#FFFFFF",
                        x: "0",
                        y: "0",
                        width: "28",
                        height: "28",
                        rx: "5"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                        id: "邮件-(1)",
                        transform: "translate(6.000000, 8.000000)",
                        fill: "#222121",
                        fillRule: "nonzero",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                d: "M13.9397335,0.307183141 C14.1610283,0.138241429 14.1154582,0 13.8384666,0 L1.80604123,0 C1.52904963,0 1.48340846,0.138331502 1.70459668,0.307399328 L7.4163336,4.67312928 C7.63752181,4.84219711 7.99954207,4.84230521 8.22083687,4.6733635 L13.9397335,0.307183141 Z",
                                id: "路径"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                d: "M10.7495963,4.20171574 C10.5271454,4.36583374 10.5148406,4.64908914 10.7222542,4.83114688 L14.4089991,8.06740618 C14.6163949,8.24944642 14.5935712,8.27907762 14.358244,8.13321439 L9.9292461,5.38785642 C9.69391892,5.24199319 9.31941706,5.25695757 9.09694832,5.42105807 L8.22648601,6.0633008 C8.00403512,6.2274188 7.64012362,6.22731379 7.41777987,6.06307327 L6.53883455,5.41381216 C6.31649082,5.24957165 5.94209612,5.23464227 5.70685822,5.38061051 L1.27157398,8.13300436 C1.0363361,8.2790076 1.01403028,8.25000648 1.2220333,8.06857881 L4.92979812,4.83448979 C5.13778327,4.65307962 5.1260321,4.3702793 4.90368835,4.20603877 L0.404272692,0.882461061 C0.181928961,0.718220549 0,0.807096654 0,1.07997323 L0,10.7038655 C0,10.9767246 0.22780857,11.2 0.506247219,11.2 L15.1381972,11.2 C15.4166359,11.2 15.6444444,10.9767246 15.6444444,10.7038655 L15.6444444,1.08632652 C15.6444444,0.813449928 15.4624619,0.724468807 15.240011,0.888586823 L10.7495963,4.20171574 Z",
                                id: "路径"
                            })
                        ]
                    })
                ]
            })
        })
    })
});
const telegram = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "28px",
    height: "28px",
    viewBox: "0 0 28 28",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "页面-1",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "切图",
            transform: "translate(-802.000000, -204.000000)",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                id: "编组-12",
                transform: "translate(802.000000, 204.000000)",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                        id: "矩形",
                        fill: "#FFFFFF",
                        x: "0",
                        y: "0",
                        width: "28",
                        height: "28",
                        rx: "5"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                        id: "bxl-telegram",
                        transform: "translate(5.300000, 7.400000)",
                        fill: "#222121",
                        fillRule: "nonzero",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                            d: "M14.9200247,0.0882308616 L0.747101326,5.55355953 C-0.220142748,5.94205591 -0.214547115,6.48163421 0.569640018,6.72224617 L4.2083962,7.85735903 L12.6274165,2.54551041 C13.0255054,2.30329971 13.3892211,2.43359788 13.0902548,2.69899046 L6.26918563,8.85497936 L6.26758689,8.85497936 L6.26918563,8.85577874 L6.01818181,12.6064475 C6.38589443,12.6064475 6.54816761,12.4377793 6.75440642,12.2387348 L8.52182513,10.520078 L12.198152,13.2355558 C12.8760222,13.6088641 13.3628417,13.417014 13.5315099,12.6080462 L15.9448238,1.23453499 C16.1918308,0.244109038 15.5667193,-0.204340485 14.9200247,0.0882308616 Z",
                            id: "路径"
                        })
                    })
                ]
            })
        })
    })
});
const twitter = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "28px",
    height: "28px",
    viewBox: "0 0 28 28",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "页面-1",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "切图",
            transform: "translate(-764.000000, -204.000000)",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                id: "编组-13",
                transform: "translate(764.000000, 204.000000)",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                        id: "矩形",
                        fill: "#FFFFFF",
                        x: "0",
                        y: "0",
                        width: "28",
                        height: "28",
                        rx: "5"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M23,9.53509331 C22.4116092,9.78743741 21.7713015,9.9690487 21.1117654,10.0397815 C21.7924528,9.63641329 22.3096984,8.99981793 22.5538998,8.24278562 C21.9251292,8.61556668 21.2136762,8.88893946 20.4733806,9.0304051 C19.8734527,8.39380974 19.021632,8 18.0775147,8 C16.2604254,8 14.7990626,9.46436049 14.7990626,11.2613564 C14.7990626,11.5137005 14.8298281,11.7660446 14.8798221,12.0088302 C12.1589953,11.8673646 9.7323639,10.5750569 8.11909626,8.5964497 C7.83451508,9.08202094 7.67299603,9.63641329 7.67299603,10.2424215 C7.67299603,11.3741466 8.25177262,12.3720528 9.13435885,12.958944 C8.59596202,12.9379153 8.08833073,12.7868912 7.65184473,12.5441056 L7.65184473,12.5842513 C7.65184473,14.1690487 8.77863238,15.4823851 10.280375,15.7844333 C10.005408,15.8551661 9.71121259,15.8953118 9.41701719,15.8953118 C9.2035813,15.8953118 9.00168249,15.8742831 8.79786083,15.8456076 C9.21319553,17.1379153 10.4226655,18.0765589 11.8628771,18.1071461 C10.7360894,18.9846154 9.32472059,19.5007738 7.79221247,19.5007738 C7.51724552,19.5007738 7.26342988,19.4912153 7,19.4606281 C8.45367143,20.3878015 10.1784641,20.9230769 12.0359332,20.9230769 C18.0659776,20.9230769 21.3655811,15.9564861 21.3655811,11.6456076 C21.3655811,11.504142 21.3655811,11.3626764 21.3559668,11.2212107 C21.9943516,10.7566682 22.5538998,10.1812472 23,9.53509331 Z",
                        id: "路径",
                        fill: "#222121",
                        fillRule: "nonzero"
                    })
                ]
            })
        })
    })
});
const block_chain = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "16px",
    height: "16px",
    viewBox: "0 0 16 16",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "页面-1",
        stroke: "none",
        "stroke-width": "1",
        fill: "none",
        "fill-rule": "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "统计—FIL相关备份",
            transform: "translate(-124.000000, -482.000000)",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                id: "编组",
                transform: "translate(105.000000, 190.000000)",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                    id: "编组-5",
                    transform: "translate(19.000000, 292.000000)",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                            id: "矩形",
                            x: "0",
                            y: "0",
                            width: "16",
                            height: "16",
                            rx: "0.777777778"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                            id: "编组",
                            transform: "translate(1.500000, 2.000000)",
                            fill: "currentColor",
                            "fill-rule": "nonzero",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                d: "M0.65,0 L12.35,0 C12.708995,0 13,0.29848 13,0.666666667 L13,11.3333333 C13,11.7015333 12.708995,12 12.35,12 L0.65,12 C0.291018,12 0,11.7015333 0,11.3333333 L0,0.666666667 C0,0.29848 0.291018,0 0.65,0 Z M1.3,1.33333333 L1.3,10.6666667 L11.7,10.6666667 L11.7,1.33333333 L1.3,1.33333333 Z M3.25,6.66666667 L4.55,6.66666667 L4.55,9.33333333 L3.25,9.33333333 L3.25,6.66666667 Z M5.85,2.66666667 L7.15,2.66666667 L7.15,9.33333333 L5.85,9.33333333 L5.85,2.66666667 Z M8.45,4.66666667 L9.75,4.66666667 L9.75,9.33333333 L8.45,9.33333333 L8.45,4.66666667 Z",
                                id: "形状"
                            })
                        })
                    ]
                })
            })
        })
    })
});
const copyIcon = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
    height: "14",
    viewBox: "0 0 13 14",
    width: "13",
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    children: [
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("filter", {
            id: "a",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feColorMatrix", {
                in: "SourceGraphic",
                type: "matrix",
                values: "0 0 0 0 0.141176 0 0 0 0 0.450980 0 0 0 0 0.980392 0 0 0 1.000000 0"
            })
        }),
        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            fill: "none",
            fillRule: "evenodd",
            filter: "url(#a)",
            transform: "translate(-213 -138)",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                fill: "currentColor",
                fillRule: "nonzero",
                transform: "translate(213 138)",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "m9.38888889 1.94444444h-8.18518519c-.66445724.00080357-1.20290778.54443153-1.2037037 1.21527778v9.23611108c0 .6703473.54022222 1.2152778 1.2037037 1.2152778h8.18518519c.66396301 0 1.20370371-.5449305 1.20370371-1.2152778v-9.23611108c0-.66986111-.5397407-1.21527778-1.20370371-1.21527778zm.24074074 10.45138886c0 .1336806-.10833333.2430556-.24074074.2430556h-8.18518519c-.13295744 0-.24074074-.1088197-.24074074-.2430556v-9.23611108c0-.13423587.1077833-.24305555.24074074-.24305555h8.18518519c.13295744 0 .24074074.10881968.24074074.24305555z"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "m11.3148148 0h-8.18518517c-.26591488 0-.48148148.21763936-.48148148.48611111 0 .26847176.2155666.48611111.48148148.48611111h8.18518517c.1329575 0 .2407408.10881968.2407408.24305556v9.23611112c0 .2684717.2155666.4861111.4814814.4861111.2659149 0 .4814815-.2176394.4814815-.4861111v-9.23611112c0-.66986111-.5397407-1.21527778-1.2037037-1.21527778z"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "m7.7037037 5.58541667h-4.81481481c-.26591488 0-.48148148.21763935-.48148148.48611111 0 .26847175.2155666.48611111.48148148.48611111h4.81481481c.26591488 0 .48148149-.21763936.48148149-.48611111 0-.26847176-.21556661-.48611111-.48148149-.48611111zm-1.92592592 2.97402777h-2.88888889c-.26591488 0-.48148148.21763936-.48148148.48611112 0 .26847175.2155666.48611111.48148148.48611111h2.88888889c.26591488 0 .48148148-.21763936.48148148-.48611111 0-.26847176-.2155666-.48611112-.48148148-.48611112z"
                    })
                ]
            })
        })
    ]
});
const edit = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    height: "14",
    viewBox: "0 0 14 14",
    width: "14",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
        d: "m614.380141 274.356566 3.264812 3.264738c.505867.505855.466402 1.368679-.087899 1.922967l-2.240522 2.238678c-.094638.095818-.209559.159653-.330873.192017l-4.640086 4.635271c-.313869.313874-.71841.530098-1.140389.61031l-4.036697.760272c-.062774.012206-.125548.019181-.188321.019181-.261557 0-.512652-.101137-.695742-.285974-.228427-.22843-.327818-.559741-.266788-.885821l.760259-4.03502c.080211-.42373.296431-.828278.6103-1.142151l4.637383-4.637821c.032571-.120999.096247-.235292.19103-.330073l2.240522-2.240471c.554301-.554288 1.417144-.593752 1.923011-.086103zm-2.815141 3.155434-5.158477 5.159123c-.111597.111599-.186577.249355-.212733.390598l-.638199 3.382861 3.382805-.63821c.14124-.026156.278994-.102881.390592-.212737l5.158012-5.159635zm1.900276-1.976899-.993276.989899 3.004 3.004.992186-.991058z",
        transform: "translate(-604 -274)",
        fill: "currentColor"
    })
});
const search = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "14px",
    height: "15px",
    viewBox: "0 0 14 15",
    version: "1.1",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
        id: "页面-1",
        stroke: "none",
        strokeWidth: "1",
        fill: "none",
        fillRule: "evenodd",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
            id: "search",
            fill: "currentColor",
            fillRule: "nonzero",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M13.7936732,12.8829925 L11.0125641,10.1018833 C11.9075435,9.0008232 12.3962493,7.63676473 12.3962493,6.19812465 C12.3962493,4.54359043 11.7524922,2.98718991 10.5807758,1.8154735 C9.41102207,0.645719763 7.85462155,0 6.19812465,0 C4.54359043,0 2.98718991,0.643757089 1.8154735,1.8154735 C0.645719763,2.98522723 0,4.54162775 0,6.19812465 C0,7.85462155 0.643757089,9.4090594 1.8154735,10.5807758 C2.98522723,11.7505295 4.54162775,12.3962493 6.19812465,12.3962493 C7.5935859,12.3962493 8.92035356,11.9369836 10.0037496,11.0910711 L12.7946721,13.8819936 C12.9320593,14.0193807 13.1126253,14.0880743 13.295154,14.0880743 C13.4776827,14.0880743 13.656286,14.0193807 13.7956359,13.8819936 C14.0684476,13.6072192 14.0684476,13.1597295 13.7936732,12.8829925 Z M1.41508799,6.20008733 C1.41508799,3.5622534 3.56029073,1.41705066 6.19812465,1.41705066 C8.83595858,1.41705066 10.9811613,3.5622534 10.9811613,6.20008733 C10.9811613,8.83792125 8.83595858,10.983124 6.19812465,10.983124 C3.56029073,10.983124 1.41508799,8.83792125 1.41508799,6.20008733 Z",
                id: "形状"
            })
        })
    })
});
const fil_overview = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    height: "16",
    viewBox: "0 0 16 16",
    width: "16",
    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
        fill: "none",
        fillRule: "evenodd",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                height: "16",
                rx: ".583333",
                width: "16"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "m13.3333341 2c.3681996 0 .6666659.29848.6666659.66666667v10.66666663c0 .3682-.2984663.6666667-.6666659.6666667h-10.66666817c-.36819293 0-.66666593-.2984667-.66666593-.6666667v-10.66666663c0-.36818667.298473-.66666667.66666593-.66666667zm-.666666 1.33333333h-9.33333625v9.33333337h9.33333625zm-2.66667254 1.33333334c.36818494 0 .66666144.29847683.66666144.66666666 0 .36818984-.2984765.66666667-.66666144.66666667h-2.66666815v1.33333333h1.99999778c.36818942 0 .66667037.29847684.66667037.66666667s-.29848095.66666667-.66667037.66666667h-2.00066445l.00066667 2.00000003c0 .3681898-.2984765.6666666-.66666593.6666666-.36818942 0-.66666592-.2984768-.66666592-.6666666v-5.33333337c0-.36818983.2984765-.66666666.66666592-.66666666z",
                fill: "currentColor",
                fillRule: "nonzero"
            })
        ]
    })
});
const hot = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    height: "12",
    viewBox: "0 0 24 12",
    width: "24",
    children: [
        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("defs", {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("linearGradient", {
                    id: "a",
                    x1: "0%",
                    x2: "97.050251%",
                    y1: "47.679407%",
                    y2: "53.98266%",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                            offset: "0",
                            stopColor: "#e73b3b"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                            offset: "1",
                            stopColor: "#f55520"
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    id: "b",
                    d: "m5.37488914 9.2074191v-2.57734807h2.48980109v2.57734807h.9304447v-5.90055249h-.9304447v2.51933702h-2.48980109v-2.51933702h-.9304447v5.90055249zm7.00418096.04972376c.6547573 0 1.1975167-.22375691 1.619663-.62983426.5675915-.54598635.5857163-1.15804163.5858858-2.17471518l-.0000503-.19545056c0-1.13535912.0172305-1.79005525-.5858355-2.37016575-.4221463-.40607735-.9649057-.62983425-1.619663-.62983425-.6547574 0-1.1889016.2237569-1.6110478.62983425-.5321171.5118622-.5880117 1.08179281-.5937985 1.98874786v.76283577c.0057868.90695505.0616814 1.47688566.5937985 1.98874786.4221462.40607735.9562904.62983426 1.6110478.62983426zm0-.80386741c-.3618396 0-.6978336-.14088397-.9132143-.36464088-.2847811-.29742173-.3543943-.60962758-.3612502-1.641738l-.0005894-.18975371c0-1.18508288.0603066-1.51657459.3618396-1.83149172.2153807-.2237569.5513747-.36464088.9132143-.36464088s.6978335.14088398.9132142.36464088c.301533.31491713.3618396.64640884.3618396 1.83149172 0 1.18508287-.0603066 1.51657458-.3618396 1.83149171-.2153807.22375691-.5513746.36464088-.9132142.36464088zm5.4879006.75414365v-5.09668508h1.6885849v-.80386741h-4.3076144v.80386741h1.6885848v5.09668508z"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("filter", {
                    id: "c",
                    height: "266.7%",
                    width: "166.2%",
                    x: "-33.1%",
                    y: "-66.7%",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feOffset", {
                            dx: "0",
                            dy: "1",
                            in: "SourceAlpha",
                            result: "shadowOffsetOuter1"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feGaussianBlur", {
                            in: "shadowOffsetOuter1",
                            result: "shadowBlurOuter1",
                            stdDeviation: "1.5"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feColorMatrix", {
                            in: "shadowBlurOuter1",
                            type: "matrix",
                            values: "0 0 0 0 0.590750874   0 0 0 0 0.0496372439   0 0 0 0 0.0300789199  0 0 0 0.24182385 0"
                        })
                    ]
                })
            ]
        }),
        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
            fill: "none",
            fillRule: "evenodd",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "m2 0h16c3.3137085 0 6 2.6862915 6 6v4c0 1.1045695-.8954305 2-2 2h-16c-3.3137085 0-6-2.6862915-6-6v-4c0-1.1045695.8954305-2 2-2z",
                    fill: "url(#a)",
                    transform: "matrix(-1 0 0 1 24 0)"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                    fillRule: "nonzero",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("use", {
                            fill: "#000",
                            filter: "url(#c)",
                            xlinkHref: "#b"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("use", {
                            fill: "#fff",
                            xlinkHref: "#b"
                        })
                    ]
                })
            ]
        })
    ]
});
const newIcon = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    height: "12",
    viewBox: "0 0 26 12",
    width: "26",
    children: [
        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("defs", {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("linearGradient", {
                    id: "a",
                    x1: "0%",
                    x2: "97.050251%",
                    y1: "48.02269%",
                    y2: "53.393509%",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                            offset: "0",
                            stopColor: "#e73b3b"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("stop", {
                            offset: "1",
                            stopColor: "#f55520"
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    id: "d",
                    d: "m6.00597015 9v-4.22191011l2.45522388 4.22191011h.73880597v-6h-.80597015v4.21348315l-2.45522388-4.21348315h-.73880597v6zm7.99402985 0v-.81741573h-2.4404396v-1.80337079h2.0817583v-.80898876h-2.0817583v-1.75280899h2.4404396v-.81741573h-3.2v6zm2.9107185 0 1.0855124-4.20505618 1.0930506 4.20505618h.7085984l1.4021201-6h-.859364l-.9347467 4.28932584-1.0779741-4.28932584h-.6558304l-1.0779741 4.28932584-.9347467-4.28932584h-.859364l1.4021201 6z"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("filter", {
                    id: "c",
                    height: "266.7%",
                    width: "162.5%",
                    x: "-31.2%",
                    y: "-66.7%",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feOffset", {
                            dx: "0",
                            dy: "1",
                            in: "SourceAlpha",
                            result: "shadowOffsetOuter1"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feGaussianBlur", {
                            in: "shadowOffsetOuter1",
                            result: "shadowBlurOuter1",
                            stdDeviation: "1.5"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("feColorMatrix", {
                            in: "shadowBlurOuter1",
                            type: "matrix",
                            values: "0 0 0 0 0.590750874   0 0 0 0 0.0496372439   0 0 0 0 0.0300789199  0 0 0 0.24182385 0"
                        })
                    ]
                })
            ]
        }),
        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
            fill: "none",
            fillRule: "evenodd",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "m2 0h19c2.7614237 0 5 2.23857625 5 5v5c0 1.1045695-.8954305 2-2 2h-18c-3.3137085 0-6-2.6862915-6-6v-4c0-1.1045695.8954305-2 2-2z",
                    fill: "url(#a)",
                    transform: "matrix(-1 0 0 1 26 0)"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                    fillRule: "nonzero",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("use", {
                            fill: "#000",
                            filter: "url(#c)",
                            xlinkHref: "#d"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("use", {
                            fill: "#fff",
                            xlinkHref: "#d"
                        })
                    ]
                })
            ]
        })
    ]
});
const barLegend = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    height: "16",
    viewBox: "0 0 16 16",
    width: "16",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
        d: "m359 852h4c.552285 0 1 .447715 1 1v4c0 .552285-.447715 1-1 1h-4c-.552285 0-1-.447715-1-1v-4c0-.552285.447715-1 1-1z",
        fill: "currentColor",
        "fill-rule": "evenodd",
        transform: "translate(-350 -847)"
    })
});
const meta = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
    xmlns: "http://www.w3.org/2000/svg",
    height: "13",
    viewBox: "0 0 13 13",
    width: "13",
    fill: "currentColor",
    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
        d: "m4.36664104 1.35142438c.15363207.31166259.0250236.68861275-.28725507.84194173-1.71178983.84048967-2.81907918 2.5796638-2.81907918 4.51753184 0 2.77870012 2.25703428 5.03128165 5.04122716 5.03128165 1.92475966 0 3.65469708-1.0858016 4.50539075-2.77127574.1565667-.31020454.5354566-.43500305.8462743-.27874528.3108178.15625777.435863.5344002.2792963.84460474-1.062832 2.10578248-3.22557599 3.46323668-5.63096135 3.46323668-3.4802411 0-6.30153395-2.8157269-6.30153395-6.28910205 0-2.42180142 1.3842788-4.59603155 3.52303501-5.64616193.31227867-.15332898.68997395-.02497423.84360603.28668836zm2.80717792-1.35142438c3.09867234.25765748 5.56800754 2.72657396 5.82618104 5.82513172l-.0164727.20629333c-.1399534.56578827-.6483137.96857495-1.2380421.96857495h-4.4687107c-.70514309 0-1.2767745-.57162418-1.2767745-1.27675834v-4.4686542c0-.56717421.37296998-1.06138665.93913314-1.23105872l.02851855-.00705305zm.10231715 1.2932094.00063839 4.43003226 4.4291307-.00031919-.0350145-.23634375c-.3783985-2.19238008-2.15582149-3.90694569-4.37909473-4.19064632z"
    })
});
const svgTypes = {
    moon,
    sun,
    network,
    downIcon,
    uploadIcon,
    closeIcon,
    addIcon,
    account_overview,
    account_miners,
    account_personal,
    account_logout,
    legendIcon,
    no_nodes,
    editIcon,
    downloadIcon,
    successIcon,
    pendingIcon,
    errorIcon,
    dateArrowIcon,
    dateIcon,
    openAllIcon,
    deleteIcon,
    fileIcon,
    tip,
    outlook,
    telegram,
    twitter,
    block_chain,
    edit,
    copyIcon,
    search,
    fil_overview,
    hot,
    newIcon,
    barLegend,
    meta
};
const getSvgIcon = (type)=>{
    return svgTypes[type] || "";
};


/***/ }),

/***/ 3495:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $B: () => (/* binding */ get_account_type),
/* harmony export */   D2: () => (/* binding */ unitConversionNum),
/* harmony export */   EA: () => (/* binding */ isIndent),
/* harmony export */   Fy: () => (/* binding */ formatNumberPercentage),
/* harmony export */   H_: () => (/* binding */ account_link),
/* harmony export */   IC: () => (/* binding */ getShowData),
/* harmony export */   Mr: () => (/* binding */ max_name_length),
/* harmony export */   Nm: () => (/* binding */ formatFilNum),
/* harmony export */   P5: () => (/* binding */ pageLimit),
/* harmony export */   Qs: () => (/* binding */ titleCase),
/* harmony export */   Uk: () => (/* binding */ formatFil),
/* harmony export */   Uy: () => (/* binding */ get$Number),
/* harmony export */   dD: () => (/* binding */ parseQueryString),
/* harmony export */   dN: () => (/* binding */ unitConversion),
/* harmony export */   jE: () => (/* binding */ validateCode),
/* harmony export */   m$: () => (/* binding */ pageHomeLimit),
/* harmony export */   mr: () => (/* binding */ formatTime),
/* harmony export */   o0: () => (/* binding */ formatDateTime),
/* harmony export */   pf: () => (/* binding */ getCalcTime),
/* harmony export */   sQ: () => (/* binding */ formatNumberUnit),
/* harmony export */   tq: () => (/* binding */ isMobile),
/* harmony export */   uf: () => (/* binding */ formatNumber),
/* harmony export */   uo: () => (/* binding */ validatePassword)
/* harmony export */ });
/* unused harmony export getClassName */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _components_copy__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5174);
/* harmony import */ var _store_server__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(785);
/* harmony import */ var bignumber_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9766);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1635);
/* harmony import */ var dayjs__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(dayjs__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9676);
/* harmony import */ var _assets_images_icon_copy_svg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5903);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([bignumber_js__WEBPACK_IMPORTED_MODULE_3__]);
bignumber_js__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/** @format */ 








const pageLimit = 15;
const pageHomeLimit = 10;
const max_name_length = 10;
// 账户类型
/*
account:一般账户

*/ function parseQueryString(queryString) {
    const params = new URLSearchParams(queryString);
    const obj = {};
    for (const [key, value] of params.entries()){
        if (obj[key]) {
            if (Array.isArray(obj[key])) {
                obj[key].push(value);
            } else {
                obj[key] = [
                    obj[key],
                    value
                ];
            }
        } else {
            obj[key] = value;
        }
    }
    return obj;
}
function getShowData(item, data) {
    let showData = data;
    const [first, second] = item.type || [];
    if (first) {
        if (second) {
            showData = data && data[first] && data[first][second];
        } else {
            showData = data && data[first];
        }
    }
    return showData;
}
function formatFil(number, unit = "FIL", len = 4, isAccount) {
    let returnValue;
    const num = Math.abs(Number(number));
    const flag = Number(number) < 0 ? "-" : "";
    if (unit.startsWith("FIL")) {
        const showNum = new bignumber_js__WEBPACK_IMPORTED_MODULE_3__["default"](num).dividedBy(Math.pow(10, 18));
        returnValue = Number(showNum);
    } else if (unit === "nanoFiL") {
        const showNum = new bignumber_js__WEBPACK_IMPORTED_MODULE_3__["default"](num).dividedBy(Math.pow(10, 9));
        returnValue = Number(showNum);
    } else {
        returnValue = Number(num);
    }
    if (isAccount) {
        //unit === 'FIL',len=4
        if (returnValue === 0) {
            return `0 ${unit}`;
        }
        if (returnValue < 0.0001) {
            return "<0.0001 FIL";
        }
        return len ? flag + Number(returnValue).toLocaleString("en", {
            maximumFractionDigits: len
        }) + " " + unit : flag + Number(returnValue);
    }
    return len ? flag + Number(returnValue).toFixed(len) : flag + Number(returnValue);
}
function formatFilNum(showNum, atto = false, pure = false, len = 4, toLocal = true) {
    let baseNum = Number(showNum);
    let num = baseNum;
    let flag = "";
    if (atto) {
        return num + (pure ? "" : " attoFIL");
    }
    if (baseNum < 0) {
        num = Math.abs(baseNum);
        flag = "-";
    }
    let dot = new bignumber_js__WEBPACK_IMPORTED_MODULE_3__["default"](Number(num)).dividedBy(Math.pow(10, 18)).toFixed().split(".")[1];
    const num1 = new bignumber_js__WEBPACK_IMPORTED_MODULE_3__["default"](Number(num)).dividedBy(Math.pow(10, 18)).toFixed().split(".")[0];
    const num2 = new bignumber_js__WEBPACK_IMPORTED_MODULE_3__["default"](Number(num)).dividedBy(Math.pow(10, 9)).toFixed(len).split(".")[0];
    let zero = 1;
    let res = num;
    let unit = " attoFIL";
    if (atto) {
        unit = " attoFIL";
        num = num;
    }
    if (dot) {
        for (let v of dot){
            if (Number(v) !== 0) {
                break;
            } else {
                zero++;
            }
        }
    }
    if (zero <= 5 && Number(num1) || num2.length > 6) {
        res = new bignumber_js__WEBPACK_IMPORTED_MODULE_3__["default"](Number(num)).dividedBy(Math.pow(10, 18)).toFixed(len);
        unit = " FIL";
    //return num + " FIL";
    } else if (zero <= 13 && Number(num) > Math.pow(10, 7)) {
        res = new bignumber_js__WEBPACK_IMPORTED_MODULE_3__["default"](Number(num)).dividedBy(Math.pow(10, 9)).toFixed(len);
        unit = " nanoFIL";
    } else {
        res = num;
        unit = " attoFIL";
    }
    if (res === 0 && unit === " attoFIL") {
        return "0 FIL";
    }
    return toLocal ? flag + formatNumber(res) + (pure ? "" : unit) : flag + res + (pure ? "" : unit);
}
const unitConversionNum = (str)=>{
    let sizes = [
        "Bytes",
        "KiB",
        "MiB",
        "GiB",
        "TiB",
        "PiB",
        "EiB",
        "ZiB",
        "YiB"
    ];
    return sizes.findIndex((v)=>v === str);
};
const unitConversion = (item, len, num = 0)=>{
    let showItem = Number(item);
    let sizes = [
        "Bytes",
        "KiB",
        "MiB",
        "GiB",
        "TiB",
        "PiB",
        "EiB",
        "ZiB",
        "YiB"
    ];
    let positive = true;
    if (showItem == 0) {
        let unit = sizes[num];
        if (unit === "Bytes") {
            unit = "Byte";
        }
        return "0" + " " + unit;
    }
    if (showItem < 0) {
        positive = false;
        showItem = Math.abs(showItem);
    }
    let k = 1024;
    let c = num || Math.floor(Math.log(showItem) / Math.log(k));
    if (c < 0) {
        showItem = 0;
    } else {
        let units = sizes[c];
        if (!showItem && units === "Bytes") {
            units = "Byte";
        }
        showItem = (showItem / Math.pow(k, c)).toFixed(len) + " " + units;
    }
    return positive ? `${showItem}` : `-${showItem}`;
};
function formatNumber(v, len = 4) {
    if (Number(v) === 0) {
        return v;
    }
    return v ? Number(v).toLocaleString("en", {
        maximumFractionDigits: len
    }) : "--";
}
function formatDateTime(time, str = "YYYY-MM-DD HH:mm:ss") {
    if (!time) return "--";
    return typeof time === "number" ? dayjs__WEBPACK_IMPORTED_MODULE_4___default()(time * 1000).format(str) : dayjs__WEBPACK_IMPORTED_MODULE_4___default()(time).format(str);
}
function formatTime(from, to, ago = true) {
    let startTime = from; // 开始时间
    let endTime = to || new Date().getTime(); // 结束时间
    let usedTime = endTime - startTime; // 相差的毫秒数
    //timeDifference(usedTime)
    // let days = Math.floor(usedTime / (24 * 3600 * 1000)); // 计算出天数
    // let leavel = usedTime % (24 * 3600 * 1000); // 计算天数后剩余的时间
    // let hours = Math.floor(leavel / (3600 * 1000)); // 计算剩余的小时数
    // let leavel2 = leavel % (3600 * 1000); // 计算剩余小时后剩余的毫秒数
    //  let minutes = Math.floor(leavel2 / (60 * 1000)); // 计算剩余的分钟数
    // let second = runTime % 60
    //计算出相差天数
    let days = Math.floor(usedTime / (24 * 3600 * 1000));
    //计算出小时数
    let leave1 = usedTime % (24 * 3600 * 1000);
    //计算天数后剩余的毫秒数
    let hours = Math.floor(leave1 / (3600 * 1000));
    //计算相差分钟数
    let leave2 = leave1 % (3600 * 1000); //计算小时数后剩余的毫秒数
    let minutes = Math.floor(leave2 / (60 * 1000)); // 分
    //计算相差秒数
    let leave3 = leave2 % (60 * 1000); //计算分钟数后剩余的毫秒数
    let seconds = Math.round(leave3 / 1000); // 秒
    //let second = runTime % 60
    return {
        days,
        hours,
        minutes,
        seconds
    };
}
function isIndent(str, unit = 6, unitNum) {
    const showUnit = unitNum ? unit + unitNum : unit * 2;
    const suffixNum = unitNum || unit;
    return str && unit && str.length > showUnit ? str?.slice(0, unit) + "..." + str?.slice(-suffixNum) : str;
}
function formatNumberUnit(number, len = 2) {
    const num = Number(number);
    if (num >= 1e9) {
        return Number(num / 1e9).toLocaleString("en", {
            maximumFractionDigits: len
        }) + "B";
    }
    if (num >= 1e6) {
        return Number(num / 1e6).toLocaleString("en", {
            maximumFractionDigits: len
        }) + "M";
    }
    // if (num >= 1e3) {
    //   return Number(num / 1e3).toLocaleString('en', { maximumFractionDigits: len }) +'K'
    // }
    return Number(num).toLocaleString("en", {
        maximumFractionDigits: len
    });
}
//连续0后保留几位
function truncateDecimalAfterZeros(num, decimalPlaces = 2) {
    const strNum = num.toString();
    const match = strNum.match(/0\.(0*)(\d{1,2})?/);
    if (!match) {
        return parseFloat(strNum).toFixed(decimalPlaces);
    }
    const leadingZeros = match[1];
    const digits = match[2] || "";
    return "0." + leadingZeros + digits;
}
// $ + number
function get$Number(str, len) {
    const showNum = Number(str);
    let showStr = str.toString();
    let flag = "";
    if (showStr.includes("-")) {
        showStr = showStr.split("-")[1];
        flag = "-";
    }
    if (str > "0" && str < "1") {
        return flag + "$" + truncateDecimalAfterZeros(showStr, 2);
    }
    const newNum = showNum < 0 ? "-$" + formatNumberUnit(Math.abs(showNum), len) : "$" + formatNumberUnit(showNum, len);
    return newNum;
}
//%
function formatNumberPercentage(num, decimalPlaces = 2) {
    return parseFloat((Number(num) * 100).toFixed(decimalPlaces));
}
function getClassName(str) {
    const showNum = Number(str);
    if (showNum === 0) return "";
    return showNum < 0 ? "text_red" : "text_green";
}
//获取当天的日期
function getCalcTime(startTime) {
    if (startTime) {
        return (new Date().getTime() - startTime * 24 * 60 * 60 * 1000) / 1000;
    }
    return new Date().getTime() / 1000;
}
//密码校验规则
function validatePassword(password, email) {
    // 8-20个字符
    if (password.length < 8 || password.length > 20) {
        return false;
    }
    // 需要同时包含数字、字母
    if (!/[A-Za-z]/.test(password) || !/[0-9]/.test(password)) {
        return false;
    }
    // 密码不能与邮箱地址相同
    if (password === email) {
        return false;
    }
    return true;
}
// 校验验证码
function validateCode(code) {
    // 六位验证码 9999 100000
    const newCode = Number(code);
    return newCode > 99999 && newCode < 1000000;
}
//首字母大写,其余不变
function titleCase(str) {
    const Str = String(str);
    const newStr = Str.slice(0, 1).toUpperCase() + Str.slice(1);
    return newStr;
}
//不同账户 ,
const get_account_type = (value = "", unit = 6)=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_6__/* .MobileView */ .$, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "copy-row",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "w-28 text",
                            onClick: ()=>{
                                account_link(value);
                            },
                            children: value
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                            text: value,
                            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_icon_copy_svg__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}),
                            className: "copy"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_device_detect__WEBPACK_IMPORTED_MODULE_6__/* .BrowserView */ .I, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "link_text",
                        onClick: ()=>{
                            account_link(value);
                        },
                        children: isIndent(value, unit)
                    }),
                    value && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        className: "!w-[13px]",
                        text: value
                    })
                ]
            })
        ]
    });
};
const account_link = async (value)=>{
    let show_type;
    const result = await (0,_store_server__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.searchInfo, {
        input: value
    });
    show_type = result?.result_type;
    switch(show_type){
        case "miner":
            return next_router__WEBPACK_IMPORTED_MODULE_5___default().push(`/miner/${value}`, `/miner/${value}`, {
                scroll: true
            });
        case "storageminer":
            return next_router__WEBPACK_IMPORTED_MODULE_5___default().push(`/miner/${value}`, `/miner/${value}`, {
                scroll: true
            });
        default:
            return next_router__WEBPACK_IMPORTED_MODULE_5___default().push(`/address/${value}`, `/address/${value}`, {
                scroll: true
            });
    }
};
const isMobile = ()=>{
    try {
        return window.innerWidth <= 1000;
    } catch (error) {
        console.log("Error: Window does not exist!");
        return false;
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7526:
/***/ (() => {



/***/ }),

/***/ 6333:
/***/ (() => {



/***/ }),

/***/ 6764:
/***/ (() => {



/***/ })

};
;