exports.id = 3055;
exports.ids = [3055];
exports.modules = {

/***/ 17689:
/***/ ((module) => {

// Exports
module.exports = {
	"skeleton_screen": "skeleton_skeleton_screen__0AC9J",
	"loading": "skeleton_loading__ww4DW"
};


/***/ }),

/***/ 79922:
/***/ ((module) => {

// Exports
module.exports = {
	"echart": "accountChange_echart__k0KiW",
	"legend-title-wrap": "accountChange_legend-title-wrap__YhbL8",
	"legend-title": "accountChange_legend-title__vU0nP"
};


/***/ }),

/***/ 88465:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(17689);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_2__);
/** @format */ 


function SkeletonScreen() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_2___default().skeleton_screen)
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SkeletonScreen);


/***/ }),

/***/ 16735:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _components_echarts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(13778);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(62881);
/* harmony import */ var _contents_detail__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(78817);
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(48804);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7947);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(23495);
/* harmony import */ var _utils_echarts__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7355);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(29676);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(79922);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(31061);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(68108);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_detail__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_7__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_13__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_detail__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_7__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 














/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ accountId, interval, list, header })=>{
    const { theme, lang } = (0,_store_FilscanStore__WEBPACK_IMPORTED_MODULE_5__/* .useFilscanStore */ .J)();
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__/* .Translation */ .W)({
        ns: "detail"
    });
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)({});
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z)();
    const [noShow, setNoShow] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)({});
    const { isMobile } = (0,_components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)();
    const color = (0,react__WEBPACK_IMPORTED_MODULE_9__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_8__/* .getColor */ .Lq)(theme);
    }, [
        theme
    ]);
    const default_xAxis = (0,react__WEBPACK_IMPORTED_MODULE_9__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_8__/* .get_xAxis */ .Fs)(theme, isMobile);
    }, [
        theme,
        isMobile
    ]);
    const defaultOptions = (0,react__WEBPACK_IMPORTED_MODULE_9__.useMemo)(()=>{
        return {
            grid: {
                top: 10,
                left: 20,
                right: list ? 10 : "8%",
                bottom: 10,
                containLabel: true
            },
            yAxis: {
                type: "value",
                scale: true,
                nameTextStyle: {
                    color: color.textStyle,
                    align: "left"
                },
                axisLine: {
                    show: false
                },
                axisTick: {
                    show: false
                },
                axisLabel: {
                    show: true,
                    lineStyle: {
                        color: color.lineStyle
                    },
                    textStyle: {
                        color: isMobile ? color.mobileLabelColor : color.labelColor
                    },
                    formatter (v) {
                        return v + " FIL";
                    }
                },
                splitLine: {
                    show: true,
                    lineStyle: {
                        type: "dashed",
                        color: color.splitLine
                    }
                }
            },
            tooltip: {
                trigger: "axis",
                position: "right",
                backgroundColor: color.toolbox,
                borderColor: "transparent",
                textStyle: {
                    color: "#ffffff"
                },
                formatter (p) {
                    let result = p[0].data.showTime || p[0].name;
                    p.forEach((item, index)=>{
                        if (item.data) {
                            result += "<br/>" + item.marker + tr(item.seriesName) + ": " + item.data.amount + " " + item.data.unit;
                        }
                    });
                    return result;
                }
            }
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        theme,
        isMobile
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_9__.useEffect)(()=>{
        if (accountId) {
            load();
        }
    }, [
        accountId,
        interval,
        isMobile
    ]);
    const load = async ()=>{
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.account_change, {
            account_id: accountId,
            filters: {
                interval: interval
            }
        });
        const dateList = [];
        const seriesObj = {
            balance: [],
            available_balance: [],
            initial_pledge: [],
            locked_funds: []
        };
        const seriesData = [];
        const legendData = [];
        (result?.balance_trend_by_account_id_list || []).forEach((item)=>{
            const { block_time, available_balance, balance, //precommit_deposits,
            locked_funds, initial_pledge } = item;
            let showTime = interval === "24h" ? (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatDateTime */ .o0)(block_time, "HH:mm") : (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatDateTime */ .o0)(block_time, "MM-DD HH:mm");
            if (isMobile && interval !== "24h") {
                showTime = (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatDateTime */ .o0)(block_time, "MM-DD");
            }
            dateList.push(showTime);
            const [balance_amount, balance_unit] = balance ? (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatFilNum */ .Nm)(balance, false, false, 4, false)?.split(" ") : [];
            const [available_balance_amount, available_balance_unit] = available_balance ? (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatFilNum */ .Nm)(available_balance, false, false, 4, false)?.split(" ") : [];
            //   const [precommit_deposits_amount, precommit_deposits_unit] =
            //     precommit_deposits
            //       ? formatFilNum(precommit_deposits, false, false, 4, false)?.split(' ')
            //       : [];
            const [locked_funds_amount, locked_funds_unit] = locked_funds ? (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatFilNum */ .Nm)(locked_funds, false, false, 4, false)?.split(" ") : [];
            const [initial_pledge_amount, initial_pledge_unit] = initial_pledge ? (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatFilNum */ .Nm)(initial_pledge, false, false, 4, false)?.split(" ") : [];
            if (available_balance) {
                seriesObj.available_balance.push({
                    amount: available_balance_amount,
                    value: (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatFil */ .Uk)(available_balance),
                    unit: available_balance_unit,
                    showTime: (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatDateTime */ .o0)(block_time, "YYYY-MM-DD HH:mm")
                });
            }
            if (balance) {
                seriesObj.balance.push({
                    amount: balance_amount,
                    value: (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatFil */ .Uk)(balance),
                    unit: balance_unit,
                    showTime: (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatDateTime */ .o0)(block_time, "YYYY-MM-DD HH:mm")
                });
            }
            if (initial_pledge) {
                seriesObj.initial_pledge.push({
                    amount: initial_pledge_amount,
                    value: (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatFil */ .Uk)(initial_pledge),
                    unit: initial_pledge_unit,
                    showTime: (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatDateTime */ .o0)(block_time, "YYYY-MM-DD HH:mm")
                });
            }
            if (locked_funds) {
                seriesObj.locked_funds.push({
                    amount: locked_funds_amount,
                    value: (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatFil */ .Uk)(locked_funds),
                    unit: locked_funds_unit,
                    showTime: (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatDateTime */ .o0)(block_time, "YYYY-MM-DD HH:mm")
                });
            }
        });
        (list || _contents_detail__WEBPACK_IMPORTED_MODULE_4__/* .account_change */ .UW.list).forEach((item)=>{
            const dataIndex = item?.dataIndex;
            let otherObj = {};
            if (item.seriesChangeArea) {
                otherObj = {
                    ..._utils_echarts__WEBPACK_IMPORTED_MODULE_8__/* .seriesChangeArea */ .v$
                };
            }
            legendData.push({
                dataIndex,
                color: item.color,
                title: item.title
            });
            seriesData.push({
                ...otherObj,
                type: item.type,
                smooth: true,
                data: seriesObj[dataIndex],
                name: item.title,
                dataIndex,
                symbol: "circle",
                itemStyle: {
                    color: item.color
                }
            });
        });
        setOptions({
            series: seriesData,
            xData: dateList,
            legendData: legendData
        });
    };
    const newOptions = (0,react__WEBPACK_IMPORTED_MODULE_9__.useMemo)(()=>{
        const newSeries = [];
        (options?.series || []).forEach((seriesItem)=>{
            if (!noShow[seriesItem?.dataIndex]) {
                newSeries.push(seriesItem);
            }
        });
        if (isMobile) {
            defaultOptions.legend = {
                show: false
            };
            defaultOptions.grid.left = 0;
            defaultOptions.grid.right = "10px";
            default_xAxis.axisLabel.padding = [
                0,
                10,
                0,
                0
            ];
        }
        return {
            ...defaultOptions,
            xAxis: {
                ...default_xAxis,
                data: options?.xData || []
            },
            series: newSeries
        };
    }, [
        options,
        default_xAxis,
        noShow,
        defaultOptions,
        isMobile
    ]);
    const ledRender = ()=>{
        if ((lang === "en" || lang === "ka") && isMobile) {
            return options?.legendData?.length > 1 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: classnames__WEBPACK_IMPORTED_MODULE_11___default()("grid grid-cols-2 gap-2"),
                children: options?.legendData?.map((v)=>{
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: classnames__WEBPACK_IMPORTED_MODULE_11___default()("text-xs flex cursor-pointer items-center gap-x-1", (_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default()["legend-title-wrap"])),
                        onClick: ()=>{
                            setNoShow({
                                ...noShow,
                                [v.dataIndex]: !noShow[v.dataIndex]
                            });
                        },
                        style: {
                            color: noShow[v.dataIndex] ? "#d1d5db" : v.color
                        },
                        children: [
                            (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_6__/* .getSvgIcon */ .a)("legendIcon"),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: classnames__WEBPACK_IMPORTED_MODULE_11___default()("text-xs text_des font-normal", (_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default()["legend-title"])),
                                children: tr(v.title)
                            })
                        ]
                    }, v.dataIndex);
                })
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
        }
        return options?.legendData?.length > 1 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
            className: classnames__WEBPACK_IMPORTED_MODULE_11___default()("flex gap-x-4 mr-2.5"),
            children: options?.legendData?.map((v)=>{
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: classnames__WEBPACK_IMPORTED_MODULE_11___default()("text-xs flex cursor-pointer items-center gap-x-1", (_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default()["legend-title-wrap"])),
                    onClick: ()=>{
                        setNoShow({
                            ...noShow,
                            [v.dataIndex]: !noShow[v.dataIndex]
                        });
                    },
                    style: {
                        color: noShow[v.dataIndex] ? "#d1d5db" : v.color
                    },
                    children: [
                        (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_6__/* .getSvgIcon */ .a)("legendIcon"),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: classnames__WEBPACK_IMPORTED_MODULE_11___default()("text-xs text_des font-normal", (_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default()["legend-title"])),
                            children: tr(v.title)
                        })
                    ]
                }, v.dataIndex);
            })
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex-1",
        children: [
            header ? header : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_11___default()("flex justify-between  items-center mb-2 h-[32px]"),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-lg font-semibold mr-5 name-height mx-2.5",
                        children: tr(_contents_detail__WEBPACK_IMPORTED_MODULE_4__/* .account_change */ .UW.title)
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_10__/* .BrowserView */ .I, {
                        children: ledRender()
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_11___default()("card_shadow w-full border rounded-xl p-2.5 pt-5 border_color", (_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default().echart)),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_10__/* .MobileView */ .$, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "tips mb-2",
                            children: ledRender()
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full h-[348px]",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                            options: newOptions
                        })
                    })
                ]
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;