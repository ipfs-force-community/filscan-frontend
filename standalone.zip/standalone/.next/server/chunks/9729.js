"use strict";
exports.id = 9729;
exports.ids = [9729];
exports.modules = {

/***/ 9729:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   QU: () => (/* binding */ meta_list),
/* harmony export */   g9: () => (/* binding */ no_result),
/* harmony export */   nW: () => (/* binding */ home_meta)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3495);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils__WEBPACK_IMPORTED_MODULE_1__]);
_utils__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/** @format */ 

const home_meta = [
    {
        title: "quality_power/increase_24h",
        dataIndex: "total_quality_power",
        tip: "total_quality_power_tip",
        tipContent: [
            {
                title: "quality_power_Cc",
                dataIndex: "Cc",
                render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .unitConversion */ .dN)(text, 2)
            },
            {
                title: "quality_power_Dc",
                dataIndex: "Dc",
                render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .unitConversion */ .dN)(text, 2)
            }
        ],
        render: (v, record)=>{
            const changeText = record?.power_increase_24h && Number(record.power_increase_24h);
            const className = changeText ? changeText < 0 ? "text_red" : "text_green" : "";
            const flag = changeText ? changeText > 0 ? "+" : "-" : "";
            const [textValue, unit] = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .unitConversion */ .dN)(v, 2).split(" ");
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: textValue
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "inline text-xs ml-1 unit",
                        children: unit
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: `${className} font-DINPro-Medium text-xs ml-1`,
                        children: `${flag}${(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .unitConversion */ .dN)(Math.abs(changeText), 2)}`
                    })
                ]
            });
        }
    },
    {
        title: "add_power_in_32g",
        title_tip: "add_power_in_32g_tip",
        tip: "add_power_in_32g_tip",
        dataIndex: "add_power_in_32g",
        tipContent: [
            {
                title: "gas_in_32g",
                dataIndex: "gas_in_32g",
                render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(text, false, false, 2) + "/TIB"
            },
            {
                title: "gas_in_64g",
                dataIndex: "gas_in_64g",
                render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(text, false, false, 2) + "/TIB"
            }
        ],
        render: (v)=>{
            const [show, unit] = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(v, false, false, 4).split(" ");
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: show
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-xs ml-1 unit",
                        children: unit + "/TiB"
                    })
                ]
            });
        }
    },
    {
        title: "miner_initial_pledge",
        dataIndex: "miner_initial_pledge",
        render: (v)=>{
            const [show, unit] = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(v, false, false, 4).split(" ");
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: show
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-xs ml-1 unit",
                        children: unit + "/TiB"
                    })
                ]
            });
        }
    },
    {
        title: "fil_per_tera_24h",
        tip: "fil_per_tera_24h_tip",
        dataIndex: "fil_per_tera_24h",
        render: (v)=>{
            const [show, unit] = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(v, false, false, 4).split(" ");
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: show
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-xs ml-1 unit",
                        children: unit + "/TiB"
                    })
                ]
            });
        }
    },
    {
        title: "total_contract/24h_contract",
        dataIndex: "total_contract",
        tip: "total_contract/24h_contract_tip",
        tipContent: [
            {
                title: "verified_contracts",
                dataIndex: "verified_contracts"
            }
        ],
        render: (v, record)=>{
            const changeText = record?.total_contract_change_in_24h && Number(record.total_contract_change_in_24h);
            const className = changeText ? changeText < 0 ? "text_red" : "text_green" : "";
            const flag = changeText ? changeText > 0 ? "+" : "-" : "";
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: "flex gap-x-1 items-baseline",
                children: [
                    (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(v, 2),
                    changeText && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: `${className} font-medium font-DINPro-Medium text-xs`,
                        children: [
                            flag,
                            changeText
                        ]
                    })
                ]
            });
        }
    },
    {
        title: "contract_transaction/24h_change",
        dataIndex: "contract_txs",
        render: (v, record)=>{
            const changeText = record?.contract_txs_change_in_24h && Number(record.contract_txs_change_in_24h);
            const className = changeText ? changeText < 0 ? "text_red" : "text_green" : "";
            const flag = changeText ? changeText > 0 ? "+" : "-" : "";
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: "flex gap-x-1 items-baseline",
                children: [
                    (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(v, 2),
                    changeText && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: `${className} font-medium font-DINPro-Medium text-xs`,
                        children: [
                            flag,
                            changeText
                        ]
                    })
                ]
            });
        }
    },
    {
        title: "contract_address/24h_change",
        dataIndex: "contract_users",
        render: (v, record)=>{
            const changeText = record?.contract_users_change_in_24h && Number(record.contract_users_change_in_24h);
            const className = changeText ? changeText < 0 ? "text_red" : "text_green" : "";
            const flag = changeText ? changeText > 0 ? "+" : "-" : "";
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: "flex gap-x-1 items-baseline",
                children: [
                    (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(v, 2),
                    changeText && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: `${className} font-medium  font-DINPro-Medium text-xs`,
                        children: [
                            flag,
                            " ",
                            changeText
                        ]
                    })
                ]
            });
        }
    },
    {
        title: "gas_24",
        dataIndex: "sum",
        tipContent: [
            {
                title: "contract_gas",
                dataIndex: "contract_gas",
                render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(text, false, false, 2)
            }
        ],
        render: (v)=>{
            const [show, unit] = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(v, false, false, 4).split(" ");
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: show
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-xs ml-1 unit",
                        children: unit
                    })
                ]
            });
        }
    }
];
const meta_list = [
    {
        title: "power_increase_24h",
        dataIndex: "power_increase_24h",
        render: (v)=>{
            if (!v) return "--";
            const [textValue, unit] = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .unitConversion */ .dN)(v, 4).split(" ");
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: textValue + " "
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "unit",
                        children: unit
                    })
                ]
            });
        }
    },
    //最新区块时间
    // {
    //   title: 'total_blocks',
    //   dataIndex:'total_blocks',
    //   render: (v: number | string) => formatNumber(v, 2)
    // }, //全网出块数量
    {
        title: "total_quality_power",
        tip: "total_quality_power_tip",
        dataIndex: "total_quality_power",
        render: (v)=>{
            if (!v) return "--";
            const [textValue, unit] = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .unitConversion */ .dN)(v, 4).split(" ");
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: textValue + " "
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "unit",
                        children: unit
                    })
                ]
            });
        }
    },
    {
        title: "rewards_increase_24h",
        dataIndex: "rewards_increase_24h",
        render: (v)=>{
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)((0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFil */ .Uk)(v, "FIL"), 2) + " "
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "unit",
                        children: "FIL"
                    })
                ]
            });
        }
    },
    {
        title: "miner_initial_pledge",
        dataIndex: "miner_initial_pledge",
        render: (v)=>{
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)((0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFil */ .Uk)(v, "FIL", 4)) + " "
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "unit",
                        children: "FIL/TiB"
                    })
                ]
            });
        }
    },
    // {
    //   title: 'base_fee',
    //   dataIndex:'base_fee',
    //   render: (v: string | number) => {
    //     return formatFilNum(Number(v),false,false) //  Number(formatFil(v,'attoFIL'))+' attoFIL'
    //   }
    // }, //当前基础费率
    {
        title: "gas_in_32g_meta",
        tip: "gas_in_32g_tip",
        dataIndex: "gas_in_32g",
        render: (v)=>{
            let value = "";
            let unit = "";
            if (Number(v) < 0.0001) {
                value = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFil */ .Uk)(v, "nanoFIL", 4);
                unit = "nanoFIL/TiB";
            } else {
                value = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFil */ .Uk)(v, "FIL", 4);
                unit = "FIL/TiB";
            }
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: value + " "
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "unit",
                        children: unit
                    })
                ]
            });
        }
    },
    {
        title: "add_power_in_32g",
        tip: "add_power_in_32g_tip",
        dataIndex: "add_power_in_32g",
        render: (v)=>{
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFil */ .Uk)(v, "FIL", 4) + " "
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "unit",
                        children: "FIL/TiB"
                    })
                ]
            });
        }
    },
    {
        title: "fil_per_tera_24h",
        tip: "fil_per_tera_24h_tip",
        dataIndex: "fil_per_tera_24h",
        render: (v)=>{
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFil */ .Uk)(v, "FIL", 4) + " "
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "unit",
                        children: "FIL/TiB"
                    })
                ]
            });
        }
    },
    {
        title: "total_rewards",
        dataIndex: "total_rewards",
        render: (v)=>{
            // return Number(formatFil(v,'FIL')).toLocaleString() + ' FIL'
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: Number((0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFil */ .Uk)(v, "FIL")).toLocaleString() + " "
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "unit",
                        children: "FIL"
                    })
                ]
            });
        }
    },
    {
        title: "win_count_reward",
        dataIndex: "win_count_reward",
        render: (v)=>{
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: Number((0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFil */ .Uk)(v, "FIL", 4)).toLocaleString() + " "
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "unit",
                        children: "FIL"
                    })
                ]
            });
        }
    },
    {
        title: "gas_in_64g_meta",
        tip: "gas_in_64g_tip",
        dataIndex: "gas_in_64g",
        render: (v)=>{
            let value = "";
            let unit = "";
            if (Number(v) < 0.0001) {
                value = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFil */ .Uk)(v, "nanoFIL", 4);
                unit = "nanoFIL/TiB";
            } else {
                value = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFil */ .Uk)(v, "FIL", 4);
                unit = "FIL/TiB";
            }
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: value + " "
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "unit",
                        children: unit
                    })
                ]
            });
        }
    },
    {
        title: "add_power_in_64g",
        tip: "add_power_in_64g_tip",
        dataIndex: "add_power_in_64g",
        render: (v)=>{
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFil */ .Uk)(v, "FIL", 4) + " "
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "unit",
                        children: "FIL/TiB"
                    })
                ]
            });
        }
    },
    {
        title: "avg_block_count",
        tip: "avg_block_count_tip",
        dataIndex: "avg_block_count",
        render: (v)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(v)
    },
    {
        title: "avg_message_count",
        dataIndex: "avg_message_count",
        tip: "avg_message_count_tip",
        render: (v)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(v)
    },
    {
        title: "active_miners",
        dataIndex: "active_miners",
        render: (v)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(v)
    },
    {
        title: "burnt",
        dataIndex: "burnt",
        render: (v)=>{
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)((0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFil */ .Uk)(v, "FIL"), 4) + " "
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "unit",
                        children: "FIL"
                    })
                ]
            });
        }
    },
    {
        title: "circulating_percent",
        dataIndex: "circulating_percent",
        render: (v)=>Number(v * 100).toFixed(2) + "%"
    },
    {
        title: "total_contract",
        dataIndex: "total_contract",
        tip: "total_contract/24h_contract_tip",
        render: (v, record)=>{
            const changeText = record?.total_contract_change_in_24h && Number(record.total_contract_change_in_24h);
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "flex gap-x-1 items-baseline",
                children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(v, 2)
            });
        }
    },
    {
        title: "total_contract_24h_contract",
        dataIndex: "total_contract_change_in_24h",
        render: (v, record)=>{
            const changeText = record?.total_contract_change_in_24h && Number(record.total_contract_change_in_24h);
            const className = changeText ? changeText < 0 ? "text_red" : "text_green" : "";
            const flag = changeText ? changeText > 0 ? "+" : "-" : "";
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: "flex gap-x-1 items-baseline",
                children: [
                    flag,
                    Math.abs(changeText)
                ]
            });
        }
    },
    {
        title: "verified_contracts",
        dataIndex: "verified_contracts"
    },
    {
        title: "contract_transaction",
        dataIndex: "contract_txs",
        render: (v, record)=>{
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "flex gap-x-1 items-baseline",
                children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(v, 2)
            });
        }
    },
    {
        title: "contract_transaction_24h_change",
        dataIndex: "contract_txs",
        render: (v, record)=>{
            const changeText = record?.contract_txs_change_in_24h && Number(record.contract_txs_change_in_24h);
            const flag = changeText ? changeText > 0 ? "+" : "-" : "";
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "flex gap-x-1 items-baseline",
                children: changeText && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    children: [
                        flag,
                        changeText
                    ]
                })
            });
        }
    },
    {
        title: "contract_address",
        dataIndex: "contract_users",
        render: (v, record)=>{
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "flex gap-x-1 items-baseline",
                children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(v, 2)
            });
        }
    },
    {
        title: "contract_address_24h_change",
        dataIndex: "contract_users",
        render: (v, record)=>{
            const changeText = record?.contract_users_change_in_24h && Number(record.contract_users_change_in_24h);
            const flag = changeText ? changeText > 0 ? "+" : "-" : "";
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "flex gap-x-1 items-baseline",
                children: changeText && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    children: [
                        flag,
                        " ",
                        changeText
                    ]
                })
            });
        }
    },
    {
        title: "gas_24",
        dataIndex: "sum",
        tipContent: [
            {
                title: "contract_gas",
                dataIndex: "contract_gas",
                render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(text, false, false, 2)
            }
        ],
        render: (v)=>{
            const [show, unit] = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(v, false, false, 4).split(" ");
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: show
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-xs ml-1 unit",
                        children: unit
                    })
                ]
            });
        }
    },
    {
        title: "quality_power_Cc",
        dataIndex: "Cc",
        render: (text)=>{
            const [textValue, unit] = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .unitConversion */ .dN)(text, 2).split(" ");
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: textValue + " "
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "unit",
                        children: unit
                    })
                ]
            });
        }
    },
    {
        title: "quality_power_Dc",
        dataIndex: "Dc",
        render: (text)=>{
            const [textValue, unit] = (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .unitConversion */ .dN)(text, 2).split(" ");
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: textValue + " "
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "unit",
                        children: unit
                    })
                ]
            });
        }
    }
];
const no_result = {
    title: "search_notFound",
    warn_text: "warn_text",
    warn_details: "warn_details",
    go_home: "go_home"
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;