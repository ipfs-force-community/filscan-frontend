exports.id = 2373;
exports.ids = [2373];
exports.modules = {

/***/ 7689:
/***/ ((module) => {

// Exports
module.exports = {
	"skeleton_screen": "skeleton_skeleton_screen__0AC9J",
	"loading": "skeleton_loading__ww4DW"
};


/***/ }),

/***/ 2526:
/***/ ((module) => {

// Exports
module.exports = {
	"message": "message_message__ZNfNX",
	"top-title": "message_top-title__ygpyd",
	"trans": "message_trans__CfMBx",
	"detail": "message_detail__V3jRB",
	"title": "message_title___YzfS",
	"card": "message_card__M34jl",
	"card-item": "message_card-item__plApJ",
	"card-item-label": "message_card-item-label__kzJvN",
	"card-item-value": "message_card-item-value__sImNs"
};


/***/ }),

/***/ 2964:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8054);
/** @format */ 



const ImageWithFallback = (props)=>{
    const { src, fallbackSrc = _contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__/* .fvmUrl */ .dE + `/images/default.png`, ...rest } = props;
    const [imgSrc, setImgSrc] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(src || fallbackSrc);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const showSrc = src || fallbackSrc;
        setImgSrc(showSrc);
    }, [
        src
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
        alt: "",
        ...rest,
        className: "rounded-full cursor-pointer",
        src: imgSrc,
        onError: ()=>{
            setImgSrc(fallbackSrc);
        }
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ImageWithFallback);


/***/ }),

/***/ 8465:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7689);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_2__);
/** @format */ 


function SkeletonScreen() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_2___default().skeleton_screen)
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SkeletonScreen);


/***/ }),

/***/ 5184:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _contents_detail__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8817);
/* harmony import */ var _packages_content__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5586);
/* harmony import */ var _packages_noData__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5178);
/* harmony import */ var _packages_skeleton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8465);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8108);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_contents_detail__WEBPACK_IMPORTED_MODULE_2__, _packages_content__WEBPACK_IMPORTED_MODULE_3__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_6__]);
([_contents_detail__WEBPACK_IMPORTED_MODULE_2__, _packages_content__WEBPACK_IMPORTED_MODULE_3__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ cid })=>{
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)(false);
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)([]);
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        load();
    }, [
        cid
    ]);
    const load = async ()=>{
        setLoading(true);
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.detail_message_event, {
            cid
        });
        setLoading(false);
        setData(result?.logs || []);
    };
    if (loading) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "main_contain",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_skeleton__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_skeleton__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_skeleton__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
            ]
        });
    }
    if (!loading && data.length === 0) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "card_shadow border border_color rounded-xl p-5 min-h-[500px]",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_noData__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "card_shadow border border_color rounded-xl p-5 min-h-[500px]",
        children: data.map((item, index)=>{
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_content__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                contents: _contents_detail__WEBPACK_IMPORTED_MODULE_2__/* .message_detail */ .TK.eventLog,
                className: "border-b border_color mt-5 last:border-none",
                ns: "detail",
                data: item
            }, index);
        })
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4643:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2881);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8054);
/* harmony import */ var _contents_detail__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8817);
/* harmony import */ var _packages_Table__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(430);
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8804);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8108);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_detail__WEBPACK_IMPORTED_MODULE_3__, _packages_Table__WEBPACK_IMPORTED_MODULE_4__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_6__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_detail__WEBPACK_IMPORTED_MODULE_3__, _packages_Table__WEBPACK_IMPORTED_MODULE_4__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ cid })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "detail"
    });
    const { theme, lang } = (0,_store_FilscanStore__WEBPACK_IMPORTED_MODULE_5__/* .useFilscanStore */ .J)();
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)(false);
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)([]);
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        load();
    }, [
        cid
    ]);
    const load = async ()=>{
        setLoading(true);
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_2__/* .apiUrl */ .JW.detail_message_trans, {
            cid
        });
        setLoading(false);
        setData(result?.internal_transfers || []);
    };
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return _contents_detail__WEBPACK_IMPORTED_MODULE_3__/* .message_detail */ .TK.trade.map((item)=>{
            return {
                ...item,
                title: tr(item.title)
            };
        });
    }, [
        lang
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "card_shadow border border_color rounded-xl p-5 min-h-[500px]",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_Table__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            data: data,
            columns: columns,
            loading: loading
        })
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1580:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9676);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2881);
/* harmony import */ var _components_hooks_useHash__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8087);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8054);
/* harmony import */ var _contents_detail__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8817);
/* harmony import */ var _packages_content__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5586);
/* harmony import */ var _packages_noData__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5178);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8108);
/* harmony import */ var antd_lib_skeleton__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1030);
/* harmony import */ var antd_lib_skeleton__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(antd_lib_skeleton__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(2526);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var lodash_get__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1712);
/* harmony import */ var lodash_get__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(lodash_get__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3495);
/* harmony import */ var _packages_segmented__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5622);
/* harmony import */ var _Trade__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(4643);
/* harmony import */ var _Event__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(5184);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_detail__WEBPACK_IMPORTED_MODULE_5__, _packages_content__WEBPACK_IMPORTED_MODULE_6__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__, _utils__WEBPACK_IMPORTED_MODULE_13__, _packages_segmented__WEBPACK_IMPORTED_MODULE_14__, _Trade__WEBPACK_IMPORTED_MODULE_15__, _Event__WEBPACK_IMPORTED_MODULE_16__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_detail__WEBPACK_IMPORTED_MODULE_5__, _packages_content__WEBPACK_IMPORTED_MODULE_6__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__, _utils__WEBPACK_IMPORTED_MODULE_13__, _packages_segmented__WEBPACK_IMPORTED_MODULE_14__, _Trade__WEBPACK_IMPORTED_MODULE_15__, _Event__WEBPACK_IMPORTED_MODULE_16__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 

















/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ cid })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__/* .Translation */ .W)({
        ns: "detail"
    });
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    const [TransferData, setTransfer] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)(undefined);
    const [TransferNFTData, setTransferNft] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)(undefined);
    // const [isF4, setIsF4] = useState(false);
    const [swap, setSwap] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)();
    const { hash } = (0,_components_hooks_useHash__WEBPACK_IMPORTED_MODULE_3__/* .useHash */ .H)();
    const { data: result, loading } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_4__/* .apiUrl */ .JW.detail_message, {
        message_cid: cid
    });
    const active = (0,react__WEBPACK_IMPORTED_MODULE_10__.useMemo)(()=>{
        if (hash) {
            return hash;
        }
        return "detail";
    }, [
        hash
    ]);
    const data = (0,react__WEBPACK_IMPORTED_MODULE_10__.useMemo)(()=>{
        return result?.MessageDetails || {};
    }, [
        result
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_10__.useEffect)(()=>{
        loadTrans(data?.message_basic?.cid);
    }, [
        data?.message_basic?.cid
    ]);
    const loadTrans = (id)=>{
        //erc20
        if (id) {
            axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_4__/* .apiUrl */ .JW.contract_transferInMessage, {
                cid: id
            }).then((result)=>{
                setTransfer(result?.items || []);
            });
            //nft
            axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_4__/* .apiUrl */ .JW.contract_transferInMessageNft, {
                cid: id
            }).then((result)=>{
                setTransferNft(result?.items || []);
            });
            //contract_swap
            axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_4__/* .apiUrl */ .JW.contract_swap, {
                cid: id
            }).then((result)=>{
                setSwap(result?.swap_info);
            });
        }
    };
    if (loading) {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "main_contain",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_skeleton__WEBPACK_IMPORTED_MODULE_9___default()), {
                    active: true
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_skeleton__WEBPACK_IMPORTED_MODULE_9___default()), {
                    active: true
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_skeleton__WEBPACK_IMPORTED_MODULE_9___default()), {
                    active: true
                })
            ]
        });
    }
    if (!loading && Object.keys(data).length === 0) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_noData__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {});
    }
    const renderItemChild = ()=>{
        switch(active){
            case "trade":
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Trade__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                    cid: cid
                });
            case "event_log":
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Event__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                    cid: cid
                });
            default:
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: classnames__WEBPACK_IMPORTED_MODULE_11___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_17___default().detail), "flex gap-y-5 flex-col mb-5"),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "card_shadow border border_color rounded-xl p-5",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_content__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                    ns: "detail",
                                    contents: _contents_detail__WEBPACK_IMPORTED_MODULE_5__/* .message_detail */ .TK.trans,
                                    data: {
                                        ...data,
                                        message_ERC20Trans: TransferData,
                                        nftTrans: TransferNFTData,
                                        swap_info: swap
                                    }
                                })
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_device_detect__WEBPACK_IMPORTED_MODULE_1__/* .MobileView */ .$, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_17___default().title),
                                    children: tr("transfer_records")
                                }),
                                lodash_get__WEBPACK_IMPORTED_MODULE_12___default()(data, "consume_list")?.map((n, index)=>{
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_17___default().card),
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_17___default()["card-item"]),
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: classnames__WEBPACK_IMPORTED_MODULE_11___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_17___default()["card-item-label"]), "w-28"),
                                                        children: [
                                                            tr("from_ath"),
                                                            "："
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_17___default()["card-item-value"]),
                                                        children: [
                                                            " ",
                                                            (0,_utils__WEBPACK_IMPORTED_MODULE_13__/* .get_account_type */ .$B)(n["from"])
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_17___default()["card-item"]),
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: classnames__WEBPACK_IMPORTED_MODULE_11___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_17___default()["card-item-label"]), "w-28"),
                                                        children: [
                                                            tr("to_ath"),
                                                            "："
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_17___default()["card-item-value"]),
                                                        children: [
                                                            " ",
                                                            (0,_utils__WEBPACK_IMPORTED_MODULE_13__/* .get_account_type */ .$B)(n["to"])
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_17___default()["card-item"]),
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: classnames__WEBPACK_IMPORTED_MODULE_11___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_17___default()["card-item-label"]), "w-28"),
                                                        children: [
                                                            tr("value"),
                                                            "："
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_17___default()["card-item-value"]),
                                                        children: [
                                                            " ",
                                                            (0,_utils__WEBPACK_IMPORTED_MODULE_13__/* .formatFilNum */ .Nm)(n["value"], false, false, 4) || "--"
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_17___default()["card-item"]),
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: classnames__WEBPACK_IMPORTED_MODULE_11___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_17___default()["card-item-label"]), "w-28"),
                                                        children: [
                                                            tr("consume_type"),
                                                            "："
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_17___default()["card-item-value"]),
                                                        children: [
                                                            " ",
                                                            tr(n["consume_type"])
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    }, `card-${index}`);
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: classnames__WEBPACK_IMPORTED_MODULE_11___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_17___default().detail), "flex gap-y-5 flex-col"),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "card_shadow border border_color rounded-xl p-5",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_content__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                    ns: "detail",
                                    contents: _contents_detail__WEBPACK_IMPORTED_MODULE_5__/* .message_detail */ .TK.detail,
                                    data: {
                                        ...data,
                                        message_ERC20Trans: TransferData,
                                        nftTrans: TransferNFTData
                                    }
                                })
                            })
                        })
                    ]
                });
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_11___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_17___default().message), "main_contain"),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex items-center my-2.5",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: classnames__WEBPACK_IMPORTED_MODULE_11___default()("font-DINPro-Bold font-semibold text-lg", (_index_module_scss__WEBPACK_IMPORTED_MODULE_17___default()["top-title"])),
                        children: tr(_contents_detail__WEBPACK_IMPORTED_MODULE_5__/* .message_detail */ .TK?.title || "")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_segmented__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                        data: _contents_detail__WEBPACK_IMPORTED_MODULE_5__/* .message_detail */ .TK.tabs,
                        defaultActive: "detail",
                        defaultValue: active,
                        ns: "detail",
                        isHash: true
                    })
                ]
            }),
            renderItemChild()
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;