"use strict";
exports.id = 4852;
exports.ids = [4852];
exports.modules = {

/***/ 4852:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FG: () => (/* binding */ gas_24),
/* harmony export */   ZQ: () => (/* binding */ contract_trend),
/* harmony export */   a$: () => (/* binding */ fil_overviewList),
/* harmony export */   bZ: () => (/* binding */ active_miner_count),
/* harmony export */   eh: () => (/* binding */ block_rewards_per),
/* harmony export */   jD: () => (/* binding */ block_rewards),
/* harmony export */   k2: () => (/* binding */ chartsNav),
/* harmony export */   l2: () => (/* binding */ cc_dc_trend),
/* harmony export */   qd: () => (/* binding */ fil_charts),
/* harmony export */   t9: () => (/* binding */ timeList),
/* harmony export */   wO: () => (/* binding */ power_trend)
/* harmony export */ });
/* unused harmony exports gas, active_node */
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3495);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils__WEBPACK_IMPORTED_MODULE_0__]);
_utils__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/** @format */ 
const timeList = [
    {
        label: "24h",
        title: "24h",
        value: "24h",
        dataIndex: "24h"
    },
    {
        label: "7d",
        title: "7d",
        value: "7d",
        dataIndex: "7d"
    },
    {
        label: "30d",
        title: "30d",
        value: "1m",
        dataIndex: "1m"
    }
];
const gas = {
    title: "trend_24",
    list: [
        {
            label: "24h",
            value: "24h"
        },
        {
            label: "7d",
            value: "7d"
        },
        {
            label: "30d",
            value: "1m"
        },
        {
            label: "1year",
            value: "1year"
        }
    ]
};
const gas_24 = {
    title: {
        label: "gas_24"
    },
    columns: [
        {
            dataIndex: "method_name",
            title: "method_name",
            align: "left"
        },
        {
            dataIndex: "avg_gas_premium",
            title: "avg_gas_premium",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatFilNum */ .Nm)(text, false, false)
        },
        {
            dataIndex: "avg_gas_limit",
            title: "avg_gas_limit",
            render: (v)=>(0,_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatNumber */ .uf)(v)
        },
        {
            dataIndex: "avg_gas_used",
            title: "avg_gas_used",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatNumber */ .uf)(text)
        },
        {
            dataIndex: "avg_gas_fee",
            title: "avg_gas_fee",
            render: (v)=>{
                if (Number(v) === 0) {
                    return 0;
                }
                return (0,_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatFilNum */ .Nm)(v, false, false);
            }
        },
        {
            dataIndex: "sum_gas_fee",
            title: "sum_gas_fee/ratio",
            render: (text, record)=>{
                if (Number(text) === 0) {
                    return 0;
                }
                return `${(0,_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatFilNum */ .Nm)(text, false, false)}/${Number(record.gas_fee_ratio * 100).toFixed(2)}%`;
            }
        },
        {
            dataIndex: "message_count",
            title: "message_count/ratio",
            render: (text, record)=>{
                return `${(0,_utils__WEBPACK_IMPORTED_MODULE_0__/* .formatNumber */ .uf)(text)}/${(record.message_count_ratio * 100).toFixed(2)}%`;
            }
        }
    ]
};
//算力走势图
const power_trend = {
    title: "power",
    list: [
        {
            title: "total_quality_adj_power",
            dataIndex: "total_quality_adj_power",
            yIndex: 0,
            type: "line",
            color: "#FFC53D"
        },
        {
            title: "total_raw_byte_power",
            dataIndex: "total_raw_byte_power",
            yIndex: 0,
            type: "line",
            color: "#4ACAB4"
        },
        {
            title: "power_increase",
            dataIndex: "power_increase",
            yIndex: 1,
            color: "#1C6AFD",
            type: "bar"
        },
        {
            dataIndex: "power_decrease",
            title: "power_decrease",
            yIndex: 1,
            color: "#B0CBFE",
            type: "bar"
        }
    ]
};
//合约交易走势图
const contract_trend = {
    list: [
        {
            title: "contract_trend",
            dataIndex: "txs_count",
            type: "line",
            color: "#1C6AFD"
        }
    ]
};
// 区块奖励走势
const block_rewards = {
    list: [
        {
            title: "acc_block_rewards",
            dataIndex: "acc_block_rewards",
            type: "line",
            color: "#1C6AFD"
        }
    ]
};
//产出效率
const block_rewards_per = {
    list: [
        {
            title: "block_reward_per_TiB",
            dataIndex: "block_reward_per_tib",
            type: "line",
            color: "#1C6AFD"
        }
    ]
};
const active_node = {
    list: [
        {
            title: "block_reward_per_tib",
            dataIndex: "block_reward_per_tib",
            type: "line",
            color: "#1C6AFD"
        }
    ]
};
const active_miner_count = {
    list: [
        {
            title: "active_miner_count",
            dataIndex: "active_miner_count",
            type: "line",
            color: "#1C6AFD"
        }
    ]
};
//DC CC 走势
const cc_dc_trend = {
    list: [
        {
            title: "dc_trend",
            dataIndex: "dc",
            type: "line",
            color: "#4ACAB4"
        },
        {
            title: "cc_trend",
            dataIndex: "cc",
            type: "line",
            color: "#F8CD4D"
        }
    ]
};
const fil_overviewList = [
    {
        title: "pie_title_a",
        list: [
            {
                key: "mined",
                color: "#F8CD4D"
            },
            {
                key: "remaining_mined",
                color: "#1C6AFD"
            },
            {
                key: "vested",
                color: "#4988FD"
            },
            {
                key: "remaining_vested",
                color: "#4ACAB4"
            },
            {
                key: "reserve_disbursed",
                color: "#B0CBFE"
            },
            {
                key: "remaining_reserved",
                color: "#6E69CF"
            }
        ]
    },
    {
        title: "pie_title_b",
        title_tip: "pie_title_a_tip",
        list: [
            {
                key: "locked",
                color: "#4ACAB4"
            },
            {
                key: "burnt",
                color: "#1C6AFD"
            },
            {
                key: "circulating",
                color: "#F8CD4D"
            }
        ]
    }
];
const fil_charts = {
    title: {
        label: "TokenRules"
    },
    chart: [
        {
            key: "FilecoinFoundation",
            name: "Filecoin基金会",
            value: "5",
            color: "#477DE5"
        },
        {
            key: "Contributors",
            name: "协议实验室团队及贡献者",
            value: "4.5",
            color: "#4FD0A1"
        },
        {
            key: "protocolLab",
            name: "协议实验室",
            value: "10.5",
            color: "#5D77A3"
        },
        {
            key: "FundraisingRemainder",
            name: "募资 – 剩余通证",
            value: "2.5",
            color: "#E8B61B"
        },
        {
            key: "FundraisingSAFT",
            name: "募资 – 未来通证简单协议",
            value: "7.5",
            color: "#D75B42"
        },
        {
            key: "MiningReserve",
            name: "为存储服务提供者预留通证",
            value: "15",
            color: "#59BAE3"
        },
        {
            key: "TokenAllocation",
            name: "存储提供者通证分配",
            value: "55",
            color: "#876AC3"
        }
    ],
    content: [
        {
            label: "Allocation",
            value: "value",
            Released: "Released",
            description: "description"
        },
        {
            label: "filBase",
            value: "2,000,000,000",
            Released: "2,000,000",
            description: "filBase_des"
        },
        {
            label: "ReservedTokens",
            value: "300,000,000 ",
            Released: "300,000 ",
            description: "ReservedTokens_des"
        },
        {
            label: "TokenAllocation",
            value: "1,100,000,000",
            Released: "1,100",
            description: "TokenAllocation_des"
        },
        {
            label: "Fundraising",
            value: "150,000,000 ",
            Released: "50,000 ",
            description: "Fundraising_des"
        },
        {
            label: "Funds",
            value: "50,000,000",
            Released: "50,000 ",
            description: "Funds_des"
        },
        {
            label: "FilecoinFoundation",
            value: "100,000,000",
            description: "FilecoinFoundation_des"
        },
        {
            label: "protocolLab",
            value: "210,000,000",
            Released: "20,000",
            description: "protocolLab_des"
        },
        {
            label: "Contributors",
            value: "90,000,000",
            Released: "9,000 ",
            description: "Contributors_des"
        }
    ]
};
//charts
const chartsNav = [
    {
        key: "networks",
        preIcon: "meta",
        title: "networks_overview"
    },
    {
        key: "BlockChain",
        preIcon: "block_chain",
        title: "BlockChain"
    },
    {
        key: "fil_overview",
        preIcon: "fil_overview",
        title: "fil_overview"
    }
];

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;