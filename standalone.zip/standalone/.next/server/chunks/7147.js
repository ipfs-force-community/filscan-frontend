"use strict";
exports.id = 7147;
exports.ids = [7147];
exports.modules = {

/***/ 7147:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Hr: () => (/* binding */ pool_list),
/* harmony export */   Js: () => (/* binding */ transfer_list),
/* harmony export */   Sk: () => (/* binding */ dsn_list),
/* harmony export */   X: () => (/* binding */ address_list),
/* harmony export */   Xd: () => (/* binding */ message_list),
/* harmony export */   x7: () => (/* binding */ chain_list)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_copy__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5174);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3495);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9676);
/* harmony import */ var _assets_images_icon_copy_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5903);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils__WEBPACK_IMPORTED_MODULE_2__]);
_utils__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/** @format */ 





//消息列表
const message_list = {
    title: "message_list",
    total_list: "total_list",
    columns: [
        {
            dataIndex: "cid",
            title: "cid",
            width: "12%",
            render: (text)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "flex items-center gap-x-1",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                            href: `/message/${text}`,
                            className: "link",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_4__/* .MobileView */ .$, {
                                    children: (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text, 6, 6)
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_4__/* .BrowserView */ .I, {
                                    children: (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text)
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                            text: text
                        })
                    ]
                })
        },
        {
            dataIndex: "height",
            title: "height",
            width: "10%",
            render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                    href: `/height/${text}`,
                    className: "link",
                    children: text
                })
        },
        {
            dataIndex: "block_time",
            title: "block_time",
            width: "15%",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatDateTime */ .o0)(text, "YYYY-MM-DD HH:mm")
        },
        {
            dataIndex: "from",
            title: "from",
            width: "15%",
            render: (text, record)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "flex items-center gap-x-1",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_4__/* .MobileView */ .$, {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "copy-row",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "w-28 text",
                                        onClick: ()=>{
                                            (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .account_link */ .H_)(text);
                                        },
                                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text, 6, 6)
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                        text: text,
                                        icon: _assets_images_icon_copy_svg__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z,
                                        className: "copy"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_4__/* .BrowserView */ .I, {
                            children: (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .get_account_type */ .$B)(text)
                        })
                    ]
                })
        },
        {
            dataIndex: "to",
            title: "to",
            width: "15%",
            render: (text, record)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "flex items-center gap-x-1",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_4__/* .MobileView */ .$, {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "copy-row",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "w-28 text",
                                        onClick: ()=>{
                                            (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .account_link */ .H_)(text);
                                        },
                                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text, 6, 6)
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                        text: text,
                                        icon: _assets_images_icon_copy_svg__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z,
                                        className: "copy"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_4__/* .BrowserView */ .I, {
                            children: (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .get_account_type */ .$B)(text)
                        })
                    ]
                })
        },
        {
            dataIndex: "value",
            title: "value",
            width: "10%",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text, false, false, 4)
        },
        {
            dataIndex: "exit_code",
            width: "8%",
            title: "message_list_exit_code"
        },
        {
            dataIndex: "method_name",
            width: "15%",
            title: "method_name"
        }
    ]
};
//富豪榜
const address_list = {
    title: "address_list",
    total_list: "address_total_list",
    options: [
        {
            value: "all",
            label: "address_all"
        },
        {
            value: "account",
            label: "account"
        },
        {
            value: "storageminer",
            label: "miner"
        },
        {
            value: "multisig",
            label: "multisig"
        }
    ],
    columns: [
        {
            dataIndex: "rank",
            title: "rank",
            width: "10%",
            render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "rank_icon",
                    children: text
                })
        },
        {
            width: "20%",
            dataIndex: "account_address",
            title: "account_address",
            render: (text)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "flex items-center gap-x-1 ",
                    children: (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .get_account_type */ .$B)(text)
                });
            }
        },
        {
            dataIndex: "balance",
            width: "20%",
            title: "balance_percentage",
            rowKey: "balance_percentage",
            render: (text, record)=>{
                return `${(0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text, false, false, 2)} / ${(record.balance_percentage * 100).toFixed(2)}%`;
            }
        },
        {
            dataIndex: "account_type",
            title: "account_type",
            width: "20%"
        },
        {
            dataIndex: "latest_transfer_time",
            width: "20%",
            title: "latest_transfer_time",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatDateTime */ .o0)(text)
        }
    ]
};
//订单
const dsn_list = {
    title: "dsn_list",
    placeholder: "dsn_placeholder",
    total_list: "dsn_total_list",
    columns: [
        {
            dataIndex: "deal_id",
            title: "deal_id",
            width: "10%",
            render: (text, record)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                    href: `/deal/${text}`,
                    className: "link",
                    children: text
                });
            }
        },
        {
            dataIndex: "piece_cid",
            title: "piece_cid",
            width: "10%",
            render: (text)=>{
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_4__/* .MobileView */ .$, {
                            children: (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text, 6, 6)
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_4__/* .BrowserView */ .I, {
                            children: (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text)
                        })
                    ]
                });
            }
        },
        {
            dataIndex: "piece_size",
            title: "piece_size",
            width: "10%",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .unitConversion */ .dN)(text)
        },
        {
            dataIndex: "client_address",
            title: "client_address",
            width: "12%",
            render: (text, record)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "flex items-center gap-x-1",
                    children: (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .get_account_type */ .$B)(text)
                })
        },
        {
            dataIndex: "provider_id",
            title: "provider_id",
            width: "12%",
            render: (text, record)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "flex items-center gap-x-1",
                    children: (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .get_account_type */ .$B)(text)
                })
        },
        {
            dataIndex: "service_start_time",
            title: "service_start_time",
            width: "13%",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatDateTime */ .o0)(text, "YYYY-MM-DD HH:mm")
        },
        {
            dataIndex: "end_time",
            title: "end_time",
            width: "13%",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatDateTime */ .o0)(text, "YYYY-MM-DD HH:mm")
        },
        {
            dataIndex: "storage_price_per_height",
            title: "storage_price_per_height",
            width: "10%",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text)
        },
        {
            dataIndex: "verified_deal",
            width: "10%",
            title: "verified_deal",
            render: (text)=>String(text)
        }
    ]
};
//消息池
const pool_list = {
    title: "pool_list",
    total_list: "total_list",
    columns: [
        {
            dataIndex: "cid",
            title: "cid",
            width: "10%",
            render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                    href: `/message/${text}`,
                    children: (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text)
                })
        },
        {
            dataIndex: "block_time",
            title: "block_time",
            width: "15%",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatDateTime */ .o0)(text, "YYYY-MM-DD HH:mm")
        },
        {
            dataIndex: "from",
            title: "from",
            width: "13%",
            render: (text)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex items-center gap-x-1 flex-wrap",
                    children: (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .get_account_type */ .$B)(text)
                });
            }
        },
        {
            dataIndex: "to",
            title: "to",
            width: "13%",
            render: (text)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "flex items-center gap-x-1 flex-wrap w-full",
                    children: (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .get_account_type */ .$B)(text)
                });
            }
        },
        {
            dataIndex: "value",
            title: "value",
            width: "10%",
            render: (text)=>{
                return (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text, false, false);
            }
        },
        {
            dataIndex: "gas_fee_cap",
            title: "gas_fee_cap",
            width: "12%",
            render: (text)=>text || "--"
        },
        {
            dataIndex: "gas_premium",
            title: "gas_premium",
            width: "12%",
            render: (text)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text, false, false, 2) : "--"
        },
        {
            dataIndex: "method_name",
            title: "method_name",
            width: "15%"
        }
    ]
};
// 区块
const chain_list = {
    columns: [
        {
            dataIndex: "height",
            title: "height",
            width: "15%",
            render: (text)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                    className: "link",
                    href: `/height/${text}`,
                    children: text
                });
            }
        },
        {
            dataIndex: "block_time",
            title: "block_time",
            width: "20%",
            type: [
                "blocks",
                "block_basic"
            ],
            render: (text, rowData)=>{
                const record = rowData.block_basic;
                const time = record.length > 0 && record[0]?.block_time;
                if (time) {
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatDateTime */ .o0)(time)
                    });
                }
                return "--";
            }
        },
        {
            dataIndex: "cid",
            title: "blocks_cid",
            width: "20%",
            type: [
                "block_basic"
            ],
            render: (text, rowData)=>{
                const record = rowData?.block_basic;
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex flex-col gap-y-2",
                    children: record.map((data, index)=>{
                        if (data?.cid) {
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                className: "link",
                                href: `/cid/${data.cid}`,
                                children: (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(data.cid)
                            }, index);
                        }
                        return "--";
                    })
                });
            }
        },
        {
            dataIndex: "miner_id",
            title: "blocks_miner",
            width: "20%",
            render: (text, rowData)=>{
                const record = rowData?.block_basic;
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex flex-col gap-y-2",
                    children: record.map((data, index)=>{
                        if (data?.miner_id) {
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                className: "link",
                                href: `/miner/${data.miner_id}`,
                                children: data.miner_id
                            }, index);
                        }
                        return "--";
                    })
                });
            }
        },
        {
            dataIndex: "messages_count",
            title: "blocks_messages",
            width: "15%",
            render: (text, rowData)=>{
                const record = rowData.block_basic;
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex flex-col gap-y-2",
                    children: record.map((data, index)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: data?.messages_count || 0
                        }, index);
                    })
                });
            }
        },
        {
            dataIndex: "reward",
            title: "blocks_reward",
            width: "10%",
            render: (text, rowData)=>{
                const record = rowData.block_basic;
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex flex-col gap-y-2",
                    children: record.map((data, index)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: data?.reward ? (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(data.reward, false, false) : ""
                        }, index);
                    })
                });
            }
        }
    ]
};
//大额转账
const transfer_list = {
    columns: [
        {
            dataIndex: "height",
            title: "height",
            render: (text)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                    href: `/height/${text}`,
                    className: "link",
                    children: text
                });
            }
        },
        {
            dataIndex: "cid",
            title: "cid",
            render: (text)=>{
                if (!text) return "--";
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                    href: `/message/${text}`,
                    className: "table_link",
                    children: (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .isIndent */ .EA)(text)
                });
            }
        },
        {
            dataIndex: "block_time",
            title: "block_time",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatDateTime */ .o0)(text)
        },
        {
            dataIndex: "from",
            title: "from",
            render: (text, record)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "flex items-center gap-x-1",
                    children: (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .get_account_type */ .$B)(text)
                })
        },
        {
            dataIndex: "to",
            title: "to",
            render: (text, record)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "flex items-center gap-x-1",
                    children: (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .get_account_type */ .$B)(text)
                })
        },
        {
            dataIndex: "value",
            title: "value",
            render: (text)=>{
                // let str = formatFilNum(text, false, false);
                // let ArrStr = str.split(" ");
                return (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text);
            }
        },
        {
            dataIndex: "method_name",
            title: "method_name"
        }
    ]
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;