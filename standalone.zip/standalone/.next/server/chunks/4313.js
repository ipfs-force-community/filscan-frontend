exports.id = 4313;
exports.ids = [4313];
exports.modules = {

/***/ 96051:
/***/ ((module) => {

// Exports
module.exports = {
	"trend": "ContractTrend_trend__JmXbO",
	"title-wrap": "ContractTrend_title-wrap__wvGB6",
	"title": "ContractTrend_title__9JfKn",
	"chart-wrap": "ContractTrend_chart-wrap__NxeBe"
};


/***/ }),

/***/ 64313:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _components_echarts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(13778);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(62881);
/* harmony import */ var _contents_statistic__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(24852);
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(48804);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(23495);
/* harmony import */ var _utils_echarts__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7355);
/* harmony import */ var _assets_images_icon_right_white_svg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(821);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(41664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _components_hooks_useObserver__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(38187);
/* harmony import */ var _ContractTrend_module_scss__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(96051);
/* harmony import */ var _ContractTrend_module_scss__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_ContractTrend_module_scss__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(29676);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(68108);
/* harmony import */ var _packages_select__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(76423);
/* harmony import */ var _components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(31061);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_statistic__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_6__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_14__, _packages_select__WEBPACK_IMPORTED_MODULE_15__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_statistic__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_6__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_14__, _packages_select__WEBPACK_IMPORTED_MODULE_15__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 

















/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { origin, className } = props;
    const { theme, lang } = (0,_store_FilscanStore__WEBPACK_IMPORTED_MODULE_5__/* .useFilscanStore */ .J)();
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__/* .Translation */ .W)({
        ns: "static"
    });
    const ref = (0,_components_hooks_useObserver__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)();
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z)();
    const [noShow, setNoShow] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)({});
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)({});
    const [interval, setInterval] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)("1m");
    const { isMobile } = (0,_components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z)();
    const color = (0,react__WEBPACK_IMPORTED_MODULE_10__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_7__/* .getColor */ .Lq)(theme);
    }, [
        theme
    ]);
    const default_xAxis = (0,react__WEBPACK_IMPORTED_MODULE_10__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_7__/* .get_xAxis */ .Fs)(theme, isMobile);
    }, [
        theme,
        isMobile
    ]);
    const defaultOptions = (0,react__WEBPACK_IMPORTED_MODULE_10__.useMemo)(()=>{
        let options = {
            grid: {
                top: 30,
                left: 20,
                right: 20,
                bottom: 20,
                containLabel: true
            },
            yAxis: {
                type: "value",
                position: "left",
                scale: true,
                nameTextStyle: {
                    color: color.textStyle
                },
                axisLabel: {
                    formatter: "{value}",
                    margin: 8,
                    hideOverlap: true,
                    textStyle: {
                        //  fontSize: this.fontSize,
                        color: isMobile ? color.mobileLabelColor : color.labelColor
                    }
                },
                axisLine: {
                    show: false
                },
                axisTick: {
                    show: false
                },
                splitLine: {
                    show: true,
                    lineStyle: {
                        type: "dashed",
                        color: color.splitLine
                    }
                }
            },
            legend: {
                show: false
            },
            tooltip: {
                //@ts-ignore
                position: function(pos, params, dom, rect, size) {
                    // 鼠标在左侧时 tooltip 显示到右侧，鼠标在右侧时 tooltip 显示到左侧。
                    var obj = {
                        top: 80
                    };
                    //@ts-ignore
                    obj[[
                        "left",
                        "right"
                    ][+(pos[0] < size.viewSize[0] / 2)]] = 5;
                    return isMobile ? obj : undefined;
                },
                trigger: "axis",
                backgroundColor: color.toolbox,
                borderColor: "transparent",
                textStyle: {
                    color: "#ffffff"
                },
                formatter (v) {
                    var result = v[0].data.showTime;
                    v.forEach((item)=>{
                        if (item.data) {
                            result += "<br/>" + item.marker + tr(item.seriesName) + ": " + item.data.amount + item.data.unit;
                        }
                    });
                    return result;
                }
            }
        };
        if (isMobile) {
            options["grid"] = {
                top: "8%",
                right: "12px",
                bottom: "16px",
                left: "12px",
                containLabel: true
            };
        }
        return options;
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        theme,
        tr,
        isMobile
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_10__.useEffect)(()=>{
        load();
    }, []);
    const load = async (time)=>{
        const seriesObj = {};
        _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .contract_trend */ .ZQ.list.forEach((v)=>{
            seriesObj[v.dataIndex] = [];
        });
        const dateList = [];
        const seriesData = [];
        const inter = time || interval;
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .EvmTxsHistory */ .i5, {
            interval: inter
        });
        result?.points?.forEach((value)=>{
            const { timestamp, txs_count } = value;
            let showTime = inter === "24h" ? (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatDateTime */ .o0)(timestamp, "HH:mm") : (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatDateTime */ .o0)(timestamp, "MM-DD HH:mm");
            if (isMobile) {
                showTime = (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatDateTime */ .o0)(timestamp, "MM-DD");
            }
            dateList.push(showTime);
            //amount
            seriesObj.txs_count.push({
                amount: txs_count,
                value: txs_count,
                showTime: (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatDateTime */ .o0)(timestamp, "YYYY-MM-DD HH:mm"),
                unit: ""
            });
        });
        _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .contract_trend */ .ZQ.list.forEach((item)=>{
            seriesData.push({
                type: item.type,
                data: seriesObj[item.dataIndex],
                name: item.title,
                symbol: "circle",
                smooth: true,
                itemStyle: {
                    color: item.color
                },
                barMaxWidth: "30"
            });
        });
        setOptions({
            series: seriesData,
            xData: dateList
        });
    };
    const newOptions = (0,react__WEBPACK_IMPORTED_MODULE_10__.useMemo)(()=>{
        const newSeries = [];
        (options?.series || []).forEach((seriesItem)=>{
            if (!noShow[seriesItem?.name]) {
                newSeries.push(seriesItem);
            }
        });
        return {
            ...defaultOptions,
            xAxis: {
                ...default_xAxis,
                data: options?.xData || []
            },
            series: newSeries
        };
    }, [
        options,
        defaultOptions,
        noShow
    ]);
    const propsRef = origin === "home" ? {
        ref
    } : {};
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_12___default()((_ContractTrend_module_scss__WEBPACK_IMPORTED_MODULE_17___default().trend), `w-full h-[full]  ${className} ${origin === "home" ? "mt-20" : ""}`),
        ...propsRef,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_12___default()(`flex justify-between flex-wrap items-center min-h-[36px] mb-2.5 ${lang === "en" ? "h-[60px]" : ""}`, (_ContractTrend_module_scss__WEBPACK_IMPORTED_MODULE_17___default()["title-wrap"])),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex-1 flex flex-row flex-wrap items-center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: classnames__WEBPACK_IMPORTED_MODULE_12___default()("min-w-[120px] w-fit font-PingFang font-semibold text-lg pl-2.5", (_ContractTrend_module_scss__WEBPACK_IMPORTED_MODULE_17___default().title)),
                            children: tr("contract_trend")
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_13__/* .BrowserView */ .I, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex gap-x-4 items-center mx-2.5",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_select__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                ns: "static",
                                options: _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .timeList */ .t9,
                                value: interval,
                                onChange: (interval)=>{
                                    setInterval(interval);
                                    load(interval);
                                }
                            }, `static_${origin}_contract`)
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: origin === "home" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_13__/* .MobileView */ .$, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_9___default()), {
                                    href: `/statistics/charts#fevm`,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_icon_right_white_svg__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                        width: 28,
                                        height: 28
                                    })
                                })
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_12___default()(`h-[350px] w-full card_shadow border border_color pb-2 rounded-xl`, (_ContractTrend_module_scss__WEBPACK_IMPORTED_MODULE_17___default()["chart-wrap"])),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    options: newOptions
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;