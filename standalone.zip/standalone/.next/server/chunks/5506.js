exports.id = 5506;
exports.ids = [5506];
exports.modules = {

/***/ 95607:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap": "table_wrap__yRzbf"
};


/***/ }),

/***/ 20130:
/***/ ((module) => {

// Exports
module.exports = {
	"top-wrap": "header_top-wrap__WD2Sk"
};


/***/ }),

/***/ 20166:
/***/ ((module) => {

// Exports
module.exports = {
	"reset": "rank_reset__rMApz",
	"table": "rank_table__R2Yg4",
	"item-right-quality": "rank_item-right-quality___tsLl",
	"item-right-pool": "rank_item-right-pool__vVfTA",
	"item-right-rewards": "rank_item-right-rewards__88849"
};


/***/ }),

/***/ 86:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   cg: () => (/* binding */ getDefaultSort),
/* harmony export */   r0: () => (/* binding */ rank_header),
/* harmony export */   vc: () => (/* binding */ mobileRankList),
/* harmony export */   vr: () => (/* binding */ getMobileColumn),
/* harmony export */   wD: () => (/* binding */ getColumn)
/* harmony export */ });
/* unused harmony exports providerList, poolList */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(41664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(23495);
/* harmony import */ var _packages_progress__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(52218);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils__WEBPACK_IMPORTED_MODULE_2__]);
_utils__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/** @format */ 



const sectorOptions = [
    {
        label: "select_rank_all",
        value: "all"
    },
    {
        label: "select_rank_32",
        value: "32 GiB"
    },
    {
        label: "select_rank_64",
        value: "64 GiB"
    }
];
const timeList = [
    {
        label: "24h",
        value: "24h"
    },
    {
        label: "week_days",
        value: "7d"
    },
    {
        label: "month",
        value: "1m"
    }
];
const rank_header = {
    tabList: [
        {
            title: "growth",
            dataIndex: "growth",
            options: [
                "sectorOptions",
                "timeList"
            ]
        },
        {
            title: "provider",
            dataIndex: "provider"
        },
        {
            title: "pool",
            dataIndex: "pool"
        },
        {
            title: "rewards",
            dataIndex: "rewards",
            options: [
                "sectorOptions",
                "timeList"
            ]
        }
    ],
    growth: {
        sector_size: sectorOptions,
        interval: timeList
    },
    rewards: {
        sector_size: sectorOptions,
        interval: timeList
    }
};
const providerList = (progress)=>{
    return [
        {
            title: "ranking",
            dataIndex: "rank",
            width: "6%",
            render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "rank_icon",
                    children: text
                })
        },
        {
            title: "provider_miner",
            dataIndex: "miner_id",
            with: "9%",
            render: (text)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                    href: `/miner/${text}`,
                    scroll: true,
                    prefetch: true,
                    className: "link_text",
                    children: text
                });
            }
        },
        {
            title: "provider_power_ratio",
            dataIndex: "quality_adj_power",
            with: "37%",
            sorter: true,
            defaultSortOrder: "descend",
            render: (text, record)=>{
                const text1 = record.quality_power_ratio;
                const left = 100 - Number(text) / Number(progress) * 100;
                const showLeft = left > 100 ? 100 : left;
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "flex items-center gap-x-2",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_progress__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            left: showLeft + "%"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            children: `${(0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .unitConversion */ .dN)(text, 2)} / ${(Number(text1) * 100).toFixed(2)}%`
                        })
                    ]
                });
            }
        },
        {
            title: "pool_increase_24h",
            dataIndex: "power_increase_24h",
            sorter: true,
            width: "13%",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .unitConversion */ .dN)(text, 4)
        },
        {
            title: "provider_block_ratio",
            dataIndex: "block_count",
            rowKey: "block_count",
            width: "15%",
            sorter: true,
            render: (text, record)=>{
                const text1 = record.block_ratio;
                return `${text} / ${(Number(text1) * 100).toFixed(2)}%`;
            }
        },
        {
            title: "provider_rewards_ratio",
            dataIndex: "rewards",
            rowKey: "rewards",
            width: "15%",
            sorter: true,
            render: (text, record)=>{
                const text1 = (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text, false, false, 2);
                return `${text1} / ${(Number(record.rewards_ratio) * 100).toFixed(2)}%`;
            }
        },
        {
            title: "balance",
            dataIndex: "balance",
            sorter: true,
            width: "15%",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text, false, false, 2)
        }
    ];
};
const poolList = (progress)=>{
    return [
        {
            title: "ranking",
            dataIndex: "rank",
            width: "6%",
            render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "rank_icon",
                    children: text
                })
        },
        {
            title: "pool_owner",
            dataIndex: "owner_id",
            with: "24%",
            render: (text)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                    href: `/owner/${text}`,
                    scroll: true,
                    prefetch: true,
                    className: "link_text",
                    children: text
                });
            }
        },
        {
            title: "pool_power",
            dataIndex: "quality_adj_power",
            with: "35%",
            sorter: true,
            defaultSortOrder: "descend",
            render: (text, record)=>{
                const left = 100 - Number(text) / Number(progress) * 100;
                const showLeft = left > 100 ? 100 : left;
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "flex items-center gap-x-2",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_progress__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            left: showLeft + "%"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            children: (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .unitConversion */ .dN)(record.quality_adj_power, 2)
                        })
                    ]
                });
            }
        },
        {
            title: "pool_efficiency_24h",
            dataIndex: "rewards_ratio_24h",
            sorter: true,
            with: "15%",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text, false, false, 2) + "/TiB"
        },
        {
            title: "pool_increase_24h",
            dataIndex: "power_change_24h",
            sorter: true,
            with: "14%",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .unitConversion */ .dN)(text, 4)
        },
        {
            title: "pool_block_count_24h",
            dataIndex: "block_count",
            sorter: true,
            with: "6%"
        }
    ];
};
const growthList = (progress)=>{
    return [
        {
            title: "ranking",
            dataIndex: "rank",
            width: "6%",
            render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "rank_icon",
                    children: text
                })
        },
        {
            title: "miner",
            dataIndex: "miner_id",
            width: "12%",
            render: (text)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                    href: `/miner/${text}`,
                    scroll: true,
                    className: "link_text",
                    children: text
                });
            }
        },
        {
            title: "power_ratio",
            title_tip: "power_ratio_tip",
            dataIndex: "power_ratio",
            sorter: true,
            width: "18%",
            defaultSortOrder: "descend",
            render: (text, record)=>{
                const left = 100 - Number(text) / Number(progress) * 100;
                const showLeft = left > 100 ? 100 : left;
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "flex items-center gap-x-2",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_progress__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            left: showLeft + "%"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            children: (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .unitConversion */ .dN)(text, 2) + "/D"
                        })
                    ]
                });
            }
        },
        {
            title: "quality_power_increase",
            title_tip: "quality_power_increase_tip",
            sorter: true,
            width: "15%",
            dataIndex: "quality_power_increase",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .unitConversion */ .dN)(text, 2)
        },
        {
            title: "quality_adj_power",
            dataIndex: "quality_adj_power",
            sorter: true,
            width: "15%",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .unitConversion */ .dN)(text, 2)
        },
        {
            title: "raw_power",
            dataIndex: "raw_power",
            sorter: true,
            width: "17%",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .unitConversion */ .dN)(text, 2)
        },
        {
            title: "sector_size",
            width: "13%",
            dataIndex: "sector_size"
        }
    ];
};
const mobileRankList = [
    "rank",
    "miner_id",
    "power_ratio"
];
const rewardsList = ()=>{
    return [
        {
            title: "ranking",
            dataIndex: "rank",
            width: "10%",
            render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "rank_icon",
                    children: text
                })
        },
        {
            title: "miner",
            dataIndex: "miner_id",
            width: "15%",
            render: (text)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                    href: `/miner/${text}`,
                    scroll: true,
                    className: "table_link",
                    children: text
                });
            }
        },
        {
            title: "rewards/ratio",
            dataIndex: "rewards",
            title_tip: "rewards/ratio_tip",
            width: "18%",
            sorter: true,
            defaultSortOrder: "descend",
            render: (text, record)=>{
                const showNum = (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatFilNum */ .Nm)(text, false, false, 2);
                const ratio = Number(record.rewards_ratio * 100).toFixed(2) + "%";
                return `${showNum}/${ratio}`;
            }
        },
        {
            title: "block_count",
            dataIndex: "block_count",
            title_tip: "block_count_tip",
            sorter: true,
            width: "15%"
        },
        {
            title: "winning_rate",
            dataIndex: "winning_rate",
            sorter: true,
            width: "12%",
            render: (text)=>Number(text * 100).toFixed(2) + "%"
        },
        {
            title: "quality_adj_power",
            dataIndex: "quality_adj_power",
            sorter: true,
            width: "15%",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .unitConversion */ .dN)(text, 2)
        },
        {
            title: "sector_size",
            width: "15%",
            dataIndex: "sector_size"
        }
    ];
};
const getColumn = (type, progress)=>{
    switch(type){
        case "provider":
            return providerList(progress);
        case "pool":
            return poolList(progress);
        case "growth":
            return growthList(progress);
        case "rewards":
            return rewardsList();
        default:
            return providerList(progress);
    }
};
const getMobileColumn = (type)=>{
    switch(type){
        case "provider":
            return [
                "rank",
                "miner_id",
                "quality_adj_power"
            ];
        case "pool":
            return [
                "rank",
                "owner_id",
                "quality_adj_power"
            ];
        case "growth":
            return [
                "rank",
                "miner_id",
                "power_ratio"
            ];
        case "rewards":
            return [
                "rank",
                "miner_id",
                "rewards"
            ];
        default:
            break;
    }
};
const getDefaultSort = {
    provider: "quality_adj_power",
    pool: "quality_adj_power",
    growth: "power_ratio",
    rewards: "rewards"
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 20937:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var antd_lib_table__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(74285);
/* harmony import */ var antd_lib_table__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd_lib_table__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(95607);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(23495);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils__WEBPACK_IMPORTED_MODULE_4__]);
_utils__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const Table = (props)=>{
    const { columns, loading, current, total = 0, limit } = props;
    const showLimit = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        return limit || _utils__WEBPACK_IMPORTED_MODULE_4__/* .pageLimit */ .P5;
    }, [
        limit
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_2___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().wrap)),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_table__WEBPACK_IMPORTED_MODULE_1___default()), {
            loading: loading,
            columns: columns,
            dataSource: props.dataSource,
            onChange: props.onChange,
            pagination: total > showLimit ? {
                position: [
                    "bottomRight"
                ],
                current: current,
                pageSize: _utils__WEBPACK_IMPORTED_MODULE_4__/* .pageLimit */ .P5,
                showSizeChanger: false,
                showLessItems: true,
                total
            } : false
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Table);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 52218:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/** @format */ 
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ left })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
        className: "flex gap-x-px w-fit h-fit relative",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                className: `absolute mark h-full ${left ? "mark" : "bg-transparent"} right-0`,
                style: {
                    width: left
                }
            }),
            [
                1,
                2,
                3,
                4,
                5,
                6,
                7,
                8,
                9,
                10
            ].map((item)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                    className: "w-[5px] h-[12px] rounded-[1px] bg-primary"
                }, item);
            })
        ]
    });
});


/***/ }),

/***/ 3305:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _contents_rank__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(86);
/* harmony import */ var _packages_segmented__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(25622);
/* harmony import */ var _packages_select__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(76423);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(41664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _assets_images_black_go_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(53309);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(62881);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(29676);
/* harmony import */ var _header_module_scss__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(20130);
/* harmony import */ var _header_module_scss__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_header_module_scss__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_contents_rank__WEBPACK_IMPORTED_MODULE_1__, _packages_segmented__WEBPACK_IMPORTED_MODULE_2__, _packages_select__WEBPACK_IMPORTED_MODULE_3__, _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_6__]);
([_contents_rank__WEBPACK_IMPORTED_MODULE_1__, _packages_segmented__WEBPACK_IMPORTED_MODULE_2__, _packages_select__WEBPACK_IMPORTED_MODULE_3__, _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 









/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ origin, active, onChange })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_6__/* .Translation */ .W)({
        ns: "rank"
    });
    let SegmentedProps = {};
    if (origin === "home") {
        SegmentedProps.onChange = (value)=>{
            onChange("active", value);
        };
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_device_detect__WEBPACK_IMPORTED_MODULE_7__/* .MobileView */ .$, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()((_header_module_scss__WEBPACK_IMPORTED_MODULE_9___default()["top-wrap"])),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    " ",
                                    tr("rank_title")
                                ]
                            }),
                            _contents_rank__WEBPACK_IMPORTED_MODULE_1__/* .rank_header */ .r0[active] && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex gap-x-2.5 items-center",
                                children: Object.keys(_contents_rank__WEBPACK_IMPORTED_MODULE_1__/* .rank_header */ .r0[active]).map((item)=>{
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        options: _contents_rank__WEBPACK_IMPORTED_MODULE_1__/* .rank_header */ .r0[active][item],
                                        ns: "rank",
                                        onChange: (value)=>{
                                            onChange(item, value);
                                        }
                                    }, `${active}_${item}`);
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_segmented__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        data: _contents_rank__WEBPACK_IMPORTED_MODULE_1__/* .rank_header */ .r0.tabList,
                        ns: "rank",
                        defaultValue: active,
                        defaultActive: "growth",
                        isHash: origin !== "home",
                        ...SegmentedProps
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_7__/* .BrowserView */ .I, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex justify-between items-center mx-2.5",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: `flex items-center w-full gap-x-2.5`,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "font-PingFang font-semibold text-lg",
                                    children: tr("rank_title")
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: `flex items-center ${origin !== "home" ? "flex-1 justify-between" : "gap-x-4"}`,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_segmented__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                            data: _contents_rank__WEBPACK_IMPORTED_MODULE_1__/* .rank_header */ .r0.tabList,
                                            ns: "rank",
                                            defaultValue: active,
                                            defaultActive: "growth",
                                            isHash: origin !== "home",
                                            ...SegmentedProps
                                        }),
                                        _contents_rank__WEBPACK_IMPORTED_MODULE_1__/* .rank_header */ .r0[active] && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "flex gap-x-2.5 items-center",
                                            children: Object.keys(_contents_rank__WEBPACK_IMPORTED_MODULE_1__/* .rank_header */ .r0[active]).map((item)=>{
                                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_select__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                    options: _contents_rank__WEBPACK_IMPORTED_MODULE_1__/* .rank_header */ .r0[active][item],
                                                    ns: "rank",
                                                    onChange: (value)=>{
                                                        onChange(item, value);
                                                    }
                                                }, `${active}_${item}`);
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        origin === "home" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                            href: `/rank#${active}`,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_black_go_svg__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                className: "cursor-pointer",
                                width: 18,
                                height: 18
                            })
                        })
                    ]
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 85506:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _components_hooks_useHash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(38087);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _contents_rank__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(86);
/* harmony import */ var _packages_Table__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(70430);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8054);
/* harmony import */ var _header__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3305);
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(48804);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(23495);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(57987);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(68108);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(20166);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(29676);
/* harmony import */ var _packages_mobile_table__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(20937);
/* harmony import */ var _components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(31061);
/* harmony import */ var _packages_progress__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(52218);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_contents_rank__WEBPACK_IMPORTED_MODULE_3__, _packages_Table__WEBPACK_IMPORTED_MODULE_4__, _header__WEBPACK_IMPORTED_MODULE_6__, _utils__WEBPACK_IMPORTED_MODULE_8__, react_i18next__WEBPACK_IMPORTED_MODULE_9__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__, _packages_mobile_table__WEBPACK_IMPORTED_MODULE_13__]);
([_contents_rank__WEBPACK_IMPORTED_MODULE_3__, _packages_Table__WEBPACK_IMPORTED_MODULE_4__, _header__WEBPACK_IMPORTED_MODULE_6__, _utils__WEBPACK_IMPORTED_MODULE_8__, react_i18next__WEBPACK_IMPORTED_MODULE_9__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__, _packages_mobile_table__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 
















const defaultFilter = {
    sector_size: "all",
    interval: "24h"
};
const defaultData = {
    dataSource: [],
    total: 0
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ origin })=>{
    const { hash } = (0,_components_hooks_useHash__WEBPACK_IMPORTED_MODULE_1__/* .useHash */ .H)();
    const { isMobile } = (0,_components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z)();
    const { t } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_9__.useTranslation)();
    const tr = (label)=>{
        return t(label, {
            ns: "rank"
        });
    };
    const { theme, lang } = (0,_store_FilscanStore__WEBPACK_IMPORTED_MODULE_7__/* .useFilscanStore */ .J)();
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("growth");
    const [progress, setProgress] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({});
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({
        ...defaultData
    });
    const [poolData, setPoolData] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({
        ...defaultData
    });
    const [growthData, setGrowthData] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({
        ...defaultData
    });
    const [rewardsData, setRewardsData] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({
        ...defaultData
    });
    const [current, setCurrent] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(1);
    const [headerFilter, setHeaderFilter] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
    const [sort, setSort] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({});
    const { axiosData, loading } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        const showHash = hash || "growth";
        if (showHash === "growth" || showHash === "rewards") {
            setHeaderFilter({
                ...defaultFilter
            });
        }
        setActive(showHash);
        setCurrent(1);
        setSort({});
        load(showHash, 1, {
            field: _contents_rank__WEBPACK_IMPORTED_MODULE_3__/* .getDefaultSort */ .cg[showHash],
            order: "descend"
        }, defaultFilter);
    }, [
        hash
    ]);
    const load = async (tab, cur, orders, filter)=>{
        const showActive = tab || active;
        if (showActive) {
            const index = cur || current;
            const showOrder = orders || sort.field && sort || {
                field: _contents_rank__WEBPACK_IMPORTED_MODULE_3__/* .getDefaultSort */ .cg[showActive],
                order: "descend"
            };
            const showFilter = filter || headerFilter;
            const linkUrl = `rank_${showActive}`;
            const filters = showFilter ? {
                ...showFilter,
                sector_size: showFilter?.sector_size === "all" ? null : showFilter?.sector_size || ""
            } : {};
            const data = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_5__/* .apiUrl */ .JW[linkUrl], {
                index: index - 1,
                limit: origin === "home" ? _utils__WEBPACK_IMPORTED_MODULE_8__/* .pageHomeLimit */ .m$ : _utils__WEBPACK_IMPORTED_MODULE_8__/* .pageLimit */ .P5,
                order: {
                    field: showOrder.field,
                    sort: showOrder.order === "ascend" ? "asc" : "desc"
                },
                ...filters
            });
            if (data) {
                const showData = data?.items || [];
                if (showOrder.field === _contents_rank__WEBPACK_IMPORTED_MODULE_3__/* .getDefaultSort */ .cg[showActive] && showOrder.order === "descend" && showActive !== "rewards" && index === 1) {
                    setProgress({
                        ...progress,
                        [showActive]: showData.length > 0 ? showData[0][_contents_rank__WEBPACK_IMPORTED_MODULE_3__/* .getDefaultSort */ .cg[showActive]] : ""
                    });
                }
                if (showActive === "pool") {
                    setPoolData({
                        dataSource: showData,
                        total: data?.total || 0
                    });
                } else if (showActive === "growth") {
                    setGrowthData({
                        dataSource: showData,
                        total: data?.total || 0
                    });
                } else if (showActive === "rewards") {
                    setRewardsData({
                        dataSource: showData,
                        total: data?.total || 0
                    });
                } else {
                    setData({
                        dataSource: showData,
                        total: data?.total || 0
                    });
                }
            }
        }
    };
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        const content = [];
        (0,_contents_rank__WEBPACK_IMPORTED_MODULE_3__/* .getColumn */ .wD)(active, progress[active]).filter((item)=>{
            if (isMobile) {
                return (0,_contents_rank__WEBPACK_IMPORTED_MODULE_3__/* .getMobileColumn */ .vr)(active)?.includes(item.dataIndex);
            }
            return true;
        }).forEach((item)=>{
            if (isMobile) {
                if (item.dataIndex === "rank") {
                    item.width = "15%";
                    item.align = "left";
                }
                if (item.dataIndex === "miner_id") {
                    item.width = "30%";
                }
                if (item.title === "power_ratio") {
                    item.align = "right";
                    item.width = "0";
                    item.render = (value, render)=>{
                        const left = 100 - Number(value) / Number(progress[active]) * 100;
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "flex justify-end gap-x-2",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_progress__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                    left: left + "%"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: (0,_utils__WEBPACK_IMPORTED_MODULE_8__/* .unitConversion */ .dN)(value, 2) + "/D"
                                })
                            ]
                        });
                    };
                }
                if (item.dataIndex === "quality_adj_power") {
                    item.align = "right";
                    item.render = (text, record)=>{
                        const left = 100 - Number(text) / Number(progress[active]) * 100;
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: classnames__WEBPACK_IMPORTED_MODULE_11___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default()["item-right-quality"])),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_progress__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                    left: left + "%"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: (0,_utils__WEBPACK_IMPORTED_MODULE_8__/* .unitConversion */ .dN)(record.quality_adj_power, 2)
                                })
                            ]
                        });
                    };
                }
                if (item.dataIndex === "rewards") {
                    item.align = "right";
                    item.render = (text, record)=>{
                        const showNum = (0,_utils__WEBPACK_IMPORTED_MODULE_8__/* .formatFilNum */ .Nm)(text, false, false, 2);
                        const ratio = Number(record.rewards_ratio * 100).toFixed(2) + "%";
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: classnames__WEBPACK_IMPORTED_MODULE_11___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default()["item-right-rewards"])),
                            children: `${showNum}/${ratio}`
                        });
                    };
                }
                if (item.dataIndex === "pool_power") {
                    item.align = "right";
                    item.render = (text, record)=>{
                        const left = 100 - Number(record.quality_adj_power) / Number(progress[active]) * 100;
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default()["item-right-pool"]),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_progress__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                    left: left + "%"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: (0,_utils__WEBPACK_IMPORTED_MODULE_8__/* .unitConversion */ .dN)(record.quality_adj_power, 2)
                                })
                            ]
                        });
                    };
                }
            }
            content.push({
                ...item,
                title: tr(item.title)
            });
        });
        return content;
    }, [
        active,
        progress[active],
        theme,
        tr
    ]);
    const handleHeaderChange = (type, value)=>{
        let newActive = active;
        let activeHeader = headerFilter;
        if (type === "active") {
            newActive = value;
            setActive(value);
            setHeaderFilter({
                ...defaultFilter
            });
            activeHeader = {
                ...defaultFilter
            };
        } else {
            activeHeader = {
                ...headerFilter,
                [type]: value
            };
            setHeaderFilter(activeHeader);
        }
        setCurrent(1);
        load(newActive, 1, undefined, activeHeader);
    };
    const handleChange = (pagination, filters, sorter)=>{
        let cur = pagination.current || current;
        let order = {
            ...sort
        };
        if (sorter?.field) {
            if (sorter.order) {
                order = {
                    field: sorter.field,
                    order: sorter.order
                };
            } else {
                order = {
                    field: _contents_rank__WEBPACK_IMPORTED_MODULE_3__/* .getDefaultSort */ .cg[active],
                    order: "descend"
                };
            }
        }
        setCurrent(cur);
        setSort(order);
        load(active, cur, order);
    };
    const showData = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        if (active === "provider") return data;
        if (active === "pool") return poolData;
        if (active === "growth") return growthData;
        if (active === "rewards") return rewardsData;
        return data;
    }, [
        active,
        data,
        poolData,
        growthData,
        rewardsData
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_header__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                origin: origin,
                active: active,
                onChange: handleHeaderChange
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_11___default()(`mt-4 ${origin === "home" ? "h-[650px]" : ""} border rounded-xl px-5 pt-5 card_shadow border_color flex items-center`, (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().table), (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().reset)),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_12__/* .MobileView */ .$, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_mobile_table__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                            columns: columns,
                            loading: loading,
                            dataSource: showData.dataSource,
                            total: showData.total,
                            onChange: handleChange
                        }, active)
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_12__/* .BrowserView */ .I, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_Table__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                            data: showData.dataSource,
                            total: origin === "home" ? 0 : showData.total,
                            columns: columns,
                            loading: loading,
                            onChange: handleChange
                        }, active)
                    })
                ]
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;