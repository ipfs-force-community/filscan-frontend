"use strict";
exports.id = 3469;
exports.ids = [3469];
exports.modules = {

/***/ 3778:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var echarts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9201);
/* harmony import */ var echarts__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(echarts__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/** @format */ 


const EChartsComponent = ({ options = {} })=>{
    const chartRef = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (chartRef.current) {
            const chart = echarts__WEBPACK_IMPORTED_MODULE_1__.init(chartRef.current);
            const default_options = {
                backgroundColor: "transparent",
                grid: {
                    top: 10,
                    left: 20,
                    right: 20,
                    bottom: 20,
                    containLabel: true
                }
            };
            if (options && options.series) {
                chart?.setOption({
                    ...default_options,
                    ...options
                });
            }
            const handleSize = ()=>{
                chart.resize();
            };
            window.addEventListener("resize", handleSize);
            return ()=>{
                chart.dispose();
                window.removeEventListener("resize", handleSize);
            };
        }
    }, [
        options
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        ref: chartRef,
        style: {
            width: "100%",
            height: "100%"
        }
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EChartsComponent);


/***/ }),

/***/ 7355:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Fs: () => (/* binding */ get_xAxis),
/* harmony export */   IV: () => (/* binding */ seriesArea),
/* harmony export */   Lq: () => (/* binding */ getColor),
/* harmony export */   v$: () => (/* binding */ seriesChangeArea)
/* harmony export */ });
/* unused harmony exports colors, defaultOpt */
/* harmony import */ var echarts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9201);
/* harmony import */ var echarts__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(echarts__WEBPACK_IMPORTED_MODULE_0__);

//base charts colors
const colors = (/* unused pure expression or super */ null && ([
    "#F7C739",
    "#5AD8A6",
    "#5B8FF9",
    "#9270CA"
]));
//  const lightStyle = {
//       lineStyle: "rgba(0,0,0,0.15)",
//       splitLine: "rgba(0,0,0,0.15)",
//       textStyle: "#000000",
//       itemBorder: "#ffffff",
//       toolbox:'rgba(0,0,0,0.4)'
//     }
//     const blackStyle = {
//       lineStyle: "rgba(255,255,255,0.15)",
//       splitLine: "rgba(255,255,255,0.15)",
//       textStyle: "#ffffff",
//       itemBorder: "#ffffff",
//       toolbox:'rgba(0,0,0,0.4)'
//     }
const lightStyle = {
    lineStyle: "rgba(0,0,0,0.15)",
    splitLine: "rgba(230, 232, 235, 0.6)",
    textStyle: "#000000",
    labelColor: "rgba(0,0,0,0.6)",
    itemBorder: "#ffffff",
    toolbox: "rgba(0,0,0,0.4)",
    mobileLabelColor: "#B3B3B3"
};
const blackStyle = {
    lineStyle: "rgba(255,255,255,0.15)",
    splitLine: "rgba(255,255,255,0.15)",
    textStyle: "#ffffff",
    itemBorder: "#ffffff",
    labelColor: "rgba(255,255,255,0.6)",
    toolbox: "rgba(0,0,0,0.4)",
    mobileLabelColor: "#B3B3B3"
};
const seriesArea = {
    lineStyle: {
        color: new echarts__WEBPACK_IMPORTED_MODULE_0__.graphic.LinearGradient(0, 0, 1, 0, [
            {
                offset: 0,
                color: "#179CEE"
            },
            {
                offset: 0.5,
                color: "#1764FF"
            },
            {
                offset: 1,
                color: "#003DB9"
            }
        ])
    },
    areaStyle: {
        color: new echarts__WEBPACK_IMPORTED_MODULE_0__.graphic.LinearGradient(0, 0, 0, 1, [
            {
                offset: 0,
                color: "rgba(57,128 ,250,0.6)"
            },
            {
                offset: 0.7,
                color: "rgba(57,128 ,250,0.3)"
            },
            {
                offset: 1,
                color: "rgba(57 , 128,  250,0.01)"
            }
        ])
    },
    markArea: {
        itemStyle: {
            color: "trans"
        }
    }
};
const seriesChangeArea = {
    areaStyle: {
        color: new echarts__WEBPACK_IMPORTED_MODULE_0__.graphic.LinearGradient(0, 0, 0, 1, [
            {
                offset: 0,
                color: "rgba(28,106,253,0.2)"
            },
            {
                offset: 0.7,
                color: "rgba(28,106 ,253,0.1)"
            },
            {
                offset: 1,
                color: "rgba(28,106 ,253,0)"
            }
        ])
    },
    markArea: {
        itemStyle: {
            color: "trans"
        }
    }
};
const get_xAxis = (theme, isMobile)=>{
    const color = getColor(theme);
    return {
        type: "category",
        axisLabel: {
            color: isMobile ? color.mobileLabelColor : color.labelColor
        },
        axisLine: {
            lineStyle: {
                color: color.splitLine
            }
        },
        lightStyle: {
            color: color.lineStyle
        },
        axisTick: {
            show: false
        },
        data: []
    };
};
const defaultOpt = (type, theme = "light")=>{
    const color = getColor(theme);
    switch(type){
        case "line":
            return {
                xAxis: {
                    type: "category",
                    axisLabel: {
                        textStyle: {
                            color: color.textStyle
                        }
                    },
                    axisLine: {
                        lineStyle: {
                            color: color.splitLine
                        }
                    },
                    lightStyle: {
                        color: color.lineStyle
                    },
                    axisTick: {
                        show: false
                    },
                    data: []
                },
                legend: {
                    // data: this.tr("yAxisName"),
                    lineStyle: {
                        color: "#ffffff"
                    },
                    textStyle: {
                        // fontSize: this.fontSize,
                        color: color.textStyle
                    },
                    formatter (v) {
                        return v;
                    },
                    icon: "circle"
                }
            };
    }
};
const getColor = (theme)=>{
    return theme === "light" ? lightStyle : blackStyle;
};


/***/ })

};
;