exports.id = 430;
exports.ids = [430];
exports.modules = {

/***/ 50085:
/***/ ((module) => {

// Exports
module.exports = {
	"mobile-table": "Table_mobile-table__oz9hw",
	"mobile-table-card": "Table_mobile-table-card__8Q7f_",
	"mobile-table-card-item": "Table_mobile-table-card-item__p_2o_",
	"mobile-table-card-item-label": "Table_mobile-table-card-item-label__mUvWa",
	"mobile-table-card-item-value": "Table_mobile-table-card-item-value__kxy_p",
	"pagination": "Table_pagination__i3qLZ"
};


/***/ }),

/***/ 58133:
/***/ ((module) => {

// Exports
module.exports = {
	"noData": "noData_noData__9ONHs"
};


/***/ }),

/***/ 48443:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-accelerate.aliyuncs.com/client/_next/static/media/loading.f5615e5e.png","height":800,"width":800,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 70430:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(29676);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(23495);
/* harmony import */ var antd_lib_pagination__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(14528);
/* harmony import */ var antd_lib_pagination__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(antd_lib_pagination__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var antd_lib_skeleton__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(71030);
/* harmony import */ var antd_lib_skeleton__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(antd_lib_skeleton__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var antd_lib_table__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(74285);
/* harmony import */ var antd_lib_table__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(antd_lib_table__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(50085);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _noData__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(75178);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(25675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _assets_images_loading_png__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(48443);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils__WEBPACK_IMPORTED_MODULE_2__]);
_utils__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/** @format */ 











/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { data, columns, loading, total = 0, limit, current, className = "", onChange } = props;
    const showLimit = (0,react__WEBPACK_IMPORTED_MODULE_6__.useMemo)(()=>{
        return limit || _utils__WEBPACK_IMPORTED_MODULE_2__/* .pageLimit */ .P5;
    }, [
        limit
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        if (current) {
            setCur(current);
        }
    }, [
        current
    ]);
    const [cur, setCur] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(1);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_1__/* .MobileView */ .$, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default()["mobile-table"]),
                    children: [
                        [
                            ...mobileContent
                        ].filter(([key, value])=>key.loading === loading).map(([key, value])=>value.call(undefined, data, columns)),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().pagination),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_pagination__WEBPACK_IMPORTED_MODULE_3___default()), {
                                current: cur,
                                total: total,
                                pageSize: _utils__WEBPACK_IMPORTED_MODULE_2__/* .pageLimit */ .P5,
                                showQuickJumper: false,
                                showSizeChanger: false,
                                hideOnSinglePage: true,
                                showLessItems: true,
                                onChange: (cur)=>{
                                    if (onChange) {
                                        setCur(cur);
                                        onChange({
                                            current: cur
                                        });
                                    }
                                }
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_1__/* .BrowserView */ .I, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_table__WEBPACK_IMPORTED_MODULE_5___default()), {
                    tableLayout: "fixed",
                    bordered: false,
                    className: `custom_table ${className} w-full h-full`,
                    dataSource: [
                        ...data
                    ],
                    columns: columns,
                    rowClassName: "custom_table_row",
                    rowKey: new Date().getTime(),
                    onChange: onChange,
                    // loading={loading}
                    loading: {
                        spinning: loading,
                        size: "large",
                        wrapperClassName: "custom-table-loading",
                        indicator: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "custom-table-loading-div",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_9___default()), {
                                src: _assets_images_loading_png__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z,
                                width: 160,
                                height: 160,
                                alt: ""
                            })
                        })
                    },
                    scroll: {
                        x: "max-content"
                    },
                    showSorterTooltip: false,
                    pagination: total > showLimit ? {
                        position: [
                            "bottomRight"
                        ],
                        current: current,
                        showQuickJumper: true,
                        pageSize: _utils__WEBPACK_IMPORTED_MODULE_2__/* .pageLimit */ .P5,
                        showSizeChanger: false,
                        total
                    } : false
                })
            })
        ]
    });
});
const mobileContent = new Map([
    [
        {
            loading: true
        },
        ()=>{
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_skeleton__WEBPACK_IMPORTED_MODULE_4___default()), {
                active: true,
                paragraph: {
                    rows: 10
                }
            });
        }
    ],
    [
        {
            loading: false
        },
        (data, columns)=>{
            return data.length ? data.map((dataSource, index)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default()["mobile-table-card"]),
                    children: columns.map((item, idx)=>{
                        const { title, dataIndex, render } = item;
                        const showTitle = typeof title === "function" ? title(dataSource[dataIndex], dataSource, index) : title;
                        let showValue = dataSource[dataIndex];
                        if (render) {
                            showValue = render(dataSource[dataIndex], dataSource, index);
                        }
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: classnames__WEBPACK_IMPORTED_MODULE_7___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default()["mobile-table-card-item"]), `${dataIndex}-hide`),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default()["mobile-table-card-item-label"]),
                                    children: showTitle
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default()["mobile-table-card-item-value"]),
                                    children: showValue
                                })
                            ]
                        }, idx);
                    })
                }, index);
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_noData__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {});
        }
    ]
]);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 75178:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(58133);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_1__);


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ text })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_1___default().noData),
        children: text || "No Data"
    });
});


/***/ })

};
;