exports.id = 5586;
exports.ids = [5586];
exports.modules = {

/***/ 38051:
/***/ ((module) => {

// Exports
module.exports = {
	"detail-content": "content_detail-content__3ffBv",
	"item-wrap": "content_item-wrap__OSUmU",
	"title": "content_title__h1okQ",
	"value": "content_value__NJEMu",
	"message-content-value": "content_message-content-value__AOzpk"
};


/***/ }),

/***/ 55586:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(62881);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(23495);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(38051);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(31061);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(29676);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _utils__WEBPACK_IMPORTED_MODULE_2__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _utils__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 







/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { isMobile } = (0,_components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    const { contents, data, columns = 1, ns } = props;
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: ns
    });
    const showWidth = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        if (columns === 2) {
            return "calc(50% - 20px)";
        }
        return "100%";
    }, [
        columns
    ]);
    /*
  ${
        columns !== 1 ? `grid !grid-cols-2 gap-x-12 gap-y-2.5` : 'flex flex-col p-2.5 gap-y-2'
      }
  */ return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
        className: classnames__WEBPACK_IMPORTED_MODULE_4___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_7___default()["detail-content"]), `w-full max-h-full flex flex-wrap p-2.5 gap-y-2 gap-x-10`, props.className),
        children: contents.map((item, index)=>{
            const { title, dataIndex, width, style = {}, borderTop, elasticity, render, isSplit } = item;
            const itemData = (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .getShowData */ .IC)(item, data);
            let value = itemData && itemData[dataIndex];
            const renderValue = render ? render(value, data, tr) : value;
            const showTitle = typeof title === "function" ? title(tr, index) : tr(title);
            //当没有值时，不显示此行的数据，包含title
            if (elasticity && !renderValue) {
                return null;
            }
            let isSplitWidth = width;
            if (isSplit && width) {
                if (value.length < isSplit) {
                    isSplitWidth = showWidth;
                }
            }
            return isMobile && item["mobileHide"] ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                className: classnames__WEBPACK_IMPORTED_MODULE_4___default()(`flex items-baseline gap-2.5 min-h-[32px]
            ${borderTop ? "min-h-[48px] pt-5 border-t border_color relative" : ""}
            ${columns !== 1 ? "justify-between" : ""}`, (_index_module_scss__WEBPACK_IMPORTED_MODULE_7___default()["item-wrap"])),
                style: {
                    ...style,
                    width: isSplitWidth || showWidth
                },
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: classnames__WEBPACK_IMPORTED_MODULE_4___default()(`min-w-[120px] flex-shrink-0 items-baseline text_des self-start`, (_index_module_scss__WEBPACK_IMPORTED_MODULE_7___default().title)),
                        children: [
                            showTitle,
                            ":"
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_6__/* .MobileView */ .$, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: classnames__WEBPACK_IMPORTED_MODULE_4___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_7___default()["message-content-value"])),
                            children: renderValue
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_6__/* .BrowserView */ .I, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            style: {
                                maxWidth: "calc(100% - 120px)"
                            },
                            className: classnames__WEBPACK_IMPORTED_MODULE_4___default()(`flex-grow overflow-auto items-baseline font-DINPro-Medium `, columns !== 1 ? "flex justify-end" : ""),
                            children: renderValue
                        })
                    })
                ]
            }, index);
        })
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;