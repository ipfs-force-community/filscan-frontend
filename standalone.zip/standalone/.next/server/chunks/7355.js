"use strict";
exports.id = 7355;
exports.ids = [7355];
exports.modules = {

/***/ 7355:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Fs: () => (/* binding */ get_xAxis),
/* harmony export */   IV: () => (/* binding */ seriesArea),
/* harmony export */   Iq: () => (/* binding */ cwStyle),
/* harmony export */   Lq: () => (/* binding */ getColor),
/* harmony export */   v$: () => (/* binding */ seriesChangeArea)
/* harmony export */ });
/* unused harmony exports colors, defaultOpt */
/* harmony import */ var echarts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9201);
/* harmony import */ var echarts__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(echarts__WEBPACK_IMPORTED_MODULE_0__);

//base charts colors
const colors = (/* unused pure expression or super */ null && ([
    "#F7C739",
    "#5AD8A6",
    "#5B8FF9",
    "#9270CA"
]));
//  const lightStyle = {
//       lineStyle: "rgba(0,0,0,0.15)",
//       splitLine: "rgba(0,0,0,0.15)",
//       textStyle: "#000000",
//       itemBorder: "#ffffff",
//       toolbox:'rgba(0,0,0,0.4)'
//     }
//     const blackStyle = {
//       lineStyle: "rgba(255,255,255,0.15)",
//       splitLine: "rgba(255,255,255,0.15)",
//       textStyle: "#ffffff",
//       itemBorder: "#ffffff",
//       toolbox:'rgba(0,0,0,0.4)'
//     }
const lightStyle = {
    lineStyle: "rgba(0,0,0,0.15)",
    splitLine: "rgba(230, 232, 235, 0.6)",
    textStyle: "#000000",
    labelColor: "rgba(0,0,0,0.6)",
    itemBorder: "#ffffff",
    toolbox: "rgba(0,0,0,0.4)"
};
const blackStyle = {
    lineStyle: "rgba(255,255,255,0.15)",
    splitLine: "rgba(255,255,255,0.15)",
    textStyle: "#ffffff",
    itemBorder: "#ffffff",
    labelColor: "rgba(255,255,255,0.6)",
    toolbox: "rgba(0,0,0,0.4)"
};
const cwStyle = {
    "light": [
        "rgba(29, 107, 253, 0.08)",
        "rgba(112, 79, 228, 0.08)",
        "rgba(240, 176, 71, 0.08)",
        "rgba(57, 178, 226, 0.08)",
        "rgba(233, 119, 70, 0.08)",
        "rgba(116, 204, 110, 0.08)"
    ],
    "dark": []
};
const seriesArea = {
    lineStyle: {
        color: new echarts__WEBPACK_IMPORTED_MODULE_0__.graphic.LinearGradient(0, 0, 1, 0, [
            {
                offset: 0,
                color: "#179CEE"
            },
            {
                offset: 0.5,
                color: "#1764FF"
            },
            {
                offset: 1,
                color: "#003DB9"
            }
        ])
    },
    areaStyle: {
        color: new echarts__WEBPACK_IMPORTED_MODULE_0__.graphic.LinearGradient(0, 0, 0, 1, [
            {
                offset: 0,
                color: "rgba(57,128 ,250,0.6)"
            },
            {
                offset: 0.7,
                color: "rgba(57,128 ,250,0.3)"
            },
            {
                offset: 1,
                color: "rgba(57 , 128,  250,0.01)"
            }
        ])
    },
    markArea: {
        itemStyle: {
            color: "trans"
        }
    }
};
const seriesChangeArea = {
    areaStyle: {
        color: new echarts__WEBPACK_IMPORTED_MODULE_0__.graphic.LinearGradient(0, 0, 0, 1, [
            {
                offset: 0,
                color: "rgba(28,106,253,0.2)"
            },
            {
                offset: 0.7,
                color: "rgba(28,106 ,253,0.1)"
            },
            {
                offset: 1,
                color: "rgba(28,106 ,253,0)"
            }
        ])
    },
    markArea: {
        itemStyle: {
            color: "trans"
        }
    }
};
const get_xAxis = (theme)=>{
    const color = getColor(theme);
    return {
        type: "category",
        axisLabel: {
            color: color.labelColor
        },
        axisLine: {
            lineStyle: {
                color: color.splitLine
            }
        },
        lightStyle: {
            color: color.lineStyle
        },
        axisTick: {
            show: false
        },
        data: []
    };
};
const defaultOpt = (type, theme = "light")=>{
    const color = getColor(theme);
    switch(type){
        case "line":
            return {
                xAxis: {
                    type: "category",
                    axisLabel: {
                        textStyle: {
                            color: color.textStyle
                        }
                    },
                    axisLine: {
                        lineStyle: {
                            color: color.splitLine
                        }
                    },
                    lightStyle: {
                        color: color.lineStyle
                    },
                    axisTick: {
                        show: false
                    },
                    data: []
                },
                legend: {
                    // data: this.tr("yAxisName"),
                    lineStyle: {
                        color: "#ffffff"
                    },
                    textStyle: {
                        // fontSize: this.fontSize,
                        color: color.textStyle
                    },
                    formatter (v) {
                        return v;
                    },
                    icon: "circle"
                }
            };
    }
};
const getColor = (theme)=>{
    return theme === "light" ? lightStyle : blackStyle;
};


/***/ })

};
;