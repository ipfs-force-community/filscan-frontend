exports.id = 1538;
exports.ids = [1538];
exports.modules = {

/***/ 821:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _filter, _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgIconRightWhite = function SvgIconRightWhite(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 36 36"
  }, props), _filter || (_filter = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("filter", {
    id: "icon-right-white_svg__a"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("feColorMatrix", {
    in: "SourceGraphic",
    values: "0 0 0 0 0.600000 0 0 0 0 0.600000 0 0 0 0 0.600000 0 0 0 1.000000 0"
  }))), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("circle", {
    cx: 18,
    cy: 18,
    r: 18,
    fill: "#f5f5f5"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    filter: "url(#icon-right-white_svg__a)"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "#2c2c2c",
    fillRule: "nonzero"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M25.975 19.165H9.167a.684.684 0 0 1-.684-.684v-1.367c0-.378.307-.684.684-.684h16.808z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "m19.457 24.794-.965-.965a.682.682 0 0 1 0-.965l5.066-5.067-5.066-5.066a.683.683 0 0 1 0-.965l.965-.965a.683.683 0 0 1 .965 0l6.996 6.996-6.996 6.997a.683.683 0 0 1-.965 0z"
  }))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgIconRightWhite);

/***/ }),

/***/ 1161:
/***/ ((module) => {

// Exports
module.exports = {
	"trend": "trend_trend__WxeGz"
};


/***/ }),

/***/ 8187:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const useFadeInOnScroll = ()=>{
    const ref = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const observer = new IntersectionObserver(([entry])=>{
            // 当元素进入视口时，添加`fade-in`类
            if (entry.isIntersecting) {
                entry.target.classList.add("fade-in");
            }
        }, {
            // 当元素的50%可见时，触发回调
            threshold: 0.01
        });
        if (ref.current) {
            observer.observe(ref.current);
        }
        // 在组件卸载时，取消观察
        return ()=>{
            if (ref.current) {
                observer.unobserve(ref.current);
            }
        };
    }, []);
    return ref;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useFadeInOnScroll);


/***/ }),

/***/ 1538:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _components_echarts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3778);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2881);
/* harmony import */ var _contents_statistic__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4852);
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8804);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7947);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3495);
/* harmony import */ var _utils_echarts__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7355);
/* harmony import */ var _assets_images_black_go_svg__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3309);
/* harmony import */ var _assets_images_icon_right_white_svg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(821);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _components_hooks_useObserver__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8187);
/* harmony import */ var _trend_module_scss__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(1161);
/* harmony import */ var _trend_module_scss__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_trend_module_scss__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(9676);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(8108);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_statistic__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_7__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_16__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_statistic__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_7__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_16__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 

















/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { origin, className } = props;
    const { theme, lang } = (0,_store_FilscanStore__WEBPACK_IMPORTED_MODULE_5__/* .useFilscanStore */ .J)();
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__/* .Translation */ .W)({
        ns: "static"
    });
    const ref = (0,_components_hooks_useObserver__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z)();
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z)();
    const [noShow, setNoShow] = (0,react__WEBPACK_IMPORTED_MODULE_12__.useState)({});
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_12__.useState)({});
    const color = (0,react__WEBPACK_IMPORTED_MODULE_12__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_8__/* .getColor */ .Lq)(theme);
    }, [
        theme
    ]);
    const default_xAxis = (0,react__WEBPACK_IMPORTED_MODULE_12__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_8__/* .get_xAxis */ .Fs)(theme);
    }, [
        theme
    ]);
    const defaultOptions = (0,react__WEBPACK_IMPORTED_MODULE_12__.useMemo)(()=>{
        return {
            grid: {
                top: 30,
                left: 20,
                right: 20,
                bottom: 20,
                containLabel: true
            },
            yAxis: [
                {
                    type: "value",
                    position: "left",
                    scale: true,
                    nameTextStyle: {
                        color: color.textStyle
                    },
                    axisLabel: {
                        formatter: "{value} EiB",
                        textStyle: {
                            //  fontSize: this.fontSize,
                            color: color.labelColor
                        }
                    },
                    axisLine: {
                        show: false
                    },
                    axisTick: {
                        show: false
                    },
                    splitLine: {
                        show: false,
                        lineStyle: {
                            type: "dashed",
                            color: color.splitLine
                        }
                    }
                },
                {
                    type: "value",
                    position: "right",
                    scale: true,
                    nameTextStyle: {
                        color: color.textStyle
                    },
                    axisLabel: {
                        formatter: "{value} PiB",
                        textStyle: {
                            //  fontSize: this.fontSize,
                            color: color.labelColor
                        }
                    },
                    axisTick: {
                        show: false
                    },
                    axisLine: {
                        show: false
                    },
                    splitLine: {
                        lineStyle: {
                            type: "dashed",
                            color: color.splitLine
                        }
                    }
                }
            ],
            legend: {
                show: false
            },
            tooltip: {
                //@ts-ignore
                position: function(pos, params, dom, rect, size) {
                    // 鼠标在左侧时 tooltip 显示到右侧，鼠标在右侧时 tooltip 显示到左侧。
                    var obj = {
                        top: 80
                    };
                    //@ts-ignore
                    obj[[
                        "left",
                        "right"
                    ][+(pos[0] < size.viewSize[0] / 2)]] = 5;
                    return (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .isMobile */ .tq)() ? obj : undefined;
                },
                trigger: "axis",
                backgroundColor: color.toolbox,
                borderColor: "transparent",
                textStyle: {
                    color: "#ffffff"
                },
                formatter (v) {
                    var result = v[0].data.showTime;
                    v.forEach((item)=>{
                        if (item.data) {
                            result += "<br/>" + item.marker + tr(item.seriesName) + ": " + item.data.amount + item.data.unit;
                        }
                    });
                    return result;
                }
            }
        };
    }, [
        theme
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_12__.useEffect)(()=>{
        load();
    }, []);
    const load = async ()=>{
        const seriesObj = {};
        _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .power_trend */ .wO.list.forEach((v)=>{
            seriesObj[v.dataIndex] = [];
        });
        const dateList = [];
        const legendList = [];
        const seriesData = [];
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.line_trend, {
            interval: "1m"
        });
        result?.list?.forEach((value)=>{
            const { timestamp, total_raw_byte_power, total_quality_adj_power, power_increase, power_decrease } = value;
            const showTime = (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatDateTime */ .o0)(timestamp, "MM-DD");
            dateList.push(showTime);
            //amount
            const [total_raw_byte_power_amount, total_raw_byte_power_unit] = total_raw_byte_power && (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .unitConversion */ .dN)(total_raw_byte_power, 2)?.split(" ");
            const [power_increase_amount, power_increase_unit] = power_increase && (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .unitConversion */ .dN)(power_increase, 2)?.split(" ");
            const [total_quality_adj_power_amount, total_quality_adj_power_unit] = total_quality_adj_power && (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .unitConversion */ .dN)(total_quality_adj_power, 2)?.split(" ");
            const [power_decrease_amount, power_decrease_unit] = power_decrease && (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .unitConversion */ .dN)(power_decrease, 2)?.split(" ");
            seriesObj.total_raw_byte_power.push({
                amount: total_raw_byte_power_amount,
                value: (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .unitConversion */ .dN)(total_raw_byte_power, 2, 6).split(" ")[0],
                unit: total_raw_byte_power_unit,
                showTime: (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatDateTime */ .o0)(timestamp, "YYYY-MM-DD HH:mm")
            });
            seriesObj.total_quality_adj_power.push({
                amount: total_quality_adj_power_amount,
                showTime: (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatDateTime */ .o0)(timestamp, "YYYY-MM-DD HH:mm"),
                value: (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .unitConversion */ .dN)(total_quality_adj_power, 2, 6).split(" ")[0],
                unit: total_quality_adj_power_unit
            });
            seriesObj.power_increase.push({
                amount: power_increase_amount,
                showTime: (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatDateTime */ .o0)(timestamp, "YYYY-MM-DD HH:mm"),
                value: (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .unitConversion */ .dN)(power_increase, 2, 5).split(" ")[0],
                unit: power_increase_unit
            });
            seriesObj.power_decrease.push({
                amount: power_decrease_amount,
                value: (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .unitConversion */ .dN)(power_decrease, 2, 5).split(" ")[0],
                showTime: (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatDateTime */ .o0)(timestamp, "YYYY-MM-DD HH:mm"),
                unit: power_decrease_unit
            });
        });
        _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .power_trend */ .wO.list.forEach((item)=>{
            legendList.push({
                name: item.dataIndex,
                color: item.color,
                type: item.type
            });
            seriesData.push({
                type: item.type,
                data: seriesObj[item.dataIndex],
                key: item.dataIndex,
                name: item.dataIndex,
                yAxisIndex: item.yIndex,
                symbol: "circle",
                smooth: true,
                itemStyle: {
                    color: item.color
                },
                barMaxWidth: "30"
            });
        });
        setOptions({
            series: seriesData,
            xData: dateList,
            legendData: legendList
        });
    };
    const newOptions = (0,react__WEBPACK_IMPORTED_MODULE_12__.useMemo)(()=>{
        const newSeries = [];
        (options?.series || []).forEach((seriesItem)=>{
            if (!noShow[seriesItem?.name]) {
                newSeries.push(seriesItem);
            }
        });
        return {
            ...defaultOptions,
            xAxis: {
                ...default_xAxis,
                data: options?.xData || []
            },
            series: newSeries
        };
    }, [
        options,
        defaultOptions,
        noShow
    ]);
    const propsRef = origin === "home" ? {
        ref
    } : {};
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        //id='power'
        className: classnames__WEBPACK_IMPORTED_MODULE_14___default()((_trend_module_scss__WEBPACK_IMPORTED_MODULE_17___default().trend), `w-full h-[full]  ${className} ${origin === "home" ? "mt-20" : ""}`),
        ...propsRef,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: `flex justify-between flex-wrap items-center min-h-[36px] mb-2.5 ${lang === "en" ? "h-[60px]" : ""}`,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex-1 flex flex-row flex-wrap items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-fit font-PingFang font-semibold text-lg pl-2.5",
                                children: tr("power")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-fit",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_15__/* .BrowserView */ .I, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "flex gap-x-4 ml-5",
                                        children: options?.legendData?.map((v)=>{
                                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: "text-xs flex cursor-pointer items-center gap-x-1",
                                                onClick: ()=>{
                                                    setNoShow({
                                                        ...noShow,
                                                        [v.name]: !noShow[v.name]
                                                    });
                                                },
                                                style: {
                                                    color: noShow[v.name] ? "#d1d5db" : v.color
                                                },
                                                children: [
                                                    (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_6__/* .getSvgIcon */ .a)(v.type === "bar" ? "barLegend" : "legendIcon"),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "text-xs text_des font-normal",
                                                        children: tr(v.name)
                                                    })
                                                ]
                                            }, v.name);
                                        })
                                    })
                                })
                            })
                        ]
                    }),
                    origin === "home" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_11___default()), {
                        href: `/statistics/charts#BlockChain`,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_15__/* .MobileView */ .$, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_icon_right_white_svg__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                    width: 28,
                                    height: 28
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_15__/* .BrowserView */ .I, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_black_go_svg__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                    className: "cursor-pointer mr-2.5",
                                    width: 18,
                                    height: 18
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_15__/* .BrowserView */ .I, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: `h-[350px] w-full pb-2 card_shadow border border_color rounded-xl`,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        options: newOptions
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_15__/* .MobileView */ .$, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: `w-full pb-2 card_shadow border border_color rounded-xl`,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "flex gap-x-4 chart-legend",
                            children: options?.legendData?.map((v)=>{
                                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    className: "text-xs flex cursor-pointer items-center gap-x-1",
                                    onClick: ()=>{
                                        setNoShow({
                                            ...noShow,
                                            [v.name]: !noShow[v.name]
                                        });
                                    },
                                    style: {
                                        color: noShow[v.name] ? "#d1d5db" : v.color
                                    },
                                    children: [
                                        (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_6__/* .getSvgIcon */ .a)(v.type === "bar" ? "barLegend" : "legendIcon"),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "text-xs text_des font-normal",
                                            children: tr(v.name)
                                        })
                                    ]
                                }, v.name);
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "h-[350px]",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                options: newOptions
                            })
                        })
                    ]
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;