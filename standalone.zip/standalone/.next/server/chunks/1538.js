exports.id = 1538;
exports.ids = [1538];
exports.modules = {

/***/ 821:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgIconRightWhite = function SvgIconRightWhite(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 42 42"
  }, props), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("circle", {
    cx: 21,
    cy: 21,
    r: 21,
    fill: "#f5f5f5"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "#666",
    fillRule: "nonzero"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M30.304 22.36H10.695a.798.798 0 0 1-.798-.798v-1.596c0-.44.357-.798.798-.798h19.61z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M22.7 28.926 21.573 27.8a.795.795 0 0 1 0-1.126l5.91-5.91-5.91-5.91a.797.797 0 0 1 0-1.127l1.125-1.126a.797.797 0 0 1 1.126 0l8.163 8.163-8.163 8.162a.797.797 0 0 1-1.126 0z"
  })))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgIconRightWhite);

/***/ }),

/***/ 61161:
/***/ ((module) => {

// Exports
module.exports = {
	"trend": "trend_trend__WxeGz",
	"title-wrap": "trend_title-wrap__S4aMw",
	"title": "trend_title__JyKbZ",
	"chart-wrap": "trend_chart-wrap__nw7kf",
	"legend": "trend_legend__T6BXe",
	"value": "trend_value__1Zr0a"
};


/***/ }),

/***/ 38187:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const useFadeInOnScroll = ()=>{
    const ref = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const observer = new IntersectionObserver(([entry])=>{
            // 当元素进入视口时，添加`fade-in`类
            if (entry.isIntersecting) {
                entry.target.classList.add("fade-in");
            }
        }, {
            // 当元素的50%可见时，触发回调
            threshold: 0.01
        });
        if (ref.current) {
            observer.observe(ref.current);
        }
        // 在组件卸载时，取消观察
        return ()=>{
            if (ref.current) {
                observer.unobserve(ref.current);
            }
        };
    }, []);
    return ref;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useFadeInOnScroll);


/***/ }),

/***/ 71538:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _components_echarts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(13778);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(62881);
/* harmony import */ var _contents_statistic__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(24852);
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(48804);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7947);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(23495);
/* harmony import */ var _utils_echarts__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7355);
/* harmony import */ var _assets_images_black_go_svg__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(53309);
/* harmony import */ var _assets_images_icon_right_white_svg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(821);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(41664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _components_hooks_useObserver__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(38187);
/* harmony import */ var _trend_module_scss__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(61161);
/* harmony import */ var _trend_module_scss__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(_trend_module_scss__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(29676);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(68108);
/* harmony import */ var _components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(31061);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_statistic__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_7__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_16__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_statistic__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_7__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_16__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 


















/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { origin, className } = props;
    const { theme, lang } = (0,_store_FilscanStore__WEBPACK_IMPORTED_MODULE_5__/* .useFilscanStore */ .J)();
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__/* .Translation */ .W)({
        ns: "static"
    });
    const ref = (0,_components_hooks_useObserver__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z)();
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z)();
    const [noShow, setNoShow] = (0,react__WEBPACK_IMPORTED_MODULE_12__.useState)({});
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_12__.useState)({});
    const { isMobile } = (0,_components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z)();
    const color = (0,react__WEBPACK_IMPORTED_MODULE_12__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_8__/* .getColor */ .Lq)(theme);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        theme
    ]);
    const default_xAxis = (0,react__WEBPACK_IMPORTED_MODULE_12__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_8__/* .get_xAxis */ .Fs)(theme, isMobile);
    }, [
        theme,
        isMobile
    ]);
    const defaultOptions = (0,react__WEBPACK_IMPORTED_MODULE_12__.useMemo)(()=>{
        let options = {
            grid: {
                top: 30,
                left: 20,
                right: 20,
                bottom: 20,
                containLabel: true
            },
            yAxis: [
                {
                    type: "value",
                    position: "left",
                    scale: true,
                    nameTextStyle: {
                        color: color.textStyle
                    },
                    axisLabel: {
                        formatter: "{value} EiB",
                        textStyle: {
                            //  fontSize: this.fontSize,
                            color: isMobile ? color.mobileLabelColor : color.labelColor
                        }
                    },
                    axisLine: {
                        show: false
                    },
                    axisTick: {
                        show: false
                    },
                    splitLine: {
                        show: false,
                        lineStyle: {
                            type: "dashed",
                            color: color.splitLine
                        }
                    }
                },
                {
                    type: "value",
                    position: "right",
                    scale: true,
                    nameTextStyle: {
                        color: color.textStyle
                    },
                    axisLabel: {
                        formatter: "{value} PiB",
                        textStyle: {
                            //  fontSize: this.fontSize,
                            color: isMobile ? color.mobileLabelColor : color.labelColor
                        }
                    },
                    axisTick: {
                        show: false
                    },
                    axisLine: {
                        show: false
                    },
                    splitLine: {
                        lineStyle: {
                            type: "dashed",
                            color: color.splitLine
                        }
                    }
                }
            ],
            legend: {
                show: false
            },
            tooltip: {
                //@ts-ignore
                position: function(pos, params, dom, rect, size) {
                    // 鼠标在左侧时 tooltip 显示到右侧，鼠标在右侧时 tooltip 显示到左侧。
                    var obj = {
                        top: 80
                    };
                    //@ts-ignore
                    obj[[
                        "left",
                        "right"
                    ][+(pos[0] < size.viewSize[0] / 2)]] = 5;
                    return isMobile ? obj : undefined;
                },
                trigger: "axis",
                backgroundColor: color.toolbox,
                borderColor: "transparent",
                textStyle: {
                    color: "#ffffff"
                },
                formatter (v) {
                    var result = v[0].data.showTime;
                    v.forEach((item)=>{
                        if (item.data) {
                            result += "<br/>" + item.marker + tr(item.seriesName) + ": " + item.data.amount + item.data.unit;
                        }
                    });
                    return result;
                }
            }
        };
        if (isMobile) {
            options["grid"] = {
                top: "16px",
                right: "12px",
                bottom: "16px",
                left: "12px",
                containLabel: true
            };
        }
        return options;
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        theme,
        isMobile
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_12__.useEffect)(()=>{
        load();
    }, []);
    const load = async ()=>{
        const seriesObj = {};
        _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .power_trend */ .wO.list.forEach((v)=>{
            seriesObj[v.dataIndex] = [];
        });
        const dateList = [];
        const legendList = [];
        const seriesData = [];
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.line_trend, {
            interval: "1m"
        });
        result?.list?.forEach((value)=>{
            const { timestamp, total_raw_byte_power, total_quality_adj_power, power_increase, power_decrease } = value;
            const showTime = (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatDateTime */ .o0)(timestamp, "MM-DD");
            dateList.push(showTime);
            //amount
            const [total_raw_byte_power_amount, total_raw_byte_power_unit] = total_raw_byte_power && (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .unitConversion */ .dN)(total_raw_byte_power, 2)?.split(" ");
            const [power_increase_amount, power_increase_unit] = power_increase && (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .unitConversion */ .dN)(power_increase, 2)?.split(" ");
            const [total_quality_adj_power_amount, total_quality_adj_power_unit] = total_quality_adj_power && (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .unitConversion */ .dN)(total_quality_adj_power, 2)?.split(" ");
            const [power_decrease_amount, power_decrease_unit] = power_decrease && (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .unitConversion */ .dN)(power_decrease, 2)?.split(" ");
            seriesObj.total_raw_byte_power.push({
                amount: total_raw_byte_power_amount,
                value: (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .unitConversion */ .dN)(total_raw_byte_power, 2, 6).split(" ")[0],
                unit: total_raw_byte_power_unit,
                showTime: (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatDateTime */ .o0)(timestamp, "YYYY-MM-DD HH:mm")
            });
            seriesObj.total_quality_adj_power.push({
                amount: total_quality_adj_power_amount,
                showTime: (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatDateTime */ .o0)(timestamp, "YYYY-MM-DD HH:mm"),
                value: (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .unitConversion */ .dN)(total_quality_adj_power, 2, 6).split(" ")[0],
                unit: total_quality_adj_power_unit
            });
            seriesObj.power_increase.push({
                amount: power_increase_amount,
                showTime: (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatDateTime */ .o0)(timestamp, "YYYY-MM-DD HH:mm"),
                value: (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .unitConversion */ .dN)(power_increase, 2, 5).split(" ")[0],
                unit: power_increase_unit
            });
            seriesObj.power_decrease.push({
                amount: power_decrease_amount,
                value: (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .unitConversion */ .dN)(power_decrease, 2, 5).split(" ")[0],
                showTime: (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatDateTime */ .o0)(timestamp, "YYYY-MM-DD HH:mm"),
                unit: power_decrease_unit
            });
        });
        _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .power_trend */ .wO.list.forEach((item)=>{
            legendList.push({
                name: item.dataIndex,
                color: item.color,
                type: item.type
            });
            seriesData.push({
                type: item.type,
                data: seriesObj[item.dataIndex],
                key: item.dataIndex,
                name: item.dataIndex,
                yAxisIndex: item.yIndex,
                symbol: "circle",
                smooth: true,
                itemStyle: {
                    color: item.color
                },
                barMaxWidth: "30"
            });
        });
        setOptions({
            series: seriesData,
            xData: dateList,
            legendData: legendList
        });
    };
    const newOptions = (0,react__WEBPACK_IMPORTED_MODULE_12__.useMemo)(()=>{
        const newSeries = [];
        (options?.series || []).forEach((seriesItem)=>{
            if (!noShow[seriesItem?.name]) {
                newSeries.push(seriesItem);
            }
        });
        return {
            ...defaultOptions,
            xAxis: {
                ...default_xAxis,
                data: options?.xData || []
            },
            series: newSeries
        };
    }, [
        options,
        defaultOptions,
        noShow
    ]);
    const propsRef = origin === "home" ? {
        ref
    } : {};
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        //id='power'
        className: classnames__WEBPACK_IMPORTED_MODULE_14___default()((_trend_module_scss__WEBPACK_IMPORTED_MODULE_18___default().trend), `w-full h-[full]  ${className} ${origin === "home" ? "mt-20" : ""}`),
        ...propsRef,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_14___default()(`flex justify-between flex-wrap items-center min-h-[36px] mb-2.5 ${lang === "en" ? "h-[60px]" : ""}`, (_trend_module_scss__WEBPACK_IMPORTED_MODULE_18___default()["title-wrap"])),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex-1 flex flex-row flex-wrap items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: classnames__WEBPACK_IMPORTED_MODULE_14___default()("w-fit font-PingFang font-semibold text-lg pl-2.5", (_trend_module_scss__WEBPACK_IMPORTED_MODULE_18___default().title)),
                                children: tr("power")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-fit",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_15__/* .BrowserView */ .I, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "flex gap-x-4 ml-5",
                                        children: options?.legendData?.map((v)=>{
                                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: "text-xs flex cursor-pointer items-center gap-x-1",
                                                onClick: ()=>{
                                                    setNoShow({
                                                        ...noShow,
                                                        [v.name]: !noShow[v.name]
                                                    });
                                                },
                                                style: {
                                                    color: noShow[v.name] ? "#d1d5db" : v.color
                                                },
                                                children: [
                                                    (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_6__/* .getSvgIcon */ .a)(v.type === "bar" ? "barLegend" : "legendIcon"),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "text-xs text_des font-normal",
                                                        children: tr(v.name)
                                                    })
                                                ]
                                            }, v.name);
                                        })
                                    })
                                })
                            })
                        ]
                    }),
                    origin === "home" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_11___default()), {
                        href: `/statistics/charts#BlockChain`,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_15__/* .MobileView */ .$, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_icon_right_white_svg__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                    width: 28,
                                    height: 28
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_15__/* .BrowserView */ .I, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_black_go_svg__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                    width: 18,
                                    height: 18,
                                    className: "cursor-pointer mr-2.5"
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_15__/* .BrowserView */ .I, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: `h-[350px] w-full pb-2 card_shadow border border_color rounded-xl`,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        options: newOptions
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_15__/* .MobileView */ .$, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: classnames__WEBPACK_IMPORTED_MODULE_14___default()(`w-full pb-2 card_shadow border border_color rounded-xl`, (_trend_module_scss__WEBPACK_IMPORTED_MODULE_18___default()["chart-wrap"])),
                    children: [
                        (()=>{
                            if ((lang === "en" || lang === "ka") && isMobile) {
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: classnames__WEBPACK_IMPORTED_MODULE_14___default()("grid grid-cols-2 gap-2 chart-legend", (_trend_module_scss__WEBPACK_IMPORTED_MODULE_18___default().legend)),
                                    children: options?.legendData?.map((v)=>{
                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            className: "text-xs flex cursor-pointer items-center gap-x-1",
                                            onClick: ()=>{
                                                setNoShow({
                                                    ...noShow,
                                                    [v.name]: !noShow[v.name]
                                                });
                                            },
                                            style: {
                                                color: noShow[v.name] ? "#d1d5db" : v.color
                                            },
                                            children: [
                                                (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_6__/* .getSvgIcon */ .a)(v.type === "bar" ? "barLegend" : "legendIcon"),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: classnames__WEBPACK_IMPORTED_MODULE_14___default()("text-xs text_des font-normal", (_trend_module_scss__WEBPACK_IMPORTED_MODULE_18___default().value)),
                                                    children: tr(v.name)
                                                })
                                            ]
                                        }, v.name);
                                    })
                                });
                            }
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: classnames__WEBPACK_IMPORTED_MODULE_14___default()("flex gap-x-4 chart-legend", (_trend_module_scss__WEBPACK_IMPORTED_MODULE_18___default().legend)),
                                children: options?.legendData?.map((v)=>{
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "text-xs flex cursor-pointer items-center gap-x-1",
                                        onClick: ()=>{
                                            setNoShow({
                                                ...noShow,
                                                [v.name]: !noShow[v.name]
                                            });
                                        },
                                        style: {
                                            color: noShow[v.name] ? "#d1d5db" : v.color
                                        },
                                        children: [
                                            (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_6__/* .getSvgIcon */ .a)(v.type === "bar" ? "barLegend" : "legendIcon"),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: classnames__WEBPACK_IMPORTED_MODULE_14___default()("text-xs text_des font-normal", (_trend_module_scss__WEBPACK_IMPORTED_MODULE_18___default().value)),
                                                children: tr(v.name)
                                            })
                                        ]
                                    }, v.name);
                                })
                            });
                        })(),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "h-[350px]",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                options: newOptions
                            })
                        })
                    ]
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;