"use strict";
exports.id = 1921;
exports.ids = [1921];
exports.modules = {

/***/ 86699:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_0__);
/** @format */ 
const useRemoveQueryParam = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_0__.useRouter)();
    const removeQueryParam = (param)=>{
        const hash = router.asPath.split("#")[1];
        if (Array.isArray(param)) {
            let restQueryParams = {
                ...router.query
            };
            param.forEach((param)=>{
                const { [param]: removed, ...rest } = restQueryParams;
                restQueryParams = rest;
            });
            if (hash) {
                router.push({
                    pathname: router.pathname,
                    query: restQueryParams,
                    hash: hash
                }, undefined, {
                    scroll: false,
                    shallow: false
                });
            } else {
                router.push({
                    pathname: router.pathname,
                    query: restQueryParams
                }, undefined, {
                    scroll: false,
                    shallow: false
                });
            }
        } else {
            const { [param]: removed, ...restQueryParams } = router.query;
            if (hash) {
                router.push({
                    pathname: router.pathname,
                    query: restQueryParams,
                    hash: hash
                }, undefined, {
                    scroll: false,
                    shallow: false
                });
            } else {
                router.push({
                    pathname: router.pathname,
                    query: restQueryParams
                }, undefined, {
                    scroll: false,
                    shallow: false
                });
            }
        }
    };
    return removeQueryParam;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useRemoveQueryParam);


/***/ }),

/***/ 42680:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(23495);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils__WEBPACK_IMPORTED_MODULE_0__]);
_utils__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/** @format */ 

const useUpdateQuery = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    const updateQuery = (newQuery)=>{
        const isHash = router.asPath.includes("#");
        const hash = router.asPath.split("#")[1];
        if (isHash) {
            const hashParams = router.asPath?.split("?")[1];
            const result = (0,_utils__WEBPACK_IMPORTED_MODULE_0__/* .parseQueryString */ .dD)(hashParams);
            const query = {
                ...result,
                ...newQuery
            };
            router.push({
                pathname: router.pathname,
                query: {
                    ...router.query,
                    ...newQuery
                },
                hash: hash
            }, undefined, {
                scroll: false,
                shallow: false
            });
        } else {
            const newParams = {
                ...router.query,
                ...newQuery
            };
            Object.keys(newQuery).forEach((key)=>{
                if (newQuery[key] === "removed") {
                    delete newParams[key];
                }
            });
            router.push({
                pathname: router.pathname,
                query: {
                    ...newParams
                }
            }, undefined, {
                scroll: false
            }).catch((error)=>{});
        }
    };
    return updateQuery;
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useUpdateQuery);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;