"use strict";
exports.id = 5509;
exports.ids = [5509];
exports.modules = {

/***/ 1086:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-accelerate.aliyuncs.com/client/_next/static/media/TokenPocket.6e21b274.png","height":1024,"width":1024,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAAsUlEQVR42jVOuw4BARDcWqMStYTEIxR8h6/xSjju0V5P6QNEQeIDNDQ6xSUUEgoSz8RF4mQm9k4ks5vszszuSM5iPkLBYsVhyWbZoS5FK2FAEetA6pAWpIGQ0GGxpv/i9sDxnI9n2KUJiRtoDRl8OFvyfOfxwnfAqkvR02pSYX/C05U3nyuP0oZkTaRNbPZ0R/R2HEwpNWRMhM+VS3aR6iFpQLW/hOqgcoV/4qLNfCT9ArNpfEXhWTOlAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 49175:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _packages_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(92964);
/* harmony import */ var _assets_images_TokenPocket_png__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1086);
/* harmony import */ var _packages_tooltip__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(72305);
/* harmony import */ var web3__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(34325);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(57987);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([web3__WEBPACK_IMPORTED_MODULE_4__, react_i18next__WEBPACK_IMPORTED_MODULE_5__]);
([web3__WEBPACK_IMPORTED_MODULE_4__, react_i18next__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ data })=>{
    const { t } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_5__.useTranslation)();
    const tr = (label, value)=>{
        if (value) {
            return t(label, {
                ...value,
                ns: "fevm"
            });
        }
        return t(label, {
            ns: "fevm"
        });
    };
    async function getNetWork() {
        const web3 = new web3__WEBPACK_IMPORTED_MODULE_4__["default"](window.ethereum);
        const chainId = await web3.eth.getChainId();
        return Number(chainId) === 314;
    }
    const addNetwork = async ()=>{
        if (window.ethereum) {
            try {
                const res = await window.ethereum.request({
                    method: "wallet_switchEthereumChain",
                    params: [
                        {
                            chainId: "0x13a"
                        }
                    ]
                });
                return true;
            } catch (e) {
                if (e.code === 4902) {
                    try {
                        const res = await window.ethereum.request({
                            method: "wallet_addEthereumChain",
                            params: [
                                {
                                    chainId: "0x13a",
                                    chainName: "Filecoin - Mainnet",
                                    nativeCurrency: {
                                        name: "Mainnet",
                                        symbol: "FIL",
                                        decimals: 18
                                    },
                                    rpcUrls: [
                                        "https://api.node.glif.io/"
                                    ],
                                    blockExplorerUrls: [
                                        "https://filscan.io"
                                    ]
                                }
                            ]
                        });
                        return true;
                    } catch (addError) {
                        console.error(addError);
                    }
                }
            }
        } else {
            // if no window.ethereum then MetaMask is not installed
            alert("MetaMask is not installed. Please consider installing it: https://metamask.io/download.html");
        }
    };
    const handleClick = async ()=>{
        if (!window?.ethereum.isTokenPocket) {
            //dowm wallet
            window.open(`https://chrome.google.com/webstore/detail/tokenpocket/mfgccjchihfkkindfppnaooecgfneiii?hl=en`);
            window.location.reload();
        } else {
            const chainId = await getNetWork();
            if (!chainId) {
                // 切换网络
                const res = await addNetwork();
                if (res) {
                    return connect_account();
                }
            }
            return connect_account();
        }
    };
    const connect_account = ()=>{
        window.ethereum.request({
            method: "eth_requestAccounts"
        }).then((res)=>{
            addToken(res[0]);
        }).catch((error)=>{
            if (error.code === 4001) {
                console.log("Please connect to TokenPocket Extension.");
            } else {
                console.error(error);
            }
        });
    };
    const addToken = async (address)=>{
        const tokenAddress = data.contract_id;
        const tokenSymbol = data?.tokenName;
        const tokenDecimals = 18;
        const tokenImage = data?.token_image;
        try {
            // wasAdded is a boolean. Like any RPC method, an error can be thrown.
            const wasAdded = await window.ethereum.request({
                method: "wallet_watchAsset",
                params: {
                    type: "ERC20",
                    options: {
                        address: tokenAddress,
                        symbol: tokenSymbol,
                        decimals: tokenDecimals,
                        image: tokenImage
                    }
                }
            });
            if (wasAdded) {
                console.log("Thanks for your interest!");
            } else {
                console.log("Your loss!");
            }
        } catch (error) {
            console.log(error);
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tooltip__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        context: tr("tp_token"),
        icon: false,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_image__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
            onClick: handleClick,
            src: _assets_images_TokenPocket_png__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
            width: 18,
            alt: "tp wallet",
            className: "margin-6",
            style: {
                display: "block",
                cursor: "pointer",
                borderRadius: "50%"
            }
        })
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 95509:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AD: () => (/* binding */ homeContractRank),
/* harmony export */   DB: () => (/* binding */ contract_nfts),
/* harmony export */   F: () => (/* binding */ contract_token),
/* harmony export */   Fq: () => (/* binding */ contract_list),
/* harmony export */   Gg: () => (/* binding */ token_owner_columns),
/* harmony export */   JZ: () => (/* binding */ contract_detail),
/* harmony export */   Mz: () => (/* binding */ nft_transfer_columns),
/* harmony export */   OR: () => (/* binding */ contract_log),
/* harmony export */   Qm: () => (/* binding */ nft_details),
/* harmony export */   T: () => (/* binding */ verify),
/* harmony export */   XE: () => (/* binding */ mobileHomeContractRank),
/* harmony export */   _4: () => (/* binding */ verify_output),
/* harmony export */   aN: () => (/* binding */ token_transfer_columns),
/* harmony export */   kf: () => (/* binding */ contract_rank),
/* harmony export */   mO: () => (/* binding */ verify_first),
/* harmony export */   oH: () => (/* binding */ token_Dex_columns),
/* harmony export */   oO: () => (/* binding */ nft_owner_columns),
/* harmony export */   qc: () => (/* binding */ token_details),
/* harmony export */   s3: () => (/* binding */ verify_tabs),
/* harmony export */   yP: () => (/* binding */ verify_source)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _components_copy__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(25174);
/* harmony import */ var _components_TPWallet__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(49175);
/* harmony import */ var _packages_tooltip__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(72305);
/* harmony import */ var _assets_images_icon_copy_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(45903);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(23495);
/* harmony import */ var _packages_image__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(92964);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(41664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(29676);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_TPWallet__WEBPACK_IMPORTED_MODULE_2__, _utils__WEBPACK_IMPORTED_MODULE_5__]);
([_components_TPWallet__WEBPACK_IMPORTED_MODULE_2__, _utils__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 








//合约验证
const verify_first = {
    list: [
        {
            type: "Input",
            dataIndex: "contract_address",
            title: "address",
            placeholder: "address_placeholder",
            rules: [
                {
                    required: true,
                    message: ""
                },
                {
                    validator: (_, value)=>{
                        if (!value || value.length == 0 || value.startsWith("0x") || value.startsWith("f") || value.startsWith("t")) {
                            return Promise.resolve();
                        }
                        return Promise.reject("");
                    }
                }
            ]
        },
        {
            type: "Select",
            title: "verify_address",
            dataIndex: "compile_version",
            placeholder: "verify_select_placeholder"
        },
        {
            type: "Select",
            title: "verify_model",
            dataIndex: "verify_model",
            placeholder: "verify_model_placeholder",
            // rules: [{ required: true, message: '${verify_model} is required' }],
            options: [
                {
                    title: "Solidity File",
                    value: "single"
                },
                {
                    title: "Solidity File with Metadata",
                    value: "multi"
                },
                {
                    title: "Hardhat Support (Quickly)",
                    value: "standard"
                }
            ]
        },
        {
            type: "Select",
            title: "license_type",
            dataIndex: "license",
            placeholder: "verify_select_placeholder",
            options: [
                {
                    title: "No License(None)",
                    value: "No license(None)"
                },
                {
                    title: "MIT License(MIT)",
                    value: "MIT license(MIT)"
                }
            ]
        }
    ]
};
const verify = {
    tabList: [
        {
            dataIndex: "source_code",
            title: "source_code"
        },
        {
            dataIndex: "compile_output",
            title: "compile_output"
        }
    ],
    meta_list_des: [
        {
            title: "config_file_des1"
        },
        {
            title: "config_file_des1_1"
        },
        {
            title: "config_file_des1_2"
        },
        {
            title: "config_file_des2"
        },
        {
            title: "config_file_des2_1"
        },
        {
            title: "config_file_des2_2"
        }
    ]
};
const verify_source = {
    desList: [
        {
            title: "content_des1"
        },
        {
            title: "content_des2"
        },
        {
            title: "content_des3"
        }
    ],
    headerList: [
        {
            title: "contract_address",
            dataIndex: "contract_address"
        },
        {
            title: "compile_version",
            dataIndex: "compile_version"
        },
        {
            title: "optimize",
            dataIndex: "optimize",
            type: "Select",
            options: [
                {
                    title: "Yes",
                    label: "Yes",
                    value: true
                },
                {
                    title: "No",
                    label: "No",
                    value: false
                }
            ]
        },
        {
            title: "run_optimizer",
            dataIndex: "optimize_runs",
            type: "Input"
        }
    ]
};
const verify_output = {
    headerList: [
        {
            title: "compile_version",
            dataIndex: "compiler"
        },
        {
            title: "optimize",
            dataIndex: "optimize"
        },
        {
            title: "RUNS",
            dataIndex: "optimize_runs"
        }
    ]
};
const contract_rank = {
    title: "contract_rank",
    title_des: "contract_rank_des",
    options: [
        {
            title: "transaction_count",
            value: "transfer_count"
        },
        {
            title: "actor_balance",
            value: "actor_balance"
        },
        {
            title: "gas_cost",
            value: "gas_cost"
        },
        {
            title: "user_count",
            value: "user_count"
        }
    ],
    total_msg: "contract_rank_total",
    columns: [
        {
            title: "rank",
            dataIndex: "rank",
            width: "10%",
            render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "rank_icon",
                    children: text
                })
        },
        {
            title: "contract_address",
            dataIndex: "contract_address",
            width: "10%",
            render: (text, record)=>{
                if (!text) return "--";
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "flex gap-x-2 items-center",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_device_detect__WEBPACK_IMPORTED_MODULE_8__/* .BrowserView */ .I, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                    className: "link_text",
                                    href: `/address/${text}`,
                                    children: (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .isIndent */ .EA)(text, 5, 4)
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                    text: text
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_8__/* .MobileView */ .$, {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "copy-row",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                        className: "link_text",
                                        href: `/address/${text}`,
                                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .isIndent */ .EA)(text, 5, 4)
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                        text: text,
                                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_icon_copy_svg__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
                                        className: "copy"
                                    })
                                ]
                            })
                        })
                    ]
                });
            }
        },
        {
            title: "contract_name",
            dataIndex: "contract_name",
            width: "20%"
        },
        {
            title: "transaction_count",
            dataIndex: "transfer_count",
            width: "15%",
            sorter: true,
            align: "left",
            defaultSortOrder: "descend",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatNumber */ .uf)(text)
        },
        {
            title: "user_count",
            dataIndex: "user_count",
            width: "15%",
            sorter: true,
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatNumber */ .uf)(text)
        },
        {
            title: "actor_balance",
            dataIndex: "actor_balance",
            width: "15%",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatFilNum */ .Nm)(text),
            sorter: true
        },
        {
            title: "gas_cost",
            dataIndex: "gas_cost",
            width: "15%",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatFilNum */ .Nm)(text),
            sorter: true
        }
    ],
    mobileColumns: [
        {
            title: "rank",
            dataIndex: "rank",
            width: "10%",
            render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "rank_icon",
                    children: text
                })
        },
        {
            title: "contract_address",
            dataIndex: "contract_address",
            width: "30%",
            render: (text, record)=>{
                if (!text) return "--";
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "flex gap-x-2 items-center copy-row",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                        className: "link_text",
                        href: `/address/${text}`,
                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .isIndent */ .EA)(text, 5, 4)
                    })
                });
            }
        },
        {
            title: "contract_name",
            dataIndex: "contract_name",
            width: "20%"
        },
        {
            title: "transaction_count",
            dataIndex: "transfer_count",
            width: "15%",
            align: "right",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatNumber */ .uf)(text)
        }
    ]
};
const homeContractRank = {
    rank: "10%",
    contract_address: "15%",
    contract_name: "20%",
    transfer_count: "15%",
    user_count: "15%"
};
const mobileHomeContractRank = [
    "rank",
    "contract_address",
    "contract_name",
    "transfer_count"
];
const contract_list = {
    columns: [
        // {
        //   dataIndex: 'rank',
        //   title: 'rank',
        //   width:'10%',
        //   render: (text: any, record: any) => {
        //     return <span className='rank_icon'>{ text}</span>
        //   } },
        {
            dataIndex: "contract_address",
            title: "contract_address",
            width: "20%",
            render: (text, record)=>{
                if (!text) return "--";
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                    className: "link",
                    href: `/address/${text}`,
                    children: text
                });
            }
        },
        {
            dataIndex: "contract_name",
            width: "10%",
            title: "contract_name",
            render: (text, record)=>{
                if (!text) return "--";
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                    href: `/address/${record.contract_address}`,
                    children: text
                });
            }
        },
        {
            dataIndex: "language",
            title: "language",
            width: "10%"
        },
        {
            dataIndex: "compiler",
            title: "compile_version",
            width: "15%"
        },
        {
            dataIndex: "optimize_runs",
            title: "Optimizations",
            width: "15%"
        },
        {
            dataIndex: "license",
            title: "license",
            render: (text)=>text || "No License(None)",
            width: "20%"
        }
    ]
};
const contract_token = {
    columns: (tr)=>{
        return [
            {
                dataIndex: "rank",
                title: "rank",
                width: "10%",
                render: (text, record, index)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "rank_icon",
                        children: index + 1
                    });
                }
            },
            {
                dataIndex: "token_name",
                title: "token_name",
                render: (text, record)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                            href: `/token/${record.contract_id}`,
                            className: "flex items-center gap-x-1",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_image__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                    src: record?.icon_url,
                                    alt: "",
                                    height: 32,
                                    width: 32
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "margin-6 text_color",
                                    children: text
                                })
                            ]
                        })
                    });
                }
            },
            {
                dataIndex: "total_supply",
                title: ()=>{
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_8__/* .BrowserView */ .I, {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    className: "flex items-center gap-x-2",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            children: [
                                                " ",
                                                tr("total_supply")
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tooltip__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            context: tr("total_supply_tip")
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_8__/* .MobileView */ .$, {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    className: "flex items-center gap-x-2",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            style: {
                                                width: "min-content",
                                                wordBreak: "initial"
                                            },
                                            children: [
                                                " ",
                                                tr("total_supply")
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tooltip__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                            context: tr("total_supply_tip")
                                        })
                                    ]
                                })
                            })
                        ]
                    });
                },
                render: (text)=>{
                    return text ? (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatNumber */ .uf)(text, 4) : text;
                }
            },
            {
                dataIndex: "vol_24",
                title: "vol_24",
                render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .get$Number */ .Uy)(text)
            },
            {
                dataIndex: "latest_price",
                title: "latest_price",
                render: (text)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .get$Number */ .Uy)(text) : text
            },
            {
                dataIndex: "market_cap",
                title: "market_value",
                render: (text)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .get$Number */ .Uy)(text) : "--"
            },
            {
                dataIndex: "owners",
                title: "owners"
            }
        ];
    }
};
const token_details = {
    headerList: [
        {
            title: "overview",
            list: [
                {
                    title: "total_supply",
                    dataIndex: "total_supply",
                    render: (text)=>{
                        return text ? (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatNumber */ .uf)(text, 4) : text || "--";
                    }
                },
                {
                    title: "owners",
                    dataIndex: "owners"
                },
                {
                    title: "transfers",
                    dataIndex: "transfers"
                }
            ]
        },
        {
            title: "market",
            list: [
                {
                    title: "latest_price",
                    dataIndex: "latest_price",
                    render: (text)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .get$Number */ .Uy)(text) : text || "--"
                },
                {
                    title: "market_value",
                    dataIndex: "market_cap",
                    render: (text)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .get$Number */ .Uy)(text) : text || "--"
                },
                {
                    title: "token_contract",
                    dataIndex: "contract_id",
                    render: (text, record)=>{
                        if (!text) {
                            return "--";
                        }
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "flex items-center gap-x-2",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                    href: `/address/${text}`,
                                    className: "link",
                                    children: text
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                    text: text
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_TPWallet__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                    data: record
                                })
                            ]
                        });
                    }
                }
            ]
        }
    ],
    tabList: [
        {
            title: "transfer",
            dataIndex: "transfer",
            total: "transfer_total"
        },
        {
            title: "owner",
            dataIndex: "owner",
            total: "owner_total"
        },
        {
            title: "dex",
            dataIndex: "dex",
            total: "dex_total"
        }
    ]
};
const token_transfer_columns = (fromList, toList)=>{
    return [
        {
            dataIndex: "cid",
            title: "message_cid",
            width: "10%",
            render: (text)=>text ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                    href: `/message/${text}`,
                    className: "link",
                    children: text ? (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .isIndent */ .EA)(text, 6) : ""
                }) : "--"
        },
        {
            dataIndex: "method",
            title: "method",
            width: "25%",
            render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .titleCase */ .Qs)(text)
                })
        },
        {
            dataIndex: "time",
            title: "time",
            width: "20%",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(text, "YYYY-MM-DD HH:mm")
        },
        {
            dataIndex: "from",
            title: "from",
            width: "15%",
            render: (text, record)=>{
                if (!text) return "--";
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "flex items-center gap-x-1",
                    children: [
                        (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .get_account_type */ .$B)(text),
                        fromList?.domains && fromList?.domains[text] && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                            href: `/domain/${fromList.domains[text]}?provider=${fromList.provider}`,
                            children: [
                                "(",
                                fromList.domains[text],
                                ")"
                            ]
                        })
                    ]
                });
            }
        },
        {
            dataIndex: "to",
            title: "to",
            width: "15%",
            render: (text, record)=>{
                if (!text) return "--";
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "flex items-center gap-x-1",
                    children: [
                        (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .get_account_type */ .$B)(text),
                        toList?.domains && toList?.domains[text] && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                            href: `/domain/${toList.domains[text]}?provider=${toList.provider}`,
                            children: [
                                "(",
                                toList.domains[text],
                                ")"
                            ]
                        })
                    ]
                });
            }
        },
        {
            dataIndex: "amount",
            title: "amount",
            width: "10%",
            render: (text, record)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatNumber */ .uf)(text, 4) : text || "--"
        }
    ];
};
const token_owner_columns = (ownerList)=>{
    return [
        {
            dataIndex: "rank",
            title: "rank",
            width: "10%",
            render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "rank_icon",
                    children: text
                })
        },
        {
            dataIndex: "owner",
            title: "owner",
            width: "40%",
            render: (text, record)=>{
                if (!text) return "--";
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "flex link_text items-center gap-x-1",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                            href: `/address/${text}`,
                            children: [
                                " ",
                                text,
                                "  "
                            ]
                        }),
                        text && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                            text: text
                        }),
                        ownerList?.domains && ownerList?.domains[text] && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                            href: `/domain/${ownerList.domains[text]}?provider=${ownerList.provider}`,
                            children: [
                                "(",
                                ownerList.domains[text],
                                ")"
                            ]
                        })
                    ]
                });
            }
        },
        {
            dataIndex: "amount",
            title: "amount",
            width: "20%",
            render: (text, record)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatNumber */ .uf)(text, 4) : text || "--"
        },
        {
            dataIndex: "rate",
            title: "percentage",
            width: "15%",
            render: (text, record)=>text ? Number(text).toFixed(4) + "%" : text || "--"
        },
        {
            dataIndex: "value",
            title: "Value",
            width: "15%",
            render: (text)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .get$Number */ .Uy)(text) : ""
        }
    ];
};
const token_Dex_columns = [
    {
        dataIndex: "cid",
        title: "message_cid",
        render: (text)=>{
            if (!text) return "--";
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                href: `/message/${text}`,
                className: "link_text",
                children: (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .isIndent */ .EA)(text)
            });
        }
    },
    {
        dataIndex: "time",
        title: "time",
        render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(text, "YYYY-MM-DD HH:mm")
    },
    {
        dataIndex: "action",
        title: "Action",
        render: (text)=>{
            const color = text === "buy" ? "green" : text === "sell" ? "red" : "";
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                style: {
                    color
                },
                children: text ? text[0].toUpperCase() + text.substr(1) : text
            });
        }
    },
    {
        dataIndex: "amount_out",
        title: "Token_Amount_out",
        render: (text, record)=>{
            return (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatNumber */ .uf)(text, 4) + " " + record?.amount_out_token_name;
        }
    },
    {
        dataIndex: "amount_in",
        title: "Token_Amount_in",
        render: (text, record)=>{
            return (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatNumber */ .uf)(text, 4) + " " + record?.amount_in_token_name;
        }
    },
    {
        dataIndex: "swap_rate",
        title: "swapped_Rate",
        render: (text, record)=>text ? text + " " + record.swap_token_name : ""
    },
    {
        dataIndex: "value",
        title: "Txn_Value",
        render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .get$Number */ .Uy)(text)
    },
    {
        dataIndex: "dex",
        title: "platform",
        render: (text, record)=>{
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "link",
                onClick: ()=>{
                    if (record.dex_url) {
                        window.open(record.dex_url);
                    }
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_image__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    className: "fvm_img_url",
                    src: record.icon_url,
                    alt: "",
                    width: 25,
                    height: 25
                })
            });
        }
    }
];
const contract_nfts = {
    columns: [
        {
            dataIndex: "rank",
            title: "rank",
            render: (text, record, index)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "rank_icon",
                    children: index + 1
                });
            }
        },
        {
            dataIndex: "collection",
            title: "Collection",
            render: (text, record)=>{
                if (!text) return "--";
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                    href: `/nft/${record.provider}`,
                    className: "flex items-center gap-x-2",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_image__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                            className: "fvm_img_url",
                            src: record.icon,
                            alt: "",
                            height: 36,
                            width: 36
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "text_color",
                            children: [
                                " ",
                                text
                            ]
                        })
                    ]
                });
            }
        },
        // { dataIndex: 'trading_volume', title: 'Volume' },
        {
            dataIndex: "holders",
            title: "owner"
        },
        {
            dataIndex: "transfers",
            title: "transfer",
            render: (text)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatNumber */ .uf)(text, 4) : "--"
        }
    ]
};
const nft_details = {
    headerList: [
        {
            title: "overview",
            list: [
                {
                    title: "total_supply",
                    dataIndex: "total_supply",
                    render: (text)=>{
                        return text ? (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatNumber */ .uf)(text, 4) : text || "--";
                    }
                },
                {
                    title: "owners",
                    dataIndex: "owners"
                },
                {
                    title: "transfers",
                    dataIndex: "transfers"
                }
            ]
        },
        {
            title: "market",
            list: [
                {
                    title: "token_contract",
                    dataIndex: "contract",
                    render: (text)=>{
                        if (text) {
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_8__/* .BrowserView */ .I, {
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            className: "flex gap-x-1 ",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                    href: `/address/${text}`,
                                                    className: "link",
                                                    children: text
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                    text: text
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_8__/* .MobileView */ .$, {
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            className: "copy-row",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                                    href: `/address/${text}`,
                                                    className: "link",
                                                    children: text
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                                    text: text,
                                                    icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_icon_copy_svg__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}),
                                                    className: "copy"
                                                })
                                            ]
                                        })
                                    })
                                ]
                            });
                        }
                        return "--";
                    }
                }
            ]
        }
    ],
    tabList: [
        {
            title: "transfer",
            dataIndex: "transfer",
            total: "transfer_total"
        },
        {
            title: "owner",
            dataIndex: "owner",
            total: "owner_total"
        }
    ]
};
const nft_transfer_columns = (fromList, toList)=>{
    return [
        {
            dataIndex: "cid",
            title: "message_cid",
            render: (text)=>text ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                    href: `/message/${text}`,
                    className: "link",
                    children: text ? (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .isIndent */ .EA)(text, 6) : ""
                }) : "--"
        },
        {
            dataIndex: "method",
            title: "method",
            render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "bg-render",
                    children: (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .titleCase */ .Qs)(text)
                })
        },
        {
            dataIndex: "time",
            title: "time",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(text, "YYYY-MM-DD HH:mm")
        },
        {
            dataIndex: "from",
            title: "from",
            render: (text, record)=>{
                if (!text) return "--";
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "flex items-center gap-x-1",
                    children: [
                        (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .get_account_type */ .$B)(text),
                        fromList?.domains && fromList?.domains[text] && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                            href: `/domain/${fromList.domains[text]}?provider=${fromList.provider}`,
                            children: [
                                "(",
                                fromList.domains[text],
                                ")"
                            ]
                        })
                    ]
                });
            }
        },
        {
            dataIndex: "to",
            title: "to",
            render: (text, record)=>{
                if (!text) return "--";
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex items-center gap-x-1",
                    children: [
                        (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .get_account_type */ .$B)(text),
                        toList?.domains && toList?.domains[text] && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                            href: `/domain/${toList.domains[text]}?provider=${toList.provider}`,
                            children: [
                                "(",
                                toList.domains[text],
                                ")"
                            ]
                        })
                    ]
                });
            }
        },
        {
            dataIndex: "item",
            title: "item",
            render: (text, record)=>{
                if (record.url) {
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_image__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        className: "fvm_img_url",
                        alt: "",
                        width: 25,
                        height: 25,
                        src: record.url
                    });
                }
                return text || "--";
            }
        }
    ];
};
const nft_owner_columns = (ownerList)=>{
    return [
        {
            dataIndex: "rank",
            title: "rank",
            width: "10%",
            render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "rank_icon",
                    children: text
                })
        },
        {
            dataIndex: "owner",
            title: "owner",
            width: "50%",
            render: (text, record)=>{
                if (!text) return "--";
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "flex gap-x-1 items-center",
                    children: [
                        text,
                        ownerList?.domains && ownerList?.domains[text] && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                            href: `/domain/${ownerList.domains[text]}?provider=${ownerList.provider}`,
                            children: [
                                "(",
                                ownerList.domains[text],
                                ")"
                            ]
                        })
                    ]
                });
            }
        },
        {
            dataIndex: "amount",
            title: "amount",
            width: "20%",
            render: (text, record)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatNumber */ .uf)(text, 4) : text || "--"
        },
        {
            dataIndex: "percentage",
            width: "20%",
            title: "percentage",
            render: (text, record)=>text ? Number(Number(text) * 100).toFixed(4) + "%" : text || "--"
        }
    ];
};
//合约详情
//已验证合约 读写合约
const verify_tabs = [
    {
        title: "Verify_code",
        dataIndex: "Verify_code"
    },
    {
        title: "Verify_read",
        dataIndex: "Verify_read"
    },
    {
        title: "Verify_write",
        dataIndex: "Verify_write"
    }
];
const contract_detail = {
    list: [
        {
            dataIndex: "contract_name",
            title: "contract_name"
        },
        {
            dataIndex: "optimize",
            title: "optimize",
            render: (text, record)=>{
                return text ? (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .titleCase */ .Qs)(text) + ` with (${record.optimize_runs}) runs` : (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .titleCase */ .Qs)(text);
            }
        },
        {
            dataIndex: "compiler",
            title: "compiler"
        },
        {
            dataIndex: "license",
            title: "license"
        }
    ],
    abiOptions: {
        placeholder: "source_abi_default",
        list: [
            {
                label: "Json_Format",
                value: "json"
            },
            {
                label: "Text_Format",
                value: "text"
            }
        ]
    }
};
const contract_log = [
    {
        dataIndex: "epoch",
        title: "epoch"
    },
    {
        dataIndex: "cid",
        title: "cid",
        render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                href: `/message/${text}`,
                className: "link",
                children: text
            })
    },
    {
        dataIndex: "event_name",
        title: "event_name"
    },
    {
        dataIndex: "topics",
        title: "topics",
        render: (text, record)=>{
            if (Array.isArray(text)) {
                return text.map((item, index)=>{
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                        className: "flex items-center gap-x-1 mb-1",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "flex item-center flex-shrink-0 justify-center bg-bg_hover border rounded-[5px] w-5 h-5",
                                children: index
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                children: [
                                    " ",
                                    item
                                ]
                            })
                        ]
                    }, item);
                });
            }
            return text || "--";
        }
    },
    {
        dataIndex: "data",
        title: "coompoent_data",
        render: (text)=>{
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "bg-bg_hover px-2.5 py-2 rounded-md",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "code",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("pre", {
                        className: "pre",
                        style: {
                            whiteSpace: "pre-wrap",
                            overflowWrap: "break-word"
                        },
                        children: JSON.stringify(text, undefined, 6)
                    })
                })
            });
        }
    },
    {
        dataIndex: "log_index",
        title: "log_index",
        render: (text)=>text
    },
    {
        dataIndex: "removed",
        title: "removed",
        render: (text)=>String(text)
    }
];

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 92964:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(25675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8054);
/** @format */ 



const ImageWithFallback = (props)=>{
    const { src, fallbackSrc = _contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__/* .fvmUrl */ .dE + `/images/default.png`, ...rest } = props;
    const [imgSrc, setImgSrc] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(src || fallbackSrc);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const showSrc = src || fallbackSrc;
        setImgSrc(showSrc);
    }, [
        src
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
        alt: "",
        ...rest,
        className: "rounded-full cursor-pointer",
        src: imgSrc,
        onError: ()=>{
            setImgSrc(fallbackSrc);
        }
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ImageWithFallback);


/***/ }),

/***/ 72305:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7947);
/* harmony import */ var antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(69348);
/* harmony import */ var antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_2__);
/** @format */ 


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { context, icon = true } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_2___default()), {
        overlayClassName: "custom-tooltip-wrap",
        title: context,
        children: [
            icon ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "cursor-pointer",
                children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)("tip")
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: props.children
            })
        ]
    });
});


/***/ })

};
;