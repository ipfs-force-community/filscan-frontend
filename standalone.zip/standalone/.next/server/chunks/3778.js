"use strict";
exports.id = 3778;
exports.ids = [3778];
exports.modules = {

/***/ 3778:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var echarts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9201);
/* harmony import */ var echarts__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(echarts__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/** @format */ 


const EChartsComponent = ({ options = {} })=>{
    const chartRef = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (chartRef.current) {
            const chart = echarts__WEBPACK_IMPORTED_MODULE_1__.init(chartRef.current);
            const default_options = {
                backgroundColor: "transparent",
                grid: {
                    top: 10,
                    left: 20,
                    right: 20,
                    bottom: 20,
                    containLabel: true
                }
            };
            if (options && options.series) {
                chart?.setOption({
                    ...default_options,
                    ...options
                });
            }
            const handleSize = ()=>{
                chart.resize();
            };
            window.addEventListener("resize", handleSize);
            return ()=>{
                chart.dispose();
                window.removeEventListener("resize", handleSize);
            };
        }
    }, [
        options
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        ref: chartRef,
        style: {
            width: "100%",
            height: "100%"
        }
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EChartsComponent);


/***/ })

};
;