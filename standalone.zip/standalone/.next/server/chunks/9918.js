exports.id = 9918;
exports.ids = [9918];
exports.modules = {

/***/ 3307:
/***/ ((module) => {

// Exports
module.exports = {
	"pow": "style_pow__priRY",
	"row": "style_row__xR72_",
	"between": "style_between__xtflk",
	"row-item": "style_row-item__Y_0dv",
	"label": "style_label__sazaj",
	"value": "style_value__9wPMI",
	"column": "style_column__wTo6_",
	"full": "style_full__tyQl2",
	"status": "style_status__sNmEJ",
	"status-row": "style_status-row__bX8Aq",
	"sector-status-value": "style_sector-status-value__F2njQ",
	"sector-status-title": "style_sector-status-title__xvg4O"
};


/***/ }),

/***/ 5313:
/***/ ((module) => {

// Exports
module.exports = {
	"account-balance": "accountBalance_account-balance__HYsDK",
	"title-label": "accountBalance_title-label__ofIba",
	"title-value": "accountBalance_title-value__KeWMJ",
	"chart": "accountBalance_chart__Abw7U",
	"title": "accountBalance_title__321j4",
	"legend-title": "accountBalance_legend-title__heUVo",
	"info": "accountBalance_info__giSGO"
};


/***/ }),

/***/ 8840:
/***/ ((module) => {

// Exports
module.exports = {
	"list": "style_list__zjQ6B",
	"overview": "style_overview__OXS1O",
	"title": "style_title__mhTgE",
	"list-row": "style_list-row__Oij9A",
	"label": "style_label__t7zqQ"
};


/***/ }),

/***/ 496:
/***/ ((module) => {

// Exports
module.exports = {
	"title": "style_title___RUO4",
	"chart": "style_chart__phVfp",
	"power-change": "style_power-change___TDI_",
	"between": "style_between__TVvmP"
};


/***/ }),

/***/ 4362:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2881);
/* harmony import */ var _contents_detail__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8817);
/* harmony import */ var _packages_skeleton__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8465);
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8804);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3495);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9676);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3307);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_style_module_scss__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_detail__WEBPACK_IMPORTED_MODULE_2__, _utils__WEBPACK_IMPORTED_MODULE_5__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_detail__WEBPACK_IMPORTED_MODULE_2__, _utils__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 









/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ data })=>{
    const { theme, lang } = (0,_store_FilscanStore__WEBPACK_IMPORTED_MODULE_4__/* .useFilscanStore */ .J)();
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "detail"
    });
    const loading = (0,react__WEBPACK_IMPORTED_MODULE_6__.useMemo)(()=>{
        if (data.hasOwnProperty("quality_power_percentage")) {
            return false;
        }
        return true;
    }, [
        data
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()((_style_module_scss__WEBPACK_IMPORTED_MODULE_9___default().pow), "w-1/2 h-[280px]  border-l border_color p-5"),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex justify-between border-b border_color pb-7",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                    className: classnames__WEBPACK_IMPORTED_MODULE_8___default()((_style_module_scss__WEBPACK_IMPORTED_MODULE_9___default().row), (_style_module_scss__WEBPACK_IMPORTED_MODULE_9___default().between), "flex flex-1"),
                    children: _contents_detail__WEBPACK_IMPORTED_MODULE_2__/* .power_list */ .lU.header.map((headerItem)=>{
                        const { render, dataIndex, title } = headerItem;
                        const showData = (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .getShowData */ .IC)(headerItem, data);
                        const value = render ? render(showData[dataIndex]) : showData[dataIndex] || "--";
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                            className: classnames__WEBPACK_IMPORTED_MODULE_8___default()((_style_module_scss__WEBPACK_IMPORTED_MODULE_9___default()["row-item"]), "flex flex-col w-1/2"),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: classnames__WEBPACK_IMPORTED_MODULE_8___default()("text-sm text_des", (_style_module_scss__WEBPACK_IMPORTED_MODULE_9___default().label)),
                                    children: tr(title)
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_7__/* .BrowserView */ .I, {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text_clip font-DINPro-Bold text-xl",
                                                children: loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_skeleton__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}) : value
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_7__/* .MobileView */ .$, {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_9___default().value),
                                                children: loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_skeleton__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}) : value
                                            })
                                        })
                                    ]
                                })
                            ]
                        }, dataIndex);
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                className: classnames__WEBPACK_IMPORTED_MODULE_8___default()((_style_module_scss__WEBPACK_IMPORTED_MODULE_9___default().column), "mt-5 flex  flex-col flex-wrap gap-y-6 justify-between max-h-[120px]"),
                children: _contents_detail__WEBPACK_IMPORTED_MODULE_2__/* .power_list */ .lU.list.map((item)=>{
                    const { render, dataIndex, title } = item;
                    const showData = (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .getShowData */ .IC)(item, data);
                    const value = render ? render(showData[dataIndex]) : showData[dataIndex] || "--";
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()((_style_module_scss__WEBPACK_IMPORTED_MODULE_9___default().full), "w-1/2 flex flex-0"),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: classnames__WEBPACK_IMPORTED_MODULE_8___default()("text-sm text_des w-28", (_style_module_scss__WEBPACK_IMPORTED_MODULE_9___default().label)),
                                children: tr(title)
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "font-DINPro-Medium text-sm font-medium",
                                children: loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_skeleton__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}) : value
                            })
                        ]
                    }, dataIndex);
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_8___default()((_style_module_scss__WEBPACK_IMPORTED_MODULE_9___default().status), "flex w-full items-center mt-6"),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-sm text_des w-28",
                        children: tr("sector_status")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "font-DINPro-Medium text-sm font-medium",
                        children: loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_skeleton__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                            className: classnames__WEBPACK_IMPORTED_MODULE_8___default()((_style_module_scss__WEBPACK_IMPORTED_MODULE_9___default()["status-row"]), "flex flex-1 gap-x-4"),
                            children: _contents_detail__WEBPACK_IMPORTED_MODULE_2__/* .power_list */ .lU.sector_status.renderList.map((sector_item)=>{
                                const { dataIndex, title, color } = sector_item;
                                const showData = (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .getShowData */ .IC)(sector_item, data);
                                const value = showData[dataIndex];
                                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                    className: "flex items-center gap-x-1",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: classnames__WEBPACK_IMPORTED_MODULE_8___default()("font-DINPro-Medium text-sm font-medium", (_style_module_scss__WEBPACK_IMPORTED_MODULE_9___default()["sector-status-value"])),
                                            style: {
                                                color: color
                                            },
                                            children: (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatNumber */ .uf)(value)
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: classnames__WEBPACK_IMPORTED_MODULE_8___default()("text-sm text_des", (_style_module_scss__WEBPACK_IMPORTED_MODULE_9___default()["sector-status-title"])),
                                            children: tr(title)
                                        })
                                    ]
                                }, dataIndex);
                            })
                        })
                    })
                ]
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9866:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9676);
/* harmony import */ var _components_echarts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3778);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2881);
/* harmony import */ var _contents_detail__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8817);
/* harmony import */ var _packages_skeleton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8465);
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8804);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3495);
/* harmony import */ var _utils_echarts__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7355);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5313);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7947);
/* harmony import */ var _packages_tooltip__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2305);
/* harmony import */ var _components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1061);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_13__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_detail__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_7__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_detail__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 














/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ data, loading })=>{
    const { theme, lang } = (0,_store_FilscanStore__WEBPACK_IMPORTED_MODULE_6__/* .useFilscanStore */ .J)();
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__/* .Translation */ .W)({
        ns: "detail"
    });
    const { isMobile } = (0,_components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)();
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)({});
    const [noShow, setNoShow] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)({});
    const color = (0,react__WEBPACK_IMPORTED_MODULE_9__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_8__/* .getColor */ .Lq)(theme);
    }, [
        theme
    ]);
    const defaultOptions = (0,react__WEBPACK_IMPORTED_MODULE_9__.useMemo)(()=>{
        return {
            grid: {
                width: "100%",
                height: "100%",
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                containLabel: true
            },
            tooltip: {
                trigger: "item",
                backgroundColor: color.toolbox,
                borderColor: "transparent",
                textStyle: {
                    color: "#ffffff"
                },
                formatter (v) {
                    const { name, value } = v;
                    return `${v.marker} ${tr(name)}: ${(0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatFilNum */ .Nm)(value)}`;
                },
                position: "right"
            },
            legend: {
                show: false
            },
            series: [
                {
                    type: "pie",
                    radius: [
                        "40%",
                        "68%"
                    ],
                    //  radius: ['40%', '48%'],
                    avoidLabelOverlap: false,
                    label: {
                        show: false,
                        fontSize: 16,
                        rich: {
                            dark: {
                                color: "#000"
                            },
                            color: {
                                color: "#309cfe"
                            }
                        }
                    },
                    data: [],
                    center: [
                        "55%",
                        "48%"
                    ]
                }
            ]
        };
    }, [
        theme
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_9__.useEffect)(()=>{
        const seriesData = [];
        const legendData = [];
        _contents_detail__WEBPACK_IMPORTED_MODULE_4__/* .account_balance */ .j_.list.forEach((item)=>{
            const showData = (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .getShowData */ .IC)(item, data);
            const value = showData && showData[item.dataIndex] || "--";
            if (value !== "--") {
                const [showValue, showUnit] = value.split(" ");
                legendData.push({
                    showValue: showValue,
                    unit: showUnit,
                    value
                });
            } else {
                legendData.push({
                    unit: "autoFil",
                    value
                });
            }
            seriesData.push({
                value,
                dataIndex: item.dataIndex,
                name: item.dataIndex,
                itemStyle: {
                    color: item.color
                }
            });
        });
        setOptions({
            series: seriesData,
            legendData: legendData
        });
    }, [
        data
    ]);
    const newOptions = (0,react__WEBPACK_IMPORTED_MODULE_9__.useMemo)(()=>{
        const newOpt = {
            ...defaultOptions
        };
        const newSeries = [];
        (options?.series || []).forEach((v)=>{
            if (!noShow[v.dataIndex]) {
                newSeries.push(v);
            }
        });
        if (isMobile) {
            newOpt.series[0].radius = [
                "45%",
                "80%"
            ];
            newOpt.series[0].center = [
                "50%",
                "50%"
            ];
            newOpt.tooltip.position = [
                "50%",
                "50%"
            ];
            newOpt.tooltip.formatter = (v)=>{
                const { name, value } = v;
                return `${v.marker} ${tr(name)}:\n <div>${(0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatFilNum */ .Nm)(value)}</div>`;
            };
        }
        newOpt.series[0].data = newSeries;
        return newOpt;
    }, [
        options,
        defaultOptions,
        noShow
    ]);
    const renderTotal = ()=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex flex-col gap-x-1",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: classnames__WEBPACK_IMPORTED_MODULE_13___default()("flex items-center gap-x-2 text-sm text_des", (_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default()["title-label"])),
                    children: [
                        tr(_contents_detail__WEBPACK_IMPORTED_MODULE_4__/* .account_balance */ .j_.title),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tooltip__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                            context: tr("total_balance_tip")
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: classnames__WEBPACK_IMPORTED_MODULE_13___default()("font-DINPro-Bold text-xl text_clip", (_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default()["title-value"])),
                    children: loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_skeleton__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}) : data?.balance ? (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatFilNum */ .Nm)(data?.balance, false, false, 4) : "--"
                })
            ]
        });
    };
    const renderBalance = ()=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
            className: "mt-12 flex flex-wrap gap-y-6 justify-between account-balance",
            children: _contents_detail__WEBPACK_IMPORTED_MODULE_4__/* .account_balance */ .j_.list.map((balance_item)=>{
                const value = data[balance_item.dataIndex];
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                    className: "w-full flex items-center flex-0 account-balance-item",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "text-sm text_des flex gap-x-1 items-center cursor-pointer min-w-[100px]",
                            onClick: ()=>{
                                setNoShow({
                                    ...noShow,
                                    [balance_item.dataIndex]: !noShow[balance_item.dataIndex]
                                });
                            },
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "flex w-[5px] h-[5px] rounded-full",
                                    style: {
                                        backgroundColor: noShow[balance_item.dataIndex] ? "#d1d5db" : balance_item.color
                                    }
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tooltip__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                    context: tr(balance_item.title_tip),
                                    icon: false,
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: classnames__WEBPACK_IMPORTED_MODULE_13___default()("flex gap-x-1 items-center", (_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default()["legend-title"])),
                                        children: [
                                            tr(balance_item.title),
                                            (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_10__/* .getSvgIcon */ .a)("tip")
                                        ]
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "font-DINPro-Medium text-sm font-medium  ml-5",
                            children: loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_skeleton__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}) : value ? (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatFilNum */ .Nm)(value, false, false, 4) : "--"
                        })
                    ]
                }, balance_item.dataIndex);
            })
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_1__/* .BrowserView */ .I, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex h-[280px] w-1/2 p-5",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex-1",
                            children: [
                                renderTotal(),
                                renderBalance()
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "h-[280px] flex-1 ",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                options: newOptions
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_1__/* .MobileView */ .$, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default()["account-balance"]),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default().title),
                            children: renderTotal()
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default().chart),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                options: newOptions
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_14___default().info),
                            children: renderBalance()
                        })
                    ]
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7986:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2881);
/* harmony import */ var _packages_segmented__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5622);
/* harmony import */ var _packages_skeleton__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8465);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3495);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8840);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_style_module_scss__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _packages_tooltip__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2305);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7947);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8108);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _packages_segmented__WEBPACK_IMPORTED_MODULE_3__, _utils__WEBPACK_IMPORTED_MODULE_5__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _packages_segmented__WEBPACK_IMPORTED_MODULE_3__, _utils__WEBPACK_IMPORTED_MODULE_5__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 











//统计指标
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ overView, accountId })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__/* .Translation */ .W)({
        ns: "detail"
    });
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
    const [interval, setInterval] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)("24h");
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)({});
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false);
    //   useColumnAlign('.overView', '.overView_item', 'last_item');
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        if (accountId) {
            load();
        }
    }, [
        accountId
    ]);
    const load = async (inter)=>{
        setLoading(true);
        const show_inter = inter || interval;
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.detail_Indicators, {
            account_id: accountId,
            filters: {
                interval: show_inter
            }
        });
        setLoading(false);
        setData(result?.miner_indicators || {});
    };
    const handleTabChange = (value)=>{
        setInterval(value);
        load(value);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_7___default()((_style_module_scss__WEBPACK_IMPORTED_MODULE_11___default().overview), "w-full"),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_7___default()("w-full flex items-center mt-7 mb-5 ml-2.5", (_style_module_scss__WEBPACK_IMPORTED_MODULE_11___default().title)),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text-lg font-semibold mr-5",
                        children: tr(overView.title)
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_segmented__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        data: overView.tabList,
                        ns: "detail",
                        defaultValue: interval,
                        isHash: false,
                        onChange: handleTabChange
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                className: classnames__WEBPACK_IMPORTED_MODULE_7___default()((_style_module_scss__WEBPACK_IMPORTED_MODULE_11___default().list), "card_shadow p-5 h-[150px] py-7 px-5 grid rounded-xl border border_color gap-y-6"),
                children: overView?.list.map((item)=>{
                    const { render, dataIndex, style = {}, width, title, title_tip } = item;
                    const showData = (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .getShowData */ .IC)(item, data);
                    const value = render ? render(showData[dataIndex]) : showData[dataIndex] || "--";
                    //style={{ ...style }}
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                        className: classnames__WEBPACK_IMPORTED_MODULE_7___default()((_style_module_scss__WEBPACK_IMPORTED_MODULE_11___default()["list-row"]), "flex"),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: classnames__WEBPACK_IMPORTED_MODULE_7___default()("text-sm text_des min-w-20 flex flex-wrap", (_style_module_scss__WEBPACK_IMPORTED_MODULE_11___default().label)),
                                children: title_tip ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tooltip__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                    context: tr(title_tip),
                                    icon: false,
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "flex items-center gap-x-1 cursor-pointer",
                                        children: [
                                            tr(title),
                                            " ",
                                            (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_9__/* .getSvgIcon */ .a)("tip"),
                                            ":"
                                        ]
                                    })
                                }) : `${tr(title)}`
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "font-DINPro-Medium text-sm font-medium ml-1",
                                children: loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_skeleton__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {}) : value
                            })
                        ]
                    }, dataIndex);
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7916:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _components_echarts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3778);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2881);
/* harmony import */ var _contents_detail__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8817);
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8804);
/* harmony import */ var _store_server__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(785);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7947);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3495);
/* harmony import */ var _utils_echarts__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7355);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9676);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(496);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_style_module_scss__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1061);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_detail__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_7__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_detail__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 














/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ accountId, type })=>{
    const { theme, lang } = (0,_store_FilscanStore__WEBPACK_IMPORTED_MODULE_5__/* .useFilscanStore */ .J)();
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__/* .Translation */ .W)({
        ns: "detail"
    });
    const [interval, setInterval] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)("1m");
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)({});
    const [noShow, setNoShow] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)({});
    const [unit, setUnit] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)("TiB");
    const { isMobile } = (0,_components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)();
    const color = (0,react__WEBPACK_IMPORTED_MODULE_9__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_8__/* .getColor */ .Lq)(theme);
    }, [
        theme
    ]);
    const default_xAxis = (0,react__WEBPACK_IMPORTED_MODULE_9__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_8__/* .get_xAxis */ .Fs)(theme, isMobile);
    }, [
        theme,
        isMobile
    ]);
    const defaultOptions = (0,react__WEBPACK_IMPORTED_MODULE_9__.useMemo)(()=>{
        return {
            grid: {
                top: 10,
                left: 20,
                right: "8%",
                bottom: 10,
                containLabel: true
            },
            yAxis: [
                {
                    type: "value",
                    position: "left",
                    scale: true,
                    nameTextStyle: {
                        color: color.textStyle
                    },
                    axisLabel: {
                        formatter: `{value} ${unit}`,
                        textStyle: {
                            //  fontSize: this.fontSize,
                            color: isMobile ? color.mobileLabelColor : color.labelColor
                        }
                    },
                    axisTick: {
                        show: false
                    },
                    axisLine: {
                        show: false
                    },
                    splitLine: {
                        lineStyle: {
                            type: "dashed",
                            color: color.splitLine
                        }
                    }
                }
            ],
            tooltip: {
                trigger: "axis",
                position: "right",
                backgroundColor: color.toolbox,
                borderColor: "transparent",
                textStyle: {
                    color: "#ffffff"
                },
                formatter (p) {
                    let result = p[0].data.showTime;
                    p.forEach((item, index)=>{
                        if (item.data) {
                            result += "<br/>" + item.marker + tr(item.seriesName) + ": " + item.data.amount + " " + item.data.unit;
                        }
                    });
                    return result;
                }
            }
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        theme,
        unit,
        isMobile
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_9__.useEffect)(()=>{
        if (accountId) {
            load();
        }
    }, [
        accountId
    ]);
    const load = async (inter)=>{
        const showInter = inter || interval;
        const seriesObj = {
            power: [],
            power_increase: []
        };
        const timeData = [];
        const legendData = [];
        const seriesData = [];
        const result = await (0,_store_server__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.account_trend, {
            account_id: accountId,
            filters: {
                interval: showInter,
                account_type: type
            }
        });
        let maxValue = 0;
        let unitNum = -1;
        (result?.power_trend_by_account_id_list || []).forEach((v)=>{
            const { block_time, power, power_increase } = v;
            maxValue = Number(power) > maxValue ? Number(power) : maxValue;
        });
        if (maxValue) {
            const unit = (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .unitConversion */ .dN)(maxValue, 4)?.split(" ")[1];
            setUnit(unit);
            unitNum = (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .unitConversionNum */ .D2)(unit);
        }
        (result?.power_trend_by_account_id_list || []).forEach((value)=>{
            const { block_time, power, power_increase } = value;
            let showTime = "";
            showTime = (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatDateTime */ .o0)(block_time, "MM-DD HH:mm");
            timeData.push(showTime);
            //y轴
            const [powerValue, powerUnit] = power ? (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .unitConversion */ .dN)(power, 4, unitNum || 4).split(" ") : [];
            const [increaseValue, increaseUnit] = power_increase ? (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .unitConversion */ .dN)(power_increase, 4, unitNum || 4)?.split(" ") : [];
            //amount
            const [powerValue_amount, powerValue_unit] = power ? (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .unitConversion */ .dN)(power, 5)?.split(" ") : [];
            const [power_increase_amount, power_increase_unit] = power_increase ? (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .unitConversion */ .dN)(power_increase, 4)?.split(" ") : [];
            seriesObj.power.push({
                value: powerValue,
                unit: powerValue_unit,
                amount: powerValue_amount,
                showTime: (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatDateTime */ .o0)(block_time, "YYYY-MM-DD HH:mm")
            });
            seriesObj.power_increase.push({
                value: increaseValue,
                unit: power_increase_unit,
                amount: power_increase_amount,
                showTime: (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatDateTime */ .o0)(block_time, "YYYY-MM-DD HH:mm")
            });
        });
        _contents_detail__WEBPACK_IMPORTED_MODULE_4__/* .power_change */ .IY.list.forEach((item)=>{
            const { dataIndex, color, title } = item;
            legendData.push({
                dataIndex,
                color: color,
                title: title,
                type: item.type
            });
            seriesData.push({
                type: item.type,
                smooth: true,
                data: seriesObj[dataIndex],
                dataIndex,
                name: title,
                symbol: "circle",
                barMaxWidth: "30",
                barMinWidth: "12",
                yAxisIndex: item.yIndex,
                backgroundStyle: {
                    color: item?.color || ""
                },
                itemStyle: {
                    color: item.color
                }
            });
        });
        setOptions({
            xData: timeData,
            series: seriesData,
            legendData
        });
    };
    const newOptions = (0,react__WEBPACK_IMPORTED_MODULE_9__.useMemo)(()=>{
        const newSeries = [];
        (options?.series || []).forEach((seriesItem)=>{
            if (!noShow[seriesItem?.dataIndex]) {
                newSeries.push(seriesItem);
            }
        });
        if (isMobile) {
            defaultOptions.grid.left = 0;
        }
        return {
            ...defaultOptions,
            xAxis: {
                ...default_xAxis,
                data: options?.xData || []
            },
            series: newSeries
        };
    }, [
        options,
        default_xAxis,
        noShow,
        defaultOptions,
        isMobile
    ]);
    const ledRender = ()=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
            className: "flex gap-x-4",
            children: options?.legendData?.map((v)=>{
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "text-xs flex cursor-pointer items-center gap-x-1",
                    onClick: ()=>{
                        setNoShow({
                            ...noShow,
                            [v.dataIndex]: !noShow[v.dataIndex]
                        });
                    },
                    style: {
                        color: noShow[v.dataIndex] ? "#d1d5db" : v.color
                    },
                    children: [
                        (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_6__/* .getSvgIcon */ .a)(v.type === "bar" ? "barLegend" : "legendIcon"),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-xs text_des font-normal",
                            children: tr(v.title)
                        })
                    ]
                }, v.dataIndex);
            })
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_11___default()((_style_module_scss__WEBPACK_IMPORTED_MODULE_14___default()["power-change"]), "flex-1"),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_11___default()("flex justify-between items-center mb-2 mx-2.5 h-[32px]", (_style_module_scss__WEBPACK_IMPORTED_MODULE_14___default().title)),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: classnames__WEBPACK_IMPORTED_MODULE_11___default()((_style_module_scss__WEBPACK_IMPORTED_MODULE_14___default().between), "flex gpa-x-5 items-center"),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: classnames__WEBPACK_IMPORTED_MODULE_11___default()("text-lg font-semibold mr-5"),
                            children: tr(_contents_detail__WEBPACK_IMPORTED_MODULE_4__/* .power_change */ .IY.title)
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_10__/* .BrowserView */ .I, {
                        children: ledRender()
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_11___default()("card_shadow w-full border rounded-xl p-2.5 pt-5 border_color", (_style_module_scss__WEBPACK_IMPORTED_MODULE_14___default().chart)),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_10__/* .MobileView */ .$, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "tips mb-2",
                            children: ledRender()
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: " w-full h-[348px]",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                            options: newOptions
                        })
                    })
                ]
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;