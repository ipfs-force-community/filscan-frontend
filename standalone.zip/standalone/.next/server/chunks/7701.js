"use strict";
exports.id = 7701;
exports.ids = [7701];
exports.modules = {

/***/ 3727:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgBalance = function SvgBalance(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 40 40"
  }, props), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "#1c6afd",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", {
    width: 40,
    height: 40,
    fillOpacity: 0.05,
    rx: 5
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fillRule: "nonzero",
    d: "M24.648 11c1.56 0 2.829 1.228 2.829 2.74v1.604A2.832 2.832 0 0 1 30 18.156v2.913a2.831 2.831 0 0 1-2.523 2.81v2.272c0 1.511-1.27 2.74-2.83 2.74H12.83c-1.56 0-2.83-1.229-2.83-2.74V13.74C10 12.23 11.27 11 12.83 11zm0 2H12.83c-.458 0-.83.332-.83.74V26.15c0 .408.372.74.83.74h11.818c.457 0 .83-.332.83-.74v-2.257l-4.93.001c-2.362 0-4.284-1.923-4.284-4.284s1.922-4.283 4.283-4.283l4.931-.001v-1.588c0-.407-.371-.739-.83-.739zm2.524 4.326h-6.625a2.285 2.285 0 0 0-2.283 2.283 2.285 2.285 0 0 0 2.283 2.283h6.625a.83.83 0 0 0 .828-.827v-2.911a.83.83 0 0 0-.828-.828zm-6.593 1.27a1.015 1.015 0 1 1 0 2.03 1.015 1.015 0 0 1 0-2.03z",
    opacity: 0.5
  }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgBalance);

/***/ }),

/***/ 3931:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgGas = function SvgGas(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 40 40"
  }, props), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "#1c6afd",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", {
    width: 40,
    height: 40,
    fillOpacity: 0.05,
    rx: 5
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fillRule: "nonzero",
    d: "M23.799 11c.515 0 .933.418.933.934v.415l1.494.001A2.777 2.777 0 0 1 29 15.124v11.795a2.778 2.778 0 0 1-2.774 2.776H13.774A2.778 2.778 0 0 1 11 26.92V15.124a2.777 2.777 0 0 1 2.774-2.774l.925-.001v-.415a.934.934 0 0 1 1.868 0l-.001.415h6.298v-.415c0-.516.42-.934.935-.934zm-9.1 3.219h-.925a.905.905 0 0 0-.904.905v11.795c0 .499.405.904.904.904h12.452a.905.905 0 0 0 .904-.904V15.124a.905.905 0 0 0-.904-.904l-1.494-.001v.419a.934.934 0 0 1-1.868 0v-.419h-6.298v.419a.934.934 0 0 1-1.867 0zm8.172 3.267a.935.935 0 0 1 0 1.322l-.845.845h.389a.934.934 0 0 1 0 1.868h-1.482v.9h1.482a.934.934 0 0 1 0 1.868l-1.482-.001v.86a.934.934 0 0 1-1.867 0v-.86h-1.48a.934.934 0 0 1 0-1.867h1.48v-.9h-1.48a.934.934 0 0 1 0-1.867l.351-.001-.808-.809a.935.935 0 1 1 1.322-1.322l1.531 1.53 1.567-1.566a.935.935 0 0 1 1.322 0z",
    opacity: 0.5
  }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgGas);

/***/ }),

/***/ 6215:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgPledge = function SvgPledge(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 40 40"
  }, props), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "#1c6afd",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", {
    width: 40,
    height: 40,
    fillOpacity: 0.05,
    rx: 5
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fillRule: "nonzero",
    d: "m11.4 23.52 8.576 3.729 8.626-3.729a1 1 0 1 1 .793 1.837l-9.022 3.9a.987.987 0 0 1-.795 0l-8.976-3.904a.998.998 0 0 1-.518-1.315.998.998 0 0 1 1.315-.518zm0-4.228 8.576 3.729 8.626-3.729a1 1 0 1 1 .793 1.838l-9.022 3.896a.984.984 0 0 1-.796 0l-8.975-3.9a.998.998 0 0 1-.518-1.316.998.998 0 0 1 1.315-.518zM19.98 11l.422.166 8.881 3.85a1.056 1.056 0 0 1 .003 1.933l-9.29 4.015-.432-.17-8.848-3.845a1.052 1.052 0 0 1-.63-.968c0-.421.247-.8.63-.966zm.02 2.169-6.488 2.814 6.464 2.81 6.507-2.812z",
    opacity: 0.5
  }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgPledge);

/***/ }),

/***/ 7949:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgPower = function SvgPower(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 40 40"
  }, props), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "#1c6afd",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", {
    width: 40,
    height: 40,
    fillOpacity: 0.05,
    rx: 5
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fillRule: "nonzero",
    d: "M21.495 10c1.083 0 1.962.88 1.962 1.962v3.289a1.962 1.962 0 0 1-1.962 1.961h-.914v1.768h3.685c.888 0 1.61.723 1.61 1.61v1.649l.903.001c1.083 0 1.961.88 1.961 1.961v3.266c0 1.08-.88 1.962-1.961 1.962h-3.266a1.964 1.964 0 0 1-1.961-1.962v-3.266c0-1.082.88-1.961 1.961-1.961l.902-.001.001-1.648a.152.152 0 0 0-.152-.152h-8.788a.152.152 0 0 0-.152.152v1.648l.903.001c1.083 0 1.962.88 1.962 1.961v3.266c0 1.08-.881 1.962-1.962 1.962h-3.265A1.964 1.964 0 0 1 11 27.467v-3.266c0-1.082.88-1.961 1.962-1.961l.904-.001v-1.648c0-.888.723-1.61 1.61-1.61l3.647-.001v-1.768h-.915a1.964 1.964 0 0 1-1.961-1.961v-3.29c0-1.082.88-1.961 1.961-1.961zm-8.533 14.182-.02 3.283 3.285.02a.02.02 0 0 0 .02-.02V24.2zm10.551 0-.02 3.283 3.284.02a.02.02 0 0 0 .02-.02V24.2zm-5.305-12.24-.02 3.309 3.307.02a.02.02 0 0 0 .02-.02v-3.29z",
    opacity: 0.5
  }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgPower);

/***/ }),

/***/ 357:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgReward = function SvgReward(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 40 40"
  }, props), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "#1c6afd",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", {
    width: 40,
    height: 40,
    fillOpacity: 0.05,
    rx: 5
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fillRule: "nonzero",
    d: "M28.652 25.118c0 2.784-3.796 4.882-8.827 4.882C14.794 30 11 27.902 11 25.118v-9.234C11 13.1 14.794 11 19.825 11c4.982 0 8.751 2.06 8.824 4.803l.003.081zM12.9 23.598v1.52c0 1.409 2.961 2.984 6.925 2.984s6.927-1.577 6.927-2.984v-1.52c-1.59 1.103-4.058 1.785-6.927 1.785-2.868 0-5.335-.682-6.925-1.785zm6.925-2.83c-2.868 0-5.335-.682-6.925-1.785v1.518c0 1.41 2.961 2.984 6.925 2.984s6.927-1.577 6.927-2.984l.001-1.519c-1.59 1.104-4.058 1.787-6.928 1.787zm0-7.868c-3.964 0-6.925 1.575-6.925 2.984 0 1.41 2.961 2.985 6.925 2.985s6.925-1.575 6.925-2.985c.002-1.409-2.96-2.984-6.925-2.984z",
    opacity: 0.5
  }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgReward);

/***/ }),

/***/ 7701:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Ai: () => (/* binding */ login_list),
/* harmony export */   GK: () => (/* binding */ personal_setting),
/* harmony export */   G_: () => (/* binding */ overview),
/* harmony export */   Gu: () => (/* binding */ account_power),
/* harmony export */   Hp: () => (/* binding */ account_manager),
/* harmony export */   JQ: () => (/* binding */ account_gas),
/* harmony export */   Oy: () => (/* binding */ account_miners),
/* harmony export */   PO: () => (/* binding */ logTabs),
/* harmony export */   dA: () => (/* binding */ registerList),
/* harmony export */   j_: () => (/* binding */ account_balance),
/* harmony export */   n1: () => (/* binding */ account_lucky),
/* harmony export */   nS: () => (/* binding */ account_expired),
/* harmony export */   vw: () => (/* binding */ account_reward)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7947);
/* harmony import */ var _ant_design_icons_lib_icons_LockOutlined__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6762);
/* harmony import */ var _ant_design_icons_lib_icons_LockOutlined__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons_lib_icons_LockOutlined__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ant_design_icons_lib_icons_UserOutlined__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2127);
/* harmony import */ var _ant_design_icons_lib_icons_UserOutlined__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons_lib_icons_UserOutlined__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _packages_tagInput__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6247);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3495);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _assets_images_power_svg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7949);
/* harmony import */ var _assets_images_pledge_svg__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6215);
/* harmony import */ var _assets_images_gas_svg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3931);
/* harmony import */ var _assets_images_reward_svg__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(357);
/* harmony import */ var _assets_images_balance_svg__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3727);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils__WEBPACK_IMPORTED_MODULE_6__]);
_utils__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/** @format */ 












const logTabs = [
    {
        title: "password_login",
        dataIndex: "login"
    },
    {
        title: "verification_code",
        dataIndex: "code"
    }
];
const login_list = (type)=>{
    const arr = [
        {
            label: "email",
            name: "email",
            prefix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_ant_design_icons_lib_icons_UserOutlined__WEBPACK_IMPORTED_MODULE_3___default()), {
                className: "site-form-item-icon"
            }),
            placeholder: "email_placeholder",
            rules: [
                {
                    required: true,
                    message: "${email} is required"
                }
            ]
        }
    ];
    if (type === "code") {
        return [
            ...arr,
            {
                label: "code",
                name: "code",
                placeholder: "code_placeholder",
                prefix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_ant_design_icons_lib_icons_LockOutlined__WEBPACK_IMPORTED_MODULE_2___default()), {
                    className: "site-form-item-icon"
                }),
                rules: [
                    {
                        required: true,
                        message: "${code} is required"
                    }
                ]
            }
        ];
    }
    return [
        ...arr,
        {
            label: "password",
            name: "password",
            placeholder: "password_placeholder",
            prefix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_ant_design_icons_lib_icons_LockOutlined__WEBPACK_IMPORTED_MODULE_2___default()), {
                className: "site-form-item-icon"
            }),
            rules: [
                {
                    required: true,
                    message: "${password} is required"
                }
            ]
        }
    ];
};
const registerList = [
    {
        label: "email",
        name: "email",
        prefix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_ant_design_icons_lib_icons_UserOutlined__WEBPACK_IMPORTED_MODULE_3___default()), {
            className: "site-form-item-icon"
        }),
        placeholder: "email_placeholder",
        rules: [
            // {
            //   required: true,
            //   message: 'email_required',
            // },
            {
                type: "email",
                required: true,
                message: "email_rules"
            }
        ]
    },
    {
        label: "code",
        name: "code",
        placeholder: "code_placeholder",
        prefix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_ant_design_icons_lib_icons_LockOutlined__WEBPACK_IMPORTED_MODULE_2___default()), {
            className: "site-form-item-icon"
        }),
        rules: [
            {
                required: true,
                message: "${password} is required"
            }
        ]
    },
    {
        label: "password",
        name: "new_password",
        placeholder: "new_password",
        prefix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_ant_design_icons_lib_icons_LockOutlined__WEBPACK_IMPORTED_MODULE_2___default()), {
            className: "site-form-item-icon"
        }),
        rules: [
            {
                required: true,
                message: "${password} is required"
            }
        ]
    },
    {
        label: "password",
        name: "confirm_password",
        placeholder: "confirm_password",
        prefix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_ant_design_icons_lib_icons_LockOutlined__WEBPACK_IMPORTED_MODULE_2___default()), {
            className: "site-form-item-icon"
        }),
        rules: [
            {
                required: true,
                message: "${password} is required"
            }
        ]
    }
];
const account_manager = [
    {
        label: "overview",
        icon: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)("account_overview"),
        href: "overview",
        key: "overview",
        children: [
            {
                label: "overview_power",
                key: "power"
            },
            {
                label: "overview_gas",
                key: "gas"
            },
            {
                label: "overview_expired",
                key: "expired"
            },
            {
                label: "overview_reward",
                key: "reward"
            },
            {
                label: "overview_lucky",
                key: "lucky"
            },
            {
                label: "overview_balance",
                key: "balance"
            }
        ]
    },
    {
        label: "miners",
        icon: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)("account_miners"),
        key: "miners",
        href: "miners"
    },
    {
        label: "personal",
        icon: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)("account_personal"),
        key: "personal",
        href: "personal"
    },
    {
        label: "logout",
        icon: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)("account_logout"),
        href: "",
        key: "logout"
    }
];
const personal_setting = [
    // {
    //   title: 'personal_name',
    //   dataIndex: 'name',
    //   placeholder: 'personal_name_holder',
    // },
    {
        title: "old_password",
        placeholder: "old_placeholder",
        dataIndex: "old_password",
        rules: [
            {
                required: true,
                message: "${old_placeholder} is required"
            }
        ]
    },
    {
        title: "new_password",
        placeholder: "new_placeholder",
        dataIndex: "new_password",
        rules: [
            {
                required: true,
                message: "${new_password} is required"
            }
        ]
    },
    {
        title: "confirm_password",
        dataIndex: "confirm_password",
        placeholder: "confirm_password",
        rules: [
            {
                required: true,
                message: "${confirm_password} is required"
            }
        ]
    }
];
const overview = {
    headerList: [
        [
            {
                title: "quality_power_24",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_7___default()), {
                    src: _assets_images_power_svg__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z,
                    width: 40,
                    height: 40,
                    alt: ""
                }),
                dataIndex: "sum_quality_adj_power",
                render: (text, record, tr)=>{
                    const changeText = record?.sum_power_change_24h ? Number(record.sum_power_change_24h) : "";
                    const flag = changeText ? changeText > 0 ? "+" : "" : "";
                    const className = changeText ? changeText > 0 ? "text_green" : "text_red" : "";
                    const [textValue, unit] = (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .unitConversion */ .dN)(text, 2).split(" ");
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex w-full h-full flex-col justify-between",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "flex flex-col",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-sm text_des",
                                        children: tr("quality_power_24")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: className,
                                        children: changeText ? flag + (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .unitConversion */ .dN)(changeText, 2) : "--"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "flex items-baseline gap-x-1 text-xl font-DINPro-Bold font-semibold text_clip",
                                children: [
                                    textValue,
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-sm text_color",
                                        children: unit
                                    })
                                ]
                            })
                        ]
                    });
                }
            },
            {
                title: "total_reward_24",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_7___default()), {
                    src: _assets_images_reward_svg__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z,
                    width: 40,
                    height: 40,
                    alt: ""
                }),
                dataIndex: "sum_reward_change_24h",
                render: (text, record, tr)=>{
                    // const changeText = record?.sum_reward_change_24h
                    //   ? Number(record.sum_reward_change_24h)
                    //   : '';
                    // const flag = changeText ? (changeText > 0 ? '+' : '-') : '';
                    // const className = changeText
                    //   ? changeText > 0
                    //     ? 'text_green'
                    //     : 'text_red'
                    //   : '';
                    const [textValue, unit] = (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatFil */ .Uk)(text, "FIL", 4, true).split(" ");
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex w-full h-full flex-col justify-between",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "flex flex-col",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "text-sm text_des",
                                    children: tr("total_reward_24")
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "flex items-baseline gap-x-1 text-xl font-DINPro-Bold font-semibold text_clip",
                                children: [
                                    textValue,
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-sm",
                                        children: unit
                                    })
                                ]
                            })
                        ]
                    });
                }
            }
        ],
        [
            {
                title: "total_out_come_gas",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_7___default()), {
                    src: _assets_images_gas_svg__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z,
                    width: 40,
                    height: 40,
                    alt: ""
                }),
                dataIndex: "sum_outlay",
                render: (text, record, tr)=>{
                    const changeText = record?.sum_gas ? Number(record.sum_gas) : "";
                    const flag = changeText ? changeText > 0 ? "+" : "-" : "";
                    const className = changeText ? changeText > 0 ? "text_green" : "text_red" : "text_des_unit";
                    const [textValue, unit] = (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatFil */ .Uk)(text, "FIL", 4, true).split(" ");
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex w-full h-full flex-col justify-between",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "flex flex-col",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-sm text_des",
                                        children: tr("total_out_come_gas")
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: className,
                                        children: [
                                            flag,
                                            changeText ? (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatFil */ .Uk)(Math.abs(Number(changeText)), "FIL", 4, true) : "--"
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "flex items-baseline gap-x-1 text-xl font-DINPro-Bold font-semibold text_clip",
                                children: [
                                    textValue,
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-sm",
                                        children: unit
                                    })
                                ]
                            })
                        ]
                    });
                }
            },
            {
                title: "pledge_amount_24",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_7___default()), {
                    src: _assets_images_pledge_svg__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z,
                    width: 40,
                    height: 40,
                    alt: ""
                }),
                dataIndex: "sum_pledge",
                render: (text, record, tr)=>{
                    const changeText = record?.sum_pledge_change_24h ? Number(record.sum_pledge_change_24h) : "";
                    const flag = changeText ? changeText > 0 ? "+" : "-" : "";
                    const className = changeText ? changeText > 0 ? "text_green" : "text_red" : "";
                    const [textValue, unit] = (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatFil */ .Uk)(text, "FIL", 4, true).split(" ");
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex w-full h-full flex-col justify-between",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "flex flex-col",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-sm text_des",
                                        children: tr("pledge_amount_24")
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: className,
                                        children: [
                                            flag,
                                            changeText ? (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatFil */ .Uk)(Math.abs(Number(changeText)), "FIL", 2, true) : "--"
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "flex items-baseline gap-x-1 text-xl font-DINPro-Bold font-semibold text_clip",
                                children: [
                                    textValue,
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-sm",
                                        children: unit
                                    })
                                ]
                            })
                        ]
                    });
                }
            },
            {
                title: "balance_24",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_7___default()), {
                    src: _assets_images_balance_svg__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z,
                    width: 40,
                    height: 40,
                    alt: ""
                }),
                dataIndex: "sum_balance",
                render: (text, record, tr)=>{
                    const changeText = record?.sum_balance_change_24h ? Number(record.sum_balance_change_24h) : "";
                    const flag = changeText ? changeText > 0 ? "+" : "-" : "";
                    const className = changeText ? changeText > 0 ? "text_green" : "text_red" : "";
                    const [textValue, unit] = (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatFil */ .Uk)(text, "FIL", 4, true).split(" ");
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex w-full h-full flex-col justify-between",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "flex flex-col",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-sm text_des",
                                        children: tr("balance_24")
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: className,
                                        children: [
                                            flag,
                                            changeText ? (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatFil */ .Uk)(Math.abs(Number(changeText)), "FIL", 2, true) : "--"
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "flex items-baseline gap-x-1 text-xl font-DINPro-Bold font-semibold text_clip",
                                children: [
                                    textValue,
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text-sm",
                                        children: unit
                                    })
                                ]
                            })
                        ]
                    });
                }
            }
        ]
    ],
    columns: (tr)=>[
            {
                title: "tag",
                dataIndex: "tag",
                fixed: "left",
                width: 100,
                ellipsis: {
                    showTitle: false
                },
                render: (text, record)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tagInput__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        text: text,
                        isEdit: false,
                        record: record
                    });
                }
            },
            {
                title: "miner_id",
                dataIndex: "miner_id",
                width: 100,
                fixed: "left",
                render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                        href: `/miner/${text}`,
                        className: "link_text",
                        children: text
                    })
            },
            {
                title: "group_name",
                dataIndex: "group_name",
                width: 100,
                fixed: "left",
                ellipsis: {
                    showTitle: false
                },
                render: (text, record)=>{
                    const showText = record.is_default ? tr("default_group") : text;
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "bg-bg_hover text-xs text-primary rounded-[5px] p-2 w-fit",
                        children: [
                            " ",
                            showText
                        ]
                    });
                }
            },
            {
                title: "quality_power",
                dataIndex: "total_quality_adj_power",
                render: (text, record)=>(0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .unitConversion */ .dN)(text, 2)
            },
            {
                title: "raw_power",
                dataIndex: "total_raw_byte_power",
                render: (text, record)=>(0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .unitConversion */ .dN)(text, 2)
            },
            {
                title: "total_reward_24",
                dataIndex: "reward_change_24h",
                //  exports: ['reward_change_24h'],
                amountUnit: {
                    reward_change_24h: {
                        unit: "fil"
                    }
                },
                render: (text)=>renderFil(text)
            },
            {
                title: "total_out_come_gas",
                dataIndex: "total_outlay",
                exports: [
                    "total_gas"
                ],
                amountUnit: {
                    total_outlay: {
                        unit: "fil",
                        number: 2
                    },
                    total_gas: {
                        unit: "fil",
                        number: 2
                    }
                },
                render: (text, record)=>{
                    const changeText = record?.total_gas ? Number(record.total_gas) : "";
                    const flag = changeText ? changeText > 0 ? "+" : "-" : "";
                    const className = changeText ? changeText > 0 ? "text_green" : "text_red" : "";
                    return renderFil(text, changeText, flag, className);
                }
            },
            {
                title: "pledge_amount_24",
                dataIndex: "total_pledge_amount",
                exports: [
                    "pledge_change_24h"
                ],
                amountUnit: {
                    pledge_change_24h: {
                        unit: "fil",
                        number: 2
                    },
                    total_pledge_amount: {
                        unit: "fil",
                        number: 2
                    }
                },
                render: (text, record)=>{
                    const changeText = record?.pledge_change_24h ? Number(record.pledge_change_24h) : "";
                    const flag = changeText ? changeText > 0 ? "+" : "-" : "";
                    const className = changeText ? changeText > 0 ? "text_green" : "text_red" : "";
                    return renderFil(text, changeText, flag, className);
                }
            },
            {
                title: "balance_24",
                dataIndex: "total_balance",
                exports: [
                    "balance_change_24h"
                ],
                amountUnit: {
                    balance_change_24h: {
                        unit: "fil",
                        number: 2
                    },
                    total_balance: {
                        unit: "fil",
                        number: 2
                    }
                },
                render: (text, record)=>{
                    const changeText = record?.balance_change_24h ? Number(record.balance_change_24h) : "";
                    const flag = changeText ? changeText > 0 ? "+" : "-" : "";
                    const className = changeText ? changeText > 0 ? "text_green" : "text_red" : "";
                    return renderFil(text, changeText, flag, className);
                }
            }
        ]
};
const account_lucky = {
    columns: (tr)=>[
            {
                title: "tag",
                dataIndex: "tag",
                width: "20%",
                fixed: "left",
                ellipsis: {
                    showTitle: false
                },
                render: (text, record)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tagInput__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        isEdit: false,
                        text: text,
                        record: record
                    });
                }
            },
            {
                title: "miner_id",
                dataIndex: "miner_id",
                width: "15%",
                fixed: "left",
                render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                        href: `/miner/${text}`,
                        className: "link_text",
                        children: text
                    })
            },
            {
                title: "group_name",
                dataIndex: "group_name",
                fixed: "left",
                width: "20%",
                ellipsis: {
                    showTitle: false
                },
                render: (text, record)=>{
                    const showText = record.is_default ? tr("default_group") : text;
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "bg-bg_hover text-xs text-primary rounded-[5px] p-2 w-fit",
                        children: [
                            " ",
                            showText
                        ]
                    });
                }
            },
            {
                title: "24h_lucky",
                dataIndex: "lucky_rate_24h",
                width: "15%",
                amountUnit: {
                    lucky_rate_24h: {
                        unit: "%",
                        number: 2
                    }
                },
                render: (text)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatNumberPercentage */ .Fy)(text) + "%" : text
            },
            {
                title: "7d_lucky",
                dataIndex: "lucky_rate_7d",
                width: "15%",
                amountUnit: {
                    "lucky_rate_7d": {
                        unit: "%",
                        number: 2
                    }
                },
                render: (text)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatNumberPercentage */ .Fy)(text) + "%" : text
            },
            {
                title: "30d_lucky",
                dataIndex: "lucky_rate_30d",
                amountUnit: {
                    "lucky_rate_30d": {
                        unit: "%",
                        number: 2
                    }
                },
                width: "15%",
                render: (text)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatNumberPercentage */ .Fy)(text) + "%" : text
            }
        ]
};
const account_balance = {
    columns: (tr)=>[
            {
                title: "tag",
                dataIndex: "tag",
                fixed: "left",
                width: 100,
                ellipsis: {
                    showTitle: false
                },
                render: (text, record)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tagInput__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        isEdit: false,
                        text: text,
                        record: record
                    });
                }
            },
            {
                title: "miner_id",
                dataIndex: "miner_id",
                width: 100,
                fixed: "left",
                render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                        href: `/miner/${text}`,
                        className: "link_text",
                        children: text
                    })
            },
            {
                title: "group_name",
                dataIndex: "group_name",
                width: 100,
                fixed: "left",
                ellipsis: {
                    showTitle: false
                },
                render: (text, record)=>{
                    const showText = record.is_default ? tr("default_group") : text;
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "bg-bg_hover text-xs text-primary rounded-[5px] p-2 w-fit",
                        children: [
                            " ",
                            showText
                        ]
                    });
                }
            },
            {
                title: "miner_balance",
                dataIndex: "miner_balance",
                exports: [
                    "miner_balance_changed"
                ],
                amountUnit: {
                    miner_balance_changed: {
                        unit: "fil",
                        number: 2
                    },
                    miner_balance: {
                        unit: "fil",
                        number: 0
                    }
                },
                //width: 170,
                render: (text, record)=>{
                    const changeText = record?.miner_balance_changed ? Number(record.miner_balance_changed) : "";
                    const flag = changeText ? changeText > 0 ? "+" : "-" : "";
                    const className = changeText ? changeText > 0 ? "text_green" : "text_red" : "";
                    return renderFil(text, changeText, flag, className);
                //   (
                //   <span className='flex flex-col'>
                //     <span>{formatFilNum(text, false, false, 2)}</span>
                //     <span className={`${className}`}>
                //       {flag +
                //         formatFilNum(Math.abs(Number(changeText)), false, false, 2)}
                //     </span>
                //   </span>
                // );
                }
            },
            {
                title: "owner_balance",
                dataIndex: "owner_balance",
                // width: 170,
                exports: [
                    "Owner_balance_changed"
                ],
                amountUnit: {
                    owner_balance: {
                        unit: "fil",
                        number: 0
                    },
                    Owner_balance_changed: {
                        unit: "fil",
                        number: 0
                    }
                },
                render: (text, record)=>{
                    const changeText = record?.Owner_balance_changed ? Number(record.Owner_balance_changed) : "";
                    const flag = changeText ? changeText > 0 ? "+" : "-" : "";
                    const className = changeText ? changeText > 0 ? "text_green" : "text_red" : "";
                    return renderFil(text, changeText, flag, className);
                }
            },
            {
                title: "worker_balance",
                dataIndex: "worker_balance",
                //width: 170,
                exports: [
                    "Worker_balance_changed"
                ],
                amountUnit: {
                    worker_balance: {
                        unit: "fil"
                    },
                    Worker_balance_changed: {
                        unit: "fil"
                    }
                },
                render: (text, record)=>{
                    const changeText = record?.Worker_balance_changed ? Number(record.Worker_balance_changed) : "";
                    const flag = changeText ? changeText > 0 ? "+" : "-" : "";
                    const className = changeText ? changeText > 0 ? "text_green" : "text_red" : "";
                    return renderFil(text, changeText, flag, className);
                }
            },
            {
                title: "controller_0_balance",
                dataIndex: "controller_0_balance",
                // width: 200,
                exports: [
                    "Controller_0_balance_changed"
                ],
                amountUnit: {
                    controller_0_balance: {
                        unit: "fil"
                    },
                    Controller_0_balance_changed: {
                        unit: "fil"
                    }
                },
                render: (text, record)=>{
                    const changeText = record?.Controller_0_balance_changed ? Number(record.Controller_0_balance_changed) : "";
                    const flag = changeText ? changeText > 0 ? "+" : "-" : "";
                    const className = changeText ? changeText > 0 ? "text_green" : "text_red" : "";
                    return renderFil(text, changeText, flag, className);
                }
            },
            {
                title: "controller_1_balance",
                dataIndex: "controller_1_balance",
                // width: 200,
                exports: [
                    "controller_1_balance_changed"
                ],
                amountUnit: {
                    controller_1_balance: {
                        unit: "fil"
                    },
                    controller_1_balance_changed: {
                        unit: "fil"
                    }
                },
                render: (text, record)=>{
                    const changeText = record?.controller_1_balance_changed ? Number(record.controller_1_balance_changed) : "";
                    const flag = changeText ? changeText > 0 ? "+" : "-" : "";
                    const className = changeText ? changeText > 0 ? "text_green" : "text_red" : "";
                    return renderFil(text, changeText, flag, className);
                }
            },
            {
                title: "controller_2_balance",
                dataIndex: "controller_2_balance",
                // width: 200,
                exports: [
                    "controller_2_balance_changed"
                ],
                amountUnit: {
                    controller_2_balance: {
                        unit: "fil"
                    },
                    controller_2_balance_changed: {
                        unit: "fil"
                    }
                },
                render: (text, record)=>{
                    const changeText = record?.controller_2_balance_changed ? Number(record.controller_2_balance_changed) : "";
                    const flag = changeText ? changeText > 0 ? "+" : "-" : "";
                    const className = changeText ? changeText > 0 ? "text_green" : "text_red" : "";
                    return renderFil(text, changeText, flag, className);
                }
            },
            {
                title: "beneficiary_balance",
                dataIndex: "beneficiary_balance",
                // width: 200,
                exports: [
                    "beneficiary_balance_changed"
                ],
                amountUnit: {
                    beneficiary_balance: {
                        unit: "fil"
                    },
                    beneficiary_balance_changed: {
                        unit: "fil"
                    }
                },
                render: (text, record)=>{
                    const changeText = record?.beneficiary_balance_changed ? Number(record.beneficiary_balance_changed) : "";
                    const flag = changeText ? changeText > 0 ? "+" : "-" : "";
                    const className = changeText ? changeText > 0 ? "text_green" : "text_red" : "";
                    return renderFil(text, changeText, flag, className);
                }
            },
            {
                title: "market_balance",
                dataIndex: "market_balance",
                // width: 200,
                exports: [
                    "market_balance_changed"
                ],
                amountUnit: {
                    market_balance: {
                        unit: "fil"
                    },
                    market_balance_changed: {
                        unit: "fil"
                    }
                },
                render: (text, record)=>{
                    const changeText = record?.market_balance_changed ? Number(record.market_balance_changed) : "";
                    const flag = changeText ? changeText > 0 ? "+" : "-" : "";
                    const className = changeText ? changeText > 0 ? "text_green" : "text_red" : "";
                    return renderFil(text, changeText, flag, className);
                }
            }
        ]
};
const account_reward = {
    columns: (tr, type)=>{
        let arr = [
            {
                title: "tag",
                dataIndex: "tag",
                width: "10%",
                fixed: "left",
                ellipsis: {
                    showTitle: false
                },
                render: (text, record)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tagInput__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        isEdit: false,
                        text: text,
                        record: record
                    });
                }
            },
            {
                title: "miner_id",
                dataIndex: "miner_id",
                width: "15%",
                fixed: "left",
                render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                        href: `/account#reward?miner=${text}`,
                        className: "link_text",
                        children: text
                    })
            },
            {
                title: "group_name",
                dataIndex: "group_name",
                fixed: "left",
                width: "15%",
                ellipsis: {
                    showTitle: false
                },
                render: (text, record)=>{
                    const showText = record.is_default ? tr("default_group") : text;
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "bg-bg_hover text-xs text-primary rounded-[5px] p-2 w-fit",
                        children: [
                            " ",
                            showText
                        ]
                    });
                }
            },
            {
                title: "block_count",
                dataIndex: "block_count",
                width: "20%"
            },
            {
                title: "win_count",
                dataIndex: "win_count",
                width: "20%"
            },
            {
                title: "block_reward",
                dataIndex: "block_reward",
                width: "20%",
                amountUnit: {
                    block_reward: {
                        unit: "fil",
                        number: 4
                    }
                },
                render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatFilNum */ .Nm)(text)
            }
        ];
        if (type && type === "detail") {
            arr.unshift({
                title: "date",
                dataIndex: "date",
                fixed: "left",
                width: "10%",
                render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatDateTime */ .o0)(text, "YYYY-MM-DD")
            });
            arr[1].width = "15%";
            arr[2].width = "10%";
            arr[2].render = (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                    href: `/miner/${text}`,
                    className: "link_text",
                    children: text
                });
        }
        return arr;
    }
};
const account_power = {
    columns: (tr, type)=>{
        let arr = [
            {
                title: "tag",
                dataIndex: "tag",
                fixed: "left",
                width: 100,
                ellipsis: {
                    showTitle: false
                },
                render: (text, record)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tagInput__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        isEdit: false,
                        text: text,
                        record: record
                    });
                }
            },
            {
                title: "miner_id",
                dataIndex: "miner_id",
                width: 100,
                fixed: "left",
                render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                        href: `/account#power?miner=${text}`,
                        className: "link_text",
                        children: text
                    })
            },
            {
                title: "group_name",
                dataIndex: "group_name",
                width: 100,
                ellipsis: {
                    showTitle: false
                },
                fixed: "left",
                render: (text, record)=>{
                    const showText = record.is_default ? tr("default_group") : text;
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "bg-bg_hover text-xs text-primary rounded-[5px] p-2 w-fit",
                        children: [
                            " ",
                            showText
                        ]
                    });
                }
            },
            {
                title: "quality_power",
                dataIndex: "quality_power",
                amountUnit: {
                    quality_power: {
                        unit: "power",
                        number: 2
                    }
                },
                //width: 150,
                render: (text, record)=>(0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .unitConversion */ .dN)(text, 2)
            },
            {
                title: "raw_power",
                dataIndex: "raw_power",
                /// width: 100,
                amountUnit: {
                    raw_power: {
                        unit: "power",
                        number: 2
                    }
                },
                render: (text, record)=>(0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .unitConversion */ .dN)(text, 2)
            },
            {
                title: "dc_power",
                dataIndex: "dc_power",
                //  width: 100,
                amountUnit: {
                    dc_power: {
                        unit: "power",
                        number: 2
                    }
                },
                render: (text, record)=>(0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .unitConversion */ .dN)(text, 2)
            },
            {
                title: "cc_power",
                dataIndex: "cc_power",
                //// width: 200,
                amountUnit: {
                    cc_power: {
                        unit: "power",
                        number: 2
                    }
                },
                render: (text, record)=>(0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .unitConversion */ .dN)(text, 2)
            },
            {
                title: "sector_size",
                dataIndex: "sector_size",
                //// width: 200,
                render: (text, record)=>(0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .unitConversion */ .dN)(text, 2)
            },
            {
                title: "sector_power_change",
                dataIndex: "sector_count_change",
                exports: [
                    "sector_power_change"
                ],
                titleTip: "sector_power_change_tip",
                amountUnit: {
                    sector_power_change: {
                        unit: "power",
                        number: 2
                    }
                },
                //width: 200,
                render: (text, record)=>{
                    const flag = text ? Number(text) > 0 ? "+" : "-" : "";
                    const className = Number(text) ? Number(text) > 0 ? "text_green" : "text_red" : "";
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: className,
                                children: [
                                    flag,
                                    (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatNumber */ .uf)(Math.abs(text))
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                children: [
                                    "/",
                                    (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .unitConversion */ .dN)(record?.sector_power_change, 2)
                                ]
                            })
                        ]
                    });
                }
            },
            {
                title: "pledge_changed",
                dataIndex: "pledge_changed",
                titleTip: "pledge_changed_tip",
                //width: 200,
                amountUnit: {
                    pledge_changed: {
                        unit: "fil"
                    }
                },
                render: (text, record)=>renderFil(text)
            },
            {
                title: "pledge_changed_per_t",
                dataIndex: "pledge_changed_per_t",
                titleTip: "pledge_changed_per_t_tip",
                //width: 200,
                amountUnit: {
                    pledge_changed_per_t: {
                        unit: "fil/T"
                    }
                },
                render: (text, record)=>{
                    return renderFil(text, undefined, undefined, undefined, "FIL/T");
                }
            },
            {
                title: "penalty",
                dataIndex: "penalty",
                titleTip: "penalty_tip",
                //// width: 200,
                amountUnit: {
                    penalty: {
                        unit: "fil"
                    }
                },
                render: (text, record)=>renderFil(text)
            },
            {
                title: "fault_sectors",
                dataIndex: "fault_sectors",
                titleTip: "fault_sectors_tip",
                //width: 200,
                render: (text, record)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: Number(text) ? "" : "text_des_unit",
                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatNumber */ .uf)(text)
                    })
            }
        ];
        if (type && type === "detail") {
            arr.unshift({
                title: "date",
                dataIndex: "date",
                fixed: "left",
                render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatDateTime */ .o0)(text, "YYYY-MM-DD")
            });
            arr[2].render = (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                    href: `/miner/${text}`,
                    className: "link_text",
                    children: text
                });
        }
        return arr;
    }
};
const account_gas = {
    columns: (tr, type)=>{
        let arr = [
            {
                title: "tag",
                dataIndex: "tag",
                fixed: "left",
                width: 100,
                ellipsis: {
                    showTitle: false
                },
                render: (text, record)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tagInput__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        isEdit: false,
                        text: text,
                        record: record
                    });
                }
            },
            {
                title: "miner_id",
                dataIndex: "miner_id",
                width: 100,
                fixed: "left",
                render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                        href: `/account#gas?miner=${text}`,
                        className: "link_text",
                        children: text
                    })
            },
            {
                title: "group_name",
                dataIndex: "group_name",
                width: 100,
                fixed: "left",
                ellipsis: {
                    showTitle: false
                },
                render: (text, record)=>{
                    const showText = record.is_default ? tr("default_group") : text;
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "bg-bg_hover text-xs text-primary rounded-[5px] p-2 w-fit",
                        children: [
                            " ",
                            showText
                        ]
                    });
                }
            },
            {
                title: "sector_power_change",
                dataIndex: "sector_count_change",
                titleTip: "sector_power_change_tip",
                exports: [
                    "sector_power_change"
                ],
                amountUnit: {
                    sector_power_change: {
                        unit: "power",
                        number: 2
                    }
                },
                render: (text, record)=>{
                    const flag = text ? Number(text) > 0 ? "+" : "-" : "";
                    const className = Number(text) ? Number(text) > 0 ? "text_green" : "text_red" : "";
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: className,
                                children: [
                                    flag,
                                    (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatNumber */ .uf)(Math.abs(text))
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                children: [
                                    "/",
                                    (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .unitConversion */ .dN)(record?.sector_power_change, 2)
                                ]
                            })
                        ]
                    });
                }
            },
            {
                title: "total_gas_cost",
                dataIndex: "total_gas_cost",
                titleTip: "total_gas_cost_tip",
                // width: 200,
                amountUnit: {
                    total_gas_cost: {
                        unit: "fil"
                    }
                },
                render: (text)=>renderFil(text)
            },
            {
                title: "seal_gas_cost",
                dataIndex: "seal_gas_cost",
                titleTip: "seal_gas_cost_tip",
                // width: 200,
                amountUnit: {
                    total_gas_cost: {
                        unit: "fil"
                    }
                },
                render: (text)=>renderFil(text, undefined, undefined, undefined, "FIL")
            },
            {
                title: "seal_gas_per_t",
                dataIndex: "seal_gas_per_t",
                titleTip: "seal_gas_per_t_tip",
                // width: 200,
                amountUnit: {
                    total_gas_cost: {
                        unit: "fil/T"
                    }
                },
                render: (text)=>renderFil(text, undefined, undefined, undefined, "FIL/T")
            },
            {
                title: "deal_gas_cost",
                dataIndex: "deal_gas_cost",
                titleTip: "deal_gas_cost_tip",
                // width: 200,
                amountUnit: {
                    deal_gas_cost: {
                        unit: "fil"
                    }
                },
                render: (text)=>renderFil(text)
            },
            {
                title: "wd_post_gas_cost",
                titleTip: "wd_post_gas_cost_tip",
                dataIndex: "wd_post_gas_cost",
                // width: 200,
                amountUnit: {
                    wd_post_gas_cost: {
                        unit: "fil"
                    }
                },
                render: (text)=>renderFil(text)
            },
            {
                title: "wd_post_gas_per_t",
                dataIndex: "wd_post_gas_per_t",
                titleTip: "wd_post_gas_per_t_tip",
                // width: 200,
                amountUnit: {
                    wd_post_gas_per_t: {
                        unit: "fil/T"
                    }
                },
                render: (text)=>renderFil(text, undefined, undefined, undefined, "FIL/T")
            }
        ];
        if (type && type === "detail") {
            arr.unshift({
                title: "date",
                dataIndex: "date",
                fixed: "left",
                // width: 200,
                render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatDateTime */ .o0)(text, "YYYY-MM-DD")
            });
            arr[2].render = (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                    href: `/miner/${text}`,
                    className: "link_text",
                    children: text
                });
        }
        return arr;
    }
};
const account_expired = {
    headerList: [
        {
            title: "exp_month",
            dataIndex: "exp_month",
            width: "20%",
            render: (text, record, tr)=>{
                const [year, month] = text.split("-");
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    children: (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatDateTime */ .o0)(text, "YYYY-MM")
                });
            // return <span>{tr('exp_month', { year, month })}</span>;
            }
        },
        {
            title: "miner_count",
            dataIndex: "total_miner_count",
            width: "20%",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatNumber */ .uf)(text)
        },
        {
            title: "exp_power",
            dataIndex: "total_exp_power",
            width: "15%",
            render: (text, record)=>(0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .unitConversion */ .dN)(text, 2)
        },
        {
            title: "sector_count",
            dataIndex: "total_exp_sector_count",
            width: "15%",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatNumber */ .uf)(text)
        },
        {
            title: "exp_dc",
            dataIndex: "total_exp_dc",
            width: "15%",
            render: (text, record)=>(0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .unitConversion */ .dN)(text, 2)
        },
        {
            title: "exp_pledge",
            dataIndex: "total_exp_pledge",
            width: "15%",
            render: (text)=>renderFil(text)
        }
    ],
    columns: (tr, type)=>{
        let arr = [
            {
                title: "tag",
                dataIndex: "tag",
                width: "15%",
                ellipsis: {
                    showTitle: false
                },
                render: (text, record)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tagInput__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        isEdit: false,
                        text: text,
                        record: record
                    });
                }
            },
            {
                title: "miner_id",
                dataIndex: "miner_id",
                width: "10%",
                render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                        href: `/account#expired?miner=${text}`,
                        className: "link_text",
                        children: text
                    })
            },
            {
                title: "group_name",
                dataIndex: "group_name",
                width: "15%",
                ellipsis: {
                    showTitle: false
                },
                render: (text, record)=>{
                    const showText = record.is_default ? tr("default_group") : text;
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "bg-bg_hover text-xs text-primary rounded-[5px] p-2 w-fit",
                        children: [
                            " ",
                            showText
                        ]
                    });
                }
            },
            {
                title: "exp_power",
                dataIndex: "exp_power",
                width: "15%",
                amountUnit: {
                    exp_power: {
                        unit: "power",
                        number: 2
                    }
                },
                render: (text, record)=>(0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .unitConversion */ .dN)(text, 2)
            },
            {
                title: "sector_count",
                dataIndex: "exp_sector_count",
                width: "15%",
                render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatNumber */ .uf)(text)
            },
            {
                title: "exp_dc",
                dataIndex: "exp_dc",
                width: "15%",
                amountUnit: {
                    exp_dc: {
                        unit: "power",
                        number: 2
                    }
                },
                render: (text, record)=>(0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .unitConversion */ .dN)(text, 2)
            },
            {
                title: "exp_pledge",
                dataIndex: "exp_pledge",
                amountUnit: {
                    exp_pledge: {
                        unit: "fil",
                        number: 4
                    }
                },
                width: "15%",
                render: (text)=>renderFil(text)
            }
        ];
        if (type && type === "detail") {
            arr.unshift({
                title: "exp_time",
                dataIndex: "exp_date",
                fixed: "left",
                width: "10%",
                render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatDateTime */ .o0)(text, "YYYY-MM-DD")
            });
            arr[1].width = "10%", arr[3].width = "10%", arr[2].render = (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                    href: `/miner/${text}`,
                    className: "link_text",
                    children: text
                });
        }
        return arr;
    }
};
const account_miners = {
    groups_miners_columns: [
        {
            dataIndex: "miner_tag",
            title: "custom_tag",
            width: "45%"
        },
        {
            dataIndex: "miner_id",
            title: "miner_id",
            width: "45%",
            render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                    href: `/miner/${text}`,
                    className: "link_text",
                    children: text
                })
        },
        {
            dataIndex: "edit",
            title: "edit",
            width: "10%"
        }
    ]
};
function renderFil(text, changeText, flag = "", className, unit = "FIL") {
    const textValue = (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatFil */ .Uk)(text, unit, 4, true);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
        className: "flex flex-col",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: `${Number(text) ? "" : "text_des_unit"}`,
                children: textValue
            }),
            changeText !== undefined && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: `${changeText ? className : "text_des_unit"}`,
                children: [
                    flag + " ",
                    (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatFil */ .Uk)(Math.abs(Number(changeText)), unit, 4, true)
                ]
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6247:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(675);
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd_lib_input__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _textTooltip__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2642);
/** @format */ 



const EditableText = ({ text, record, onChange, isEdit = true })=>{
    const [isEditing, setIsEditing] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [currentText, setCurrentText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(text);
    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setCurrentText(text);
    }, [
        text
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (isEditing) {
            inputRef.current?.focus();
        }
    }, [
        isEditing
    ]);
    const handleTextClick = ()=>{
        setIsEditing(true);
    };
    const handleInputChange = async (e)=>{
        setCurrentText(e.target.value);
    //发起请求，修改标签
    };
    const handleBlur = ()=>{
        setIsEditing(false);
        if (onChange) {
            onChange(currentText);
        }
    //save current
    };
    return isEditing && isEdit ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_input__WEBPACK_IMPORTED_MODULE_2___default()), {
        ref: inputRef,
        value: currentText,
        onChange: handleInputChange,
        onBlur: handleBlur,
        showCount: true,
        maxLength: 20,
        onPressEnter: handleBlur,
        className: "!rounded-md custom_input  !w-4/5" // tailwindcss样式
    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        onClick: handleTextClick,
        className: "flex des_bg_color h-8 w-fit max-w-[200px] text-xs items-center p-2 rounded-[5px] cursor-default overflow-hidden text-ellipsis",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_textTooltip__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
            className: "cursor-default",
            text: currentText || "--"
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EditableText);


/***/ })

};
;