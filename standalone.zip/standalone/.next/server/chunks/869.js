"use strict";
exports.id = 869;
exports.ids = [869];
exports.modules = {

/***/ 60869:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var antd_lib_select__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(53526);
/* harmony import */ var antd_lib_select__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd_lib_select__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/** @format */ 


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ options, onChange, value, className = "", popupClassName = "", border, placeholder })=>{
    const [new_options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        setOptions(options || []);
    }, [
        options
    ]);
    const handleChange = (value)=>{
        onChange(value);
    };
    /*
  ${
        border ? 'border_select' : 'no_border_select'
        }
  */ return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_select__WEBPACK_IMPORTED_MODULE_1___default()), {
        showSearch: true,
        placeholder: placeholder || "Select a person",
        optionFilterProp: "children",
        value: value,
        className: `custom_select ${className}`,
        popupClassName: "custom_select_wrapper",
        filterOption: (input, option)=>(option?.label ?? "").toLowerCase().includes(input.toLowerCase()),
        options: [
            ...new_options
        ],
        onChange: handleChange
    });
});


/***/ })

};
;