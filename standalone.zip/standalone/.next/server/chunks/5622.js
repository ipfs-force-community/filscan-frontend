exports.id = 5622;
exports.ids = [5622];
exports.modules = {

/***/ 54437:
/***/ ((module) => {

// Exports
module.exports = {
	"segmented": "segmented_segmented__8wrvF",
	"item": "segmented_item__va2RW"
};


/***/ }),

/***/ 25622:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(62881);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(54437);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__]);
_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/** @format */ 





function extractPathParam(route) {
    const match = route.match(/\[([^\]]+)\]/);
    return match ? match[1] : null;
}
//分段控制器，添加锚点
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ data, defaultValue, ns, isHash = true, onChange, defaultActive })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns
    });
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(defaultValue);
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        setActive(defaultValue);
    }, [
        defaultValue
    ]);
    const handleClick = (event, tabId)=>{
        // 在当前路由上添加锚点 '#section1'
        // const scrollPosition =
        //   window.pageYOffset || document.documentElement.scrollTop;
        event.preventDefault();
        setActive(tabId);
        if (onChange) onChange(tabId);
        if (isHash) {
            // 获取动态路由参数的名称
            const paramName = extractPathParam(router.pathname);
            // 获取动态路由参数的值
            const paramValue = paramName ? router.query[paramName] : null;
            const newQuery = paramName ? {
                [paramName]: paramValue
            } : {};
            let newAsPath = paramValue ? `${router.pathname.split("[")[0]}${paramValue}#${tabId}` : `${router.pathname}#${tabId}`;
            if (tabId === defaultActive) {
                newAsPath = newAsPath.split("#")[0];
            }
            router.push({
                pathname: `${router.pathname}`,
                query: {
                    ...newQuery
                }
            }, newAsPath, {
                shallow: false,
                scroll: false
            });
        }
    // 恢复滚动条位置
    // window.scrollTo(0, scrollPosition);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
            className: classnames__WEBPACK_IMPORTED_MODULE_2___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().segmented), "list-none w-fit h-fit des_bg_color p-0.5 rounded-[5px] flex ml-2.5"),
            children: data.map((item)=>{
                const { title } = item;
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                    onClick: (e)=>handleClick(e, item.dataIndex),
                    className: classnames__WEBPACK_IMPORTED_MODULE_2___default()(`px-4  text-xs font-medium py-[5px] h-7 w-fit cursor-pointer flex items-center justify-center text_des_hover  ${active === item.dataIndex ? "tab_shadow highlight  rounded-[5px] main_bg_color" : ""}`, (_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().item)),
                    children: typeof title === "function" ? title() : tr(item.title)
                }, item.dataIndex);
            })
        })
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;