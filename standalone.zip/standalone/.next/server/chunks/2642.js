"use strict";
exports.id = 2642;
exports.ids = [2642];
exports.modules = {

/***/ 2642:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9348);
/* harmony import */ var antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_2__);
/** @format */ 


const EllipsisText = ({ text, className })=>{
    const textRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const [isOverflowing, setIsOverflowing] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const checkOverflow = ()=>{
            const element = textRef.current;
            if (element) {
                const computedStyle = window.getComputedStyle(element);
                const paddingLeft = parseFloat(computedStyle.paddingLeft);
                const paddingRight = parseFloat(computedStyle.paddingRight);
                setIsOverflowing(element.offsetWidth < element.scrollWidth + paddingLeft + paddingRight || element.offsetHeight < element.scrollHeight);
            }
        };
        window.addEventListener("resize", checkOverflow);
        checkOverflow();
        return ()=>window.removeEventListener("resize", checkOverflow);
    }, [
        text
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_2___default()), {
        title: isOverflowing ? text : "",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            ref: textRef,
            className: `overflow-hidden text-ellipsis cursor-pointer ${className}`,
            children: text
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EllipsisText);


/***/ })

};
;