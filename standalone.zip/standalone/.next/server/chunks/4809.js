exports.id = 4809;
exports.ids = [4809];
exports.modules = {

/***/ 622:
/***/ ((module) => {

// Exports
module.exports = {
	"banner": "banner_banner__3rt70",
	"banner_bg_circle1": "banner_banner_bg_circle1__vBAG3",
	"banner_bg_circle2": "banner_banner_bg_circle2___yA47",
	"banner_search": "banner_banner_search__hP_zg",
	"banner_search_input": "banner_banner_search_input__ep_FU",
	"banner_content": "banner_banner_content__5NPWC"
};


/***/ }),

/***/ 2265:
/***/ ((module) => {

// Exports
module.exports = {
	"banner": "style_banner__L3M16"
};


/***/ }),

/***/ 2358:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap": "contractRank_wrap__PgBXo",
	"title": "contractRank_title__MjRZd",
	"content": "contractRank_content__QgqgD"
};


/***/ }),

/***/ 2500:
/***/ ((module) => {

// Exports
module.exports = {
	"rank": "defi_rank__FIJ9H",
	"protocol": "defi_protocol__N4Ipx",
	"wrap": "defi_wrap__JmwCv",
	"title": "defi_title__jR8w9",
	"content": "defi_content__I4j9L"
};


/***/ }),

/***/ 845:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap": "rank_wrap__543R8",
	"title": "rank_title__EcODb",
	"content": "rank_content__yJdjL"
};


/***/ }),

/***/ 4422:
/***/ ((module) => {

// Exports
module.exports = {
	"home-page": "style_home-page__6_bZw",
	"chart-title": "style_chart-title__N0QA1",
	"label": "style_label__jibRV"
};


/***/ }),

/***/ 8355:
/***/ ((module) => {

// Exports
module.exports = {
	"meta": "style_meta__hmvXq",
	"meta-item": "style_meta-item__imNJc"
};


/***/ }),

/***/ 9930:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(622);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _header_Search__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9655);
/* harmony import */ var _src_home_Banner__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4998);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_header_Search__WEBPACK_IMPORTED_MODULE_1__, _src_home_Banner__WEBPACK_IMPORTED_MODULE_2__]);
([_header_Search__WEBPACK_IMPORTED_MODULE_1__, _src_home_Banner__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default().banner),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default().banner_bg),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default().banner_bg_bl)
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "banner-contain !h-[350px] relative",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default().banner_bg_circle1)} animated-div`
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default().banner_bg_circle2)} animated-div1`
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default().banner_search),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                    className: "clip_text text-[28px] py-2 font-Barlow font-bold",
                                    children: "Filecoin Blockchain Explorer"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_header_Search__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                    origin: "banner"
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_3___default().banner_content)}`,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_home_Banner__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
                        })
                    ]
                })
            ]
        })
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2694:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2265);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_style_module_scss__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2062);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd_lib_carousel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3029);
/* harmony import */ var antd_lib_carousel__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd_lib_carousel__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8108);
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8804);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1061);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8054);
/* harmony import */ var antd_lib_image__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8070);
/* harmony import */ var antd_lib_image__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(antd_lib_image__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_store_useAxiosData__WEBPACK_IMPORTED_MODULE_3__]);
_store_useAxiosData__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










const Banner = (props)=>{
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
    const { theme, lang } = (0,_store_FilscanStore__WEBPACK_IMPORTED_MODULE_4__/* .useFilscanStore */ .J)();
    const carousel = (0,react__WEBPACK_IMPORTED_MODULE_5__.useRef)(null);
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)([]);
    const { isMobile } = (0,_components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        loadBanner();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        lang,
        isMobile
    ]);
    const loadBanner = async ()=>{
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_7__/* .apiUrl */ .JW.home_banner, {
            category: "moblie_home",
            language: lang || "zh"
        });
        setData(result?.items || []);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_9___default().banner),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_carousel__WEBPACK_IMPORTED_MODULE_2___default()), {
            children: data?.map((item, index)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    onClick: ()=>{
                        if (item.link) {
                            window.open(item.link);
                        }
                    },
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_image__WEBPACK_IMPORTED_MODULE_8___default()), {
                        preview: false,
                        src: item.url,
                        alt: "",
                        width: "100%",
                        className: "cursor-pointer object-cover carousel-image rounded-[6px]"
                    })
                }, index);
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,mobx_react__WEBPACK_IMPORTED_MODULE_1__.observer)(Banner));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2009:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _packages_mobile_table__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(937);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2358);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _contents_contract__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5509);
/* harmony import */ var _store_modules_home__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(170);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7987);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2062);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _assets_images_verify_svg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5392);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_packages_mobile_table__WEBPACK_IMPORTED_MODULE_1__, _contents_contract__WEBPACK_IMPORTED_MODULE_3__, react_i18next__WEBPACK_IMPORTED_MODULE_5__]);
([_packages_mobile_table__WEBPACK_IMPORTED_MODULE_1__, _contents_contract__WEBPACK_IMPORTED_MODULE_3__, react_i18next__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const ContractRank = ()=>{
    const [sort, setSort] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({
        field: "transfer_count",
        order: "descend"
    });
    const { t } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_5__.useTranslation)("contract");
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_9__.useRouter)();
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        return _contents_contract__WEBPACK_IMPORTED_MODULE_3__/* .contract_rank */ .kf?.mobileColumns.filter((value, index)=>{
            if (value.dataIndex === "contract_name") {
                value.render = (text, record)=>{
                    if (text) {
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "flex gap-x-2 items-center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                    href: `/address/${record.contract_address}`,
                                    children: text
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_verify_svg__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                    width: 13,
                                    height: 14
                                })
                            ]
                        });
                    }
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                        href: "/contract/verify",
                        className: "text_color",
                        children: t("ver_address")
                    });
                };
            }
            value.title = `${t(value.title)}`;
            return _contents_contract__WEBPACK_IMPORTED_MODULE_3__/* .mobileHomeContractRank */ .XE.includes(value.dataIndex);
        });
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        _store_modules_home__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z.fetchContractRank({
            page: 1,
            limit: 10,
            sort: sort.order === "ascend" ? "asc" : "desc",
            field: sort.field
        });
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_10___default().wrap),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_10___default().title),
                children: t(_contents_contract__WEBPACK_IMPORTED_MODULE_3__/* .contract_rank */ .kf.title)
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_10___default().content),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_mobile_table__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        columns: columns,
                        dataSource: _store_modules_home__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z.contractData?.evm_contract_list,
                        pagination: false,
                        loading: false
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        onClick: ()=>{
                            router.push("/contract/rank");
                        },
                        className: "flex justify-center items-center h-[45px] text-[13px] font-DINPro-Medium text-mobile-text-warning",
                        children: t("see_more")
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,mobx_react__WEBPACK_IMPORTED_MODULE_6__.observer)(ContractRank));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4102:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _store_modules_home__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(170);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2062);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7987);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2500);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _packages_mobile_table__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(937);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3495);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_4__, _packages_mobile_table__WEBPACK_IMPORTED_MODULE_6__, _utils__WEBPACK_IMPORTED_MODULE_7__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_4__, _packages_mobile_table__WEBPACK_IMPORTED_MODULE_6__, _utils__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const Defi = ()=>{
    const { t } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)("fevm");
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_8__.useRouter)();
    const [sort, setSort] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({
        field: "tvl",
        order: "descend"
    });
    const columns = [
        {
            title: `${t("rank")}`,
            dataIndex: "rank",
            key: "rank",
            width: "15%",
            render (value, record, index) {
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().rank),
                    children: index + 1
                });
            }
        },
        {
            title: `${t("Protocol")}`,
            dataIndex: "protocol",
            key: "protocol",
            ellipsis: {
                showTitle: false
            },
            render (value, record, index) {
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().protocol),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                            fill: true,
                            src: record.icon_url,
                            alt: ""
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            style: {
                                overflow: "hidden",
                                textOverflow: "ellipsis",
                                cursor: "pointer"
                            },
                            children: value
                        })
                    ]
                });
            }
        },
        {
            title: `${t("tvl")}`,
            dataIndex: "tvl",
            key: "tvl",
            align: "right",
            render (value) {
                return (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .get$Number */ .Uy)(value);
            }
        }
    ];
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        _store_modules_home__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z.fetchHomeDefi({
            page: 1,
            limit: 10,
            field: sort.field,
            reverse: sort.order.toLocaleLowerCase() === "ascend"
        });
    }, [
        sort
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().wrap),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().title),
                children: "Defi Protocol"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_9___default().content),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_mobile_table__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        columns: columns,
                        dataSource: _store_modules_home__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z.defiData?.items,
                        pagination: false
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        onClick: ()=>{
                            router.push("/contract/rank");
                        },
                        className: "flex justify-center items-center h-[45px] text-[13px] font-DINPro-Medium text-mobile-text-warning",
                        children: t("see_more")
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,mobx_react__WEBPACK_IMPORTED_MODULE_2__.observer)(Defi));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2995:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _packages_mobile_table__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(937);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(845);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _contents_rank__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(86);
/* harmony import */ var _store_modules_home__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(170);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7987);
/* harmony import */ var _packages_progress__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2218);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3495);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2062);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_packages_mobile_table__WEBPACK_IMPORTED_MODULE_1__, _contents_rank__WEBPACK_IMPORTED_MODULE_3__, react_i18next__WEBPACK_IMPORTED_MODULE_5__, _utils__WEBPACK_IMPORTED_MODULE_7__]);
([_packages_mobile_table__WEBPACK_IMPORTED_MODULE_1__, _contents_rank__WEBPACK_IMPORTED_MODULE_3__, react_i18next__WEBPACK_IMPORTED_MODULE_5__, _utils__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const Rank = ()=>{
    const [sort, setSort] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({
        field: "power_ratio",
        order: "descend"
    });
    const { t } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_5__.useTranslation)("rank");
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_9__.useRouter)();
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        return (0,_contents_rank__WEBPACK_IMPORTED_MODULE_3__/* .getColumn */ .wD)("growth", "").filter((item)=>{
            if (item.dataIndex === "rank") {
                item.width = "15%";
                item.align = "left";
            }
            if (item.dataIndex === "miner_id") {
                item.width = "30%";
            }
            if (item.title === "power_ratio") {
                item.align = "right";
                item.width = "0";
                item.render = (value, render)=>{
                    const left = 100 - Number(value) / Number(render.power_ratio) * 100;
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: "flex justify-end gap-x-2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_progress__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                left: left + "%"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .unitConversion */ .dN)(value, 2) + "/D"
                            })
                        ]
                    });
                };
            }
            item.title = t(item.title);
            return _contents_rank__WEBPACK_IMPORTED_MODULE_3__/* .mobileRankList */ .vc.includes(item.dataIndex);
        });
    }, [
        t
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        load();
    }, [
        sort
    ]);
    const load = ()=>{
        _store_modules_home__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z.fetchMinerPowerRank({
            index: 1,
            limit: 10,
            interval: "24h",
            order: {
                sort: sort.order === "ascend" ? "asc" : "desc",
                field: sort.field
            },
            sector_size: null
        });
    };
    const handleChange = (pagination, filters, sorter)=>{
        let order = {
            ...sort
        };
        if (sorter?.field) {
            if (sorter.order) {
                order = {
                    field: sorter.field,
                    order: sorter.order
                };
            } else {
                order = {
                    field: "power_ratio",
                    order: "descend"
                };
            }
        }
        setSort(order);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_10___default().wrap),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_10___default().title),
                children: t("growth")
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_10___default().content),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_mobile_table__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        onChange: handleChange,
                        columns: columns,
                        dataSource: _store_modules_home__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z.minerPowerRankData?.items,
                        pagination: false
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        onClick: ()=>{
                            router.push("/rank#growth");
                        },
                        className: "flex justify-center items-center h-[45px] text-[13px] font-DINPro-Medium text-mobile-text-warning",
                        children: t("see_more")
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,mobx_react__WEBPACK_IMPORTED_MODULE_8__.observer)(Rank));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4809:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_banner__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9930);
/* harmony import */ var _components_mobile_home_banner__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2694);
/* harmony import */ var _src_home_meta__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8842);
/* harmony import */ var _src_statistics_Gas__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(58);
/* harmony import */ var _src_rank__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5506);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2881);
/* harmony import */ var _assets_images_black_go_svg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3309);
/* harmony import */ var _assets_images_icon_right_white_svg__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(821);
/* harmony import */ var _src_contract_rank__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6789);
/* harmony import */ var _src_fevm_defi__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9412);
/* harmony import */ var _src_statistics_Trend__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1538);
/* harmony import */ var _components_hooks_useObserver__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8187);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9676);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(4422);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(_style_module_scss__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _components_mobile_home_defi__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(4102);
/* harmony import */ var _components_mobile_home_contractRank__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(2009);
/* harmony import */ var _components_mobile_home_rank__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(2995);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _src_statistics_ContractTrend__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(4313);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_banner__WEBPACK_IMPORTED_MODULE_1__, _components_mobile_home_banner__WEBPACK_IMPORTED_MODULE_2__, _src_home_meta__WEBPACK_IMPORTED_MODULE_3__, _src_statistics_Gas__WEBPACK_IMPORTED_MODULE_4__, _src_rank__WEBPACK_IMPORTED_MODULE_5__, _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_7__, _src_contract_rank__WEBPACK_IMPORTED_MODULE_10__, _src_fevm_defi__WEBPACK_IMPORTED_MODULE_11__, _src_statistics_Trend__WEBPACK_IMPORTED_MODULE_12__, _components_mobile_home_defi__WEBPACK_IMPORTED_MODULE_15__, _components_mobile_home_contractRank__WEBPACK_IMPORTED_MODULE_16__, _components_mobile_home_rank__WEBPACK_IMPORTED_MODULE_17__, _src_statistics_ContractTrend__WEBPACK_IMPORTED_MODULE_19__]);
([_components_banner__WEBPACK_IMPORTED_MODULE_1__, _components_mobile_home_banner__WEBPACK_IMPORTED_MODULE_2__, _src_home_meta__WEBPACK_IMPORTED_MODULE_3__, _src_statistics_Gas__WEBPACK_IMPORTED_MODULE_4__, _src_rank__WEBPACK_IMPORTED_MODULE_5__, _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_7__, _src_contract_rank__WEBPACK_IMPORTED_MODULE_10__, _src_fevm_defi__WEBPACK_IMPORTED_MODULE_11__, _src_statistics_Trend__WEBPACK_IMPORTED_MODULE_12__, _components_mobile_home_defi__WEBPACK_IMPORTED_MODULE_15__, _components_mobile_home_contractRank__WEBPACK_IMPORTED_MODULE_16__, _components_mobile_home_rank__WEBPACK_IMPORTED_MODULE_17__, _src_statistics_ContractTrend__WEBPACK_IMPORTED_MODULE_19__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ //import type { InferGetServerSidePropsType, GetServerSideProps } from 'next'





















function Home(props) {
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_7__/* .Translation */ .W)({
        ns: "home"
    });
    const ref = (0,_components_hooks_useObserver__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z)();
    const ref1 = (0,_components_hooks_useObserver__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_20___default()["home-page"]),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_14__/* .MobileView */ .$, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_mobile_home_banner__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_14__/* .BrowserView */ .I, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_banner__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {})
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "main_contain !mt-[26px]",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex justify-between h-[270px] gap-x-5 meta-gas ",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_home_meta__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "border card_shadow w-[403px] h-[270px] rounded-xl border_color gas-wrap",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_14__/* .BrowserView */ .I, {
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: `flex justify-between text-xs font-PingFang p-5`,
                                                    children: [
                                                        tr("base_gas"),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                            href: `/statistics/gas/`,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_black_go_svg__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                                className: "cursor-pointer",
                                                                width: 18,
                                                                height: 18
                                                            })
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_14__/* .MobileView */ .$, {
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_20___default()["chart-title"]),
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_20___default().label),
                                                            children: tr("base_gas")
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                            href: `/statistics/gas/`,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_icon_right_white_svg__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                                className: "cursor-pointer",
                                                                width: 28,
                                                                height: 28
                                                            })
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_statistics_Gas__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                className: "w-full !h-[210px]"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex justify-between mt-12 gap-x-5 h-[400px] box-column",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_statistics_Trend__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                        origin: "home",
                                        className: "flex-1 w-full !h-full"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_statistics_ContractTrend__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {
                                        origin: "home",
                                        className: "flex-1 w-full !h-full"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_device_detect__WEBPACK_IMPORTED_MODULE_14__/* .BrowserView */ .I, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "mt-32",
                                        ref: ref,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_rank__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                            origin: "home"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex gap-x-5 mt-12",
                                        ref: ref1,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "w-1/2",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_contract_rank__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                                    origin: "home"
                                                })
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "w-1/2",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: `flex justify-between items-center h-[30px] px-2.5`,
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "font-PingFang font-semibold text-lg",
                                                                children: tr("defi_list")
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                                href: `/contract/rank`,
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_black_go_svg__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                                    className: "cursor-pointer",
                                                                    width: 18,
                                                                    height: 18
                                                                })
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_fevm_defi__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                                        origin: "home"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_14__/* .MobileView */ .$, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: classnames__WEBPACK_IMPORTED_MODULE_18___default()("px-[12px]"),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_mobile_home_rank__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_mobile_home_contractRank__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_mobile_home_defi__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {})
                    ]
                })
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Home);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4998:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var antd_lib_carousel__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3029);
/* harmony import */ var antd_lib_carousel__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd_lib_carousel__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var antd_lib_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8070);
/* harmony import */ var antd_lib_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(antd_lib_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8108);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8054);
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8804);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_store_useAxiosData__WEBPACK_IMPORTED_MODULE_4__]);
_store_useAxiosData__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







function Banner() {
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
    const { theme, lang } = (0,_store_FilscanStore__WEBPACK_IMPORTED_MODULE_6__/* .useFilscanStore */ .J)();
    const carousel = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(null);
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        loadBanner();
    }, [
        lang
    ]);
    const loadBanner = async ()=>{
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_5__/* .apiUrl */ .JW.home_banner, {
            category: "new_home",
            language: lang || "zh"
        });
        setData(result?.items || []);
    };
    if (data.length === 0) {
        return null;
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "group relative overflow-hidden w-full h-full",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_carousel__WEBPACK_IMPORTED_MODULE_1___default()), {
            autoplay: false,
            autoplaySpeed: 5000,
            ref: carousel,
            infinite: true,
            children: [
                ...data
            ]?.map((item, index)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    onClick: ()=>{
                        if (item.link) {
                            window.open(item.link);
                        }
                    },
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                        preview: false,
                        src: item.url,
                        alt: "",
                        width: "100%",
                        className: "rounded-2xl cursor-pointer object-cover carousel-image"
                    })
                }, index);
            })
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Banner);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8842:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2881);
/* harmony import */ var _contents_home__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9729);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(8355);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_style_module_scss__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8108);
/* harmony import */ var _packages_skeleton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8465);
/* harmony import */ var _packages_tooltip__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2305);
/* harmony import */ var _components_hooks_useInterval__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9447);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9676);
/* harmony import */ var _assets_images_black_go_svg__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3309);
/* harmony import */ var _assets_images_icon_right_white_svg__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(821);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_home__WEBPACK_IMPORTED_MODULE_3__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_6__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_home__WEBPACK_IMPORTED_MODULE_3__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 














function Meta() {
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__/* .Translation */ .W)({
        ns: "home"
    });
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)();
    const [contractData, setContractData] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)();
    (0,_components_hooks_useInterval__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)(()=>{
        load();
    }, 5 * 60 * 1000);
    const load = async ()=>{
        const data = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.home_meta);
        setData(data?.total_indicators || {});
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .EvmContractSummary */ .Uh);
        setContractData(result || {});
    };
    // useInterval(() => {
    //   loadInterval();
    // }, 15000);
    const loadInterval = async ()=>{
        const lastData = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.tipset_chain_FinalHeight);
    // postAxios(apiUrl.tipset_chain_FinalHeight).then((res: any) => {
    //   const data = res?.result || {};
    //   setLast({
    //     latest_height: data.height,
    //     latest_block_time: data.block_time,
    //   });
    // });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        //ref={ref}
        style: {
            overflow: "hidden"
        },
        className: classnames__WEBPACK_IMPORTED_MODULE_5___default()((_style_module_scss__WEBPACK_IMPORTED_MODULE_14___default().meta), `relative border card_shadow flex-1 items-center h-[270px] inline-grid grid-cols-4 gap-2 pl-10 pr-6  py-10 rounded-xl border_color overflow-hidden`),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_10___default()), {
                href: `/statistics/charts#networks`,
                className: "absolute right-2 top-5",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_11__/* .MobileView */ .$, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_icon_right_white_svg__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                            width: 28,
                            height: 28
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_11__/* .BrowserView */ .I, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_black_go_svg__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                            className: "cursor-pointer mr-2.5",
                            width: 18,
                            height: 18
                        })
                    })
                ]
            }),
            _contents_home__WEBPACK_IMPORTED_MODULE_3__/* .home_meta */ .nW.map((item, index)=>{
                const { render, dataIndex, title } = item;
                const dataSource = {
                    ...data,
                    ...contractData
                };
                const value = dataSource && dataSource[dataIndex] || "";
                let renderDom = value;
                let tipContent;
                if (item.tipContent && Array.isArray(item.tipContent)) {
                    tipContent = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                        className: "px-2 pt-2 w-fit",
                        children: item.tipContent.map((tipItem)=>{
                            let tipValue = dataSource[tipItem.dataIndex];
                            if (tipItem.render) {
                                tipValue = tipItem.render(tipValue, dataSource);
                            }
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                className: "mb-2.5",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "min-w-[80px] w-fit",
                                        children: [
                                            tr(tipItem.title),
                                            ":"
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "w-fit ml-1",
                                        children: tipValue
                                    })
                                ]
                            }, tipItem.dataIndex);
                        })
                    });
                }
                if (data) {
                    renderDom = render && render(value, {
                        ...data,
                        ...contractData
                    });
                }
                if (item.tipContent) {
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: `${(_style_module_scss__WEBPACK_IMPORTED_MODULE_14___default()["meta-item"])} cursor-pointer relative`,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tooltip__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                context: tipContent,
                                icon: false,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "text_clip DINPro-Bold font-bold text-xl",
                                    children: [
                                        !value && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_skeleton__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}),
                                        renderDom
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex items-center gap-x-1 text-xs text_des mt-1 font-PingFang",
                                children: [
                                    tr(title),
                                    item.tip && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tooltip__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                        context: tr(item.tip),
                                        icon: true
                                    })
                                ]
                            })
                        ]
                    }, item.dataIndex);
                }
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_style_module_scss__WEBPACK_IMPORTED_MODULE_14___default()["meta-item"]),
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "text_clip DINPro-Bold font-bold text-xl",
                            children: [
                                !value && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_skeleton__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}),
                                renderDom
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex items-center gap-x-1 text-xs text_des mt-1 font-PingFang",
                            children: [
                                tr(title),
                                item.tip && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tooltip__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                    context: tr(item.tip),
                                    icon: true
                                })
                            ]
                        })
                    ]
                }, item.dataIndex);
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Meta);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4313:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _components_echarts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3778);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2881);
/* harmony import */ var _contents_statistic__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4852);
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8804);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3495);
/* harmony import */ var _utils_echarts__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7355);
/* harmony import */ var _assets_images_icon_right_white_svg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(821);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _components_hooks_useObserver__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8187);
/* harmony import */ var _trend_module_scss__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1161);
/* harmony import */ var _trend_module_scss__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_trend_module_scss__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9676);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(8108);
/* harmony import */ var _packages_select__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(6423);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_statistic__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_6__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_14__, _packages_select__WEBPACK_IMPORTED_MODULE_15__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_statistic__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_6__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_14__, _packages_select__WEBPACK_IMPORTED_MODULE_15__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 
















/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { origin, className } = props;
    const { theme, lang } = (0,_store_FilscanStore__WEBPACK_IMPORTED_MODULE_5__/* .useFilscanStore */ .J)();
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__/* .Translation */ .W)({
        ns: "static"
    });
    const ref = (0,_components_hooks_useObserver__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)();
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z)();
    const [noShow, setNoShow] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)({});
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)({});
    const [interval, setInterval] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)("1m");
    const color = (0,react__WEBPACK_IMPORTED_MODULE_10__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_7__/* .getColor */ .Lq)(theme);
    }, [
        theme
    ]);
    const default_xAxis = (0,react__WEBPACK_IMPORTED_MODULE_10__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_7__/* .get_xAxis */ .Fs)(theme);
    }, [
        theme
    ]);
    const defaultOptions = (0,react__WEBPACK_IMPORTED_MODULE_10__.useMemo)(()=>{
        return {
            grid: {
                top: 30,
                left: 20,
                right: 20,
                bottom: 20,
                containLabel: true
            },
            yAxis: {
                type: "value",
                position: "left",
                scale: true,
                nameTextStyle: {
                    color: color.textStyle
                },
                axisLabel: {
                    formatter: "{value}",
                    textStyle: {
                        //  fontSize: this.fontSize,
                        color: color.labelColor
                    }
                },
                axisLine: {
                    show: false
                },
                axisTick: {
                    show: false
                },
                splitLine: {
                    show: true,
                    lineStyle: {
                        type: "dashed",
                        color: color.splitLine
                    }
                }
            },
            legend: {
                show: false
            },
            tooltip: {
                //@ts-ignore
                position: function(pos, params, dom, rect, size) {
                    // 鼠标在左侧时 tooltip 显示到右侧，鼠标在右侧时 tooltip 显示到左侧。
                    var obj = {
                        top: 80
                    };
                    //@ts-ignore
                    obj[[
                        "left",
                        "right"
                    ][+(pos[0] < size.viewSize[0] / 2)]] = 5;
                    return (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .isMobile */ .tq)() ? obj : undefined;
                },
                trigger: "axis",
                backgroundColor: color.toolbox,
                borderColor: "transparent",
                textStyle: {
                    color: "#ffffff"
                },
                formatter (v) {
                    var result = v[0].data.showTime;
                    v.forEach((item)=>{
                        if (item.data) {
                            result += "<br/>" + item.marker + tr(item.seriesName) + ": " + item.data.amount + item.data.unit;
                        }
                    });
                    return result;
                }
            }
        };
    }, [
        theme,
        tr
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_10__.useEffect)(()=>{
        load();
    }, []);
    const load = async (time)=>{
        const seriesObj = {};
        _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .contract_trend */ .ZQ.list.forEach((v)=>{
            seriesObj[v.dataIndex] = [];
        });
        const dateList = [];
        const seriesData = [];
        const inter = time || interval;
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .EvmTxsHistory */ .i5, {
            interval: inter
        });
        result?.points?.forEach((value)=>{
            const { timestamp, txs_count } = value;
            const showTime = inter === "24h" ? (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatDateTime */ .o0)(timestamp, "HH:mm") : (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatDateTime */ .o0)(timestamp, "MM-DD HH:mm");
            dateList.push(showTime);
            //amount
            seriesObj.txs_count.push({
                amount: txs_count,
                value: txs_count,
                showTime: (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatDateTime */ .o0)(timestamp, "YYYY-MM-DD HH:mm"),
                unit: ""
            });
        });
        _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .contract_trend */ .ZQ.list.forEach((item)=>{
            seriesData.push({
                type: item.type,
                data: seriesObj[item.dataIndex],
                name: item.title,
                symbol: "circle",
                smooth: true,
                itemStyle: {
                    color: item.color
                },
                barMaxWidth: "30"
            });
        });
        setOptions({
            series: seriesData,
            xData: dateList
        });
    };
    const newOptions = (0,react__WEBPACK_IMPORTED_MODULE_10__.useMemo)(()=>{
        const newSeries = [];
        (options?.series || []).forEach((seriesItem)=>{
            if (!noShow[seriesItem?.name]) {
                newSeries.push(seriesItem);
            }
        });
        return {
            ...defaultOptions,
            xAxis: {
                ...default_xAxis,
                data: options?.xData || []
            },
            series: newSeries
        };
    }, [
        options,
        defaultOptions,
        noShow
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_12___default()((_trend_module_scss__WEBPACK_IMPORTED_MODULE_16___default().trend), `w-full h-[full]  ${className} mt-20`),
        ref: origin === "home" ? ref : "",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: `flex justify-between flex-wrap items-center min-h-[36px] mb-2.5 ${lang === "en" ? "h-[60px]" : ""}`,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex-1 flex flex-row flex-wrap items-center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "min-w-[120px] w-fit font-PingFang font-semibold text-lg pl-2.5",
                            children: tr("contract_trend")
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: origin === "home" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_13__/* .MobileView */ .$, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_9___default()), {
                                        href: `/statistics/charts#contract`,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_icon_right_white_svg__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                            width: 28,
                                            height: 28
                                        })
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_13__/* .BrowserView */ .I, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "flex gap-x-4 items-center mx-2.5",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_select__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                            ns: "static",
                                            options: _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .timeList */ .t9,
                                            value: interval,
                                            onChange: (interval)=>{
                                                setInterval(interval);
                                                load(interval);
                                            }
                                        }, `static_${origin}_contract`)
                                    })
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `h-[350px] w-full card_shadow border border_color pb-2 rounded-xl`,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    options: newOptions
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 170:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6211);
/* harmony import */ var mobx__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mobx__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _server__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(785);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);



class HomeStore {
    constructor(){
        this.meta = {
            power_increase_24h: "0",
            add_power_in_32g: "0",
            miner_initial_pledge: "0",
            fil_per_tera_24h: "0",
            total_contract: "0",
            contract_transaction: "0",
            contract_address: "0",
            gas_24: "0"
        };
        this.fee = [];
        this.defiData = undefined;
        this.contractData = undefined;
        this.minerPowerRankData = undefined;
        (0,mobx__WEBPACK_IMPORTED_MODULE_0__.makeObservable)(this, {
            meta: mobx__WEBPACK_IMPORTED_MODULE_0__.observable,
            fee: mobx__WEBPACK_IMPORTED_MODULE_0__.observable,
            defiData: mobx__WEBPACK_IMPORTED_MODULE_0__.observable,
            contractData: mobx__WEBPACK_IMPORTED_MODULE_0__.observable,
            minerPowerRankData: mobx__WEBPACK_IMPORTED_MODULE_0__.observable,
            fetchContractRank: mobx__WEBPACK_IMPORTED_MODULE_0__.action
        });
    }
    /**
   *
   * @param params
   */ async fetchHomeDefi(params) {
        params.page = params.page - 1;
        const result = await (0,_server__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.fevm_defiList, params);
        if (!result.error) {
            this.defiData = result;
        }
    }
    async fetchContractRank(data) {
        data.page = data.page - 1;
        const res = await (0,_server__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.contract_rank, data);
        if (!res.error) {
            (0,mobx__WEBPACK_IMPORTED_MODULE_0__.runInAction)(()=>{
                this.contractData = res;
            });
        }
    }
    async fetchMinerPowerRank(data) {
        data.index = data.index - 1;
        const res = await (0,_server__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.rank_growth, data);
        if (!res.error) {
            (0,mobx__WEBPACK_IMPORTED_MODULE_0__.runInAction)(()=>{
                this.minerPowerRankData = res;
            });
        }
    }
}
const homeStore = new HomeStore();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (homeStore);


/***/ })

};
;