"use strict";
exports.id = 58;
exports.ids = [58];
exports.modules = {

/***/ 90058:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(48804);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(62881);
/* harmony import */ var _utils_echarts__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7355);
/* harmony import */ var _components_echarts__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(13778);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8054);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(23495);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(68108);
/* harmony import */ var _components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(31061);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _utils__WEBPACK_IMPORTED_MODULE_7__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _utils__WEBPACK_IMPORTED_MODULE_7__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 









//仅含基础费
const showData = [
    {
        label: "base_fee",
        type: "line",
        unit: "nanoFIL"
    }
];
function Gas(props) {
    const { theme, lang } = (0,_store_FilscanStore__WEBPACK_IMPORTED_MODULE_2__/* .useFilscanStore */ .J)();
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__/* .Translation */ .W)({
        ns: "static"
    });
    const { active = "24h", className = "" } = props;
    const [value, setValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(active);
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    const [unit, setUnit] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { isMobile } = (0,_components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
    const color = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_4__/* .getColor */ .Lq)(theme);
    }, [
        theme
    ]);
    const default_xAxis = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_4__/* .get_xAxis */ .Fs)(theme, isMobile);
    }, [
        theme,
        isMobile
    ]);
    const defaultOptions = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        let options = {
            yAxis: {
                type: "value",
                //scale: true,
                axisLabel: {
                    fontFamily: "DINPro",
                    fontSize: 14,
                    color: isMobile ? color.mobileLabelColor : color.labelColor,
                    formatter (v) {
                        return (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatNumber */ .uf)(v) + "" + unit;
                    }
                },
                axisTick: {
                    show: false
                },
                axisLine: {
                    show: false,
                    lineStyle: {
                        color: color.lineStyle
                    }
                },
                splitLine: {
                    show: true,
                    lineStyle: {
                        type: "dashed",
                        color: color.splitLine
                    }
                }
            },
            legend: {
                show: false
            },
            tooltip: {
                trigger: "axis",
                backgroundColor: color.toolbox,
                borderColor: "transparent",
                textStyle: {
                    color: "#ffffff"
                },
                formatter (v) {
                    var result = v[0].data.timestamp || v[0].name;
                    v.forEach((item, index)=>{
                        if (item.data) {
                            result += "<br/>" + item.marker + item.seriesName + ": " + item.data.showValue + " " + item.data.showUnit;
                        }
                    });
                    return result;
                }
            }
        };
        if (isMobile) {
            options["grid"] = {
                top: "5%",
                right: "20px",
                bottom: "0%",
                left: "12px",
                containLabel: true
            };
        }
        return options;
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        theme,
        isMobile,
        unit
    ]);
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setValue(active);
        load(active);
    }, [
        active
    ]);
    const load = (inter)=>{
        const interval = inter || value;
        const dateList = [];
        const seriesObj = {
            base_fee: []
        };
        const newOpt = {};
        let maxGas = 0;
        let showUnit = "";
        axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_6__/* .apiUrl */ .JW.static_gas, {
            interval
        }).then((res)=>{
            res?.list?.forEach((vItem)=>{
                const { timestamp, base_fee, gas_in_32g, gas_in_64g } = vItem;
                maxGas = maxGas > Number(base_fee) ? maxGas : Number(base_fee);
            });
            if (maxGas) {
                showUnit = (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatFilNum */ .Nm)(maxGas, false, false, 4, false).split(" ")[1];
                setUnit(showUnit);
            }
            res?.list?.forEach((dataItem)=>{
                const { timestamp, base_fee, gas_in_32g, gas_in_64g } = dataItem;
                let showTime = "";
                if (value === "24h") {
                    const newTime = timestamp.split(" ")[1];
                    showTime = newTime.split(":")[0] + ":" + newTime.split(":")[1];
                } else {
                    showTime = timestamp.split("+")[0];
                }
                dateList.push(showTime);
                seriesObj.base_fee.push({
                    value: (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatFil */ .Uk)(base_fee, showUnit),
                    showValue: (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatFilNum */ .Nm)(base_fee, false, false, 4, false).split(" ")[0],
                    showUnit: (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatFilNum */ .Nm)(base_fee, false, false, 4, false).split(" ")[1],
                    timestamp: timestamp.split("+")[0]
                });
            });
            newOpt.xData = dateList;
            newOpt.series = [];
            showData.forEach((item)=>{
                newOpt.series.push({
                    type: item.type,
                    ..._utils_echarts__WEBPACK_IMPORTED_MODULE_4__/* .seriesArea */ .IV,
                    data: seriesObj[item.label],
                    name: tr(item.label),
                    smooth: false,
                    yAxisIndex: item.yIndex,
                    symbol: "none",
                    unit: item.unit
                });
            });
            setOptions({
                ...newOpt
            });
        });
    };
    const newOptions = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        return {
            ...defaultOptions,
            xAxis: {
                ...default_xAxis,
                data: options?.xData || []
            },
            series: options?.series || []
        };
    }, [
        options,
        defaultOptions
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: `w-full h-full ${className}`,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
            options: newOptions
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Gas);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;