exports.id = 7103;
exports.ids = [7103];
exports.modules = {

/***/ 7689:
/***/ ((module) => {

// Exports
module.exports = {
	"skeleton_screen": "skeleton_skeleton_screen__0AC9J",
	"loading": "skeleton_loading__ww4DW"
};


/***/ }),

/***/ 7195:
/***/ ((module) => {

// Exports
module.exports = {
	"reset": "defi_reset__zoq5_",
	"wrap": "defi_wrap__ccGkr",
	"rank": "defi_rank__dvkDO"
};


/***/ }),

/***/ 2059:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   L_: () => (/* binding */ defi_list),
/* harmony export */   RJ: () => (/* binding */ homeDefiColumns),
/* harmony export */   hw: () => (/* binding */ defi_market)
/* harmony export */ });
/* unused harmony export mobileHomeDefiColumns */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _packages_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2964);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3495);
/* harmony import */ var _packages_textTooltip__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2642);
/* harmony import */ var _packages_progress__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2218);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils__WEBPACK_IMPORTED_MODULE_2__]);
_utils__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/** @format */ 




const mobilColumns = [
    {
        title: "rank",
        dataIndex: "rank",
        key: "rank",
        render (value, record, index) {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: index + 1
            });
        }
    },
    {
        title: "Protocol",
        // width: '25%',
        dataIndex: "protocol",
        key: "protocol",
        render (value, record, index) {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: value
            });
        }
    },
    {
        title: "tvl",
        // width: '15%',
        dataIndex: "tvl",
        key: "tvl",
        render (value, record, index) {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: value
            });
        }
    },
    {
        title: "tvl_change_rate_in_24h",
        sorter: true,
        // width: '20%',
        dataIndex: "tvl_change_rate_in_24h",
        key: "tvl_change_rate_in_24h",
        render (value, record, index) {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: value
            });
        }
    }
];
const defi_market = [
    {
        title: "fevm_staked",
        dataIndex: "fevm_staked",
        render: (text, record)=>(0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .get$Number */ .Uy)(text)
    },
    {
        title: "staked_change_in_24h",
        dataIndex: "staked_change_in_24h",
        render: (text, record)=>{
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: Number(text) < 0 ? "text_red" : "text_green",
                children: [
                    Number(text) > 0 ? "+" : "",
                    (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .get$Number */ .Uy)(text)
                ]
            });
        }
    },
    {
        title: "total_user",
        dataIndex: "total_user",
        render: (text, record)=>{
            return (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatNumber */ .uf)(text, 2);
        }
    },
    {
        title: "user_change_in_24h",
        dataIndex: "user_change_in_24h",
        render: (text, record)=>{
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: Number(text) < 0 ? "text_red" : "text_green",
                children: [
                    Number(text) > 0 ? "+" : "",
                    (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatNumber */ .uf)(text, 2)
                ]
            });
        }
    },
    {
        title: "fil_staked",
        dataIndex: "fil_staked",
        render: (text, record)=>{
            return (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatNumber */ .uf)(text, 2) + " FIL";
        }
    }
];
const defi_list = {
    title: "defi_list",
    total_msg: "defi_list_total",
    columns: (progress, origin)=>[
            {
                title: "rank",
                dataIndex: "rank",
                width: "5%",
                render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "rank_icon",
                        children: text
                    })
            },
            {
                title: "Protocol",
                width: "25%",
                dataIndex: "protocol",
                render: (text, record)=>{
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: "flex items-center gap-x-1",
                        onClick: ()=>{
                            if (record.main_site) {
                                window.open(record.main_site);
                            }
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_image__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                src: record.icon_url || "",
                                width: 32,
                                height: 32,
                                alt: "logo"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_textTooltip__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                text: text
                            })
                        ]
                    });
                }
            },
            {
                title: "tvl",
                dataIndex: "tvl",
                width: "20%",
                defaultSortOrder: "descend",
                sorter: true,
                render: (text, record)=>{
                    if (origin === "home") {
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_textTooltip__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            text: (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .get$Number */ .Uy)(text)
                        });
                    }
                    const left = 100 - Number(text) / Number(progress) * 100;
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: "flex items-center gap-x-2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_progress__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                left: left + "%"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .get$Number */ .Uy)(text)
                            })
                        ]
                    });
                }
            },
            {
                dataIndex: "tvl_change_rate_in_24h",
                title: "tvl_change_rate_in_24h",
                sorter: true,
                width: "15%",
                render: (text)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: Number(text) < 0 ? "text_red" : "text_green",
                        children: [
                            Number(text) > 0 ? "+" : "",
                            Number(text).toFixed(2) + "%"
                        ]
                    })
            },
            {
                dataIndex: "tvl_change_in_24h",
                title: "tvl_change_in_24h",
                sorter: true,
                width: "15%",
                render: (text)=>{
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: Number(text) < 0 ? "text_red" : "text_green",
                        children: [
                            Number(text) > 0 ? "+" : "",
                            (0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .get$Number */ .Uy)(text)
                        ]
                    });
                }
            },
            {
                dataIndex: "users",
                title: "users",
                width: "10%",
                sorter: true,
                render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_2__/* .formatNumber */ .uf)(text)
            },
            {
                dataIndex: "tokens",
                title: "tokens",
                width: "10%",
                render: (text)=>{
                    if (Array.isArray(text)) {
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                            className: "flex items-center gap-x-4",
                            children: text.map((item_t, index)=>{
                                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                    className: "flex items-center gap-x-1",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_image__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                            src: item_t.icon_url,
                                            width: 20,
                                            height: 20,
                                            alt: "",
                                            style: {
                                                borderRadius: "50%"
                                            }
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            className: "margin-6",
                                            children: [
                                                item_t.rate,
                                                "%"
                                            ]
                                        })
                                    ]
                                }, index);
                            })
                        });
                    }
                    return "--";
                }
            }
        ],
    mobilColumns: mobilColumns
};
const homeDefiColumns = {
    rank: "10%",
    protocol: "25%",
    tvl: "20%",
    tvl_change_rate_in_24h: "30%",
    users: ""
};
const mobileHomeDefiColumns = (/* unused pure expression or super */ null && ([
    "rank",
    "protocol",
    "tvl",
    "tvl_change_rate_in_24h"
]));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8465:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7689);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_2__);
/** @format */ 


function SkeletonScreen() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_2___default().skeleton_screen)
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SkeletonScreen);


/***/ }),

/***/ 9412:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2881);
/* harmony import */ var _packages_Table__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(430);
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8804);
/* harmony import */ var _store_server__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(785);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _contents_fevm__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2059);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3495);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(7195);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1061);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _packages_textTooltip__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2642);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _packages_Table__WEBPACK_IMPORTED_MODULE_3__, _contents_fevm__WEBPACK_IMPORTED_MODULE_6__, _utils__WEBPACK_IMPORTED_MODULE_7__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _packages_Table__WEBPACK_IMPORTED_MODULE_3__, _contents_fevm__WEBPACK_IMPORTED_MODULE_6__, _utils__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 













const default_sort = {
    field: "tvl",
    order: "descend"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ origin })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__/* .Translation */ .W)({
        ns: "fevm"
    });
    const { theme } = (0,_store_FilscanStore__WEBPACK_IMPORTED_MODULE_4__/* .useFilscanStore */ .J)();
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    const [current, setCurrent] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(1);
    const [sort, setSort] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)({
        ...default_sort
    });
    const { isMobile } = (0,_components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
    const [progress, setProgress] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(0);
    const [dataSource, setDataSource] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)({
        data: [],
        total: undefined
    });
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        load();
    }, []);
    const load = async (cur, sorter)=>{
        setLoading(true);
        const page = cur || current;
        const sortData = sorter || sort;
        const result = await (0,_store_server__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.fevm_defiList, {
            page: page - 1,
            limit: origin === "home" ? _utils__WEBPACK_IMPORTED_MODULE_7__/* .pageHomeLimit */ .m$ : _utils__WEBPACK_IMPORTED_MODULE_7__/* .pageLimit */ .P5,
            field: sortData.field,
            reverse: sortData.order === "ascend"
        });
        setLoading(false);
        setDataSource({
            data: result?.items?.map((v, index)=>{
                return {
                    ...v,
                    rank: index * page + 1
                };
            }) || [],
            total: result?.total
        });
        if (sortData.field === default_sort.field && sortData.order === "descend") {
            //默认排序，pr
            setProgress(result?.items[0]?.tvl || 0);
        }
    };
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_5__.useMemo)(()=>{
        const newArr = [];
        _contents_fevm__WEBPACK_IMPORTED_MODULE_6__/* .defi_list */ .L_.columns(progress, origin).forEach((col)=>{
            if (origin === "home") {
                if (_contents_fevm__WEBPACK_IMPORTED_MODULE_6__/* .homeDefiColumns */ .RJ.hasOwnProperty(col.dataIndex)) {
                    newArr.push({
                        ...col,
                        title: tr(col.title),
                        width: _contents_fevm__WEBPACK_IMPORTED_MODULE_6__/* .homeDefiColumns */ .RJ[col.dataIndex]
                    });
                }
            } else {
                if (isMobile) {
                    if (col.dataIndex === "protocol") {
                        return;
                    }
                    if (col.dataIndex === "rank") {
                        //@ts-ignore
                        col.title = (value, record, index)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: `#${record?.rank}`
                            });
                        };
                        col.render = (text, record)=>{
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_13___default().rank),
                                onClick: ()=>{
                                    if (record.main_site) {
                                        window.open(record.main_site);
                                    }
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_10___default()), {
                                        src: record.icon_url || "",
                                        width: 25,
                                        height: 25,
                                        alt: "logo"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_textTooltip__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                        text: record.protocol
                                    })
                                ]
                            });
                        };
                    }
                }
                newArr.push({
                    ...col,
                    title: typeof col.title === "string" ? tr(col.title) : col.title
                });
            }
        });
        return newArr;
    }, [
        theme,
        tr,
        progress
    ]);
    const handleChange = (pagination, filters, sorter)=>{
        let cur = pagination.current || current;
        let order = {
            ...sort
        };
        if (sorter.field) {
            order = {
                field: sorter.field,
                order: sorter.order
            };
            cur = 1;
        }
        setCurrent(1);
        setSort(order);
        load(cur, order);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()(`mt-4 border rounded-xl p-5	card_shadow border_color ${origin === "home" ? "h-[650px]" : "h-full"}`, (_index_module_scss__WEBPACK_IMPORTED_MODULE_13___default().wrap), (_index_module_scss__WEBPACK_IMPORTED_MODULE_13___default().reset)),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_Table__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
            className: "-mt-2.5 ",
            data: dataSource?.data || [],
            columns: columns || [],
            loading: loading,
            onChange: handleChange
        }, "contract_rank")
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;