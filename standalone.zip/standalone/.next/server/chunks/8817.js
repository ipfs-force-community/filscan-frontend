exports.id = 8817;
exports.ids = [8817];
exports.modules = {

/***/ 1982:
/***/ ((module) => {

// Exports
module.exports = {
	"select": "customDrop_select__MhnyQ",
	"drop-menu": "customDrop_drop-menu__BQXIM"
};


/***/ }),

/***/ 8817:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $C: () => (/* binding */ height_list),
/* harmony export */   EH: () => (/* binding */ ercToken_list),
/* harmony export */   Ef: () => (/* binding */ owner_detail_overview),
/* harmony export */   FL: () => (/* binding */ owner_detail),
/* harmony export */   IY: () => (/* binding */ power_change),
/* harmony export */   Nt: () => (/* binding */ miner_overview),
/* harmony export */   TK: () => (/* binding */ message_detail),
/* harmony export */   Tt: () => (/* binding */ address_detail),
/* harmony export */   UW: () => (/* binding */ account_change),
/* harmony export */   Xd: () => (/* binding */ message_list),
/* harmony export */   au: () => (/* binding */ peerList),
/* harmony export */   fm: () => (/* binding */ account_detail),
/* harmony export */   gm: () => (/* binding */ address_tabs),
/* harmony export */   hC: () => (/* binding */ trance_list),
/* harmony export */   j_: () => (/* binding */ account_balance),
/* harmony export */   kF: () => (/* binding */ block_list),
/* harmony export */   lU: () => (/* binding */ power_list),
/* harmony export */   qX: () => (/* binding */ cid_list),
/* harmony export */   xR: () => (/* binding */ minerTabs),
/* harmony export */   xy: () => (/* binding */ deal_list)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3495);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_copy__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5174);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7947);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9676);
/* harmony import */ var _assets_images_icon_copy_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5903);
/* harmony import */ var _packages_image__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2964);
/* harmony import */ var _packages_customDrop__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2140);
/* harmony import */ var _packages_showText__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9199);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils__WEBPACK_IMPORTED_MODULE_1__, _packages_showText__WEBPACK_IMPORTED_MODULE_9__]);
([_utils__WEBPACK_IMPORTED_MODULE_1__, _packages_showText__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 









//储存池概览 账户余额 & 有效算力
const account_balance = {
    title: "balance",
    list: [
        {
            title: "available_balance",
            dataIndex: "available_balance",
            title_tip: "available_balance_tip",
            color: "#4ACAB4"
        },
        {
            title: "init_pledge",
            dataIndex: "init_pledge",
            title_tip: "init_pledge_tip",
            color: "#256DF3"
        },
        {
            title: "pre_deposits",
            dataIndex: "pre_deposits",
            title_tip: "pre_deposits_tip",
            color: "#F8CD4D"
        },
        {
            title: "locked_balance",
            dataIndex: "locked_balance",
            title_tip: "locked_balance_tip",
            color: "#7F79EB"
        }
    ]
};
const power_list = {
    header: [
        {
            title: "quality_adjust_power",
            dataIndex: "quality_adjust_power",
            render: (text)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .unitConversion */ .dN)(text, 2) : "--"
        },
        {
            title: "quality_power_rank",
            dataIndex: "quality_power_rank",
            render: (text)=>text || "--"
        }
    ],
    list: [
        {
            title: "raw_power_percentage",
            dataIndex: "quality_power_percentage",
            render: (text)=>text ? Number(text * 100).toFixed(4) + "%" : "--"
        },
        {
            title: "total_win_count",
            dataIndex: "total_win_count"
        },
        {
            title: "total_block_count",
            dataIndex: "total_block_count"
        },
        {
            title: "raw_power",
            dataIndex: "raw_power",
            render: (text)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .unitConversion */ .dN)(text, 2) : "--"
        },
        {
            title: "total_reward",
            dataIndex: "total_reward",
            render: (text)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(text, false, false) : "--"
        },
        {
            title: "sector_size",
            dataIndex: "sector_size",
            render: (text)=>{
                if (Number(text) === 0) return text;
                return text ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .unitConversion */ .dN)(text) : "--";
            }
        }
    ],
    sector_status: {
        title: "sector_status",
        dataIndex: "sector_stauts",
        width: "100%",
        renderList: [
            {
                title: "sector_count",
                dataIndex: "live_sector_count"
            },
            {
                title: "live_sector_count",
                dataIndex: "active_sector_count",
                color: "#1C6AFD"
            },
            {
                title: "fault_sector_count",
                dataIndex: "fault_sector_count",
                color: "#ff000f"
            },
            {
                title: "recover_sector_count",
                dataIndex: "recover_sector_count",
                color: "#ffc631"
            }
        ]
    }
};
//miner_统计指标
const miner_overview = {
    title: "indicators",
    tabList: [
        {
            title: "24h",
            dataIndex: "24h"
        },
        {
            title: "7d",
            dataIndex: "7d"
        },
        {
            title: "30d",
            dataIndex: "1m"
        }
    ],
    list: [
        {
            title: "power_ratio",
            dataIndex: "power_ratio",
            width: "25%",
            style: {
                alignSelf: "flex-start"
            },
            render: (text)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .unitConversion */ .dN)(text, 2) + "/D" : "--"
        },
        {
            title: "precommit_deposits",
            dataIndex: "sector_deposits",
            style: {
                width: "25%",
                justifyContent: "flex-start"
            },
            render: (text)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(text, false, false) : text
        },
        {
            title: "gas_fee",
            dataIndex: "gas_fee",
            width: "25%",
            style: {
                alignSelf: "flex-start"
            },
            render: (text)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(text, false, false) : "--"
        },
        {
            title: "win_count",
            width: "25%",
            dataIndex: "win_count",
            title_tip: "win_count_tip",
            render: (text)=>String(text) === "0" || text ? String(text) : "--"
        },
        {
            title: "block_count",
            width: "25%",
            dataIndex: "block_count_increase",
            // title_tip: 'block_count_tip',
            render: (text)=>String(text) === "0" || text ? String(text) : "--"
        },
        {
            title: "block_rewards",
            width: "25%",
            dataIndex: "block_reward_increase",
            render: (text)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(text, false, false) : "--"
        },
        {
            title: "mining_efficiency",
            dataIndex: "rewards_per_tb",
            width: "25%",
            title_tip: "mining_efficiency_tip",
            render: (text)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(text, false, false) + "/TiB" : "--"
        },
        {
            title: "lucky",
            width: "25%",
            dataIndex: "lucky",
            title_tip: "lucky_tip",
            render: (text)=>{
                if (!text && Number(text) !== 0) {
                    return "--";
                }
                return text !== "-1" ? Number(100 * Number(text)).toFixed(4) + " %" : "--";
            }
        },
        {
            title: "net_profit_per_tb",
            width: "25%",
            dataIndex: "gas_fee_per_tb",
            title_tip: "net_profit_per_tb_tip",
            render: (text)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(text, false, false, 3) : "--"
        },
        {
            title: "power_increase_indicators",
            style: {
                width: "20%",
                justifyContent: "flex-end"
            },
            dataIndex: "power_increase",
            render: (text)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .unitConversion */ .dN)(text, 2) : "--"
        },
        {
            title: "windowPost_gas",
            style: {
                width: "20%",
                justifyContent: "flex-end"
            },
            dataIndex: "windowpost_gas",
            render: (text)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(text, false, false, 3) + "/TiB" : "--"
        }
    ]
};
const peerList = [
    {
        title: "ID",
        dataIndex: "peer_id",
        render: (text, record, tr)=>{
            return text ? tr(text) : "--";
        }
    },
    {
        title: "miner_owner",
        dataIndex: "account_id",
        type: [
            "account_basic"
        ],
        render: (text, record, tr)=>{
            if (!text) return "--";
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                href: `/miner/${text}`,
                className: "link_text",
                children: text
            });
        }
    },
    {
        title: "area",
        dataIndex: "ip_address",
        type: [
            "account_basic"
        ],
        render: (text, record, tr)=>text ? text : tr("no_area")
    },
    {
        title: "MultiAddresses",
        dataIndex: "multi_addrs",
        type: [
            "account_basic"
        ],
        render: (text, record, tr)=>{
            if (Array.isArray(text) && text.length > 0) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_showText__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                content: text,
                unit: 10
            });
            return "--";
        }
    }
];
const account_detail = {
    list: (tr)=>[
            {
                title: "account_type",
                dataIndex: "account_type",
                type: [
                    "account_basic"
                ],
                render: (text, record, tr)=>text ? tr(text) : "--"
            },
            {
                title: "peer_id",
                dataIndex: "peer_id",
                render: (text, record)=>{
                    if (!text) return "--";
                    const accountId = record?.account_basic?.account_id;
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: "flex items-baseline gap-x-2",
                        children: [
                            accountId ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                href: `/peer/${accountId}`,
                                className: "link_text",
                                children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .isIndent */ .EA)(text, 10)
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .isIndent */ .EA)(text, 10)
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                text: text
                            })
                        ]
                    });
                }
            },
            {
                title: "worker_address",
                dataIndex: "worker_address",
                render: (text)=>{
                    if (!text) return "--";
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: "flex items-baseline gap-x-2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                href: `/address/${text}`,
                                className: "link_text",
                                children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .isIndent */ .EA)(text, 10)
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                text: text
                            })
                        ]
                    });
                }
            },
            {
                title: "owner_address",
                dataIndex: "owner_address",
                render: (text)=>{
                    if (!text) return "--";
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: "flex items-baseline gap-x-2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                href: `/address/${text}`,
                                className: "link",
                                children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .isIndent */ .EA)(text, 10)
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                text: text
                            })
                        ]
                    });
                }
            },
            {
                title: "controllers_address",
                dataIndex: "controllers_address",
                render: (text, record)=>{
                    if (Array.isArray(text) && text.length > 0) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_showText__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                        content: text,
                        unit: 10
                    });
                    return "--";
                // return <div className='flex flex-wrap items-baseline justify-end gap-x-2'>
                //   {text&& Array.isArray(text)?text?.map((linkItem:string,index:number) => {
                //     return <span className="flex items-baseline gap-x-2" key={linkItem}>
                //       <Link href={`/address/${linkItem}`} className='link' >{isIndent(linkItem,10)}</Link>
                //       <Copy text={linkItem} />
                //     </span>
                //   }):'--'}
                // </div>
                }
            },
            {
                title: "beneficiary_address",
                dataIndex: "beneficiary_address",
                render: (text, record)=>{
                    if (!text) return "--";
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex flex-wrap items-baseline justify-end gap-x-2",
                        children: text && Array.isArray(text) ? text?.map((linkItem, index)=>{
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "flex items-baseline gap-x-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        href: `/address/${linkItem}`,
                                        className: "link_text",
                                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .isIndent */ .EA)(linkItem, 10)
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        text: linkItem
                                    })
                                ]
                            }, linkItem);
                        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "flex items-baseline gap-x-2",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: `/address/${text}`,
                                    className: "link_text",
                                    children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .isIndent */ .EA)(text, 10)
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                    text: text
                                })
                            ]
                        })
                    });
                }
            }
        ]
};
const owner_detail_overview = {
    title: "owner_title",
    list: [
        {
            title: "account_name",
            dataIndex: "account_id"
        },
        {
            title: "owner_address",
            dataIndex: "account_address",
            render: (text)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                    className: "link",
                    href: `/address/${text}`,
                    children: text
                });
            }
        },
        {
            title: "owned_miners",
            dataIndex: "owned_miners",
            render: (text, record)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "flex items-baseline gap-x-2 flex-wrap",
                    children: text && Array.isArray(text) && text?.map((item, index)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            className: "link",
                            href: `/miner/${item}`,
                            children: item
                        }, index);
                    })
                });
            }
        }
    ]
};
const owner_detail = {
    list: [
        {
            title: "owner_address",
            dataIndex: "account_address",
            render: (text)=>{
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex gap-x-2 items-center owner",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            className: "link",
                            href: `/address/${text}`,
                            children: text
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                            text: text
                        })
                    ]
                });
            }
        },
        {
            title: "owned_miners",
            dataIndex: "owned_miners",
            render: (text, record)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "flex flex-wrap gap-2.5 items-baseline",
                    children: text && Array.isArray(text) && text?.map((item, index)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            className: "link",
                            href: `/miner/${item}`,
                            children: item
                        }, index);
                    })
                });
            }
        },
        {
            title: "owned_active_miners",
            dataIndex: "active_miners",
            render: (text, record)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "flex flex-wrap gap-2.5 items-baseline",
                    children: text && Array.isArray(text) && text?.map((item, index)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            className: "link",
                            href: `/miner/${item}`,
                            children: item
                        }, index);
                    })
                });
            }
        }
    ]
};
//message detail
const message_detail = {
    title: "message_overview_detail",
    tabs: [
        {
            title: "message_detail",
            dataIndex: "detail"
        },
        {
            title: "trade",
            dataIndex: "trade"
        },
        {
            title: "event_log",
            dataIndex: "event_log"
        }
    ],
    eventLog: [
        {
            title: "account_address",
            dataIndex: "address"
        },
        {
            title: "Name",
            dataIndex: "name"
        },
        {
            title: "topic",
            dataIndex: "topics",
            render: (text, record)=>{
                if (Array.isArray(text)) {
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                        className: "flex flex-col gap-y-2",
                        children: text.map((item, index)=>{
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                className: "flex items-center gap-x-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "flex items-center justify-center flex-shrink-0 w-5 h-5 bg-bg_hover rounded-[5px] ",
                                        children: index
                                    }),
                                    item
                                ]
                            }, item);
                        })
                    });
                }
                return text || "--";
            }
        },
        {
            title: "params",
            dataIndex: "data",
            render: (text)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "break-words",
                    children: text
                });
            }
        },
        {
            title: "Log Index",
            dataIndex: "log_index"
        },
        {
            title: "Removed",
            dataIndex: "removed",
            render: (text)=>String(text)
        }
    ],
    trade: [
        {
            dataIndex: "from",
            title: "from_ath",
            width: "30%",
            render: (text, record)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "flex items-center gap-x-2",
                    children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .get_account_type */ .$B)(text)
                })
        },
        {
            dataIndex: "to",
            title: "to_ath",
            width: "30%",
            render: (text, record)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "flex items-center gap-x-2",
                    children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .get_account_type */ .$B)(text)
                })
        },
        {
            dataIndex: "value",
            title: "amount",
            width: "20%",
            render: (text)=>{
                return (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(text, false, false, 4);
            }
        },
        {
            dataIndex: "method",
            width: "20%",
            title: "method"
        }
    ],
    trans: [
        {
            dataIndex: "cid",
            title: "cid",
            type: [
                "message_basic"
            ],
            render: (text)=>{
                if (!text) return "--";
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_5__/* .BrowserView */ .I, {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "flex items-center gap-x-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text",
                                        children: text
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        text: text
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_5__/* .MobileView */ .$, {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "copy-row",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "normal-text",
                                        children: text
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        text: text,
                                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_icon_copy_svg__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
                                        className: "copy"
                                    })
                                ]
                            })
                        })
                    ]
                });
            }
        },
        {
            dataIndex: "eth_message",
            title: "eth_message",
            elasticity: true,
            render: (text)=>{
                if (!text) return null;
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_5__/* .BrowserView */ .I, {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "flex items-center gap-x-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text",
                                        children: text
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        text: text
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_5__/* .MobileView */ .$, {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "copy-row",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "normal-text",
                                        children: text
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        text: text,
                                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_icon_copy_svg__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
                                        className: "copy"
                                    })
                                ]
                            })
                        })
                    ]
                });
            }
        },
        {
            dataIndex: "exit_code",
            title: "exit_code",
            type: [
                "message_basic"
            ],
            render: (text)=>{
                if (text?.startsWith("Ok")) {
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: "flex py-1 gap-x-2  rounded-sm items-center",
                        children: [
                            (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_4__/* .getSvgIcon */ .a)("successIcon"),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "text-success text-cm",
                                children: "Success"
                            })
                        ]
                    });
                }
                if (text?.startsWith("Pend")) {
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: "flex py-1 gap-x-2  rounded-sm items-center",
                        children: [
                            (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_4__/* .getSvgIcon */ .a)("pendingIcon"),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "text-cm",
                                children: "Pending"
                            })
                        ]
                    });
                }
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "flex py-1 gap-x-2 rounded-sm items-center",
                    children: [
                        (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_4__/* .getSvgIcon */ .a)("errorIcon"),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text_red text-cm",
                            children: text
                        })
                    ]
                });
            }
        },
        {
            dataIndex: "value",
            title: "value",
            type: [
                "message_basic"
            ],
            render: (text)=>{
                return (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(text, false, false, 4);
            }
        },
        {
            dataIndex: "height",
            title: "height",
            type: [
                "message_basic"
            ],
            render: (text)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                    className: "link",
                    href: `/height/${text}`,
                    children: text
                });
            }
        },
        {
            dataIndex: "block_time",
            title: "time",
            type: [
                "message_basic"
            ],
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatDateTime */ .o0)(text, "YYYY-MM-DD HH:mm:ss")
        },
        {
            dataIndex: "method_name",
            title: "method_name",
            type: [
                "message_basic"
            ]
        },
        // //Transaction
        {
            dataIndex: "swap_info",
            elasticity: true,
            borderTop: true,
            title: (tr)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    children: [
                        (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_4__/* .getSvgIcon */ .a)("transaction"),
                        tr("Transaction")
                    ]
                }),
            render: (text)=>{
                if (text) {
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: "flex gap-x-2",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "flex gap-x-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Swap"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: text?.amount_out?.toLocaleString()
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: text?.amount_out_token_name.toLocaleUpperCase()
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "text_des",
                                children: "For"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "flex gap-x-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: text?.amount_in
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: text?.amount_in_token_name
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "text_des",
                                children: "On"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: `flex gap-x-2 ${text.dex_url ? "cursor-pointer" : ""}`,
                                onClick: ()=>{
                                    if (text.dex_url) {
                                        window.open(text.dex_url);
                                    }
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_image__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                        src: text.icon_url,
                                        alt: "",
                                        width: 20,
                                        height: 20
                                    }),
                                    text?.dex
                                ]
                            })
                        ]
                    });
                }
                return null;
            }
        },
        //nfts 转移
        {
            title: "message_NftTrans",
            elasticity: true,
            dataIndex: "nftTrans",
            borderTop: true,
            render: (text, record, tr)=>{
                if (Array.isArray(text)) {
                    if (text.length === 0) return null;
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex flex-col gap-y-4 align-baseline",
                        children: text.map((item, index)=>{
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex gap-x-2.5",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "flex items-center gap-x-2",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text_des",
                                                children: tr("from_ath")
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "flex gap-x-2 items-center",
                                                children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .get_account_type */ .$B)(item.from)
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "flex items-center gap-x-2 ",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text_des",
                                                children: tr("to_ath")
                                            }),
                                            " ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "flex gap-x-2 items-center",
                                                children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .get_account_type */ .$B)(item.to)
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "flex items-center font-DINPro-Medium gap-x-2 ",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "font_weight",
                                                children: "For"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: Number(item?.amount).toFixed(4) || "--"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: item?.token_name
                                            })
                                        ]
                                    })
                                ]
                            }, index);
                        })
                    });
                }
                return null;
            }
        },
        {
            dataIndex: "from",
            title: "from",
            borderTop: true,
            type: [
                "message_basic"
            ],
            render: (text, record)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "flex items-center gap-x-2 link-row",
                    children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .get_account_type */ .$B)(text, 0)
                })
        },
        {
            dataIndex: "to",
            title: "to",
            type: [
                "message_basic"
            ],
            render: (text, record)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "flex items-center gap-x-2 link-row",
                    children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .get_account_type */ .$B)(text, 0)
                });
            }
        },
        //通证转移
        {
            title: "message_ERC20Trans",
            elasticity: true,
            dataIndex: "message_ERC20Trans",
            borderTop: true,
            render: (text, record, tr)=>{
                if (Array.isArray(text)) {
                    if (text.length === 0) return null;
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_5__/* .BrowserView */ .I, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex flex-col gap-y-4 align-baseline",
                                    children: text.map((item, index)=>{
                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex gap-x-2.5",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    className: "flex items-center gap-x-2",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "text_des",
                                                            children: tr("from_ath")
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "flex gap-x-2 items-center",
                                                            children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .get_account_type */ .$B)(item.from)
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    className: "flex items-center gap-x-2 ",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "text_des",
                                                            children: tr("to_ath")
                                                        }),
                                                        " ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "flex gap-x-2 items-center",
                                                            children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .get_account_type */ .$B)(item.to)
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    className: "flex items-center font-DINPro-Medium gap-x-2 ",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "font_weight",
                                                            children: "For"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            children: Number(item?.amount).toFixed(4) || "--"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            children: item?.token_name
                                                        })
                                                    ]
                                                })
                                            ]
                                        }, index);
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_5__/* .MobileView */ .$, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex flex-col gap-y-4 align-baseline",
                                    children: text.map((item, index)=>{
                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "grid grid-cols-1 gap-y-1",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    className: "flex items-center gap-x-2",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "text_des",
                                                            children: tr("from_ath")
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "flex gap-x-2 items-center",
                                                            children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .get_account_type */ .$B)(item.from)
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    className: "flex items-center gap-x-2 ",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "text_des",
                                                            children: tr("to_ath")
                                                        }),
                                                        " ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "flex gap-x-2 items-center",
                                                            children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .get_account_type */ .$B)(item.to)
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    className: "flex items-center font-DINPro-Medium gap-x-2 ",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "font_weight",
                                                            children: "For"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            children: Number(item?.amount).toFixed(4) || "--"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            children: item?.token_name
                                                        })
                                                    ]
                                                })
                                            ]
                                        }, index);
                                    })
                                })
                            })
                        ]
                    });
                }
                return null;
            }
        },
        //转账信息
        {
            title: "message_tranf",
            dataIndex: "consume_list",
            elasticity: true,
            borderTop: true,
            mobileHide: true,
            render: (text, record, tr)=>{
                if (Array.isArray(text)) {
                    if (text.length === 0) return null;
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex flex-col gap-y-4 align-baseline",
                        children: text.map((item, index)=>{
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_5__/* .BrowserView */ .I, {
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex gap-x-2.5",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    className: "flex items-center gap-x-2",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "text_des",
                                                            children: tr("from_ath")
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "flex gap-x-2 items-center",
                                                            children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .get_account_type */ .$B)(item.from)
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    className: "flex items-center gap-x-2 ",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "text_des",
                                                            children: tr("to_ath")
                                                        }),
                                                        " ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "flex gap-x-2 items-center",
                                                            children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .get_account_type */ .$B)(item.to)
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    className: "flex items-center font-DINPro-Medium gap-x-2 ",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "font_weight",
                                                            children: "For"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(item.value, false, false, 4) || "--"
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                            className: "text_des font-PingFang",
                                                            children: [
                                                                "(",
                                                                tr(item.consume_type),
                                                                ")"
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        }, index)
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_5__/* .MobileView */ .$, {
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "grid grid-cols-1",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    className: "flex items-center gap-x-2",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "text_des",
                                                            children: tr("from_ath")
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "flex gap-x-2 items-center",
                                                            children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .get_account_type */ .$B)(item.from)
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    className: "flex items-center gap-x-2 ",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "text_des",
                                                            children: tr("to_ath")
                                                        }),
                                                        " ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "flex gap-x-2 items-center",
                                                            children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .get_account_type */ .$B)(item.to)
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    className: "flex items-center font-DINPro-Medium gap-x-2 ",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: "font_weight",
                                                            children: "For"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(item.value, false, false, 4) || "--"
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                            className: "text_des font-PingFang",
                                                            children: [
                                                                "(",
                                                                tr(item.consume_type),
                                                                ")"
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        }, index)
                                    })
                                ]
                            });
                        })
                    });
                }
                return null;
            }
        }
    ],
    detail: [
        {
            dataIndex: "nonce",
            title: "nonce",
            render: (text)=>text
        },
        {
            dataIndex: "replaced",
            title: "replaced",
            render: (text)=>String(text) === "true" ? "True" : "False"
        },
        // {
        //   dataIndex: 'base_cid',
        //   title: 'base_cid',
        //   elasticity: true,
        //   render: (text: any,record:any) => {
        //     console.log('---333',text,record)
        //     if (String(text)) {
        //       return text;
        //     }
        //     return null
        //   }
        // },
        {
            borderTop: true,
            dataIndex: "all_gas_fee",
            title: "all_gas_fee",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(text, false, false, 4)
        },
        {
            dataIndex: "base_fee",
            title: "base_fee",
            render: (text)=>{
                return (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(text, false, false, 4);
            }
        },
        {
            dataIndex: "gas_fee_cap",
            title: "gas_fee_cap",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(text, false, false, 4)
        },
        {
            dataIndex: "gas_premium",
            title: "gas_premium",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(text, false, false, 4)
        },
        {
            dataIndex: "gas_limit",
            title: "gas_limit",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(text)
        },
        {
            dataIndex: "gas_used",
            title: "gas_used",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(text)
        },
        {
            dataIndex: "blk_cids",
            title: "blk_cids",
            borderTop: true,
            render: (text)=>{
                if (!Array.isArray(text) || !text) return "--";
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex flex-col",
                    children: text.map((item, index)=>{
                        if (!text) return "--";
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_5__/* .BrowserView */ .I, {
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "flex gap-x-2 items-center  mb-2 last:mb-0",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                className: "link link-html",
                                                href: `/cid/${item}`,
                                                children: item
                                            }, index),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                text: item
                                            })
                                        ]
                                    }, index)
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_5__/* .MobileView */ .$, {
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "copy-row mt-1",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                    className: "link link-html",
                                                    href: `/cid/${item}`,
                                                    children: item
                                                }, index)
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                text: item,
                                                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_icon_copy_svg__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
                                                className: "copy"
                                            })
                                        ]
                                    })
                                })
                            ]
                        });
                    })
                });
            }
        },
        {
            dataIndex: "version",
            title: "version",
            borderTop: true,
            render: (text)=>text
        },
        {
            dataIndex: "params_detail",
            title: "params",
            render: (text, record)=>{
                const showValue = text || record?.params;
                if (!showValue) return null;
                if (typeof showValue === "string") {
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "break-words",
                        children: JSON.stringify(showValue, undefined, 2)
                    });
                }
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "code",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("pre", {
                        className: "pre",
                        style: {
                            whiteSpace: "pre-wrap",
                            overflowWrap: "break-word"
                        },
                        children: JSON.stringify(showValue, undefined, 1)
                    })
                });
            }
        },
        {
            dataIndex: "err",
            title: "err_message",
            elasticity: true,
            render: (text, record)=>{
                const showValue = text || record?.params;
                if (!showValue) return null;
                if (typeof showValue === "string") {
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "break-words",
                        children: JSON.stringify(showValue, undefined, 2)
                    });
                }
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "code",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("pre", {
                        className: "pre",
                        style: {
                            whiteSpace: "pre-wrap",
                            overflowWrap: "break-word"
                        },
                        children: JSON.stringify(showValue, undefined, 1)
                    })
                });
            }
        },
        {
            dataIndex: "returns_detail",
            title: "returns",
            render: (text, record)=>{
                const showValue = text || record?.returns;
                if (!showValue) return null;
                if (typeof showValue === "string") {
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "break-words",
                        children: JSON.stringify(showValue, undefined, 2)
                    });
                }
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("pre", {
                    className: "pre",
                    style: {
                        whiteSpace: "pre-wrap"
                    },
                    children: JSON.stringify(showValue, undefined, 1)
                });
            }
        }
    ],
    content: []
};
const default_content = [
    {
        title: "account_address",
        dataIndex: "account_address",
        type: [
            "account_basic"
        ],
        render: (text, record, tr)=>{
            const owned_miners = record?.account_basic?.owned_miners || [];
            if (!text) return "--";
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_device_detect__WEBPACK_IMPORTED_MODULE_5__/* .BrowserView */ .I, {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "flex items-center gap-x-2",
                                children: [
                                    text?.length > 30 ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .isIndent */ .EA)(text, 10, 10) : text,
                                    text && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        text: text
                                    })
                                ]
                            }),
                            owned_miners.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                href: `/owner/${record?.account_basic?.account_id}`,
                                className: "primary_btn primary_default ml-2 !h-7",
                                children: tr("account_detail")
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_5__/* .MobileView */ .$, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "copy-row",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "normal-text",
                                    children: text
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                    text: text,
                                    icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_icon_copy_svg__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
                                    className: "copy"
                                }),
                                owned_miners.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                    href: `/owner/${record?.account_basic?.account_id}`,
                                    className: "primary_btn mt-2",
                                    children: tr("account_detail")
                                })
                            ]
                        })
                    })
                ]
            });
        }
    },
    {
        title: "contract_name",
        dataIndex: "contract_name",
        elasticity: true,
        type: [
            "account_basic",
            "evm_contract"
        ],
        render: (text, record, tr)=>{
            if (record?.account_basic?.account_type === "evm") {
                if (text) {
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: "flex items-center gap-x-2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "success_color",
                                children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_4__/* .getSvgIcon */ .a)("successIcon")
                            }),
                            text
                        ]
                    });
                }
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                    className: "primary_btn !h-8",
                    href: `/contract/verify`,
                    children: tr("go_verify")
                });
            }
            return text;
        }
    },
    {
        title: "base_account_id",
        dataIndex: "account_id",
        type: [
            "account_basic"
        ],
        elasticity: true,
        render: (text, record)=>{
            if (!text) return text;
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_5__/* .BrowserView */ .I, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "flex gap-x-2 items-center",
                            children: [
                                text,
                                " ",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                    text: text
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_5__/* .MobileView */ .$, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "copy-row",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "normal-text",
                                    children: text
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                    text: text,
                                    icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_icon_copy_svg__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
                                    className: "copy"
                                })
                            ]
                        })
                    })
                ]
            });
        }
    },
    {
        title: "account_type",
        dataIndex: "account_type",
        type: [
            "account_basic"
        ],
        render: (text, record, tr)=>text ? tr(text) : "--"
    },
    {
        title: "eth_address",
        dataIndex: "eth_address",
        elasticity: true,
        type: [
            "account_basic"
        ],
        render: (text, record)=>{
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_5__/* .BrowserView */ .I, {
                        children: text ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "flex items-center gap-x-2",
                                children: [
                                    text,
                                    " ",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        text: text
                                    })
                                ]
                            })
                        }) : text
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_5__/* .MobileView */ .$, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "copy-row",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "normal-text",
                                    children: text
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                    text: text,
                                    icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_icon_copy_svg__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
                                    className: "copy"
                                })
                            ]
                        })
                    })
                ]
            });
        }
    },
    {
        title: "balance",
        dataIndex: "account_balance",
        type: [
            "account_basic"
        ],
        render: (text)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFil */ .Uk)(text, "FIL", 4) + " FIL" : "--"
    },
    {
        title: "stable_address",
        dataIndex: "stable_address",
        elasticity: true,
        type: [
            "account_basic"
        ],
        render: (text)=>{
            return text ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_5__/* .BrowserView */ .I, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "flex items-center gap-x-2",
                            children: [
                                text?.length > 30 ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .isIndent */ .EA)(text, 10, 10) : text,
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                    text: text
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_5__/* .MobileView */ .$, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "copy-row",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "normal-text",
                                    children: text?.length > 30 ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .isIndent */ .EA)(text, 10, 10) : text
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                    text: text,
                                    icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_icon_copy_svg__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
                                    className: "copy"
                                })
                            ]
                        })
                    })
                ]
            }) : text;
        }
    },
    {
        title: "Initial Balance",
        dataIndex: "initial_balance",
        elasticity: true,
        render: (text)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(text) : text
    },
    {
        title: "Locking Balance",
        dataIndex: "locked_balance",
        elasticity: true,
        render: (text)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(text) : text
    },
    {
        title: "Locking Period ",
        dataIndex: "unlock_start_time",
        elasticity: true,
        render: (text, record)=>{
            if (!text) {
                return text;
            }
            const lastTime = record?.unlock_end_time;
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                children: [
                    " ",
                    (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatDateTime */ .o0)(text, "YYYY-MM-DD HH:mm"),
                    " to  ",
                    (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatDateTime */ .o0)(lastTime, "YYYY-MM-DD HH:mm")
                ]
            });
        }
    },
    {
        title: "Approvals Threshold",
        elasticity: true,
        dataIndex: "approvals_threshold"
    },
    {
        title: "tokenList",
        elasticity: true,
        dataIndex: "tokenList",
        render: (text)=>{
            if (!text) return null;
            if (Array.isArray(text)) {
                if (text.length === 0) return null;
                const value = text[0];
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_customDrop__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                    value: value,
                    content: text.slice(1)
                });
            }
        }
    },
    {
        title: "Available Balance",
        dataIndex: "available_balance",
        elasticity: true,
        render: (text)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(text) : text
    },
    {
        title: "Robust Address",
        dataIndex: "robust_address",
        elasticity: true,
        type: [
            "account_basic"
        ],
        render: (text, record)=>{
            if (record.account_type === "multisig") {
                return text ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_5__/* .BrowserView */ .I, {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "flex items-center gap-x-2",
                                children: [
                                    text?.length > 30 ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .isIndent */ .EA)(text, 10, 10) : text,
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        text: text
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_5__/* .MobileView */ .$, {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "copy-row",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "normal-text",
                                        children: text
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        text: text,
                                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_icon_copy_svg__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
                                        className: "copy"
                                    })
                                ]
                            })
                        })
                    ]
                }) : text;
            }
            return null;
        }
    },
    {
        title: "user_count",
        dataIndex: "user_count",
        type: [
            "account_basic",
            "evm_contract"
        ],
        elasticity: true,
        render: (text)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(text) : text
    },
    {
        title: "nonce",
        dataIndex: "nonce",
        type: [
            "account_basic"
        ],
        render: (text)=>text
    },
    {
        title: "transfer_count",
        dataIndex: "transfer_count",
        type: [
            "account_basic",
            "evm_contract"
        ],
        elasticity: true,
        render: (text)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(text) : text
    },
    {
        title: "create_time",
        dataIndex: "create_time",
        type: [
            "account_basic"
        ],
        render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatDateTime */ .o0)(text)
    },
    // {
    //   title: 'message_count',
    //   dataIndex: 'message_count',
    //   type: ['account_basic'],
    //   render: (text: any) => text,
    // },
    {
        title: "latest_transfer_time",
        dataIndex: "latest_transfer_time",
        type: [
            "account_basic"
        ],
        render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatDateTime */ .o0)(text)
    },
    {
        title: "owned_miners",
        dataIndex: "owned_miners",
        elasticity: true,
        isSplit: 5,
        width: "100%",
        type: [
            "account_basic"
        ],
        render: (text)=>{
            return Array.isArray(text) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "flex items-center gap-2 flex-wrap",
                children: Array.isArray(text) && text?.map((item)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                        className: "link",
                        href: `/miner/${item}`,
                        children: item
                    }, item);
                })
            }) : text;
        }
    },
    {
        title: "owned_active_miners",
        dataIndex: "active_miners",
        width: "100%",
        isSplit: 5,
        elasticity: true,
        type: [
            "account_basic"
        ],
        render: (text)=>{
            return Array.isArray(text) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "flex items-center gap-2 flex-wrap",
                children: Array.isArray(text) && text?.map((item)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                        className: "link",
                        href: `/miner/${item}`,
                        children: item
                    }, item);
                })
            }) : text;
        }
    },
    {
        title: "Signers",
        dataIndex: "signers",
        elasticity: true,
        render: (text)=>{
            if (Array.isArray(text) && text.length > 0) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_showText__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                content: text
            });
            return null;
        // console.log('signers',text)
        // return Array.isArray(text) ? <div className="flex items-baseline flex-col  flex-wrap justify-end gap-2">
        //   {text?.map((item:any,index:number) => {
        //     return <div className='flex w-full items-center gap-x-1 justify-end' key={ index}>{get_account_type(item,0)}</div>
        //   })}
        //   {text.length > 2 && <span>All</span> }
        // </div>:text
        }
    }
];
const address_detail = {
    title: "general_overview_title",
    content: (type)=>{
        switch(type){
            case "account":
                return [
                    ...default_content
                ];
            default:
                return [
                    ...default_content
                ];
        }
    },
    account_change: {
        tabsList: [
            {
                title: "24h",
                dataIndex: "24h"
            },
            {
                title: "7d",
                dataIndex: "7d"
            },
            {
                title: "30d",
                dataIndex: "1m"
            }
        ],
        list: [
            {
                title: "balance",
                type: "line",
                dataIndex: "balance",
                color: "#1C6AFD",
                seriesArea: true
            }
        ]
    }
};
const account_change = {
    title: "account_change",
    list: [
        {
            title: "balance",
            dataIndex: "balance",
            color: "#FFC53D",
            type: "line"
        },
        {
            title: "available_balance",
            dataIndex: "available_balance",
            color: "#4ACAB4",
            type: "line"
        },
        {
            title: "init_pledge",
            dataIndex: "initial_pledge",
            type: "line",
            color: "#1C6AFD"
        },
        {
            title: "locked_balance",
            dataIndex: "locked_funds",
            type: "line",
            color: "#6E69CF"
        }
    ]
};
const power_change = {
    title: "power_change",
    tabList: [
        // { title: '7d', dataIndex: '7d' },
        {
            title: "30d",
            dataIndex: "1m"
        }
    ],
    list: [
        {
            title: "quality_adjust_power",
            dataIndex: "power",
            type: "line",
            color: "#FFC53D",
            yIndex: 0
        },
        {
            title: "power_increase",
            dataIndex: "power_increase",
            type: "bar",
            color: "#1C6AFD",
            yIndex: 0
        }
    ]
};
const address_tabs = [
    {
        title: "traces_list",
        dataIndex: "traces_list",
        optionsUrl: "TransferMethodByAccountID"
    },
    {
        title: "message_list",
        dataIndex: "message_list",
        optionsUrl: "AllMethodByAccountID"
    },
    {
        title: "erc20_transfer",
        dataIndex: "ercList",
        value: "ERC20AddrTransfers"
    }
];
const minerTabs = [
    {
        title: "message_list",
        dataIndex: "message_list",
        optionsUrl: "AllMethodByAccountID"
    },
    {
        title: "block_list",
        dataIndex: "block_list"
    },
    {
        title: "traces_list",
        dataIndex: "traces_list",
        headerOptions: [
            {
                title: "all",
                value: "all"
            },
            {
                title: "Blockreward",
                value: "blockreward"
            },
            {
                title: "Burn",
                value: "burn"
            },
            {
                title: "Transfer",
                value: "transfer"
            },
            {
                title: "Send",
                value: "send",
                isIndent: true
            },
            {
                title: "Receive",
                value: "receive",
                isIndent: true
            }
        ]
    }
];
const message_list = (fromList, toList)=>[
        {
            dataIndex: "cid",
            title: "cid",
            width: "10%",
            render: (text)=>text ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                    href: `/message/${text}`,
                    className: "link_text",
                    children: text ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .isIndent */ .EA)(text, 6) : ""
                }) : "--"
        },
        {
            dataIndex: "height",
            title: "height",
            width: "10%",
            render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                    href: `/height/${text}`,
                    className: "link_text",
                    children: text
                })
        },
        {
            dataIndex: "block_time",
            title: "time",
            width: "13%",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatDateTime */ .o0)(text, "YYYY-MM-DD HH:mm")
        },
        {
            dataIndex: "from",
            title: "from",
            width: "15%",
            render: (text, record)=>{
                if (!text) return "--";
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "flex items-center gap-x-2",
                    children: [
                        (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .get_account_type */ .$B)(text),
                        fromList?.domains && fromList?.domains[text] && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: `/domain/${fromList.domains[text]}?provider=${fromList.provider}`,
                            children: [
                                "(",
                                fromList.domains[text],
                                ")"
                            ]
                        })
                    ]
                });
            }
        },
        {
            dataIndex: "to",
            title: "to",
            width: "12%",
            render: (text, record)=>{
                if (!text) return "--";
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex items-center gap-x-2",
                    children: [
                        (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .get_account_type */ .$B)(text),
                        toList?.domains && toList?.domains[text] && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: `/domain/${toList.domains[text]}?provider=${toList.provider}`,
                            children: [
                                "(",
                                toList.domains[text],
                                ")"
                            ]
                        })
                    ]
                });
            }
        },
        {
            dataIndex: "value",
            title: "value",
            width: "15%",
            render: (text)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(text, false, false) : text || "--"
        },
        {
            dataIndex: "exit_code",
            width: "10%",
            title: "status"
        },
        {
            dataIndex: "method_name",
            width: "15%",
            title: "method_name"
        }
    ];
const block_list = (fromList, toList)=>[
        {
            dataIndex: "cid",
            title: "block_cid",
            width: "20%",
            render: (text)=>text ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                    href: `/cid/${text}`,
                    className: "link_text",
                    children: text ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .isIndent */ .EA)(text, 6) : ""
                }) : "--"
        },
        {
            dataIndex: "height",
            title: "block_height",
            width: "20%",
            render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                    href: `/height/${text}`,
                    className: "link_text",
                    children: text
                })
        },
        {
            dataIndex: "block_time",
            title: "block_time",
            width: "20%",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatDateTime */ .o0)(text, "YYYY-MM-DD HH:mm")
        },
        {
            dataIndex: "messages_count",
            width: "20%",
            title: "block_messages_count"
        },
        // {
        //   dataIndex: 'miner_id',
        //   width: '15%',
        //   title: 'block_miner_id',
        //   render: (text: string) => (
        //     <Link href={`/miner/${text}`} className='link'>
        //       {text}
        //     </Link>
        //   ),
        // },
        {
            dataIndex: "reward",
            title: "block_mined_reward",
            width: "20%",
            render: (text)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(text, false, false) : text || "--"
        }
    ];
const trance_list = (fromList, toList)=>[
        {
            dataIndex: "block_time",
            title: "time",
            width: "20%",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatDateTime */ .o0)(text, "YYYY-MM-DD HH:mm")
        },
        {
            dataIndex: "cid",
            title: "cid",
            width: "15%",
            render: (text)=>text ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                    href: `/message/${text}`,
                    className: "link",
                    children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .isIndent */ .EA)(text, 6)
                }) : "--"
        },
        {
            dataIndex: "from",
            title: "from",
            width: "15%",
            render: (text, record)=>{
                if (!text) return "--";
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "flex items-center gap-x-2",
                    children: [
                        (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .get_account_type */ .$B)(text),
                        fromList?.domains && fromList?.domains[text] && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: `/domain/${fromList.domains[text]}?provider=${fromList.provider}`,
                            children: [
                                "(",
                                fromList.domains[text],
                                ")"
                            ]
                        })
                    ]
                });
            }
        },
        {
            dataIndex: "to",
            title: "to",
            width: "15%",
            render: (text, record)=>{
                if (!text) return "--";
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex items-center gap-x-2",
                    children: [
                        (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .get_account_type */ .$B)(text),
                        toList?.domains && toList?.domains[text] && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: `/domain/${toList.domains[text]}?provider=${toList.provider}`,
                            children: [
                                "(",
                                toList.domains[text],
                                ")"
                            ]
                        })
                    ]
                });
            }
        },
        {
            dataIndex: "value",
            width: "20%",
            title: "value",
            render: (text, record)=>{
                if (!text) return "--";
                //const method_name = record?.method_name?.toLocaleLowerCase();
                let className = Number(text) < 0 ? "text_red" : "text_green";
                let flag = Number(text) < 0 ? "-" : "+";
                // if (method_name) {
                //   if (method_name === 'burn' || method_name === 'send') {
                //     className = 'text_red'
                //     flag='-'
                //   } else if (method_name === 'blockreward' || method_name === 'receive') {
                //     className = 'text_green'
                //     flag='+'
                //   }
                // }
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: className,
                    children: [
                        flag,
                        (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(Math.abs(text))
                    ]
                });
            }
        },
        {
            dataIndex: "method_name",
            width: "15%",
            title: "method_name"
        }
    ];
const ercToken_list = (fromList, toList)=>{
    return [
        {
            dataIndex: "time",
            title: "time",
            width: "15%",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatDateTime */ .o0)(text)
        },
        {
            dataIndex: "cid",
            title: "cid",
            width: "10%",
            render: (text)=>text ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                    className: "link",
                    href: `/message/${text}`,
                    children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .isIndent */ .EA)(text)
                }) : "--"
        },
        {
            dataIndex: "from",
            title: "from",
            width: "15%",
            render: (text, record)=>{
                if (!text) return "--";
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "flex gap-x-2 items-center",
                    children: [
                        (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .get_account_type */ .$B)(text),
                        fromList?.domains && fromList?.domains[text] && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: `/domain/${fromList.domains[text]}?provider=${fromList.provider}`,
                            children: [
                                "(",
                                fromList.domains[text],
                                ")"
                            ]
                        })
                    ]
                });
            }
        },
        {
            dataIndex: "to",
            title: "to",
            width: "15%",
            render: (text, record)=>{
                if (!text) return "--";
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex gap-x-2 items-center",
                    children: [
                        (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .get_account_type */ .$B)(text),
                        toList?.domains && toList?.domains[text] && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: `/domain/${toList.domains[text]}?provider=${toList.provider}`,
                            children: [
                                "(",
                                toList.domains[text],
                                ")"
                            ]
                        })
                    ]
                });
            }
        },
        {
            dataIndex: "method",
            title: "method",
            width: "15%"
        },
        {
            dataIndex: "amount",
            title: "amount",
            width: "20%",
            render: (text, record)=>{
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex items-center gap-x-2",
                    children: [
                        (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(text),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            children: record.token_name
                        })
                    ]
                });
            }
        },
        {
            dataIndex: "icon_url",
            width: "10%",
            title: "platform",
            render: (text, record)=>{
                if (!text) {
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_image__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        src: text,
                        width: 25,
                        height: 25
                    });
                }
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                    href: `/token/${record?.contract_id}`,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_image__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        src: text,
                        width: 25,
                        height: 25
                    })
                });
            }
        }
    ];
};
//height
const height_list = {
    headerList: [
        {
            dataIndex: "blcok_time",
            title: "blcok_time",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatDateTime */ .o0)(text)
        },
        {
            dataIndex: "message_count_deduplicate",
            title: "message_count_deduplicate",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(text)
        }
    ],
    columns: [
        {
            dataIndex: "cid",
            title: "block_cid",
            render: (text)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                    href: `/cid/${text}`,
                    children: text
                });
            }
        },
        {
            dataIndex: "miner_id",
            title: "miner_id",
            render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                    href: `/miner/${text}`,
                    children: text
                })
        },
        {
            dataIndex: "messages_count",
            title: "messages_count",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(text)
        },
        {
            dataIndex: "reward",
            title: "reward",
            render: (text, data)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(text, false, false) : text || "--"
        }
    ]
};
//cid detail
const cid_list = {
    headerList: [
        {
            title: "blocks_cid",
            dataIndex: "cid",
            type: [
                "block_basic"
            ],
            render: (text)=>{
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_5__/* .BrowserView */ .I, {
                            children: text
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_5__/* .MobileView */ .$, {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "copy-row",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text",
                                        children: text
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        text: text,
                                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_icon_copy_svg__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
                                        className: "copy"
                                    })
                                ]
                            })
                        })
                    ]
                });
            }
        },
        {
            title: "cid_height",
            dataIndex: "height",
            type: [
                "block_basic"
            ],
            render: (text)=>{
                if (!text) return "--";
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                    href: `/height/${text}`,
                    className: "link",
                    children: (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatNumber */ .uf)(text)
                });
            }
        },
        {
            title: "block_time",
            dataIndex: "block_time",
            type: [
                "block_basic"
            ],
            render: (text, data)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatDateTime */ .o0)(text, "YYYY-MM-DD")
        },
        {
            title: "blocks_messages",
            dataIndex: "messages_count",
            type: [
                "block_basic"
            ],
            render: (text)=>String(text) || "--"
        },
        {
            title: "blocks_miner",
            dataIndex: "miner_id",
            type: [
                "block_basic"
            ],
            render: (text)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                    href: `/miner/${text}`,
                    className: "link",
                    children: text
                });
            }
        },
        {
            title: "win_count",
            dataIndex: "win_count",
            render: (text)=>String(text) || "--"
        },
        {
            title: "blocks_reward",
            dataIndex: "mined_reward",
            type: [
                "block_basic"
            ],
            render: (text, data)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(text, false, false) : text || "--"
        },
        {
            title: "parents_cid",
            dataIndex: "parents",
            type: [
                "block_basic"
            ],
            render: (text, data)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex flex-col gap-y-2",
                    children: data?.parents?.map((item)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: `/cid/${item}`,
                            className: "link",
                            children: item
                        }, item);
                    })
                });
            }
        },
        {
            title: "parent_weight",
            dataIndex: "parent_weight"
        },
        {
            title: "parent_base_fee",
            dataIndex: "parent_base_fee"
        },
        {
            title: "ticket_value",
            dataIndex: "ticket_value"
        },
        {
            title: "state_root",
            dataIndex: "state_root"
        }
    ],
    columns: (fromList, toList)=>[
            {
                dataIndex: "cid",
                title: "cid",
                render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                        href: `/message/${text}`,
                        className: "link",
                        children: text ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .isIndent */ .EA)(text, 6) : ""
                    })
            },
            {
                dataIndex: "height",
                title: "height",
                render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                        href: `/height/${text}`,
                        className: "link",
                        children: text
                    })
            },
            {
                dataIndex: "block_time",
                title: "block_time",
                render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatDateTime */ .o0)(text, "YYYY-MM-DD HH:mm")
            },
            {
                dataIndex: "from",
                title: "from",
                render: (text, record)=>{
                    if (!text) return "--";
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: "flex items-center gap-x-2",
                        children: [
                            (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .get_account_type */ .$B)(text),
                            fromList?.domains && fromList?.domains[text] && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                href: `/domain/${fromList.domains[text]}?provider=${fromList.provider}`,
                                children: [
                                    "(",
                                    fromList.domains[text],
                                    ")"
                                ]
                            })
                        ]
                    });
                }
            },
            {
                dataIndex: "to",
                title: "to",
                render: (text, record)=>{
                    if (!text) return "--";
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex items-center gap-x-2",
                        children: [
                            (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .get_account_type */ .$B)(text, 0),
                            toList?.domains && toList?.domains[text] && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                href: `/domain/${toList.domains[text]}?provider=${toList.provider}`,
                                children: [
                                    "(",
                                    toList.domains[text],
                                    ")"
                                ]
                            })
                        ]
                    });
                }
            },
            {
                dataIndex: "value",
                title: "value",
                render: (text)=>text ? (0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatFilNum */ .Nm)(text, false, false) : text || "--"
            },
            {
                dataIndex: "exit_code",
                title: "status"
            },
            {
                dataIndex: "method_name",
                title: "method_name"
            }
        ]
};
//deal
const deal_list = {
    list: [
        {
            dataIndex: "deal_id",
            title: "deal_id"
        },
        {
            dataIndex: "service_start_time",
            title: "service_start_time",
            render: (text)=>(0,_utils__WEBPACK_IMPORTED_MODULE_1__/* .formatDateTime */ .o0)(text)
        },
        {
            dataIndex: "epoch",
            title: "epoch",
            render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                    className: "link",
                    href: `/height/${text}`,
                    children: text
                })
        },
        {
            dataIndex: "message_cid",
            title: "message_cid",
            render: (text)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                    className: "link",
                    href: `/message/${text}`,
                    children: text
                })
        },
        {
            dataIndex: "piece_cid",
            title: "piece_cid"
        },
        {
            dataIndex: "verified_deal",
            title: "verified_deal",
            render: (text)=>{
                const icon = typeof text === "boolean" ? text ? "successIcon" : "errorIcon" : "";
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "flex gap-x-2 items-center",
                    children: [
                        icon && (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_4__/* .getSvgIcon */ .a)(icon),
                        String(text)
                    ]
                });
            }
        }
    ],
    content: {
        left_title: "deal_left_title",
        right_title: "deal_right_title",
        value: "deal_value",
        cash: "deal_cash",
        time: "deal_time"
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2140:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var antd_lib_dropdown__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1788);
/* harmony import */ var antd_lib_dropdown__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd_lib_dropdown__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7947);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1982);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);






/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { content, value } = props;
    const showValue = (0,react__WEBPACK_IMPORTED_MODULE_4__.useMemo)(()=>{
        if (value) {
            return value;
        }
        return content[0];
    }, [
        value,
        content
    ]);
    const renderChildren = ()=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "max-h-[300px] overflow-auto",
            children: content.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                className: classnames__WEBPACK_IMPORTED_MODULE_3___default()(`min-w-[230px] w-max inset-y-full max-h-fit list-none p-2.5  border rounded-[5px]  select_shadow  border_color`, (_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default()["drop-menu"])),
                children: content.map((v, index)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                        className: "flex items-center min-h-[36px] ",
                        children: v?.title
                    }, index);
                })
            })
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_dropdown__WEBPACK_IMPORTED_MODULE_1___default()), {
        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().wrap),
        dropdownRender: renderChildren,
        trigger: [
            "hover"
        ],
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: classnames__WEBPACK_IMPORTED_MODULE_3___default()("flex items-center justify-between  min-w-[230px] w-fit h-[32px] px-2.5 rounded-[5px] cursor-pointer border border_color", (_index_module_scss__WEBPACK_IMPORTED_MODULE_5___default().select)),
            children: [
                showValue?.title,
                (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_2__/* .getSvgIcon */ .a)("downIcon")
            ]
        })
    });
});


/***/ }),

/***/ 9199:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2881);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7947);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3495);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _utils__WEBPACK_IMPORTED_MODULE_3__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _utils__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ content, unit = 0 })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "common"
    });
    const [open, setOpen] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const showContent = (0,react__WEBPACK_IMPORTED_MODULE_4__.useMemo)(()=>{
        if (content.length > 2 && !open) {
            return content.slice(0, 2);
        }
        return content;
    }, [
        content,
        open
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
        className: "flex items-baseline flex-col  flex-wrap justify-end gap-2",
        children: [
            showContent.map((item, index)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                    className: "flex w-full items-center gap-x-1 justify-end",
                    children: (0,_utils__WEBPACK_IMPORTED_MODULE_3__/* .get_account_type */ .$B)(item, unit)
                }, index);
            }),
            content.length > 2 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                className: "flex items-center gap-x-1 self-end text_des text-xs cursor-pointer",
                onClick: ()=>{
                    setOpen(!open);
                },
                children: [
                    tr(open ? "no_open" : "open"),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: open ? "transform rotate-180" : "",
                        children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_2__/* .getSvgIcon */ .a)("downIcon")
                    })
                ]
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;