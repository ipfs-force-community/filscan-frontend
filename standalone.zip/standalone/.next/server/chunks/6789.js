exports.id = 6789;
exports.ids = [6789];
exports.modules = {

/***/ 5392:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _linearGradient, _linearGradient2, _linearGradient3, _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgVerify = function SvgVerify(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "1em",
    height: "1em",
    viewBox: "0 0 13 14"
  }, props), _linearGradient || (_linearGradient = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("linearGradient", {
    id: "verify_svg__a"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 0,
    stopColor: "#1764ff"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 1,
    stopColor: "#398bf0"
  }))), _linearGradient2 || (_linearGradient2 = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("linearGradient", {
    xlinkHref: "#verify_svg__a",
    id: "verify_svg__b",
    x1: "114.703%",
    x2: "1.491%",
    y1: "124.283%",
    y2: "26.203%"
  })), _linearGradient3 || (_linearGradient3 = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("linearGradient", {
    xlinkHref: "#verify_svg__a",
    id: "verify_svg__c",
    x1: "88.281%",
    x2: "12.861%",
    y1: "100%",
    y2: "26.203%"
  })), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "url(#verify_svg__b)",
    d: "M6.125 1.477a4.648 4.648 0 1 0 0 9.296 4.648 4.648 0 0 0 0-9.296zm1.9 5.538a.11.11 0 0 0-.031.097l.354 2.066a.219.219 0 0 1-.317.231l-1.855-.975a.11.11 0 0 0-.102 0L4.22 9.41a.219.219 0 0 1-.317-.231l.354-2.066a.112.112 0 0 0-.031-.097L2.723 5.552a.219.219 0 0 1 .122-.373l2.074-.3a.107.107 0 0 0 .082-.061l.927-1.88a.219.219 0 0 1 .393 0l.926 1.88a.11.11 0 0 0 .082.06l2.075.3c.179.027.251.247.121.374z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "url(#verify_svg__c)",
    d: "M12.25 6.125c0-.466-.376-.882-.473-1.318-.1-.45.06-.991-.133-1.399-.195-.412-.71-.622-.988-.976-.279-.357-.364-.916-.712-1.202-.346-.283-.9-.244-1.303-.443C8.243.592 7.93.124 7.488.022A.857.857 0 0 0 7.293 0c-.375 0-.78.202-1.168.202S5.332 0 4.957 0a.94.94 0 0 0-.195.02c-.44.103-.755.57-1.153.766-.403.2-.957.161-1.304.444-.349.285-.435.845-.712 1.202-.278.354-.793.564-.989.976-.191.406-.031.948-.132 1.399C.376 5.243 0 5.659 0 6.125s.376.882.473 1.318c.1.45-.06.991.133 1.399.14.295.444.486.707.701.103.085.202.174.28.275l.001.001a.348.348 0 0 1 .063.306l-.774 2.888a.11.11 0 0 0 .105.138H1l1.54-.15a.434.434 0 0 1 .297.08l1.259.898c.019.014.04.021.063.021a.11.11 0 0 0 .106-.08l.445-1.66a.045.045 0 0 1 .053-.032c.064.015.13.02.195.02.375 0 .78-.202 1.168-.202s.793.203 1.168.203a.94.94 0 0 0 .195-.02.03.03 0 0 1 .037.021l.447 1.668a.11.11 0 0 0 .17.06l1.259-.9A.44.44 0 0 1 9.697 13l1.54.15h.01a.109.109 0 0 0 .106-.137l-.765-2.857a.387.387 0 0 1 .068-.339c.04-.05.083-.098.131-.143.048-.045.099-.089.15-.131.264-.215.568-.406.707-.702.192-.406.032-.947.133-1.398.097-.435.473-.85.473-1.317zm-2.064 3.063a5.021 5.021 0 0 1-1.437 1.295 4.866 4.866 0 0 1-.977.456 4.39 4.39 0 0 1-.559.156 5.174 5.174 0 0 1-2.191-.004 4.074 4.074 0 0 1-.223-.055 5.254 5.254 0 0 1-.875-.324 5.073 5.073 0 0 1-1.86-1.524 5.085 5.085 0 0 1 4.06-8.148 5.085 5.085 0 0 1 5.086 5.085 5.05 5.05 0 0 1-1.024 3.062z"
  }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgVerify);

/***/ }),

/***/ 8620:
/***/ ((module) => {

// Exports
module.exports = {
	"title": "rank_title__Vy861",
	"title-description": "rank_title-description__Q02oW",
	"reset": "rank_reset__0yWi6",
	"table": "rank_table__IpNsf"
};


/***/ }),

/***/ 6789:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2881);
/* harmony import */ var _contents_contract__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5509);
/* harmony import */ var _packages_Table__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(430);
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8804);
/* harmony import */ var _store_server__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(785);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _assets_images_verify_svg__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5392);
/* harmony import */ var _assets_images_black_go_svg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3309);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3495);
/* harmony import */ var _components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1061);
/* harmony import */ var _components_copy__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5174);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9676);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(8620);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(6517);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_15__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_contract__WEBPACK_IMPORTED_MODULE_3__, _packages_Table__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_10__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_contract__WEBPACK_IMPORTED_MODULE_3__, _packages_Table__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 

















const default_sort = {
    field: "transfer_count",
    order: "descend"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ origin })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__/* .Translation */ .W)({
        ns: "contract"
    });
    const { theme, lang } = (0,_store_FilscanStore__WEBPACK_IMPORTED_MODULE_5__/* .useFilscanStore */ .J)();
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false);
    const [current, setCurrent] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(1);
    const [sort, setSort] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)({
        ...default_sort
    });
    const { isMobile } = (0,_components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)();
    const [dataSource, setDataSource] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)({
        data: [],
        total: undefined,
        update_time: ""
    });
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        load();
    }, []);
    const load = async (cur, orders)=>{
        const index = cur || current;
        const sortFile = orders || sort;
        setLoading(true);
        const data = await (0,_store_server__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.contract_rank, {
            page: index - 1,
            limit: origin === "home" ? _utils__WEBPACK_IMPORTED_MODULE_10__/* .pageHomeLimit */ .m$ : _utils__WEBPACK_IMPORTED_MODULE_10__/* .pageLimit */ .P5,
            sort: sortFile.order === "ascend" ? "asc" : "desc",
            field: sortFile?.field
        });
        setLoading(false);
        setDataSource({
            data: data?.evm_contract_list || [],
            total: data?.total,
            update_time: data?.update_time || ""
        });
    };
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_6__.useMemo)(()=>{
        const newArr = origin === "home" ? _contents_contract__WEBPACK_IMPORTED_MODULE_3__/* .contract_rank */ .kf.columns.slice(0, 5) : lodash__WEBPACK_IMPORTED_MODULE_15___default().cloneDeep(_contents_contract__WEBPACK_IMPORTED_MODULE_3__/* .contract_rank */ .kf.columns);
        let content = newArr.filter((value)=>{
            if (isMobile) {
                return value.dataIndex !== "contract_address";
            }
            return true;
        }).map((item)=>{
            if (isMobile && item.dataIndex === "rank") {
                //@ts-ignore
                item.title = (value, record, index)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: `#${record?.rank}`
                    });
                };
                item.render = (value, record)=>{
                    if (!record?.contract_address) return "--";
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: "flex gap-x-2 items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_9___default()), {
                                className: "link_text",
                                href: `/address/${record?.contract_address}`,
                                children: (0,_utils__WEBPACK_IMPORTED_MODULE_10__/* .isIndent */ .EA)(record?.contract_address, 5, 4)
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                text: record?.contract_address
                            })
                        ]
                    });
                };
            }
            if (item.dataIndex === "contract_name") {
                item.render = (text, record)=>{
                    if (text) {
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "flex flex-wrap gap-x-2 items-center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_9___default()), {
                                    href: `/address/${record.contract_address}`,
                                    children: text
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_verify_svg__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                    width: 13,
                                    height: 14
                                })
                            ]
                        });
                    }
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_9___default()), {
                        href: "/contract/verify",
                        className: "text_color",
                        children: tr("ver_address")
                    });
                };
            }
            return {
                ...item,
                title: typeof item.title === "string" ? tr(item.title) : item.title,
                width: origin === "home" ? _contents_contract__WEBPACK_IMPORTED_MODULE_3__/* .homeContractRank */ .AD[item.dataIndex] : item.width
            };
        });
        return content;
    }, [
        theme,
        tr,
        isMobile
    ]);
    const handleChange = (pagination, filters, sorter)=>{
        let cur = pagination.current || current;
        let order = {
            ...sort
        };
        if (sorter?.field) {
            order = {
                field: sorter.field,
                order: sorter.order
            };
        }
        setCurrent(cur);
        setSort(order);
        load(cur, order);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_device_detect__WEBPACK_IMPORTED_MODULE_13__/* .MobileView */ .$, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: classnames__WEBPACK_IMPORTED_MODULE_14___default()("font-PingFang font-semibold text-lg", (_index_module_scss__WEBPACK_IMPORTED_MODULE_17___default().title)),
                        children: tr("contract_rank")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: classnames__WEBPACK_IMPORTED_MODULE_14___default()("text-xs text_des ", (_index_module_scss__WEBPACK_IMPORTED_MODULE_17___default()["title-description"])),
                        children: tr("contract_list_total", {
                            value: dataSource.total
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_device_detect__WEBPACK_IMPORTED_MODULE_13__/* .BrowserView */ .I, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: `flex justify-between items-center h-[30px]`,
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "font-PingFang font-semibold text-lg pl-2.5",
                                children: [
                                    tr("contract_rank"),
                                    origin !== "home" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text_des text-xs font-normal ml-2",
                                        children: tr(_contents_contract__WEBPACK_IMPORTED_MODULE_3__/* .contract_rank */ .kf.title_des, {
                                            value: (0,_utils__WEBPACK_IMPORTED_MODULE_10__/* .formatDateTime */ .o0)(dataSource.update_time, "YYYY-MM-DD HH:mm")
                                        })
                                    })
                                ]
                            }),
                            origin === "home" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_9___default()), {
                                className: "pr-2.5",
                                href: `/contract/rank`,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_black_go_svg__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                    className: "cursor-pointer ",
                                    width: 18,
                                    height: 18
                                })
                            })
                        ]
                    }),
                    origin !== "home" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "text-xs text_des mx-2.5",
                        children: [
                            " ",
                            tr("contract_list_total", {
                                value: dataSource.total
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_14___default()(`mt-4 border  rounded-xl p-5	card_shadow border_color ${origin === "home" ? "h-[650px] " : "h-full"}`, (_index_module_scss__WEBPACK_IMPORTED_MODULE_17___default().reset), (_index_module_scss__WEBPACK_IMPORTED_MODULE_17___default().table)),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_Table__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    className: "-mt-2.5 ",
                    total: origin !== "home" ? dataSource.total : 0,
                    data: dataSource?.data || [],
                    columns: columns || [],
                    loading: loading,
                    onChange: handleChange
                }, "contract_rank")
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;