"use strict";
exports.id = 8833;
exports.ids = [8833];
exports.modules = {

/***/ 9484:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-accelerate.aliyuncs.com/client/_next/static/media/accountBg.5a5bf589.png","height":600,"width":2880,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAAOklEQVR42mNABqovbrDKLrsqFNF6Qcq07pK0WdMtIbik7M37bPw77wvIh90Vlsg4Jc0Sc1BKLW+fOADxOBGg80XKYQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":2});

/***/ }),

/***/ 8666:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-accelerate.aliyuncs.com/client/_next/static/media/accountMain.2346e495.png","height":578,"width":600,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA9UlEQVR42mMAAU63ehY1BgZ2BgYGVgbXdfL6IJqBga3q3w5mBhBQy7bjFPao1FAtOb3Fve7MH9HCY3Pc6xj4GcBg438mBhBIPzy1YMrF/zUzL/1nKLzwP/7CmoXl/5aXMICA8dXzAfwTz15L6Lrw377+4n+G6ONXU7bPDc58uuo2A+ulB1V6y273OxVfeqiSfeq/VPbh/9bduz4H7dt8yHH+BisGtjOPL8gtuzPDetq9//bzrv+znnP2l033yf86XodOMICA8MwXilxLr2SJ5267phi6+7+y+Z7/Sjyb/ympLallQAOcAgylFsKy5U5sjqpKMEEAjHdhtJ5gBAsAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 6854:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ useCountdown)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

// 自定义hook
function useCountdown(initialCount) {
    const [count, setCount] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initialCount);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (count > 0) {
            const timer = setInterval(()=>{
                setCount((prevCount)=>prevCount - 1);
            }, 1000);
            return ()=>clearInterval(timer);
        }
    }, [
        count
    ]);
    const resetCountdown = (newCount)=>{
        setCount(newCount);
    };
    return {
        count,
        resetCountdown
    };
}


/***/ }),

/***/ 7588:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _assets_images_accountBg_png__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9484);
/* harmony import */ var _assets_images_accountMain_png__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8666);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2881);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_4__]);
_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_4__/* .Translation */ .W)({
        ns: "common"
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-full relative h-[320px] bg-accountBg",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                src: _assets_images_accountBg_png__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z,
                alt: "",
                className: "h-[320px]"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "absolute top-[50%] left-[50%] -translate-x-1/2 -translate-y-1/2  max-w-[1440px] w-full flex justify-between px-[70px]",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "text-white text-5xl flex justify-center flex-col  ml-[90px]",
                        children: [
                            tr("account_banner_bg"),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: " text-gray-400 text-xl mt-4",
                                children: tr("account_banner_main")
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                        src: _assets_images_accountMain_png__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
                        alt: "",
                        className: " h-[280px] w-auto"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {})
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2104:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2881);
/* harmony import */ var _components_hooks_useCount__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6854);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8054);
/* harmony import */ var _store_server__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(785);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__]);
_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/** @format */ 




// 在组件中使用自定义hook
function VerifyCodeButton({ mail, onChange }) {
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "common"
    });
    const { count, resetCountdown } = (0,_components_hooks_useCount__WEBPACK_IMPORTED_MODULE_2__/* .useCountdown */ .a)(0);
    function validateEmail(email) {
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    }
    // 模拟发送验证码的函数
    const sendCode = async (e)=>{
        // 假设验证码发送后，倒计时60秒
        if (mail && validateEmail(mail)) {
            resetCountdown(60); // 证码有效期为60秒
            const result = await (0,_store_server__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__/* .proApi */ .g2.send_code, {
                mail: mail
            });
            if (result?.token) {
                localStorage.setItem("token", result.token);
                if (onChange) onChange(result?.token);
            }
        }
        e.preventDefault();
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
        className: "text_primary text-sm border-s border_color pl-2 cursor-pointer",
        disabled: count > 0,
        onClick: sendCode,
        children: count > 0 ? `${tr("retry_code")}(${count})` : tr("get_code")
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VerifyCodeButton);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;