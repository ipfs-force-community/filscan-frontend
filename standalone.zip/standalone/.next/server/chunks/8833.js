"use strict";
exports.id = 8833;
exports.ids = [8833];
exports.modules = {

/***/ 6854:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a: () => (/* binding */ useCountdown)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

// 自定义hook
function useCountdown(initialCount) {
    const [count, setCount] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initialCount);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (count > 0) {
            const timer = setInterval(()=>{
                setCount((prevCount)=>prevCount - 1);
            }, 1000);
            return ()=>clearInterval(timer);
        }
    }, [
        count
    ]);
    const resetCountdown = (newCount)=>{
        setCount(newCount);
    };
    return {
        count,
        resetCountdown
    };
}


/***/ }),

/***/ 7588:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full bg-black",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
            src: `${_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .fvmUrl */ .dE}/images/account.png`,
            className: "w-full h-auto"
        })
    });
});


/***/ }),

/***/ 2104:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2881);
/* harmony import */ var _components_hooks_useCount__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6854);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8054);
/* harmony import */ var _store_server__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(785);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__]);
_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/** @format */ 




// 在组件中使用自定义hook
function VerifyCodeButton({ mail, onChange }) {
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "common"
    });
    const { count, resetCountdown } = (0,_components_hooks_useCount__WEBPACK_IMPORTED_MODULE_2__/* .useCountdown */ .a)(0);
    function validateEmail(email) {
        var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    }
    // 模拟发送验证码的函数
    const sendCode = async (e)=>{
        // 假设验证码发送后，倒计时60秒
        if (mail && validateEmail(mail)) {
            resetCountdown(60); // 证码有效期为60秒
            const result = await (0,_store_server__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__/* .proApi */ .g2.send_code, {
                mail: mail
            });
            if (result?.token) {
                if (onChange) onChange(result?.token);
            }
        }
        e.preventDefault();
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
        className: "text_primary text-sm border-s border_color pl-2 cursor-pointer",
        disabled: count > 0,
        onClick: sendCode,
        children: count > 0 ? `${tr("retry_code")}(${count})` : tr("get_code")
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VerifyCodeButton);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;