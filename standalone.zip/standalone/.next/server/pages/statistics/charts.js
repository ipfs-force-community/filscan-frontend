(() => {
var exports = {};
exports.id = 6468;
exports.ids = [6468];
exports.modules = {

/***/ 2976:
/***/ ((module) => {

// Exports
module.exports = {
	"statistics-charts": "charts_statistics-charts__OgleB",
	"content": "charts_content__HybXV",
	"nav-wrap": "charts_nav-wrap__BDVsE",
	"active": "charts_active__4Lv5E",
	"tab-content": "charts_tab-content__Iukl8"
};


/***/ }),

/***/ 7804:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap": "ActiveNodeTrend_wrap__Z6TYG",
	"title-wrap": "ActiveNodeTrend_title-wrap__hAQ__",
	"content": "ActiveNodeTrend_content__BTfXp"
};


/***/ }),

/***/ 9896:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap": "BlockRewardPer_wrap__xpu7i",
	"title-wrap": "BlockRewardPer_title-wrap__SCimK",
	"content": "BlockRewardPer_content__b7o6_"
};


/***/ }),

/***/ 3728:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap": "BlockRewardTrend_wrap__ORqAq",
	"title-wrap": "BlockRewardTrend_title-wrap__x_7Dg",
	"content": "BlockRewardTrend_content__wrdxK"
};


/***/ }),

/***/ 8694:
/***/ ((module) => {

// Exports
module.exports = {
	"title": "Charts_title__lJgS2",
	"content": "Charts_content__y5aEC",
	"chart-wrap": "Charts_chart-wrap__uAaCb",
	"chart": "Charts_chart__fZ2Fi",
	"legend-label-wrap": "Charts_legend-label-wrap__odnlJ",
	"value": "Charts_value__Z_Owu",
	"dot": "Charts_dot__Dilb2",
	"describe-item": "Charts_describe-item__kxxtm",
	"label": "Charts_label__USQzZ"
};


/***/ }),

/***/ 3565:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap": "DCCTrend_wrap__KKvYl",
	"title-wrap": "DCCTrend_title-wrap__oHNrI",
	"content": "DCCTrend_content__rad_Y"
};


/***/ }),

/***/ 8690:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap": "FilChart_wrap__2RDQX",
	"title": "FilChart_title__jPPCY",
	"card-reset": "FilChart_card-reset__9tmJi",
	"card": "FilChart_card__b9KZA",
	"echart": "FilChart_echart__Ky_O8",
	"legend-wrap": "FilChart_legend-wrap__I18qn",
	"legend-item": "FilChart_legend-item__9kuYe",
	"legend-item-left": "FilChart_legend-item-left__AjHpN",
	"legend-value": "FilChart_legend-value__QvpSJ"
};


/***/ }),

/***/ 9986:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap-reset": "Meta_wrap-reset__UI0i3",
	"wrap": "Meta_wrap__V0dCJ",
	"item-reset": "Meta_item-reset__3IGtK",
	"item": "Meta_item__1xyNL"
};


/***/ }),

/***/ 8221:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   config: () => (/* binding */ config),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   getServerSideProps: () => (/* binding */ getServerSideProps),
/* harmony export */   getStaticPaths: () => (/* binding */ getStaticPaths),
/* harmony export */   getStaticProps: () => (/* binding */ getStaticProps),
/* harmony export */   reportWebVitals: () => (/* binding */ reportWebVitals),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   unstable_getServerProps: () => (/* binding */ unstable_getServerProps),
/* harmony export */   unstable_getServerSideProps: () => (/* binding */ unstable_getServerSideProps),
/* harmony export */   unstable_getStaticParams: () => (/* binding */ unstable_getStaticParams),
/* harmony export */   unstable_getStaticPaths: () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   unstable_getStaticProps: () => (/* binding */ unstable_getStaticProps)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3185);
/* harmony import */ var next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5244);
/* harmony import */ var next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7182);
/* harmony import */ var private_next_pages_document_tsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3162);
/* harmony import */ var private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4178);
/* harmony import */ var private_next_pages_statistics_charts_index_tsx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(632);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__, private_next_pages_statistics_charts_index_tsx__WEBPACK_IMPORTED_MODULE_5__]);
([private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__, private_next_pages_statistics_charts_index_tsx__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// @ts-ignore this need to be imported from next/dist to be external



// Import the app and document modules.
// @ts-expect-error - replaced by webpack/turbopack loader

// @ts-expect-error - replaced by webpack/turbopack loader

// Import the userland code.
// @ts-expect-error - replaced by webpack/turbopack loader

const PagesRouteModule = next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__.PagesRouteModule;
// Re-export the component (should be the default export).
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_statistics_charts_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "default"));
// Re-export methods.
const getStaticProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_statistics_charts_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "getStaticProps");
const getStaticPaths = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_statistics_charts_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "getStaticPaths");
const getServerSideProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_statistics_charts_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "getServerSideProps");
const config = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_statistics_charts_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "config");
const reportWebVitals = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_statistics_charts_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "reportWebVitals");
// Re-export legacy methods.
const unstable_getStaticProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_statistics_charts_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticProps");
const unstable_getStaticPaths = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_statistics_charts_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticPaths");
const unstable_getStaticParams = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_statistics_charts_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticParams");
const unstable_getServerProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_statistics_charts_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getServerProps");
const unstable_getServerSideProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_statistics_charts_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getServerSideProps");
// Create and export the route module that will be consumed.
const routeModule = new PagesRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__/* .RouteKind */ .x.PAGES,
        page: "/statistics/charts",
        pathname: "/statistics/charts",
        // The following aren't used in production.
        bundlePath: "",
        filename: ""
    },
    components: {
        App: private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__["default"],
        Document: private_next_pages_document_tsx__WEBPACK_IMPORTED_MODULE_3__["default"]
    },
    userland: private_next_pages_statistics_charts_index_tsx__WEBPACK_IMPORTED_MODULE_5__
});

//# sourceMappingURL=pages.js.map
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2305:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7947);
/* harmony import */ var antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9348);
/* harmony import */ var antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_2__);
/** @format */ 


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { context, icon = true } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_2___default()), {
        overlayClassName: "custom-tooltip-wrap",
        title: context,
        children: [
            icon ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "cursor-pointer",
                children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)("tip")
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: props.children
            })
        ]
    });
});


/***/ }),

/***/ 632:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2881);
/* harmony import */ var _components_hooks_useHash__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8087);
/* harmony import */ var _contents_statistic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4852);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7947);
/* harmony import */ var _src_statistics_Trend__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1538);
/* harmony import */ var _src_statistics_BlockRewardTrend__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(658);
/* harmony import */ var _src_statistics_BlockRewardPer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8297);
/* harmony import */ var _src_statistics_ActiveNodeTrend__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(883);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _src_statistics_FilChart__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1340);
/* harmony import */ var _src_statistics_Charts__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7320);
/* harmony import */ var _src_statistics_DCCTrend__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(7927);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9676);
/* harmony import */ var _src_statistics_Meta__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1004);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(2976);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_16__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_statistic__WEBPACK_IMPORTED_MODULE_3__, _src_statistics_Trend__WEBPACK_IMPORTED_MODULE_5__, _src_statistics_BlockRewardTrend__WEBPACK_IMPORTED_MODULE_6__, _src_statistics_BlockRewardPer__WEBPACK_IMPORTED_MODULE_7__, _src_statistics_ActiveNodeTrend__WEBPACK_IMPORTED_MODULE_8__, _src_statistics_FilChart__WEBPACK_IMPORTED_MODULE_10__, _src_statistics_Charts__WEBPACK_IMPORTED_MODULE_11__, _src_statistics_DCCTrend__WEBPACK_IMPORTED_MODULE_12__, _src_statistics_Meta__WEBPACK_IMPORTED_MODULE_15__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_statistic__WEBPACK_IMPORTED_MODULE_3__, _src_statistics_Trend__WEBPACK_IMPORTED_MODULE_5__, _src_statistics_BlockRewardTrend__WEBPACK_IMPORTED_MODULE_6__, _src_statistics_BlockRewardPer__WEBPACK_IMPORTED_MODULE_7__, _src_statistics_ActiveNodeTrend__WEBPACK_IMPORTED_MODULE_8__, _src_statistics_FilChart__WEBPACK_IMPORTED_MODULE_10__, _src_statistics_Charts__WEBPACK_IMPORTED_MODULE_11__, _src_statistics_DCCTrend__WEBPACK_IMPORTED_MODULE_12__, _src_statistics_Meta__WEBPACK_IMPORTED_MODULE_15__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);

















/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "static"
    });
    const { hash } = (0,_components_hooks_useHash__WEBPACK_IMPORTED_MODULE_2__/* .useHash */ .H)();
    const renderNavChildren = (itemChildren)=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
            className: "flex flex-col w-full",
            children: itemChildren.map((child)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_9___default()), {
                    href: `/statistics/charts#${child.key}`,
                    scroll: false,
                    className: `flex items-center gap-x-2 p-2 w-full pl-10 h-10 text_color hover:bg-bg_hover rounded-[5px] ${hash === child.key ? "text-primary bg-bg_hover" : ""}`,
                    children: tr(child?.title || child.key)
                }, child.key);
            })
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_13___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default()["statistics-charts"]), "main_contain !overflow-auto"),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: classnames__WEBPACK_IMPORTED_MODULE_13___default()("flex gap-x-5", (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().content)),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_14__/* .BrowserView */ .I, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "w-[209px]",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex justify-center h-10 flex-col text-lg font-medium gap-y-2.5 mb-2.5 mx-2.5",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: tr("static_overview")
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                className: "flex flex-col py-4 h-fit card_shadow border border_color rounded-xl cursor-pointer",
                                children: _contents_statistic__WEBPACK_IMPORTED_MODULE_3__/* .chartsNav */ .k2.map((item)=>{
                                    const { preIcon, title, key } = item;
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "relative flex flex-col w-full px-4 items-center font-DINPro-Medium",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_9___default()), {
                                                href: `/statistics/charts#${item.key}`,
                                                scroll: false,
                                                className: `flex items-center gap-x-2 w-full h-10 px-2.5 text_color hover:bg-bg_hover rounded-[5px] ${hash === item.key ? "text-primary bg-bg_hover" : ""}`,
                                                children: [
                                                    preIcon && (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_4__/* .getSvgIcon */ .a)(preIcon),
                                                    tr(title || key)
                                                ]
                                            }, item.key),
                                            item.children && renderNavChildren(item.children)
                                        ]
                                    }, item.key);
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_14__/* .MobileView */ .$, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default()["nav-wrap"]),
                        children: _contents_statistic__WEBPACK_IMPORTED_MODULE_3__/* .chartsNav */ .k2.map((value, index)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_9___default()), {
                                className: hash === value.key || hash === "" && index == 0 ? (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().active) : "",
                                href: `/statistics/charts#${value.key}`,
                                children: tr(value.title || value.key)
                            }, value.key);
                        })
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: classnames__WEBPACK_IMPORTED_MODULE_13___default()("flex flex-1 flex-col gap-y-6", (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default()["tab-content"])),
                    children: [
                        !hash && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_statistics_Meta__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {}),
                        hash === "networks" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_statistics_Meta__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {}),
                        hash === "BlockChain" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_statistics_Trend__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_statistics_DCCTrend__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_statistics_BlockRewardTrend__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_statistics_BlockRewardPer__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_statistics_ActiveNodeTrend__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {})
                            ]
                        }),
                        hash === "fil_overview" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_statistics_FilChart__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_statistics_Charts__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {})
                            ]
                        })
                    ]
                })
            ]
        })
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 883:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _components_echarts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3778);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2881);
/* harmony import */ var _contents_statistic__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4852);
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8804);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3495);
/* harmony import */ var _utils_echarts__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7355);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _ActiveNodeTrend_module_scss__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(7804);
/* harmony import */ var _ActiveNodeTrend_module_scss__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_ActiveNodeTrend_module_scss__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8108);
/* harmony import */ var _packages_segmented__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5622);
/* harmony import */ var _components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1061);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_statistic__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_6__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__, _packages_segmented__WEBPACK_IMPORTED_MODULE_11__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_statistic__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_6__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__, _packages_segmented__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 













/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { className } = props;
    const { theme } = (0,_store_FilscanStore__WEBPACK_IMPORTED_MODULE_5__/* .useFilscanStore */ .J)();
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__/* .Translation */ .W)({
        ns: "static"
    });
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)({});
    const [interval, setInterval] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)("24h");
    const { isMobile } = (0,_components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)();
    const color = (0,react__WEBPACK_IMPORTED_MODULE_8__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_7__/* .getColor */ .Lq)(theme);
    }, [
        theme
    ]);
    const default_xAxis = (0,react__WEBPACK_IMPORTED_MODULE_8__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_7__/* .get_xAxis */ .Fs)(theme, isMobile);
    }, [
        theme,
        isMobile
    ]);
    const defaultOptions = (0,react__WEBPACK_IMPORTED_MODULE_8__.useMemo)(()=>{
        return {
            grid: {
                top: 30,
                left: 20,
                right: 20,
                bottom: 20,
                containLabel: true
            },
            yAxis: {
                type: "value",
                position: "left",
                scale: true,
                nameTextStyle: {
                    color: color.textStyle
                },
                axisLabel: {
                    formatter: "{value}",
                    textStyle: {
                        //  fontSize: this.fontSize,
                        color: isMobile ? color.mobileLabelColor : color.labelColor
                    }
                },
                axisLine: {
                    show: false
                },
                axisTick: {
                    show: false
                },
                splitLine: {
                    show: true,
                    lineStyle: {
                        type: "dashed",
                        color: color.splitLine
                    }
                }
            },
            legend: {
                show: false
            },
            tooltip: {
                //@ts-ignore
                position: function(pos, params, dom, rect, size) {
                    // 鼠标在左侧时 tooltip 显示到右侧，鼠标在右侧时 tooltip 显示到左侧。
                    var obj = {
                        top: 80
                    };
                    //@ts-ignore
                    obj[[
                        "left",
                        "right"
                    ][+(pos[0] < size.viewSize[0] / 2)]] = 5;
                    return isMobile ? obj : undefined;
                },
                trigger: "axis",
                backgroundColor: color.toolbox,
                borderColor: "transparent",
                textStyle: {
                    color: "#ffffff"
                },
                formatter (v) {
                    var result = v[0]?.data?.showTime;
                    v.forEach((item)=>{
                        if (item.data) {
                            result += "<br/>" + item.marker + item.seriesName + ": " + item.data.amount + item.data.unit;
                        }
                    });
                    return result;
                }
            }
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        theme,
        isMobile
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(()=>{
        load();
    }, []);
    const load = async (time)=>{
        const seriesObj = {};
        _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .active_miner_count */ .bZ.list.forEach((v)=>{
            seriesObj[v.dataIndex] = [];
        });
        const dateList = [];
        const seriesData = [];
        const inter = time || interval;
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.static_active_miner, {
            interval: inter
        });
        result?.items?.forEach((value)=>{
            const { block_time, active_miner_count } = value;
            const showTime = inter === "24h" ? (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatDateTime */ .o0)(block_time, "HH:mm") : (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatDateTime */ .o0)(block_time, "MM-DD HH:mm");
            dateList.push(showTime);
            //amount
            seriesObj.active_miner_count.push({
                value: active_miner_count,
                amount: active_miner_count,
                showTime: (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatDateTime */ .o0)(block_time, "YYYY-MM-DD HH:mm"),
                unit: ""
            });
        });
        _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .active_miner_count */ .bZ.list.forEach((item)=>{
            seriesData.push({
                type: item.type,
                ..._utils_echarts__WEBPACK_IMPORTED_MODULE_7__/* .seriesChangeArea */ .v$,
                data: seriesObj[item.dataIndex],
                name: tr(item.title),
                symbol: "circle",
                smooth: true,
                itemStyle: {
                    color: item.color
                },
                barMaxWidth: "30"
            });
        });
        setOptions({
            series: seriesData,
            xData: dateList
        });
    };
    const newOptions = (0,react__WEBPACK_IMPORTED_MODULE_8__.useMemo)(()=>{
        const newSeries = [];
        (options?.series || []).forEach((seriesItem)=>{
            newSeries.push(seriesItem);
        });
        return {
            ...defaultOptions,
            xAxis: {
                ...default_xAxis,
                data: options?.xData || []
            },
            series: newSeries
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        options,
        defaultOptions
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        //id='active_nodes'
        className: classnames__WEBPACK_IMPORTED_MODULE_9___default()((_ActiveNodeTrend_module_scss__WEBPACK_IMPORTED_MODULE_13___default().wrap), `w-full h-[full]  ${className}`),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_9___default()("flex-1 flex flex-row flex-wrap  justify-between items-center mb-4 mx-2.5", (_ActiveNodeTrend_module_scss__WEBPACK_IMPORTED_MODULE_13___default()["title-wrap"])),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "min-w-[120px] w-fit font-PingFang font-semibold text-lg ",
                        children: tr("active_nodes")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_segmented__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                        defaultValue: interval,
                        data: _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .timeList */ .t9,
                        ns: "static",
                        isHash: false,
                        onChange: (value)=>{
                            setInterval(value);
                            load(value);
                        }
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_9___default()(`h-[350px] w-full card_shadow border pb-2 border_color rounded-xl`, (_ActiveNodeTrend_module_scss__WEBPACK_IMPORTED_MODULE_13___default().content)),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    options: newOptions
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8297:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _components_echarts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3778);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2881);
/* harmony import */ var _contents_statistic__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4852);
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8804);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3495);
/* harmony import */ var _utils_echarts__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7355);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _BlockRewardPer_module_scss__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9896);
/* harmony import */ var _BlockRewardPer_module_scss__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_BlockRewardPer_module_scss__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8108);
/* harmony import */ var _packages_segmented__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5622);
/* harmony import */ var _components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1061);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_statistic__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_6__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__, _packages_segmented__WEBPACK_IMPORTED_MODULE_11__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_statistic__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_6__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__, _packages_segmented__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 













/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { className } = props;
    const { theme, lang } = (0,_store_FilscanStore__WEBPACK_IMPORTED_MODULE_5__/* .useFilscanStore */ .J)();
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__/* .Translation */ .W)({
        ns: "static"
    });
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)({});
    const [interval, setInterval] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)("24h");
    const { isMobile } = (0,_components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)();
    const color = (0,react__WEBPACK_IMPORTED_MODULE_8__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_7__/* .getColor */ .Lq)(theme);
    }, [
        theme
    ]);
    const default_xAxis = (0,react__WEBPACK_IMPORTED_MODULE_8__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_7__/* .get_xAxis */ .Fs)(theme, isMobile);
    }, [
        theme,
        isMobile
    ]);
    const defaultOptions = (0,react__WEBPACK_IMPORTED_MODULE_8__.useMemo)(()=>{
        return {
            grid: {
                top: 30,
                left: 20,
                right: 20,
                bottom: 20,
                containLabel: true
            },
            yAxis: {
                type: "value",
                position: "left",
                scale: true,
                nameTextStyle: {
                    color: color.textStyle
                },
                axisLabel: {
                    formatter: "{value} FIL",
                    textStyle: {
                        //  fontSize: this.fontSize,
                        color: isMobile ? color.mobileLabelColor : color.labelColor
                    }
                },
                axisLine: {
                    show: false
                },
                axisTick: {
                    show: false
                },
                splitLine: {
                    show: true,
                    lineStyle: {
                        type: "dashed",
                        color: color.splitLine
                    }
                }
            },
            legend: {
                show: false
            },
            tooltip: {
                //@ts-ignore
                position: function(pos, params, dom, rect, size) {
                    // 鼠标在左侧时 tooltip 显示到右侧，鼠标在右侧时 tooltip 显示到左侧。
                    var obj = {
                        top: 80
                    };
                    //@ts-ignore
                    obj[[
                        "left",
                        "right"
                    ][+(pos[0] < size.viewSize[0] / 2)]] = 5;
                    return isMobile ? obj : undefined;
                },
                trigger: "axis",
                backgroundColor: color.toolbox,
                borderColor: "transparent",
                textStyle: {
                    color: "#ffffff"
                },
                formatter (v) {
                    var result = v[0].data.showTime;
                    v.forEach((item)=>{
                        if (item.data) {
                            result += "<br/>" + item.marker + tr(item.seriesName) + ": " + item.data.amount + item.data.unit + "/T";
                        }
                    });
                    return result;
                }
            }
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        theme,
        lang,
        isMobile
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(()=>{
        load();
    }, []);
    const load = async (time)=>{
        const seriesObj = {};
        _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .block_rewards_per */ .eh.list.forEach((v)=>{
            seriesObj[v.dataIndex] = [];
        });
        const dateList = [];
        const seriesData = [];
        const inter = time || interval;
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.static_block_trend, {
            interval: inter
        }, {
            flag: "new"
        });
        result?.items?.forEach((value)=>{
            const { block_time, block_reward_per_tib } = value;
            const showTime = inter === "24h" ? (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatDateTime */ .o0)(block_time, "HH:mm") : (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatDateTime */ .o0)(block_time, "MM-DD HH:mm");
            dateList.push(showTime);
            //amount
            seriesObj.block_reward_per_tib.push({
                value: (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatFil */ .Uk)(block_reward_per_tib, "FIL", 2),
                showTime: (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatDateTime */ .o0)(block_time, "YYYY-MM-DD HH:mm"),
                amount: (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatFilNum */ .Nm)(block_reward_per_tib, false, false, 4, false).split(" ")[0],
                unit: "FIL"
            });
        });
        _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .block_rewards_per */ .eh.list.forEach((item)=>{
            seriesData.push({
                type: item.type,
                ..._utils_echarts__WEBPACK_IMPORTED_MODULE_7__/* .seriesChangeArea */ .v$,
                data: seriesObj[item.dataIndex],
                name: item.title,
                symbol: "circle",
                smooth: true,
                itemStyle: {
                    color: item.color
                },
                barMaxWidth: "30"
            });
        });
        setOptions({
            series: seriesData,
            xData: dateList
        });
    };
    const newOptions = (0,react__WEBPACK_IMPORTED_MODULE_8__.useMemo)(()=>{
        const newSeries = [];
        (options?.series || []).forEach((seriesItem)=>{
            newSeries.push(seriesItem);
        });
        return {
            ...defaultOptions,
            xAxis: {
                ...default_xAxis,
                data: options?.xData || []
            },
            series: newSeries
        };
    }, [
        options,
        defaultOptions
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        // id='block_reward_per'
        className: classnames__WEBPACK_IMPORTED_MODULE_9___default()((_BlockRewardPer_module_scss__WEBPACK_IMPORTED_MODULE_13___default().wrap), `w-full h-[full]  ${className}`),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_9___default()("flex-1 flex flex-row flex-wrap  justify-between items-center mb-4 mx-2.5", (_BlockRewardPer_module_scss__WEBPACK_IMPORTED_MODULE_13___default()["title-wrap"])),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "min-w-[120px] w-fit font-PingFang font-semibold text-lg ",
                        children: tr("block_reward_per_TiB")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_segmented__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                        defaultValue: interval,
                        data: _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .timeList */ .t9,
                        ns: "static",
                        isHash: false,
                        onChange: (value)=>{
                            setInterval(value);
                            load(value);
                        }
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_9___default()(`h-[350px] w-full card_shadow border border_color pb-2 rounded-xl`, (_BlockRewardPer_module_scss__WEBPACK_IMPORTED_MODULE_13___default().content)),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    options: newOptions
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 658:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _components_echarts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3778);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2881);
/* harmony import */ var _contents_statistic__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4852);
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8804);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3495);
/* harmony import */ var _utils_echarts__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7355);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _BlockRewardTrend_module_scss__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3728);
/* harmony import */ var _BlockRewardTrend_module_scss__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_BlockRewardTrend_module_scss__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8108);
/* harmony import */ var _packages_segmented__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5622);
/* harmony import */ var _components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1061);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_statistic__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_6__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__, _packages_segmented__WEBPACK_IMPORTED_MODULE_11__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_statistic__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_6__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__, _packages_segmented__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 













/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { className } = props;
    const { theme, lang } = (0,_store_FilscanStore__WEBPACK_IMPORTED_MODULE_5__/* .useFilscanStore */ .J)();
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__/* .Translation */ .W)({
        ns: "static"
    });
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)({});
    const [interval, setInterval] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)("24h");
    const { isMobile } = (0,_components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)();
    const color = (0,react__WEBPACK_IMPORTED_MODULE_8__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_7__/* .getColor */ .Lq)(theme);
    }, [
        theme
    ]);
    const default_xAxis = (0,react__WEBPACK_IMPORTED_MODULE_8__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_7__/* .get_xAxis */ .Fs)(theme, isMobile);
    }, [
        theme,
        isMobile
    ]);
    const defaultOptions = (0,react__WEBPACK_IMPORTED_MODULE_8__.useMemo)(()=>{
        return {
            grid: {
                top: 30,
                left: 20,
                right: 20,
                bottom: 20,
                containLabel: true
            },
            yAxis: {
                type: "value",
                position: "left",
                scale: true,
                nameTextStyle: {
                    color: color.textStyle
                },
                axisLabel: {
                    formatter: "{value} FIL",
                    textStyle: {
                        //  fontSize: this.fontSize,
                        color: isMobile ? color.mobileLabelColor : color.labelColor
                    }
                },
                axisLine: {
                    show: false
                },
                axisTick: {
                    show: false
                },
                splitLine: {
                    show: true,
                    lineStyle: {
                        type: "dashed",
                        color: color.splitLine
                    }
                }
            },
            legend: {
                show: false
            },
            tooltip: {
                //@ts-ignore
                position: function(pos, params, dom, rect, size) {
                    // 鼠标在左侧时 tooltip 显示到右侧，鼠标在右侧时 tooltip 显示到左侧。
                    var obj = {
                        top: 80
                    };
                    //@ts-ignore
                    obj[[
                        "left",
                        "right"
                    ][+(pos[0] < size.viewSize[0] / 2)]] = 5;
                    return isMobile ? obj : undefined;
                },
                trigger: "axis",
                backgroundColor: color.toolbox,
                borderColor: "transparent",
                textStyle: {
                    color: "#ffffff"
                },
                formatter (v) {
                    var result = v[0].data.showTime;
                    v.forEach((item)=>{
                        if (item.data) {
                            result += "<br/>" + item.marker + tr(item.seriesName) + ": " + item.data.amount + item.data.unit;
                        }
                    });
                    return result;
                }
            }
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        theme,
        lang,
        isMobile
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(()=>{
        load();
    }, []);
    const load = async (time)=>{
        const seriesObj = {};
        _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .block_rewards */ .jD.list.forEach((v)=>{
            seriesObj[v.dataIndex] = [];
        });
        const dateList = [];
        const seriesData = [];
        const inter = time || interval;
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.static_block_trend, {
            interval: inter
        });
        result?.items?.forEach((value)=>{
            const { block_time, acc_block_rewards } = value;
            const showTime = inter === "24h" ? (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatDateTime */ .o0)(block_time, "HH:mm") : (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatDateTime */ .o0)(block_time, "MM-DD HH:mm");
            dateList.push(showTime);
            //amount
            seriesObj.acc_block_rewards.push({
                value: (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatFil */ .Uk)(acc_block_rewards, "FIL", 2),
                showTime: (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatDateTime */ .o0)(block_time, "YYYY-MM-DD HH:mm"),
                amount: (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatFilNum */ .Nm)(acc_block_rewards, false, false, 4, false).split(" ")[0],
                unit: "FIL"
            });
        });
        _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .block_rewards */ .jD.list.forEach((item)=>{
            seriesData.push({
                type: item.type,
                ..._utils_echarts__WEBPACK_IMPORTED_MODULE_7__/* .seriesChangeArea */ .v$,
                data: seriesObj[item.dataIndex],
                name: item.title,
                symbol: "circle",
                smooth: true,
                itemStyle: {
                    color: item.color
                },
                barMaxWidth: "30"
            });
        });
        setOptions({
            series: seriesData,
            xData: dateList
        });
    };
    const newOptions = (0,react__WEBPACK_IMPORTED_MODULE_8__.useMemo)(()=>{
        const newSeries = [];
        (options?.series || []).forEach((seriesItem)=>{
            newSeries.push(seriesItem);
        });
        return {
            ...defaultOptions,
            xAxis: {
                ...default_xAxis,
                data: options?.xData || []
            },
            series: newSeries
        };
    }, [
        options,
        defaultOptions
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        // id='block_trend'
        className: classnames__WEBPACK_IMPORTED_MODULE_9___default()((_BlockRewardTrend_module_scss__WEBPACK_IMPORTED_MODULE_13___default().wrap), `w-full h-[full]  ${className}`),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_9___default()("flex-1 flex flex-row flex-wrap  justify-between items-center mb-4 mx-2.5", (_BlockRewardTrend_module_scss__WEBPACK_IMPORTED_MODULE_13___default()["title-wrap"])),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "min-w-[120px] w-fit font-PingFang font-semibold text-lg ",
                        children: tr("block_trend")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_segmented__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                        defaultValue: interval,
                        data: _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .timeList */ .t9,
                        ns: "static",
                        isHash: false,
                        onChange: (value)=>{
                            setInterval(value);
                            load(value);
                        }
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_9___default()(`h-[350px] w-full pb-2 card_shadow border border_color rounded-xl`, (_BlockRewardTrend_module_scss__WEBPACK_IMPORTED_MODULE_13___default().content)),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    options: newOptions
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7320:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_echarts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3778);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2881);
/* harmony import */ var _contents_statistic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4852);
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8804);
/* harmony import */ var _utils_echarts__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7355);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _Charts_module_scss__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8694);
/* harmony import */ var _Charts_module_scss__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_Charts_module_scss__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1061);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9676);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_statistic__WEBPACK_IMPORTED_MODULE_3__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_statistic__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 










function Overview() {
    const { theme, lang } = (0,_store_FilscanStore__WEBPACK_IMPORTED_MODULE_4__/* .useFilscanStore */ .J)();
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__/* .Translation */ .W)({
        ns: "static"
    });
    const [legendData, setLegendData] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({});
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)({});
    const { isMobile } = (0,_components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    const color = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_5__/* .getColor */ .Lq)(theme);
    }, [
        theme
    ]);
    const defaultOtions = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        return {
            tooltip: {
                show: false
            },
            series: [
                {
                    type: "pie",
                    radius: "50%",
                    label: {
                        show: true,
                        color: color.labelColor,
                        formatter: (param)=>{
                            return param.name + "(" + param.value + "%)";
                        //return param.name + '<br />' +`<span style="color:${color.textStyle}">(${param.value}%)</span>`
                        }
                    },
                    data: []
                }
            ]
        };
    }, [
        theme
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_7__.useEffect)(()=>{
        const seriesData = [];
        const legendData = {};
        _contents_statistic__WEBPACK_IMPORTED_MODULE_3__/* .fil_charts */ .qd.chart.forEach((item)=>{
            const value = item.value || "--";
            const name = `${tr(item.key)}`;
            legendData[item.key] = {
                name,
                value,
                color: item.color,
                key: item.key,
                isShow: true
            };
            seriesData.push({
                value,
                name,
                key: item.key,
                itemStyle: {
                    color: item.color
                }
            });
        });
        const newOpt = {
            ...defaultOtions
        };
        newOpt.series[0].data = seriesData;
        setData(newOpt);
        setLegendData(legendData);
    }, [
        lang,
        theme
    ]);
    const options = (0,react__WEBPACK_IMPORTED_MODULE_7__.useMemo)(()=>{
        const newData = {
            ...data
        };
        const series = [];
        if (newData.series && newData.series.length > 0) {
            data.series[0].data?.forEach((v)=>{
                if (legendData[v.key]?.isShow) {
                    series.push(v);
                }
            });
            newData.series[0].data = series;
            if (isMobile) {
                newData.series[0].radius = "80%";
                newData.series[0].label.show = false;
                newData.tooltip.position = [
                    "40%",
                    "50%"
                ];
                newData.tooltip.show = true;
                newData.tooltip.formatter = (v)=>{
                    const { name, value, data } = v;
                    return `${v.marker} ${data.value}% <div>${data.name}</div>`;
                };
                newData.series[0].center = [
                    "50%",
                    "45%"
                ];
            }
        }
        return newData;
    }, [
        data,
        legendData,
        isMobile
    ]);
    const handleLegend = (legendKey)=>{
        const newLegend = {
            ...legendData
        };
        newLegend[legendKey].isShow = !newLegend[legendKey].isShow;
        setLegendData(newLegend);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_6___default()("flex items-center h-9 w-fit font-PingFang font-semibold text-lg pl-2.5 mb-4", (_Charts_module_scss__WEBPACK_IMPORTED_MODULE_10___default().title)),
                children: tr("charts_title")
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_6___default()("card_shadow w-full border border_color rounded-[12px]", (_Charts_module_scss__WEBPACK_IMPORTED_MODULE_10___default().content)),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: classnames__WEBPACK_IMPORTED_MODULE_6___default()("flex flex-row border-b border_color", (_Charts_module_scss__WEBPACK_IMPORTED_MODULE_10___default()["chart-wrap"]), (_Charts_module_scss__WEBPACK_IMPORTED_MODULE_10___default()["chart-wrap-reset"])),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: classnames__WEBPACK_IMPORTED_MODULE_6___default()("w-2/3 h-[350px] py-5", (_Charts_module_scss__WEBPACK_IMPORTED_MODULE_10___default().chart)),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                    options: options
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                className: "1/3 flex gap-y-2.5  flex-col justify-center",
                                children: Object.keys(legendData).map((legendKey)=>{
                                    const legend = legendData[legendKey];
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: "flex gap-x-2 items-center text-xs text_des cursor-pointer",
                                        onClick: ()=>{
                                            handleLegend(legendKey);
                                        },
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: classnames__WEBPACK_IMPORTED_MODULE_6___default()("block w-2 h-2 rounded-full", (_Charts_module_scss__WEBPACK_IMPORTED_MODULE_10___default().dot)),
                                                style: {
                                                    background: legend.isShow ? legend?.color || "" : "#d1d5db"
                                                }
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: classnames__WEBPACK_IMPORTED_MODULE_6___default()("flex", (_Charts_module_scss__WEBPACK_IMPORTED_MODULE_10___default()["legend-label-wrap"])),
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "flex-shrink-0",
                                                        children: legend?.name || ""
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_9__/* .MobileView */ .$, {
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: (_Charts_module_scss__WEBPACK_IMPORTED_MODULE_10___default().value),
                                                            children: " " + `${legend?.value}%`
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    }, legendKey);
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_9__/* .BrowserView */ .I, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "p-10 text-xs font-DINPro-Medium text_des",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                className: "border border_color rounded-[5px]",
                                children: _contents_statistic__WEBPACK_IMPORTED_MODULE_3__/* .fil_charts */ .qd.content.map((v, index)=>{
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: "border-b border_color w-full break-words min-h-[36px] flex items-center last:border-none",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                style: {
                                                    width: "20%"
                                                },
                                                className: "flex items-center h-full min-h-[36px] px-2.5  border-r border_color",
                                                children: tr(v.label)
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                style: {
                                                    width: "25%"
                                                },
                                                className: "flex items-center h-full min-h-[36px]  px-2.5 border-r border_color",
                                                children: index === 0 ? tr(v.value) : v.value
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                style: {
                                                    width: "40%"
                                                },
                                                className: "px-2.5",
                                                children: tr(v.description)
                                            })
                                        ]
                                    }, index);
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_9__/* .MobileView */ .$, {
                        children: _contents_statistic__WEBPACK_IMPORTED_MODULE_3__/* .fil_charts */ .qd.content.filter((value)=>{
                            return value.label !== "Allocation";
                        }).map((v, index)=>{
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                className: classnames__WEBPACK_IMPORTED_MODULE_6___default()("flex flex-col text_des px-[12px] py-[14px] gap-y-[15px] border-b border_color last:border-none", (_Charts_module_scss__WEBPACK_IMPORTED_MODULE_10___default()["describe-item"])),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: classnames__WEBPACK_IMPORTED_MODULE_6___default()("min-w-[100px] pt-[2px]", (_Charts_module_scss__WEBPACK_IMPORTED_MODULE_10___default().label)),
                                                children: [
                                                    tr("Allocation"),
                                                    ":"
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "font-DINPro-Medium  text-black",
                                                children: tr(v.label)
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: classnames__WEBPACK_IMPORTED_MODULE_6___default()("min-w-[100px]", (_Charts_module_scss__WEBPACK_IMPORTED_MODULE_10___default().label)),
                                                children: [
                                                    tr("value"),
                                                    ":"
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "font-DINPro-Medium  text-black",
                                                children: index === 0 ? tr(v.value) : v.value
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: classnames__WEBPACK_IMPORTED_MODULE_6___default()("min-w-[100px]", (_Charts_module_scss__WEBPACK_IMPORTED_MODULE_10___default().label)),
                                                children: [
                                                    tr("description"),
                                                    ":"
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "font-DINPro-Medium  text-black",
                                                children: tr(v.description)
                                            })
                                        ]
                                    })
                                ]
                            }, index);
                        })
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Overview);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7927:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _components_echarts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3778);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2881);
/* harmony import */ var _contents_statistic__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4852);
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8804);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3495);
/* harmony import */ var _utils_echarts__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7355);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _DCCTrend_module_scss__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3565);
/* harmony import */ var _DCCTrend_module_scss__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_DCCTrend_module_scss__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8108);
/* harmony import */ var _packages_segmented__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5622);
/* harmony import */ var _components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1061);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_statistic__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_6__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__, _packages_segmented__WEBPACK_IMPORTED_MODULE_11__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__, _contents_statistic__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_6__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__, _packages_segmented__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 













/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { className } = props;
    const { theme, lang } = (0,_store_FilscanStore__WEBPACK_IMPORTED_MODULE_5__/* .useFilscanStore */ .J)();
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_3__/* .Translation */ .W)({
        ns: "static"
    });
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
    const [options, setOptions] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)({});
    const [interval, setInterval] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)("24h");
    const { isMobile } = (0,_components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)();
    const color = (0,react__WEBPACK_IMPORTED_MODULE_8__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_7__/* .getColor */ .Lq)(theme);
    }, [
        theme
    ]);
    const default_xAxis = (0,react__WEBPACK_IMPORTED_MODULE_8__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_7__/* .get_xAxis */ .Fs)(theme, isMobile);
    }, [
        theme,
        isMobile
    ]);
    const defaultOptions = (0,react__WEBPACK_IMPORTED_MODULE_8__.useMemo)(()=>{
        return {
            grid: {
                top: 30,
                left: 20,
                right: 20,
                bottom: 20,
                containLabel: true
            },
            yAxis: {
                type: "value",
                position: "left",
                scale: true,
                nameTextStyle: {
                    color: color.textStyle
                },
                axisLabel: {
                    formatter: "{value} PiB",
                    textStyle: {
                        //  fontSize: this.fontSize,
                        color: isMobile ? color.mobileLabelColor : color.labelColor
                    }
                },
                axisLine: {
                    show: false
                },
                axisTick: {
                    show: false
                },
                splitLine: {
                    show: true,
                    lineStyle: {
                        type: "dashed",
                        color: color.splitLine
                    }
                }
            },
            legend: {
                show: false
            },
            tooltip: {
                //@ts-ignore
                position: function(pos, params, dom, rect, size) {
                    // 鼠标在左侧时 tooltip 显示到右侧，鼠标在右侧时 tooltip 显示到左侧。
                    var obj = {
                        top: 80
                    };
                    //@ts-ignore
                    obj[[
                        "left",
                        "right"
                    ][+(pos[0] < size.viewSize[0] / 2)]] = 5;
                    return isMobile ? obj : undefined;
                },
                trigger: "axis",
                backgroundColor: color.toolbox,
                borderColor: "transparent",
                textStyle: {
                    color: "#ffffff"
                },
                formatter (v) {
                    var result = v[0]?.data?.showTime || "";
                    v.forEach((item)=>{
                        if (item.data) {
                            result += "<br/>" + item.marker + item.seriesName + ": " + item.data.amount + item.data.unit;
                        }
                    });
                    return result;
                }
            }
        };
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        theme,
        isMobile
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(()=>{
        load();
    }, []);
    const load = async (time)=>{
        const seriesObj = {};
        _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .cc_dc_trend */ .l2.list.forEach((v)=>{
            seriesObj[v.dataIndex] = [];
        });
        const dateList = [];
        const seriesData = [];
        const inter = time || interval;
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .DCTrend */ .b, {
            interval: inter
        });
        result?.items?.forEach((value)=>{
            const { block_time, cc, dc } = value;
            const showTime = inter === "24h" ? (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatDateTime */ .o0)(block_time, "HH:mm") : (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatDateTime */ .o0)(block_time, "MM-DD HH:mm");
            dateList.push(showTime);
            const [cc_amount, cc_unit] = cc && (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .unitConversion */ .dN)(cc, 2)?.split(" ");
            const [dc_amount, dc_unit] = dc && (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .unitConversion */ .dN)(dc, 2)?.split(" ");
            //amount
            seriesObj.cc.push({
                amount: cc_amount,
                value: (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .unitConversion */ .dN)(cc, 2, 5).split(" ")[0],
                showTime: (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatDateTime */ .o0)(block_time, "YYYY-MM-DD HH:mm"),
                unit: cc_unit
            });
            seriesObj.dc.push({
                amount: dc_amount,
                showTime: (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatDateTime */ .o0)(block_time, "YYYY-MM-DD HH:mm"),
                value: Number((0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .unitConversion */ .dN)(dc, 2, 5).split(" ")[0]),
                unit: dc_unit
            });
        });
        _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .cc_dc_trend */ .l2.list.forEach((item)=>{
            seriesData.push({
                type: item.type,
                // ...seriesChangeArea,
                data: seriesObj[item.dataIndex],
                name: tr(item.title),
                symbol: "circle",
                smooth: true,
                itemStyle: {
                    color: item.color
                },
                barMaxWidth: "30"
            });
        });
        setOptions({
            series: seriesData,
            xData: dateList
        });
    };
    const newOptions = (0,react__WEBPACK_IMPORTED_MODULE_8__.useMemo)(()=>{
        const newSeries = [];
        (options?.series || []).forEach((seriesItem)=>{
            newSeries.push(seriesItem);
        });
        return {
            ...defaultOptions,
            xAxis: {
                ...default_xAxis,
                data: options?.xData || []
            },
            series: newSeries
        };
    }, [
        options,
        defaultOptions
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        // id='block_reward_per'
        className: classnames__WEBPACK_IMPORTED_MODULE_9___default()((_DCCTrend_module_scss__WEBPACK_IMPORTED_MODULE_13___default().wrap), `w-full h-[full]  ${className}`),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_9___default()("flex-1 flex flex-row flex-wrap  justify-between items-center mb-4 mx-2.5", (_DCCTrend_module_scss__WEBPACK_IMPORTED_MODULE_13___default()["title-wrap"])),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: classnames__WEBPACK_IMPORTED_MODULE_9___default()("min-w-[120px] w-fit font-PingFang font-semibold text-lg ", (_DCCTrend_module_scss__WEBPACK_IMPORTED_MODULE_13___default().title)),
                        children: tr("cc_dc_power")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_segmented__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                        defaultValue: interval,
                        data: _contents_statistic__WEBPACK_IMPORTED_MODULE_4__/* .timeList */ .t9,
                        ns: "static",
                        isHash: false,
                        onChange: (value)=>{
                            setInterval(value);
                            load(value);
                        }
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_9___default()(`h-[350px] w-full card_shadow border border_color pb-2 rounded-xl`, (_DCCTrend_module_scss__WEBPACK_IMPORTED_MODULE_13___default().content)),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    options: newOptions
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1340:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_echarts__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3778);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8804);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2881);
/* harmony import */ var _utils_echarts__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7355);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8108);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8054);
/* harmony import */ var _contents_statistic__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4852);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3495);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6517);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9676);
/* harmony import */ var _FilChart_module_scss__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(8690);
/* harmony import */ var _FilChart_module_scss__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_FilChart_module_scss__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1061);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_4__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_6__, _contents_statistic__WEBPACK_IMPORTED_MODULE_8__, _utils__WEBPACK_IMPORTED_MODULE_9__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_4__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_6__, _contents_statistic__WEBPACK_IMPORTED_MODULE_8__, _utils__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 














function Overview({ className }) {
    const { theme, lang } = (0,_store_FilscanStore__WEBPACK_IMPORTED_MODULE_3__/* .useFilscanStore */ .J)();
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_4__/* .Translation */ .W)({
        ns: "static"
    });
    const { data: filData, loading } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_7__/* .apiUrl */ .JW.static_fil_chart, {});
    const [optionsA, setOptionA] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({});
    const [legendA, setLegendA] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({});
    const [optionsB, setOptionB] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({});
    const [legendB, setLegendB] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({});
    const { isMobile } = (0,_components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z)();
    const color = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        return (0,_utils_echarts__WEBPACK_IMPORTED_MODULE_5__/* .getColor */ .Lq)(theme);
    }, [
        theme
    ]);
    const defaultOtions = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        return {
            tooltip: {
                trigger: "item",
                backgroundColor: color.toolbox,
                borderColor: "transparent",
                textStyle: {
                    color: "#ffffff"
                },
                formatter (v) {
                    const { name, value, data } = v;
                    return `${v.marker} ${data.showName}`;
                },
                position: "right"
            },
            series: [
                {
                    type: "pie",
                    radius: "50%",
                    label: {
                        show: true,
                        color: color.labelColor
                    },
                    textStyle: {
                        //  fontSize: this.fontSize,
                        color: color.textStyle
                    }
                }
            ]
        };
    }, [
        theme
    ]);
    const newData = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        const newList = {};
        const data = filData?.fil_compose || {};
        _contents_statistic__WEBPACK_IMPORTED_MODULE_8__/* .fil_overviewList */ .a$.forEach((itemList)=>{
            newList[itemList.title] = itemList.list.map((itemValue)=>{
                const show_value = data && (0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .formatFil */ .Uk)(data[itemValue.key], "FIL");
                if (itemList.title === "pie_title_a") {
                    const percentage_a = Number(20 * Math.pow(10, 8));
                    return {
                        ...itemValue,
                        percentage: Number(Number(show_value) / percentage_a * 100).toFixed(2) + "%",
                        value: show_value,
                        unit: "FIL"
                    };
                } else {
                    const percentage_b = Number(Number(data[itemValue.key]) / data.total_released * 100).toFixed(2) + "%";
                    return {
                        ...itemValue,
                        percentage: percentage_b,
                        value: show_value,
                        unit: "FIL"
                    };
                }
            });
        });
        return newList;
    }, [
        filData
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        loadOptions();
    }, [
        newData,
        lang,
        theme
    ]);
    const loadOptions = ()=>{
        let options_a = lodash__WEBPACK_IMPORTED_MODULE_10___default().cloneDeep({
            ...defaultOtions
        });
        let options_b = lodash__WEBPACK_IMPORTED_MODULE_10___default().cloneDeep({
            ...defaultOtions
        });
        let legend_a = [];
        let legend_b = [];
        _contents_statistic__WEBPACK_IMPORTED_MODULE_8__/* .fil_overviewList */ .a$.forEach((item, index)=>{
            const showData = newData && newData[item.title] || {};
            const seriesData = [];
            const legend = {};
            item.list.forEach((seriesItem, index)=>{
                const baseData = showData[index];
                const showValue = (0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .formatNumberUnit */ .sQ)(baseData?.value);
                const name = `${tr(seriesItem.key)}`;
                const value = `${showValue} FIL`;
                legend[seriesItem.key] = {
                    name,
                    value,
                    color: seriesItem.color,
                    isShow: true,
                    key: seriesItem.key
                };
                seriesData.push({
                    ...baseData,
                    name,
                    showName: `${tr(seriesItem.key)}: ${baseData?.value} FIL`,
                    key: seriesItem.key,
                    itemStyle: {
                        color: seriesItem.color
                    }
                });
            });
            if (item.title === "pie_title_a") {
                options_a.series[0].data = seriesData;
                legend_a = {
                    ...legend
                };
            } else {
                options_b.series[0].data = seriesData;
                legend_b = {
                    ...legend
                };
            }
        });
        setOptionA(options_a);
        setLegendA(legend_a);
        setOptionB(options_b);
        setLegendB(legend_b);
    };
    const newOptionsA = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        const newData = [];
        const newOption = lodash__WEBPACK_IMPORTED_MODULE_10___default().cloneDeep(optionsA);
        if (newOption?.series && newOption.series.length > 0) {
            optionsA?.series && optionsA?.series[0]?.data.map((v)=>{
                if (legendA[v.key].isShow) {
                    newData.push(v);
                }
            });
            if (isMobile) {
                newOption.series[0].label.show = false;
                newOption.series[0].radius = "80%";
                newOption.tooltip.position = [
                    "15%",
                    "50%"
                ];
                newOption.tooltip.formatter = (v)=>{
                    const { name, value, data } = v;
                    return `${v.marker} ${data.value} <div>${data.name}</div>`;
                };
                newOption.series[0].center = [
                    "50%",
                    "50%"
                ];
            }
            newOption.series[0].data = newData;
        }
        return newOption;
    }, [
        legendA,
        optionsA,
        isMobile
    ]);
    const newOptionsB = (0,react__WEBPACK_IMPORTED_MODULE_2__.useMemo)(()=>{
        const newData = [];
        const newOption = lodash__WEBPACK_IMPORTED_MODULE_10___default().cloneDeep(optionsB);
        if (newOption?.series && newOption.series.length > 0) {
            optionsB?.series && optionsB?.series[0]?.data.map((v)=>{
                if (legendB[v.key].isShow) {
                    newData.push(v);
                }
            });
            if (isMobile) {
                newOption.series[0].label.show = false;
                newOption.series[0].radius = "80%";
                newOption.tooltip.position = [
                    "15%",
                    "50%"
                ];
                newOption.tooltip.formatter = (v)=>{
                    const { name, value, data } = v;
                    return `${v.marker} ${data.value} <div>${data.name}</div>`;
                };
                newOption.series[0].center = [
                    "50%",
                    "50%"
                ];
            }
            newOption.series[0].data = newData;
        }
        return newOption;
    }, [
        legendB,
        optionsB,
        isMobile
    ]);
    const handleLegend = (type, key)=>{
        if (type === "pie_title_a") {
            const newLegend = {
                ...legendA
            };
            newLegend[key].isShow = !newLegend[key].isShow;
            setLegendA(newLegend);
        } else {
            const newLegend = {
                ...legendB
            };
            newLegend[key].isShow = !newLegend[key].isShow;
            setLegendB(newLegend);
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_12___default()("flex  flex-col gap-y-5 h-fit", (_FilChart_module_scss__WEBPACK_IMPORTED_MODULE_14___default().wrap)),
        children: _contents_statistic__WEBPACK_IMPORTED_MODULE_8__/* .fil_overviewList */ .a$.map((dataItem, index)=>{
            const legendData = index === 1 ? legendB : legendA;
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: `w-full h-full ${className} `,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: classnames__WEBPACK_IMPORTED_MODULE_12___default()("flex items-center h-9 w-fit font-PingFang font-semibold text-lg pl-2.5 mb-4", (_FilChart_module_scss__WEBPACK_IMPORTED_MODULE_14___default().title)),
                        children: tr(dataItem.title)
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: classnames__WEBPACK_IMPORTED_MODULE_12___default()("card_shadow border border_color rounded-[12px]", (_FilChart_module_scss__WEBPACK_IMPORTED_MODULE_14___default().card), (_FilChart_module_scss__WEBPACK_IMPORTED_MODULE_14___default()["card-reset"])),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: classnames__WEBPACK_IMPORTED_MODULE_12___default()("w-full h-[400px]", (_FilChart_module_scss__WEBPACK_IMPORTED_MODULE_14___default().echart)),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_echarts__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                                    options: index === 1 ? {
                                        ...newOptionsB
                                    } : {
                                        ...newOptionsA
                                    }
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_11__/* .BrowserView */ .I, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                    className: "w-full flex flex-wrap gap-y-2.5 px-10 pb-10 ",
                                    children: Object.keys(legendData).map((legendKey)=>{
                                        const legend = legendData[legendKey];
                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                            className: "flex gap-x-2 items-center text-xs text_des w-1/3 cursor-pointer",
                                            onClick: ()=>{
                                                handleLegend(dataItem.title, legendKey);
                                            },
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "block w-2 h-2 rounded-full",
                                                    style: {
                                                        background: legend.isShow ? legend?.color || "" : "#d1d5db"
                                                    }
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    children: [
                                                        `${legend?.name || ""}`,
                                                        " "
                                                    ]
                                                })
                                            ]
                                        }, legendKey);
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_11__/* .MobileView */ .$, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                    className: classnames__WEBPACK_IMPORTED_MODULE_12___default()((_FilChart_module_scss__WEBPACK_IMPORTED_MODULE_14___default()["legend-wrap"])),
                                    children: Object.keys(legendData).map((legendKey)=>{
                                        const legend = legendData[legendKey];
                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                            className: classnames__WEBPACK_IMPORTED_MODULE_12___default()((_FilChart_module_scss__WEBPACK_IMPORTED_MODULE_14___default()["legend-item"])),
                                            onClick: ()=>{
                                                handleLegend(dataItem.title, legendKey);
                                            },
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: classnames__WEBPACK_IMPORTED_MODULE_12___default()((_FilChart_module_scss__WEBPACK_IMPORTED_MODULE_14___default()["legend-item-left"])),
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "block w-2 h-2 rounded-full",
                                                        style: {
                                                            background: legend.isShow ? legend?.color || "" : "#d1d5db"
                                                        }
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                        children: [
                                                            `${legend?.name || ""}:`,
                                                            " "
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: (_FilChart_module_scss__WEBPACK_IMPORTED_MODULE_14___default()["legend-value"]),
                                                        children: legend?.value || ""
                                                    })
                                                ]
                                            })
                                        }, legendKey);
                                    })
                                })
                            })
                        ]
                    })
                ]
            }, dataItem.title);
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Overview);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1004:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2881);
/* harmony import */ var _components_hooks_useInterval__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9447);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8054);
/* harmony import */ var _contents_home__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9729);
/* harmony import */ var _packages_tooltip__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2305);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8108);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7947);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _Meta_module_scss__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9986);
/* harmony import */ var _Meta_module_scss__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_Meta_module_scss__WEBPACK_IMPORTED_MODULE_10__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_home__WEBPACK_IMPORTED_MODULE_4__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_6__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_home__WEBPACK_IMPORTED_MODULE_4__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "home"
    });
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)();
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)({});
    const [contractData, setContractData] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)();
    (0,_components_hooks_useInterval__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(()=>{
        load();
    }, 5 * 60 * 1000);
    const load = async ()=>{
        const data = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__/* .apiUrl */ .JW.home_meta);
        setData(data?.total_indicators || {});
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__/* .EvmContractSummary */ .Uh);
        setContractData(result || {});
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()("flex flex-wrap gap-5 card_shadow py-5 px-6 border border_color rounded-[12px] mt-[46px]", (_Meta_module_scss__WEBPACK_IMPORTED_MODULE_10___default().wrap), (_Meta_module_scss__WEBPACK_IMPORTED_MODULE_10___default()["wrap-reset"])),
        children: _contents_home__WEBPACK_IMPORTED_MODULE_4__/* .meta_list */ .QU.map((item, index)=>{
            const { title, tip, render, dataIndex } = item;
            const newData = {
                ...contractData,
                ...data
            };
            const value = newData[dataIndex];
            let renderDom = render ? render(value, newData, tr) : value;
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                className: classnames__WEBPACK_IMPORTED_MODULE_8___default()("flex flex-col items-center w-[210px] py-4 gap-y-1 border border_color rounded-[5px]", (_Meta_module_scss__WEBPACK_IMPORTED_MODULE_10___default().item), (_Meta_module_scss__WEBPACK_IMPORTED_MODULE_10___default()["item-reset"])),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "font-medium font-DINPro-Bold text-base",
                        children: renderDom
                    }),
                    tip ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tooltip__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            context: tr(tip),
                            icon: false,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "text_des flex items-center gap-x-1",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: tr(item.title)
                                    }),
                                    (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_7__/* .getSvgIcon */ .a)("tip")
                                ]
                            })
                        })
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "text_des ",
                        children: tr(item.title)
                    })
                ]
            }, index);
        })
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2727:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/cssinjs");

/***/ }),

/***/ 7529:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons/lib/icons/LoadingOutlined");

/***/ }),

/***/ 6762:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons/lib/icons/LockOutlined");

/***/ }),

/***/ 2127:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons/lib/icons/UserOutlined");

/***/ }),

/***/ 2616:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/config-provider");

/***/ }),

/***/ 675:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/input");

/***/ }),

/***/ 4946:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/locale/en_US");

/***/ }),

/***/ 9353:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/locale/zh_CN");

/***/ }),

/***/ 274:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/menu");

/***/ }),

/***/ 7369:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/message");

/***/ }),

/***/ 9348:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/tooltip");

/***/ }),

/***/ 9003:
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ 8887:
/***/ ((module) => {

"use strict";
module.exports = require("copy-to-clipboard");

/***/ }),

/***/ 1635:
/***/ ((module) => {

"use strict";
module.exports = require("dayjs");

/***/ }),

/***/ 9201:
/***/ ((module) => {

"use strict";
module.exports = require("echarts");

/***/ }),

/***/ 6517:
/***/ ((module) => {

"use strict";
module.exports = require("lodash");

/***/ }),

/***/ 6641:
/***/ ((module) => {

"use strict";
module.exports = require("next-seo");

/***/ }),

/***/ 3076:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module.js");

/***/ }),

/***/ 4140:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 9716:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 3100:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 6368:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 6724:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 5132:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 8743:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/html-context.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 4612:
/***/ ((module) => {

"use strict";
module.exports = require("use-deep-compare-effect");

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 9766:
/***/ ((module) => {

"use strict";
module.exports = import("bignumber.js");;

/***/ }),

/***/ 2021:
/***/ ((module) => {

"use strict";
module.exports = import("i18next");;

/***/ }),

/***/ 7987:
/***/ ((module) => {

"use strict";
module.exports = import("react-i18next");;

/***/ }),

/***/ 4325:
/***/ ((module) => {

"use strict";
module.exports = import("web3");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8355,1163,8087,5622,3469,3309,4852,9729,1538], () => (__webpack_exec__(8221)));
module.exports = __webpack_exports__;

})();