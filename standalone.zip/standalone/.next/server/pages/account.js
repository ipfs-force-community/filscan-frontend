(() => {
var exports = {};
exports.id = 7966;
exports.ids = [7966];
exports.modules = {

/***/ 4945:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgDelLight = function SvgDelLight(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 12 12"
  }, props), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("circle", {
    cx: 6,
    cy: 6,
    r: 6,
    fill: "#000"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    stroke: "#fff",
    strokeLinecap: "square",
    strokeWidth: 1.2,
    d: "M8.4 3.6 3.6 8.4m0-4.8 4.8 4.8"
  }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgDelLight);

/***/ }),

/***/ 7872:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgError = function SvgError(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 18 18"
  }, props), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("circle", {
    cx: 9,
    cy: 9,
    r: 9,
    fill: "#e15252"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    stroke: "#fff",
    strokeLinecap: "square",
    strokeWidth: 1.2,
    d: "M4.5 9.5h9"
  }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgError);

/***/ }),

/***/ 8091:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _defs, _path;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgLogo = function SvgLogo(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 34 31"
  }, props), _defs || (_defs = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("defs", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("linearGradient", {
    id: "logo_svg__a",
    x1: "5.864%",
    x2: "75.628%",
    y1: "89.411%",
    y2: "-.081%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: "0%",
    stopColor: "#1764FF"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: "67.358%",
    stopColor: "#16CDE5"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: "99.92%",
    stopColor: "#A2E7A2"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: "100%",
    stopColor: "#ABE99E"
  })))), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "url(#logo_svg__a)",
    fillRule: "evenodd",
    d: "M9.526 17.82c.188-.07.428-.056.638-.033.14.016.32.07.536.162.502-.041.881-.017 1.14.073.386.134.563.305.66.553.064.165.065.35.004.554-.188-.145-.358-.226-.511-.245-.23-.029-.347.015-.7.148-.235.09-.424.2-.566.332l-3.743 3.182-.706 3.686c-.314 1.023-.73 1.843-1.246 2.458-.775.924-1.3 1.17-2.237 1.664-.625.328-1.341.544-2.15.646.396-.086.815-.414 1.257-.985.172-.223.599-.763.735-1.62.141-.89.22-2.992.234-6.308l-2.396-.835 9.051-3.432Zm18.92-7.049c.836 2.374.03 5.781-.914 7.978-2.204 5.129-7.267 8.214-12.582 8.214-1.776 0-3.578-.344-5.313-1.072-.604-.253-1.168-.6-1.622-.878l-.095-.057 2.539-4.045.098.06c.329.203.701.431.961.54 4.483 1.88 9.677-.194 11.58-4.621.778-1.811 1.046-3.855.799-4.557ZM2.407 8.214C5.346 1.37 13.375-1.833 20.302 1.072c3.205 1.344 5.703 3.77 7.112 6.881L34 6.711 0 20.058l1.339-7.154a13.33 13.33 0 0 1 1.067-4.69ZM18.42 5.452c-4.483-1.88-9.677.193-11.58 4.62a8.76 8.76 0 0 0-.565 1.868l16.2-3.055a8.715 8.715 0 0 0-4.055-3.433Z"
  })));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgLogo);

/***/ }),

/***/ 8134:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgUser = function SvgUser(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 20 20"
  }, props), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("circle", {
    cx: 10,
    cy: 10,
    r: 10,
    fill: "#000",
    opacity: 0.301
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#fff",
    fillRule: "nonzero",
    d: "M10 3.636c.214 0 .415.109.532.288l2.388 3.652 2.51-1.32a.636.636 0 0 1 .928.64l-.822 6.85a1.89 1.89 0 0 1-1.874 1.662H6.335c-.953 0-1.759-.715-1.873-1.663l-.821-6.852a.637.637 0 0 1 .928-.639l2.51 1.32 2.388-3.65a.637.637 0 0 1 .532-.288zm0 1.8L7.826 8.758A.636.636 0 0 1 7 8.973l-1.95-1.028.677 5.65c.037.308.3.54.61.54h7.327c.31 0 .572-.232.61-.54l.678-5.65-1.95 1.026a.636.636 0 0 1-.828-.215zm2.317 4.937a.636.636 0 0 1-.023.9l-1.408 1.336a1.29 1.29 0 0 1-1.773 0l-1.408-1.336a.636.636 0 0 1 .877-.923l1.407 1.337 1.428-1.337a.636.636 0 0 1 .9.023z"
  }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgUser);

/***/ }),

/***/ 4806:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap": "loading_wrap__xYdnG"
};


/***/ }),

/***/ 3292:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   config: () => (/* binding */ config),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   getServerSideProps: () => (/* binding */ getServerSideProps),
/* harmony export */   getStaticPaths: () => (/* binding */ getStaticPaths),
/* harmony export */   getStaticProps: () => (/* binding */ getStaticProps),
/* harmony export */   reportWebVitals: () => (/* binding */ reportWebVitals),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   unstable_getServerProps: () => (/* binding */ unstable_getServerProps),
/* harmony export */   unstable_getServerSideProps: () => (/* binding */ unstable_getServerSideProps),
/* harmony export */   unstable_getStaticParams: () => (/* binding */ unstable_getStaticParams),
/* harmony export */   unstable_getStaticPaths: () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   unstable_getStaticProps: () => (/* binding */ unstable_getStaticProps)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3185);
/* harmony import */ var next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5244);
/* harmony import */ var next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7182);
/* harmony import */ var private_next_pages_document_tsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3162);
/* harmony import */ var private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4178);
/* harmony import */ var private_next_pages_account_index_tsx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2806);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__, private_next_pages_account_index_tsx__WEBPACK_IMPORTED_MODULE_5__]);
([private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__, private_next_pages_account_index_tsx__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// @ts-ignore this need to be imported from next/dist to be external



// Import the app and document modules.
// @ts-expect-error - replaced by webpack/turbopack loader

// @ts-expect-error - replaced by webpack/turbopack loader

// Import the userland code.
// @ts-expect-error - replaced by webpack/turbopack loader

const PagesRouteModule = next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__.PagesRouteModule;
// Re-export the component (should be the default export).
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_account_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "default"));
// Re-export methods.
const getStaticProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_account_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "getStaticProps");
const getStaticPaths = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_account_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "getStaticPaths");
const getServerSideProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_account_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "getServerSideProps");
const config = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_account_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "config");
const reportWebVitals = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_account_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "reportWebVitals");
// Re-export legacy methods.
const unstable_getStaticProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_account_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticProps");
const unstable_getStaticPaths = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_account_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticPaths");
const unstable_getStaticParams = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_account_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticParams");
const unstable_getServerProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_account_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getServerProps");
const unstable_getServerSideProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_account_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getServerSideProps");
// Create and export the route module that will be consumed.
const routeModule = new PagesRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__/* .RouteKind */ .x.PAGES,
        page: "/account",
        pathname: "/account",
        // The following aren't used in production.
        bundlePath: "",
        filename: ""
    },
    components: {
        App: private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__["default"],
        Document: private_next_pages_document_tsx__WEBPACK_IMPORTED_MODULE_3__["default"]
    },
    userland: private_next_pages_account_index_tsx__WEBPACK_IMPORTED_MODULE_5__
});

//# sourceMappingURL=pages.js.map
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1493:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _assets_images_loading_png__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8443);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4806);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_4__);





/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ width, height })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_3___default()("main_contain flex justify-center !mt-12 ", (_index_module_scss__WEBPACK_IMPORTED_MODULE_4___default().wrap)),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
            src: _assets_images_loading_png__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
            width: width || 260,
            height: height || 260,
            alt: ""
        })
    });
});


/***/ }),

/***/ 8656:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7947);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/** @format */ 


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ items })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "flex gap-x-2 items-center",
        children: items.map((item, index)=>{
            const show = index !== items.length - 1;
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                        href: item.path,
                        className: "text_des_hover",
                        children: item.title
                    }),
                    show && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "-rotate-90",
                        children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)("downIcon")
                    })
                ]
            });
        })
    });
});


/***/ }),

/***/ 6459:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var file_saver__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8109);
/* harmony import */ var file_saver__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(file_saver__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6302);
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(xlsx__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3800);
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(antd_lib_button__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7947);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2881);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3495);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_6__, _utils__WEBPACK_IMPORTED_MODULE_7__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_6__, _utils__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 







function getUnitValue(value, amountUnit) {
    if (amountUnit?.unit?.includes("fil")) {
        const otherUnit = amountUnit?.unit?.split("/")[1];
        const filValue = (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatFil */ .Uk)(value, "FIL", 4);
        return filValue; //otherUnit ? filValue + `/${otherUnit}` : filValue+' FIL';
    } else if (amountUnit?.unit === "power") {
        const otherUnit = amountUnit?.unit?.split("/")[1];
        const powerValue = (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .unitConversion */ .dN)(value, amountUnit.number || 2);
        return otherUnit ? powerValue + `/${otherUnit}` : powerValue;
    } else if (amountUnit?.unit === "%") {
        const powerValue = (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatNumberPercentage */ .Fy)(value, amountUnit.number);
        return powerValue + "%";
    }
    return value;
}
const ExportExcel = ({ columns, ns, data, fileName })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_6__/* .Translation */ .W)({
        ns: ns || "common"
    });
    const fileType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8";
    const fileExtension = ".xlsx";
    const exportToCSV = (columns, data, fileName)=>{
        const headers = [];
        columns.forEach((col)=>{
            const { dataIndex, amountUnit } = col;
            let title = col.titleTip ? col.excelTitle : col.title;
            if (title.includes("/") && col.exports && (col?.exports || []).length > 0) {
                let newTitle = title;
                let [title0, title1] = newTitle.split("/");
                if (amountUnit && amountUnit[dataIndex] && amountUnit[dataIndex]?.unit.includes("fil") && title0) {
                    title0 = title0 + `(${amountUnit[dataIndex]?.unit?.toUpperCase()})`;
                    title1 = title1 + `(${amountUnit[dataIndex]?.unit?.toUpperCase()})`;
                }
                headers.push(title0);
                headers.push(title1);
            } else {
                if (amountUnit && amountUnit[dataIndex] && amountUnit[dataIndex]?.unit.includes("fil")) {
                    title = title + `(${amountUnit[dataIndex]?.unit?.toUpperCase()})`;
                }
                headers.push(title);
            }
        // if (col.exports && Array.isArray(col.exports)) {
        //   col.exports.forEach((v: string) => {
        //     if (v === col.dataIndex) {
        //       title = title + col.amountUnit[v]
        //     }
        //     headers.push(tr(v));
        //   });
        // }
        });
        const accessors = [];
        columns.forEach((col)=>{
            accessors.push(col.dataIndex);
        });
        const dataRows = [];
        data.forEach((dataItem)=>{
            const row = [];
            columns.forEach((col)=>{
                const dataIndex = col.dataIndex;
                let value = dataItem[dataIndex];
                let otherValue = "";
                const showUnit = col?.amountUnit && col.amountUnit[dataIndex] && col?.amountUnit[dataIndex]?.unit;
                if (showUnit) {
                    value = getUnitValue(value, col.amountUnit[dataIndex]);
                }
                // if (col.exports) {
                //   if (col.exports && Array.isArray(col.exports)) {
                //     col.exports.forEach((v: string) => {
                //       otherValue = otherValue + '/' + String(getUnitValue(dataItem[v], col.amountUnit[v]));
                //     });
                //   }
                // }
                //   row.push(String(value)+otherValue);
                if (col.exports && Array.isArray(col.exports)) {
                    col.exports.forEach((v)=>{
                        const otherKey = v;
                        let otherValue = dataItem[otherKey];
                        const otherShow = col?.amountUnit && col.amountUnit[v] && col?.amountUnit[v]?.unit;
                        if (otherShow) {
                            otherValue = getUnitValue(otherValue, col?.amountUnit[v]);
                        }
                        row.push(otherValue);
                    });
                }
                row.push(value);
            });
            dataRows.push(row);
        });
        const dataArray = [
            headers,
            ...dataRows
        ];
        //const dataArray = data.map((row) => accessors.map((field) => row[field]));
        //dataArray.unshift(headers);
        const showFileName = fileName ? fileName + (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatDateTime */ .o0)(Number(new Date().getTime() / 1000), "MM_DD hh:mm:ss") : (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatDateTime */ .o0)(Number(new Date().getTime() / 1000), "MM_DD hh:mm:ss");
        const ws = xlsx__WEBPACK_IMPORTED_MODULE_3__.utils.aoa_to_sheet(dataArray);
        const wb = {
            Sheets: {
                data: ws
            },
            SheetNames: [
                "data"
            ]
        };
        const excelBuffer = xlsx__WEBPACK_IMPORTED_MODULE_3__.write(wb, {
            bookType: "xlsx",
            type: "array"
        });
        const blobData = new Blob([
            excelBuffer
        ], {
            type: fileType
        });
        file_saver__WEBPACK_IMPORTED_MODULE_2__.saveAs(blobData, showFileName + fileExtension);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((antd_lib_button__WEBPACK_IMPORTED_MODULE_4___default()), {
        className: "confirm_btn flex items-center gap-x-1",
        onClick: (e)=>exportToCSV(columns, data, fileName),
        children: [
            (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_5__/* .getSvgIcon */ .a)("downloadIcon"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                children: tr("Export")
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ExportExcel);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4627:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2881);
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3800);
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd_lib_button__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var antd_lib_modal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6418);
/* harmony import */ var antd_lib_modal__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(antd_lib_modal__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__]);
_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/** @format */ 



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { title, children, show, onCancel, loading, onOk } = props;
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "common"
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_modal__WEBPACK_IMPORTED_MODULE_3___default()), {
        ...props,
        title: title,
        open: show,
        onCancel: onCancel,
        onOk: onOk,
        destroyOnClose: true,
        className: "custom_modal",
        wrapClassName: "custom_modal_wrapper",
        footer: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_button__WEBPACK_IMPORTED_MODULE_2___default()), {
                className: "cancel_btn",
                onClick: onCancel,
                children: tr("cancel")
            }, "cancel"),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_button__WEBPACK_IMPORTED_MODULE_2___default()), {
                className: "confirm_btn",
                loading: loading,
                onClick: onOk,
                children: tr("confirm")
            }, "confirm")
        ],
        children: children
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9876:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2881);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7947);
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(675);
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(antd_lib_input__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__]);
_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/** @format */ 




/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ ns, options, suffix, onChange, isShow, className })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns
    });
    const [inputValue, setInputValue] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)();
    const [showGroup, setShowGroup] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const handleInput = (e)=>{
        if (isShow) {
            setInputValue({
                label: "",
                value: ""
            });
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "mt-5 group relative",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_input__WEBPACK_IMPORTED_MODULE_3___default()), {
                className: `w-full mt-4 h-12 custom_input focus:outline-none ${className}`,
                placeholder: tr("miner_select_group_placeholder"),
                value: inputValue?.label,
                onChange: (e)=>handleInput(e),
                onFocus: ()=>{
                    setShowGroup(true);
                },
                suffix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "text-xl",
                    children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_2__/* .getSvgIcon */ .a)("downIcon")
                })
            }),
            isShow ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                className: `mt-1 card_shadow p-4  ${showGroup ? "block" : "hidden"} w-full z-10`,
                children: [
                    options.map((item)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            onClick: ()=>{
                                setShowGroup(false);
                                setInputValue({
                                    label: item.label,
                                    value: item.value
                                });
                                onChange(item.value);
                            },
                            className: "py-4 px-5 hover:text-primary hover:bg-bg_hover rounded-[5px] cursor-pointer",
                            children: item.label
                        }, item.value);
                    }),
                    suffix && suffix
                ]
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                className: `mt-1 card_shadow p-4  ${showGroup ? "block" : "hidden"} absolute w-full z-10`,
                children: [
                    options.map((item)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            onClick: ()=>{
                                setShowGroup(false);
                                setInputValue({
                                    label: item.label,
                                    value: item.value
                                });
                                onChange(item.value);
                            },
                            className: "py-4 px-5 hover:text-primary hover:bg-bg_hover rounded-[5px] cursor-pointer",
                            children: item.label
                        }, item.value);
                    }),
                    suffix && suffix
                ]
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2305:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7947);
/* harmony import */ var antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9348);
/* harmony import */ var antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_2__);
/** @format */ 


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { context, icon = true } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((antd_lib_tooltip__WEBPACK_IMPORTED_MODULE_2___default()), {
        overlayClassName: "custom-tooltip-wrap",
        title: context,
        children: [
            icon ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: "cursor-pointer",
                children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_1__/* .getSvgIcon */ .a)("tip")
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: props.children
            })
        ]
    });
});


/***/ }),

/***/ 2806:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2881);
/* harmony import */ var _contents_account__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7701);
/* harmony import */ var _components_hooks_useHash__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8087);
/* harmony import */ var _src_account_overview__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8847);
/* harmony import */ var _src_account_miners__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3398);
/* harmony import */ var _src_account_personal__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(510);
/* harmony import */ var _src_account_lucky__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6136);
/* harmony import */ var _src_account_balance__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7736);
/* harmony import */ var _src_account_reward__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5208);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8054);
/* harmony import */ var _src_account_NoMiner__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2518);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8108);
/* harmony import */ var _src_account_power__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(3743);
/* harmony import */ var _src_account_gas__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(7307);
/* harmony import */ var _src_account_expired__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(8702);
/* harmony import */ var _store_UserStore__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(9821);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _src_account_content__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(9794);
/* harmony import */ var _components_loading__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(1493);
/* harmony import */ var _src_account_monitor_balance__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(2085);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_account__WEBPACK_IMPORTED_MODULE_3__, _src_account_overview__WEBPACK_IMPORTED_MODULE_5__, _src_account_miners__WEBPACK_IMPORTED_MODULE_6__, _src_account_personal__WEBPACK_IMPORTED_MODULE_7__, _src_account_lucky__WEBPACK_IMPORTED_MODULE_8__, _src_account_balance__WEBPACK_IMPORTED_MODULE_9__, _src_account_reward__WEBPACK_IMPORTED_MODULE_10__, _src_account_NoMiner__WEBPACK_IMPORTED_MODULE_12__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_13__, _src_account_power__WEBPACK_IMPORTED_MODULE_14__, _src_account_gas__WEBPACK_IMPORTED_MODULE_15__, _src_account_expired__WEBPACK_IMPORTED_MODULE_16__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_account__WEBPACK_IMPORTED_MODULE_3__, _src_account_overview__WEBPACK_IMPORTED_MODULE_5__, _src_account_miners__WEBPACK_IMPORTED_MODULE_6__, _src_account_personal__WEBPACK_IMPORTED_MODULE_7__, _src_account_lucky__WEBPACK_IMPORTED_MODULE_8__, _src_account_balance__WEBPACK_IMPORTED_MODULE_9__, _src_account_reward__WEBPACK_IMPORTED_MODULE_10__, _src_account_NoMiner__WEBPACK_IMPORTED_MODULE_12__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_13__, _src_account_power__WEBPACK_IMPORTED_MODULE_14__, _src_account_gas__WEBPACK_IMPORTED_MODULE_15__, _src_account_expired__WEBPACK_IMPORTED_MODULE_16__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 






















const Account = ()=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__/* .Translation */ .W)({
        ns: "account"
    });
    const { hash, hashParams } = (0,_components_hooks_useHash__WEBPACK_IMPORTED_MODULE_4__/* .useHash */ .H)();
    const rootSubmenuKeys = [];
    const userInfo = (0,_store_UserStore__WEBPACK_IMPORTED_MODULE_17__/* .UserInfo */ .a)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_18__.useRouter)();
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z)();
    const [minersNum, setMinersNum] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const [minerLoading, setMinerLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const selectedKey = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if (hash) {
            return hash;
        }
        return "overview";
    }, [
        hash
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        loadMinersNum();
    }, []);
    const loadMinersNum = async ()=>{
        setMinerLoading(true);
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_11__/* .proApi */ .g2.account_miners, {}, {
            isCancel: false
        });
        setMinerLoading(false);
        setMinersNum(result);
    };
    // const { data: minersNum, loading: minerLoading } =
    //   useAxiosData(proApi.account_miners) || {};
    function getChildren(arr) {
        return arr.map((v)=>{
            return {
                ...v,
                label: tr(v.label)
            };
        });
    }
    const menuData = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        let itemsArr = [];
        _contents_account__WEBPACK_IMPORTED_MODULE_3__/* .account_manager */ .Hp.forEach((item)=>{
            if (item.key !== "logout") {
                rootSubmenuKeys.push(item.key);
                let others = [];
                const obj = {
                    ...item,
                    label: item.label
                };
                delete obj.children;
                if (item?.children) {
                    others = getChildren(item?.children || []);
                    itemsArr.push({
                        ...obj
                    });
                    itemsArr.push(...others);
                } else {
                    itemsArr.push({
                        ...obj
                    });
                }
            }
        });
        return itemsArr;
    }, [
        tr
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (!userInfo.mail || !localStorage.getItem("token")) {
            router.push("/account/login");
        }
    }, [
        userInfo.mail
    ]);
    if (minerLoading) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_loading__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z, {});
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "main_contain !py-6 ",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "w-full h-full flex rounded-xl border card_shadow border_color ",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "w-[210px] border-r border_color  py-10",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-full px-5 mb-10 text-lg font-semibold font-PingFang ",
                            children: tr("account_title")
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                            className: "list-none px-4",
                            children: menuData.map((parent)=>{
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_19___default()), {
                                    href: `/account#${parent.key}`,
                                    scroll: false,
                                    className: `cursor-pointer  flex gap-x-2 items-center p-2.5 text_color rounded-[5px] hover:text-primary ${parent?.icon ? "font-medium" : "ml-5 font-normal"} ${selectedKey === parent.key ? "!text-primary bg-bg_hover" : ""}`,
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "flex items-center gap-x-2 px-4",
                                        children: [
                                            parent.icon,
                                            tr(parent.label)
                                        ]
                                    })
                                }, parent.label);
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex-grow flex flex-col px-5 py-10 w_account min-h-full",
                    style: {
                        height: "inherit"
                    },
                    children: !minersNum?.miners_count && hashParams.type !== "miner_add" && selectedKey !== "personal" && selectedKey !== "miners" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_account_NoMiner__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                        selectedKey: selectedKey === "overview" ? "overview" : "overview_" + selectedKey
                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_src_account_content__WEBPACK_IMPORTED_MODULE_20__/* .MinerStoreContext */ .bw.Provider, {
                        value: {
                            setAllNum: (value)=>{
                                setMinersNum(value);
                            }
                        },
                        children: [
                            selectedKey === "overview" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_account_overview__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                selectedKey: "overview"
                            }),
                            selectedKey === "miners" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_account_miners__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                minersNum: minersNum
                            }),
                            selectedKey === "lucky" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_account_lucky__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                selectedKey: "overview_" + selectedKey
                            }),
                            selectedKey === "power" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_account_power__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                                selectedKey: "overview_" + selectedKey
                            }),
                            selectedKey === "gas" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_account_gas__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                selectedKey: "overview_" + selectedKey
                            }),
                            selectedKey === "balance" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_account_balance__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                selectedKey: "overview_" + selectedKey
                            }),
                            selectedKey === "expired" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_account_expired__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                                selectedKey: "overview_" + selectedKey
                            }),
                            selectedKey === "reward" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_account_reward__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                selectedKey: "overview_" + selectedKey
                            }),
                            selectedKey === "monitorBalance" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_account_monitor_balance__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z, {}),
                            selectedKey === "personal" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_account_personal__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {})
                        ]
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Account); //已登录/注册

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7998:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ DateTIme)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: ./svgsIcon.tsx
var svgsIcon = __webpack_require__(7947);
;// CONCATENATED MODULE: external "antd/lib/date-picker"
const date_picker_namespaceObject = require("antd/lib/date-picker");
var date_picker_default = /*#__PURE__*/__webpack_require__.n(date_picker_namespaceObject);
// EXTERNAL MODULE: external "dayjs"
var external_dayjs_ = __webpack_require__(1635);
var external_dayjs_default = /*#__PURE__*/__webpack_require__.n(external_dayjs_);
;// CONCATENATED MODULE: ./packages/pickDate/index.tsx
/** @format */ 



/* harmony default export */ const pickDate = ((props)=>{
    const { onChange, timeType, defaultValue } = props;
    function handleDateChange(date, dateString) {
        let showDate = date.format("YYYY-MM-DDTHH:mm:ssZ") || dateString;
        onChange(showDate);
    }
    const disabledDate = (current)=>{
        return current && (current < external_dayjs_default()().subtract(30, "day") || current > external_dayjs_default()().endOf("day"));
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("span", {
        className: "custom_picker",
        children: [
            /*#__PURE__*/ jsx_runtime.jsx("span", {
                className: "custom_picker_pre",
                children: (0,svgsIcon/* getSvgIcon */.a)("dateIcon")
            }),
            /*#__PURE__*/ jsx_runtime.jsx((date_picker_default()), {
                bordered: false,
                showToday: false,
                allowClear: false,
                disabledDate: disabledDate,
                defaultValue: external_dayjs_default()(defaultValue, "YYYY-MM-DD"),
                className: "custom_date_picker",
                popupClassName: "custom_date_picker_wrap",
                suffixIcon: /*#__PURE__*/ jsx_runtime.jsx("span", {
                    children: (0,svgsIcon/* getSvgIcon */.a)("downIcon")
                }),
                onChange: handleDateChange
            })
        ]
    });
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "antd/lib/message"
var message_ = __webpack_require__(7369);
var message_default = /*#__PURE__*/__webpack_require__.n(message_);
;// CONCATENATED MODULE: ./src/account/DateTIme.tsx
/** @format */ 




/* harmony default export */ const DateTIme = (({ defaultValue, onChange, showEnd })=>{
    const [startTime, setStartTime] = (0,external_react_.useState)(defaultValue[0]);
    const [endTime, setEndTime] = (0,external_react_.useState)(defaultValue[1]);
    (0,external_react_.useEffect)(()=>{
        setStartTime(defaultValue[0] || "");
        setEndTime(defaultValue[1] || "");
    }, [
        defaultValue
    ]);
    const handleDateChange = (type, value)=>{
        if (type === "start") {
            setStartTime(value);
        } else if (type === "end") {
            if (startTime && value > startTime) {
                setEndTime(value);
            } else {
                return message_default().warning("endTime must be greater than startTime");
            }
        }
        if (showEnd) {
            if (type === "start") {
                onChange(value, endTime);
            } else if (type === "end") {
                onChange(startTime, value);
            }
        } else {
            // 只有一个date card
            onChange(type === "start" ? value : value, type === "end" ? value : value);
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "flex items-center gap-x-2",
        children: [
            /*#__PURE__*/ jsx_runtime.jsx(pickDate, {
                defaultValue: defaultValue[0],
                timeType: "utc",
                onChange: (value)=>handleDateChange("start", value)
            }),
            showEnd && /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx("span", {
                        children: (0,svgsIcon/* getSvgIcon */.a)("dateArrowIcon")
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx(pickDate, {
                        defaultValue: defaultValue[1],
                        timeType: "utc",
                        onChange: (value)=>handleDateChange("end", value)
                    })
                ]
            })
        ]
    });
});


/***/ }),

/***/ 2518:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2881);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7947);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__]);
_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/** @format */ 



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ selectedKey })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "account"
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "w-full mb-5 text-lg font-semibold font-PingFang ",
                children: tr(selectedKey)
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex-1 w-full flex flex-col gap-y-5 mt-20 items-center justify-center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_2__/* .getSvgIcon */ .a)("no_nodes")
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: "flex gap-x-2",
                        children: [
                            tr("no_node_data"),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                rel: "",
                                href: `/account#miners?type=miner_add`,
                                children: tr("miners_add")
                            })
                        ]
                    })
                ]
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7736:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2881);
/* harmony import */ var _packages_Table__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(430);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _contents_account__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7701);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8054);
/* harmony import */ var _packages_selects__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(869);
/* harmony import */ var _packages_exportExcel__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6459);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3495);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8108);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _packages_Table__WEBPACK_IMPORTED_MODULE_2__, _contents_account__WEBPACK_IMPORTED_MODULE_4__, _packages_exportExcel__WEBPACK_IMPORTED_MODULE_7__, _utils__WEBPACK_IMPORTED_MODULE_8__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _packages_Table__WEBPACK_IMPORTED_MODULE_2__, _contents_account__WEBPACK_IMPORTED_MODULE_4__, _packages_exportExcel__WEBPACK_IMPORTED_MODULE_7__, _utils__WEBPACK_IMPORTED_MODULE_8__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 









/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ selectedKey })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "account"
    });
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("-1");
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        return _contents_account__WEBPACK_IMPORTED_MODULE_4__/* .account_balance */ .j_.columns(tr).map((item)=>{
            return {
                ...item,
                title: tr(item.title)
            };
        });
    }, [
        tr
    ]);
    //proApi
    const { data: balanceData, loading } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_5__/* .proApi */ .g2.getBalance, {
        group_id: active ? Number(active) : null
    });
    const { data: groupsData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_5__/* .proApi */ .g2.getGroupsId, {
        group_id: active ? Number(active) : null
    });
    const groups = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        let newGroups = [
            {
                value: "-1",
                label: tr("all")
            }
        ];
        (groupsData?.group_list || []).forEach((group)=>{
            newGroups.push({
                ...group,
                value: String(group.group_id),
                label: tr(group?.group_name)
            });
        });
        return newGroups;
    }, [
        groupsData?.group_list,
        tr
    ]);
    const data = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        return {
            result: balanceData?.address_balance_list || [],
            epoch_time: balanceData?.epoch_time
        };
    }, [
        balanceData
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "overflow-auto",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex justify-between items-center",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex  flex-col",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "w-full text-lg font-semibold font-PingFang ",
                                children: tr(selectedKey)
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "text-xs text_des",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: tr("last_time")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "ml-2",
                                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_8__/* .formatDateTime */ .o0)(data?.epoch_time, "YYYY/MM/DD HH:mm")
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex gap-x-2.5",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_selects__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                value: active,
                                options: groups,
                                onChange: (value)=>{
                                    setActive(value);
                                }
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_exportExcel__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                columns: columns,
                                data: data.result,
                                fileName: tr(selectedKey)
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "card_shadow border border_color rounded-xl p-4 mt-5 overflow-auto",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_Table__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    data: data?.result || [],
                    columns: columns,
                    loading: loading
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9794:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Bj: () => (/* binding */ useGroupsStore),
/* harmony export */   Rp: () => (/* binding */ GroupsStoreContext),
/* harmony export */   bw: () => (/* binding */ MinerStoreContext),
/* harmony export */   mO: () => (/* binding */ useMinerStore)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const GroupsStoreContext = (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)(null);
const useGroupsStore = ()=>{
    const context = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(GroupsStoreContext);
    if (!context) {
        throw new Error("useFilscanStore must be used within a FilscanStoreProvider");
    }
    return context;
};
const MinerStoreContext = (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)(null);
const useMinerStore = ()=>{
    const minerContext = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(MinerStoreContext);
    if (!minerContext) {
        throw new Error("useFilscanStore must be used within a FilscanStoreProvider");
    }
    return minerContext;
};


/***/ }),

/***/ 574:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2881);
/* harmony import */ var _packages_breadcrumb__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8656);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3495);
/* harmony import */ var _packages_exportExcel__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6459);
/* harmony import */ var _packages_Table__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(430);
/* harmony import */ var _contents_account__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7701);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8108);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8054);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _utils__WEBPACK_IMPORTED_MODULE_4__, _packages_exportExcel__WEBPACK_IMPORTED_MODULE_5__, _packages_Table__WEBPACK_IMPORTED_MODULE_6__, _contents_account__WEBPACK_IMPORTED_MODULE_7__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _utils__WEBPACK_IMPORTED_MODULE_4__, _packages_exportExcel__WEBPACK_IMPORTED_MODULE_5__, _packages_Table__WEBPACK_IMPORTED_MODULE_6__, _contents_account__WEBPACK_IMPORTED_MODULE_7__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 









/** @format */ /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ miner, selectedKey })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "account"
    });
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    const routerItems = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        if (miner && typeof miner === "string") {
            return [
                {
                    title: tr("overview_expired"),
                    path: "/account#expired"
                },
                {
                    title: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: miner
                    }),
                    path: `/account#expired?miner=${miner}`
                }
            ];
        }
        return [];
    }, [
        miner
    ]);
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({
        epoch_time: "",
        dataSource: []
    });
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        return _contents_account__WEBPACK_IMPORTED_MODULE_7__/* .account_expired */ .nS.columns(tr, "detail").map((item)=>{
            return {
                ...item,
                title: tr(item.title)
            };
        });
    }, [
        tr
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        if (miner) {
            load();
        }
    }, [
        miner
    ]);
    const load = async ()=>{
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_9__/* .proApi */ .g2.getSector, {
            miner_id: miner
        });
        setData({
            dataSource: result?.sector_detail_day || [],
            epoch_time: result?.epoch_time || ""
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            routerItems && routerItems.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_breadcrumb__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                items: routerItems
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex justify-between items-center mt-10",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex  flex-col",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "w-full text-lg font-semibold font-PingFang ",
                                children: miner
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "text-xs text_des",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: tr("last_time")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "ml-2",
                                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_4__/* .formatDateTime */ .o0)(data?.epoch_time, "YYYY/MM/DD HH:mm")
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex gap-x-2.5",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_exportExcel__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            columns: columns,
                            data: data?.dataSource,
                            fileName: tr(selectedKey) + miner ? String(miner) : ""
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "card_shadow border border_color rounded-xl p-4 mt-5 overflow-auto",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_Table__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    data: data?.dataSource,
                    columns: columns,
                    loading: false
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8702:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2881);
/* harmony import */ var _packages_Table__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(430);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _contents_account__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7701);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8054);
/* harmony import */ var _packages_selects__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(869);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3495);
/* harmony import */ var antd_lib_collapse__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8633);
/* harmony import */ var antd_lib_collapse__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(antd_lib_collapse__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _components_hooks_useHash__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8087);
/* harmony import */ var _Detail__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(574);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8108);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _packages_Table__WEBPACK_IMPORTED_MODULE_2__, _contents_account__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_7__, _Detail__WEBPACK_IMPORTED_MODULE_10__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_11__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _packages_Table__WEBPACK_IMPORTED_MODULE_2__, _contents_account__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_7__, _Detail__WEBPACK_IMPORTED_MODULE_10__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 











/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ selectedKey })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "account"
    });
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("-1");
    const { hashParams } = (0,_components_hooks_useHash__WEBPACK_IMPORTED_MODULE_9__/* .useHash */ .H)();
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        return _contents_account__WEBPACK_IMPORTED_MODULE_4__/* .account_expired */ .nS.columns(tr).map((item)=>{
            return {
                ...item,
                title: tr(item.title)
            };
        });
    }, [
        tr
    ]);
    //proApi
    const { data: expiredData, loading } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_5__/* .proApi */ .g2.getSector, {
        group_id: active ? Number(active) : ""
    });
    const { data: groupsData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_5__/* .proApi */ .g2.getGroupsId, {
        group_id: active ? Number(active) : null
    });
    const groups = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        let newGroups = [
            {
                value: "-1",
                label: tr("all")
            }
        ];
        (groupsData?.group_list || []).forEach((group)=>{
            newGroups.push({
                ...group,
                value: String(group.group_id),
                label: tr(group?.group_name)
            });
        });
        return newGroups;
    }, [
        groupsData?.group_list,
        tr
    ]);
    if (hashParams?.miner) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Detail__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
            miner: hashParams.miner,
            selectedKey: selectedKey
        });
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex justify-between items-center",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex  flex-col",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "w-full text-lg font-semibold font-PingFang ",
                                children: tr(selectedKey)
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "text-xs text_des",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: tr("last_time")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "ml-2",
                                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_7__/* .formatDateTime */ .o0)(expiredData?.epoch_time, "YYYY/MM/DD HH:mm")
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex gap-x-2.5",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_selects__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                            value: active,
                            options: groups,
                            onChange: (v)=>{
                                setActive(v);
                            }
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mt-5",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                        className: "flex mb-5 card_shadow border border_color rounded-xl px-10 py-4 text-sm text_des font-medium ",
                        children: _contents_account__WEBPACK_IMPORTED_MODULE_4__/* .account_expired */ .nS?.headerList.map((titleItem, index)=>{
                            let showTitle = titleItem.title;
                            if (showTitle === "exp_month") {
                                showTitle = "exp_time";
                            }
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                style: {
                                    width: titleItem.width
                                },
                                children: tr(showTitle)
                            }, index);
                        })
                    }),
                    expiredData?.sector_detail_month?.map((sector_item, index)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_collapse__WEBPACK_IMPORTED_MODULE_8___default()), {
                            collapsible: "header",
                            className: "card_shadow custom_Collapse  !rounded-xl mb-2.5",
                            expandIconPosition: "end",
                            items: [
                                {
                                    key: index,
                                    label: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                        className: "flex font-semibold pl-7",
                                        children: _contents_account__WEBPACK_IMPORTED_MODULE_4__/* .account_expired */ .nS?.headerList.map((item)=>{
                                            const { dataIndex, width, title, render } = item;
                                            const value = sector_item[dataIndex];
                                            const showValue = render ? render(value, sector_item, tr) : value;
                                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                style: {
                                                    width: width
                                                },
                                                children: showValue
                                            }, index);
                                        })
                                    }),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_Table__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                        data: sector_item?.sector_detail_list || [],
                                        columns: columns,
                                        loading: loading
                                    })
                                }
                            ]
                        }, index);
                    })
                ]
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5771:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2881);
/* harmony import */ var _packages_breadcrumb__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8656);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3495);
/* harmony import */ var _packages_exportExcel__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6459);
/* harmony import */ var _packages_Table__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(430);
/* harmony import */ var _src_account_DateTIme__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7998);
/* harmony import */ var _contents_account__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7701);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8108);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8054);
/* harmony import */ var _packages_tooltip__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2305);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _utils__WEBPACK_IMPORTED_MODULE_4__, _packages_exportExcel__WEBPACK_IMPORTED_MODULE_5__, _packages_Table__WEBPACK_IMPORTED_MODULE_6__, _contents_account__WEBPACK_IMPORTED_MODULE_8__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _utils__WEBPACK_IMPORTED_MODULE_4__, _packages_exportExcel__WEBPACK_IMPORTED_MODULE_5__, _packages_Table__WEBPACK_IMPORTED_MODULE_6__, _contents_account__WEBPACK_IMPORTED_MODULE_8__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 











/** @format */ /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ miner, data, selectedKey })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "account"
    });
    const routerItems = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        if (miner && typeof miner === "string") {
            return [
                {
                    title: tr("overview_gas"),
                    path: "/account#gas"
                },
                {
                    title: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: miner
                    }),
                    path: `/account#gas?miner=${miner}`
                }
            ];
        }
        return [];
    }, [
        miner
    ]);
    const [date, setDate] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({
        startTime: (0,_utils__WEBPACK_IMPORTED_MODULE_4__/* .formatDateTime */ .o0)((0,_utils__WEBPACK_IMPORTED_MODULE_4__/* .getCalcTime */ .pf)(6), "YYYY-MM-DDTHH:mm:ssZ"),
        endTime: (0,_utils__WEBPACK_IMPORTED_MODULE_4__/* .formatDateTime */ .o0)(new Date().getTime() / 1000, "YYYY-MM-DDTHH:mm:ssZ")
    });
    //proApi.getReward
    const { data: gasData, loading } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_10__/* .proApi */ .g2.getGas, {
        miner_id: miner,
        start_date: date.startTime,
        end_date: date.endTime
    });
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        return _contents_account__WEBPACK_IMPORTED_MODULE_8__/* .account_gas */ .JQ.columns(tr, "detail").map((item)=>{
            if (item.titleTip) {
                item.excelTitle = item.dataIndex === "sector_count_change" ? `${tr("raw_power")}/${tr("sector_power_count")}` : tr(item.title), item.title = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "flex items-center gap-x-1",
                    children: [
                        tr(item.title),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tooltip__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                            context: tr(item.titleTip)
                        })
                    ]
                });
            } else {
                item.title = tr(item.title);
            }
            return {
                ...item
            };
        });
    }, [
        tr
    ]);
    const showData = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        const newData = gasData?.gas_cost_detail_list || [];
        return newData || [];
    }, [
        gasData
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            routerItems && routerItems.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_breadcrumb__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                items: routerItems
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex justify-between items-center mt-10",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex  flex-col",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "w-full text-lg font-semibold font-PingFang ",
                                children: miner
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "text-xs text_des",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: tr("last_time")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "ml-2",
                                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_4__/* .formatDateTime */ .o0)(gasData?.epoch_time, "YYYY/MM/DD HH:mm")
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex gap-x-2.5",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_account_DateTIme__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                showEnd: true,
                                defaultValue: [
                                    date.startTime,
                                    date.endTime
                                ],
                                onChange: (start, end)=>{
                                    setDate({
                                        startTime: start,
                                        endTime: end
                                    });
                                }
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_exportExcel__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                columns: columns,
                                data: showData,
                                fileName: tr(selectedKey) + miner ? `(${miner})` : ""
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "card_shadow border border_color rounded-xl p-4 mt-5 overflow-auto",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_Table__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    data: showData,
                    columns: columns,
                    loading: loading
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7307:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2881);
/* harmony import */ var _packages_Table__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(430);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _contents_account__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7701);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8054);
/* harmony import */ var _packages_selects__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(869);
/* harmony import */ var _packages_exportExcel__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6459);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8108);
/* harmony import */ var _src_account_DateTIme__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7998);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3495);
/* harmony import */ var _components_hooks_useHash__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8087);
/* harmony import */ var _Detail__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5771);
/* harmony import */ var _packages_tooltip__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2305);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _packages_Table__WEBPACK_IMPORTED_MODULE_2__, _contents_account__WEBPACK_IMPORTED_MODULE_4__, _packages_exportExcel__WEBPACK_IMPORTED_MODULE_7__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__, _utils__WEBPACK_IMPORTED_MODULE_10__, _Detail__WEBPACK_IMPORTED_MODULE_12__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _packages_Table__WEBPACK_IMPORTED_MODULE_2__, _contents_account__WEBPACK_IMPORTED_MODULE_4__, _packages_exportExcel__WEBPACK_IMPORTED_MODULE_7__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__, _utils__WEBPACK_IMPORTED_MODULE_10__, _Detail__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 













/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ selectedKey })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "account"
    });
    const { hashParams } = (0,_components_hooks_useHash__WEBPACK_IMPORTED_MODULE_11__/* .useHash */ .H)();
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("-1");
    const [date, setDate] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({
        startTime: (0,_utils__WEBPACK_IMPORTED_MODULE_10__/* .formatDateTime */ .o0)(new Date().getTime() / 1000, "YYYY-MM-DDTHH:mm:ssZ"),
        endTime: (0,_utils__WEBPACK_IMPORTED_MODULE_10__/* .formatDateTime */ .o0)(new Date().getTime() / 1000, "YYYY-MM-DDTHH:mm:ssZ")
    });
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        return _contents_account__WEBPACK_IMPORTED_MODULE_4__/* .account_gas */ .JQ.columns(tr).map((item)=>{
            if (item.titleTip) {
                item.excelTitle = item.dataIndex === "sector_count_change" ? `${tr("raw_power")}/${tr("sector_power_count")}` : tr(item.title), item.title = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "flex items-center gap-x-1",
                    children: [
                        tr(item.title),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tooltip__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                            context: tr(item.titleTip)
                        })
                    ]
                });
            } else {
                item.title = tr(item.title);
            }
            return {
                ...item
            };
        });
    }, [
        tr
    ]);
    //proApi
    const { data: gasData, loading } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_5__/* .proApi */ .g2.getGas, {
        group_id: active ? Number(active) : 0,
        start_date: date.startTime,
        end_date: date.startTime
    });
    const { data: groupsData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_5__/* .proApi */ .g2.getGroupsId, {
        group_id: active ? Number(active) : null
    });
    const groups = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        let newGroups = [
            {
                value: "-1",
                label: tr("all")
            }
        ];
        (groupsData?.group_list || []).forEach((group)=>{
            newGroups.push({
                ...group,
                value: String(group.group_id),
                label: tr(group?.group_name)
            });
        });
        return newGroups;
    }, [
        groupsData?.group_list,
        tr
    ]);
    const data = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        return gasData?.gas_cost_detail_list || [];
    }, [
        gasData
    ]);
    if (hashParams?.miner) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Detail__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
            miner: hashParams.miner,
            data: gasData,
            selectedKey: selectedKey
        });
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex justify-between items-center",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex  flex-col",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "w-full text-lg font-semibold font-PingFang ",
                                children: tr(selectedKey)
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "text-xs text_des",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: tr("last_time")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "ml-2",
                                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_10__/* .formatDateTime */ .o0)(gasData?.epoch_time)
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex gap-x-2.5",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_selects__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                value: String(active),
                                options: groups,
                                onChange: (v)=>{
                                    setActive(v);
                                // load(v);
                                }
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_account_DateTIme__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                defaultValue: [
                                    date.startTime,
                                    date.endTime
                                ],
                                onChange: (start, end)=>{
                                    setDate({
                                        startTime: start,
                                        endTime: end
                                    });
                                }
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_exportExcel__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                columns: columns,
                                data: data
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "card_shadow border border_color rounded-xl p-4 mt-5",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_Table__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    data: data,
                    columns: columns,
                    loading: loading
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6136:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2881);
/* harmony import */ var _packages_Table__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(430);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _contents_account__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7701);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8054);
/* harmony import */ var _packages_selects__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(869);
/* harmony import */ var _packages_exportExcel__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6459);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8108);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3495);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _packages_Table__WEBPACK_IMPORTED_MODULE_2__, _contents_account__WEBPACK_IMPORTED_MODULE_4__, _packages_exportExcel__WEBPACK_IMPORTED_MODULE_7__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__, _utils__WEBPACK_IMPORTED_MODULE_9__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _packages_Table__WEBPACK_IMPORTED_MODULE_2__, _contents_account__WEBPACK_IMPORTED_MODULE_4__, _packages_exportExcel__WEBPACK_IMPORTED_MODULE_7__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__, _utils__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 









/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ selectedKey })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "account"
    });
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("-1");
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        return _contents_account__WEBPACK_IMPORTED_MODULE_4__/* .account_lucky */ .n1.columns(tr).map((item)=>{
            return {
                ...item,
                title: tr(item.title)
            };
        });
    }, [
        tr
    ]);
    //proApi
    const { data: luckyData, loading } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_5__/* .proApi */ .g2.getLucky, {
        group_id: active ? Number(active) : ""
    });
    const data = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        return luckyData?.lucky_rate_list || [];
    }, [
        luckyData
    ]);
    const { data: groupsData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_5__/* .proApi */ .g2.getGroupsId, {
        group_id: active ? Number(active) : null
    });
    const groups = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        let newGroups = [
            {
                value: "-1",
                label: tr("all")
            }
        ];
        (groupsData?.group_list || []).forEach((group)=>{
            newGroups.push({
                ...group,
                value: String(group.group_id),
                label: tr(group?.group_name)
            });
        });
        return newGroups;
    }, [
        groupsData?.group_list,
        tr
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex justify-between items-center",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex  flex-col",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "w-full text-lg font-semibold font-PingFang ",
                                children: tr(selectedKey)
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "text-xs text_des",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: tr("last_time")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "ml-2",
                                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .formatDateTime */ .o0)(luckyData?.epoch_time, "YYYY/MM/DD HH:mm")
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex gap-x-2.5",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_selects__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                value: active,
                                options: groups,
                                onChange: (v)=>{
                                    setActive(v);
                                }
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_exportExcel__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                columns: columns,
                                data: data,
                                fileName: tr(selectedKey)
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "card_shadow border border_color rounded-xl p-4 mt-5",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_Table__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    data: data,
                    columns: columns,
                    loading: loading
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9147:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2881);
/* harmony import */ var _components_search__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1519);
/* harmony import */ var _packages_breadcrumb__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8656);
/* harmony import */ var _assets_images_del_light_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4945);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _assets_images_error_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7872);
/* harmony import */ var _packages_message__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(275);
/* harmony import */ var _CreateGroup__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2181);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7947);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8054);
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3800);
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(antd_lib_button__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _packages_searchSelect__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9876);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8108);
/* harmony import */ var _content__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9794);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_15__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _components_search__WEBPACK_IMPORTED_MODULE_2__, _CreateGroup__WEBPACK_IMPORTED_MODULE_8__, _packages_searchSelect__WEBPACK_IMPORTED_MODULE_12__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_13__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _components_search__WEBPACK_IMPORTED_MODULE_2__, _CreateGroup__WEBPACK_IMPORTED_MODULE_8__, _packages_searchSelect__WEBPACK_IMPORTED_MODULE_12__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 















/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ groups, minersNum, defaultId })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "account"
    });
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_15__.useRouter)();
    const routerItems = [
        {
            title: tr("miners"),
            path: "/account#miners"
        },
        {
            title: tr("miners_add"),
            path: "/account#miners?type=miner_add"
        }
    ];
    const [addMiners, setAddMiner] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)([]);
    const [show, setShow] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    const [selectGroup, setSelectGroup] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)("");
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z)();
    const { setMinerNum, setGroups } = (0,_content__WEBPACK_IMPORTED_MODULE_14__/* .useGroupsStore */ .Bj)();
    const handleSearch = (values)=>{
        if (!values.startsWith("f0")) {
            return _packages_message__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z.showMessage({
                type: "error",
                content: "please add minerId",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_error_svg__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    width: 18,
                    height: 18
                }),
                suffix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "cursor-pointer",
                    onClick: ()=>{
                        _packages_message__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z.hide();
                    },
                    children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_9__/* .getSvgIcon */ .a)("closeIcon")
                })
            });
        }
        if (addMiners.length > Number(minersNum?.max_miners_count)) {
            return _packages_message__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z.showMessage({
                type: "error",
                content: "添加节点已达上限，请删除部分节点后添加新",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_error_svg__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    width: 18,
                    height: 18
                }),
                suffix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "cursor-pointer",
                    onClick: ()=>{
                        _packages_message__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z.hide();
                    },
                    children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_9__/* .getSvgIcon */ .a)("closeIcon")
                })
            });
        }
        setAddMiner([
            ...addMiners,
            {
                miner_id: values?.trim()
            }
        ]);
    };
    const handleSave = async ()=>{
        if (addMiners.length > 0) {
            setLoading(true);
            const selectedGroup = selectGroup || defaultId;
            const groupDetail = groups.find((v)=>v.value === selectedGroup);
            let payload = {};
            if (groupDetail) {
                //更新旧分组
                payload = {
                    group_id: selectedGroup,
                    group_name: groupDetail?.group_name,
                    is_default: groupDetail.is_default,
                    miners_info: (groupDetail?.miners_info || []).concat(addMiners)
                };
            } else {
                //添加新分组
                payload = {
                    group_id: selectedGroup,
                    miners_info: addMiners
                };
            }
            const data = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_10__/* .proApi */ .g2.saveGroup, payload);
            setLoading(false);
            if (data) {
                const newGroups = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_10__/* .proApi */ .g2.getGroups);
                setGroups(newGroups?.group_info_list || []);
                const minerNum = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_10__/* .proApi */ .g2.account_miners);
                setMinerNum(minerNum);
                _packages_message__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z.showMessage({
                    type: "success",
                    content: "Add Miner successfully"
                });
                router.push("/account#miners");
            } else {
                if (data && data?.code) {
                    _packages_message__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z.showMessage({
                        type: "error",
                        content: data?.message || ""
                    });
                }
            }
        } else {
            _packages_message__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z.showMessage({
                type: "warning",
                content: "Please add miner"
            });
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_breadcrumb__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                items: routerItems
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "mt-8 mb-10 font-PingFang font-semibold text-lg",
                children: tr("miners_add")
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "border_color card_shadow px-5 py-7 rounded-xl flex-1 flex flex-col",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "text_des",
                        children: tr("miners_add")
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex-1",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_search__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                ns: "account",
                                className: "w-full mt-4 !h-12",
                                placeholder: "miner_add_placeholder",
                                clear: true,
                                onClick: handleSearch,
                                suffix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "p-2 w-fit h-8 rounded-[5px] reverse_color flex items-center cursor-pointer",
                                    children: tr("miner_add")
                                }),
                                onSearch: handleSearch
                            }),
                            addMiners.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                className: "list-none border border_color rounded-[5px] mt-5 p-4 w-full h-fit flex gap-x-4 gap-y-2.5 flex-wrap",
                                children: addMiners?.map((miner, index)=>{
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: "bg-bg_hover px-2 py-1 w-fit rounded-[5px] flex items-center justify-between gap-x-6",
                                        children: [
                                            miner.miner_id,
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_del_light_svg__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                className: "cursor-pointer",
                                                width: 12,
                                                height: 12,
                                                onClick: ()=>{
                                                    const newArr = [
                                                        ...addMiners
                                                    ];
                                                    newArr.splice(index, 1), setAddMiner(newArr);
                                                }
                                            })
                                        ]
                                    }, miner.miner_id + index);
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_searchSelect__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                className: "caret-transparent",
                                ns: "account",
                                options: groups,
                                isShow: true,
                                onChange: (value)=>{
                                    setSelectGroup(value);
                                },
                                suffix: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                    className: "mt-4",
                                    onClick: ()=>setShow(true),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                            className: " border_color"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            className: "w-full py-4 px-5 flex rounded-[5px] items-center gap-x-2 mt-4 cursor-pointer hover:text-primary hover:bg-bg_hover",
                                            children: [
                                                (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_9__/* .getSvgIcon */ .a)("addIcon"),
                                                tr("group_add")
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mt-5 flex gap-x-4 justify-end",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_button__WEBPACK_IMPORTED_MODULE_11___default()), {
                                className: "cancel_btn",
                                onClick: ()=>{
                                    router.back();
                                },
                                children: tr("back")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_button__WEBPACK_IMPORTED_MODULE_11___default()), {
                                className: "confirm_btn",
                                loading: loading,
                                onClick: handleSave,
                                children: tr("confirm")
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CreateGroup__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                show: show,
                onChange: (name)=>{
                    setShow(false);
                }
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4091:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _assets_images_error_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7872);
/* harmony import */ var _assets_images_del_light_svg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4945);
/* harmony import */ var _components_search__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1519);
/* harmony import */ var _packages_message__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(275);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7947);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2881);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_search__WEBPACK_IMPORTED_MODULE_3__, _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_7__]);
([_components_search__WEBPACK_IMPORTED_MODULE_3__, _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 







/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ className, defaultMiners, minersNum, onChange })=>{
    const [addMiners, setAddMiner] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(defaultMiners || []);
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_7__/* .Translation */ .W)({
        ns: "account"
    });
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        setAddMiner(defaultMiners || []);
    }, [
        defaultMiners
    ]);
    const handleSearch = (values)=>{
        if (addMiners.length > Number(minersNum?.max_miners_count)) {
            return _packages_message__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z.showMessage({
                type: "error",
                content: "添加节点已达上限，请删除部分节点后添加新",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_error_svg__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                    width: 18,
                    height: 18
                }),
                suffix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "cursor-pointer",
                    onClick: ()=>{
                        _packages_message__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z.hide();
                    },
                    children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_6__/* .getSvgIcon */ .a)("closeIcon")
                })
            });
        }
        const newMiners = [
            ...addMiners,
            {
                miner_id: values
            }
        ];
        setAddMiner(newMiners);
        if (onChange) onChange(newMiners);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_search__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                ns: "account",
                className: `w-full mt-4 !h-12 ${className}`,
                placeholder: "miner_add_placeholder",
                clear: true,
                onClick: handleSearch,
                suffix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "p-2 w-fit h-8 rounded-[5px] reverse_color flex items-center cursor-pointer",
                    children: tr("miner_add")
                }),
                onSearch: handleSearch
            }),
            addMiners.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                className: "list-none border border_color rounded-[5px] mt-5 p-4 w-full h-fit flex gap-x-4 flex-wrap",
                children: addMiners?.map((miner, index)=>{
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                        className: "bg-bg_hover px-2 py-1 w-fit rounded-[5px] flex items-center justify-between gap-x-6",
                        children: [
                            miner.miner_id,
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_del_light_svg__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                className: "cursor-pointer",
                                width: 12,
                                height: 12,
                                onClick: ()=>{
                                    const newArr = [
                                        ...addMiners
                                    ];
                                    newArr.splice(index, 1);
                                    setAddMiner(newArr);
                                    if (onChange) onChange(newArr);
                                }
                            })
                        ]
                    }, miner + index);
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2181:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2881);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8054);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8108);
/* harmony import */ var antd_lib_modal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6418);
/* harmony import */ var antd_lib_modal__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(antd_lib_modal__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(675);
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(antd_lib_input__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3800);
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(antd_lib_button__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _content__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9794);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_3__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 








/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ show, onChange })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "account"
    });
    const [value, setValue] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)("");
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_7__.useState)(false);
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
    const { setGroups } = (0,_content__WEBPACK_IMPORTED_MODULE_8__/* .useGroupsStore */ .Bj)();
    const handleClick = async ()=>{
        //添加分组
        // onChange(value);
        setLoading(true);
        const data = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_2__/* .proApi */ .g2.saveGroup, {
            group_name: value
        });
        const newGroups = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_2__/* .proApi */ .g2.getGroups);
        setGroups(newGroups?.group_info_list || []);
        setLoading(false);
        onChange(false);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_modal__WEBPACK_IMPORTED_MODULE_4___default()), {
        width: 400,
        title: tr("create_group"),
        open: show,
        destroyOnClose: true,
        closeIcon: false,
        footer: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
            className: "flex justify-center gap-x-4 mt-5",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_button__WEBPACK_IMPORTED_MODULE_6___default()), {
                    className: "cancel_btn",
                    onClick: ()=>{
                        onChange(false);
                    },
                    children: tr("cancel")
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_button__WEBPACK_IMPORTED_MODULE_6___default()), {
                    className: "confirm_btn",
                    loading: loading,
                    onClick: handleClick,
                    children: tr("confirm")
                })
            ]
        }),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_input__WEBPACK_IMPORTED_MODULE_5___default()), {
            className: "mt-5 custom_input h-12",
            showCount: true,
            placeholder: tr("create_group_holder"),
            maxLength: 10,
            onChange: (e)=>{
                setValue(e.target.value);
            }
        })
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8812:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2881);
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3800);
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd_lib_button__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(675);
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(antd_lib_input__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _AddNode__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4091);
/* harmony import */ var _packages_breadcrumb__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8656);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8108);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8054);
/* harmony import */ var _content__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9794);
/* harmony import */ var _packages_message__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(275);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_11__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _AddNode__WEBPACK_IMPORTED_MODULE_4__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_7__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _AddNode__WEBPACK_IMPORTED_MODULE_4__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 











/** @format */ /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ groupId, groupDetail, minersNum })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "account"
    });
    const { groups, setGroups, setMinerNum } = (0,_content__WEBPACK_IMPORTED_MODULE_9__/* .useGroupsStore */ .Bj)();
    const routerItems = [
        {
            title: tr("miners"),
            path: "/account#miners"
        },
        {
            title: tr("miners_group_manage"),
            path: "/account#miners?type=miners_group"
        }
    ];
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_11__.useRouter)();
    const [groupName, setGroupName] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(groupDetail?.label);
    const [groupMinders, setGroupMiners] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(groupDetail?.miners_info);
    const [saveLoading, setSaveLoading] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false);
    const { loading, axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        setGroupName(groupDetail?.label);
        setGroupMiners(groupDetail?.miners_info || []);
    }, [
        groupDetail,
        groupId
    ]);
    const handleSave = async ()=>{
        //添加分组及节点
        setSaveLoading(true);
        // const detail
        const groupDetail = groups.find((v)=>v.value === Number(groupId));
        const data = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_8__/* .proApi */ .g2.saveGroup, {
            group_id: Number(groupId),
            is_default: groupDetail?.is_default,
            group_name: groupName,
            miners_info: groupMinders
        });
        setSaveLoading(false);
        if (data) {
            const newGroups = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_8__/* .proApi */ .g2.getGroups);
            setGroups(newGroups?.group_info_list || []);
            const minerNum = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_8__/* .proApi */ .g2.account_miners);
            setMinerNum(minerNum);
            _packages_message__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z.showMessage({
                type: "success",
                content: "Save Group successfully"
            });
            router.push("/account#miners");
        } else {
            if (data && data?.code) {
                _packages_message__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z.showMessage({
                    type: "error",
                    content: data?.message || ""
                });
            }
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_breadcrumb__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                items: routerItems
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "mt-8 mb-10 font-PingFang font-semibold text-lg",
                children: tr("miners_group_manage")
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "border_color card_shadow px-5 py-7 rounded-xl flex flex-col flex-1",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                        className: "flex-1",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                className: "flex flex-col",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text_des mb-2",
                                        children: tr("group_name")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_input__WEBPACK_IMPORTED_MODULE_3___default()), {
                                        disabled: groupDetail && groupDetail.is_default,
                                        placeholder: tr("create_group_holder"),
                                        className: "h-12 w-full custom_input mt-2",
                                        value: groupName,
                                        onChange: (e)=>{
                                            setGroupName(e.target.value);
                                        }
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                className: "mt-5",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text_des",
                                        children: tr("miners")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_AddNode__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                        className: "mt-2",
                                        defaultMiners: groupMinders,
                                        minersNum: minersNum,
                                        onChange: (values)=>{
                                            setGroupMiners(values);
                                        }
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mt-5 flex gap-x-4 justify-end",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_button__WEBPACK_IMPORTED_MODULE_2___default()), {
                                className: "cancel_btn",
                                children: tr("cancel")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_button__WEBPACK_IMPORTED_MODULE_2___default()), {
                                className: "confirm_btn",
                                onClick: handleSave,
                                loading: saveLoading,
                                children: tr("confirm")
                            })
                        ]
                    })
                ]
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 179:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd_lib_collapse__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8633);
/* harmony import */ var antd_lib_collapse__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd_lib_collapse__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9191);
/* harmony import */ var react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7947);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2881);
/* harmony import */ var _contents_account__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7701);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8108);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8054);
/* harmony import */ var _content__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9794);
/* harmony import */ var _packages_modal__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4627);
/* harmony import */ var _packages_tagInput__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6247);
/* harmony import */ var _packages_message__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(275);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_6__, _contents_account__WEBPACK_IMPORTED_MODULE_7__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__, _packages_modal__WEBPACK_IMPORTED_MODULE_11__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_6__, _contents_account__WEBPACK_IMPORTED_MODULE_7__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__, _packages_modal__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 













const Groups = ({ groups })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_6__/* .Translation */ .W)({
        ns: "account"
    });
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    const { setGroups, setMinerNum } = (0,_content__WEBPACK_IMPORTED_MODULE_10__/* .useGroupsStore */ .Bj)();
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(groups);
    const [deleteLoading, setDeleteLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [modalItems, setModalItems] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setData(groups || []);
    }, [
        groups
    ]);
    const handleDragEnd = async (result)=>{
        if (!result.destination) {
            return;
        }
        // else
        // {
        const { source, destination } = result;
        const sourceIndex = source.index; //移动的index
        const destinationIndex = destination.index; //目标index
        const [groupId, groupIndex] = source.droppableId.split("_");
        const sourceMinerItem = data[groupIndex].miners_info[sourceIndex];
        const [dest_itemId, dest_index] = destination.droppableId.split("_");
        const groupItem = data[Number(groupIndex)]; //内容group minerIem
        const destinationGroup = data[Number(dest_index)]; //移动
        if (groupId !== dest_itemId) {
            //不同的组内拖拽
            destinationGroup.miners_info = destinationGroup?.miners_info || [];
            destinationGroup.miners_info?.splice(destinationIndex, 0, sourceMinerItem);
            groupItem?.miners_info?.splice(sourceIndex, 1);
            //给予目标group，miner_id 是唯一的
            const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_9__/* .proApi */ .g2.saveMiner, destinationGroup);
            if (result) {
                setData([
                    ...data
                ]);
                const newGroups = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_9__/* .proApi */ .g2.getGroups);
                setGroups(newGroups?.group_info_list || []);
            }
        } else {
            //同组内拖拽
            groupItem?.miners_info?.splice(sourceIndex, 1);
            groupItem?.miners_info?.splice(destinationIndex, 0, sourceMinerItem);
            const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_9__/* .proApi */ .g2.saveMiner, groupItem);
            if (result) {
                setData([
                    ...data
                ]);
                const newGroups = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_9__/* .proApi */ .g2.getGroups);
                setGroups(newGroups?.group_info_list || []);
            }
        }
    // }
    //保存分组 todo
    };
    const handleDelMiner = async (modalItem)=>{
        setDeleteLoading(true);
        const { minerIndex, groupItem } = modalItem;
        groupItem.miners_info.splice(minerIndex, 1);
        const data = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_9__/* .proApi */ .g2.saveGroup, {
            ...groupItem
        });
        if (data) {
            const newGroups = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_9__/* .proApi */ .g2.getGroups);
            setGroups(newGroups?.group_info_list || []);
            const minerNumResult = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_9__/* .proApi */ .g2.account_miners);
            setMinerNum(minerNumResult);
        }
        setDeleteLoading(false);
    };
    const handleDelGroup = async (id)=>{
        const del = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_9__/* .proApi */ .g2.delGroup, {
            group_id: Number(id)
        });
        if (del) {
            //删除成功
            const newGroups = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_9__/* .proApi */ .g2.getGroups);
            setGroups(newGroups?.group_info_list || []);
            setDeleteLoading(false);
        }
    };
    const handleSaveMiners = async (group, minerInfo)=>{
        const saveResult = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_9__/* .proApi */ .g2.saveMiner, {
            ...group,
            miners_info: [
                minerInfo
            ]
        });
        if (saveResult) {
            return _packages_message__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z.showMessage({
                type: "success",
                content: "保存成功",
                suffix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "cursor-pointer",
                    onClick: ()=>{
                        _packages_message__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z.hide();
                    },
                    children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_4__/* .getSvgIcon */ .a)("closeIcon")
                })
            });
        }
    };
    const GroupItemHeader = (item)=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
            className: "custom_Collapse_item cursor-pointer w-full rounded-xl h-[38px] flex items-center justify-between",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "flex gap-x-5 items-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "des_bg_color flex items-center text-xs border_color border text_des w-fit px-1 rounded-[5px] ",
                            children: tr(item.label)
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            children: tr("item_value", {
                                value: item?.miners_info?.length || 0
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex gap-x-5 items-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_5___default()), {
                            href: `/account#miners?group=${item.group_id}`,
                            className: "cursor-pointer text_color",
                            children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_4__/* .getSvgIcon */ .a)("editIcon")
                        }),
                        !item.is_default && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "cursor-pointer hover:text-primary",
                                onClick: (e)=>{
                                    e.stopPropagation();
                                    setModalItems({
                                        id: item.group_name,
                                        group_id: item.group_id,
                                        type: "group",
                                        show: true,
                                        groupItem: item
                                    });
                                },
                                children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_4__/* .getSvgIcon */ .a)("deleteIcon")
                            })
                        })
                    ]
                })
            ]
        }, item.group_id);
    };
    const minersChildren = (minerItem, minerIndex, groupItem)=>{
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
            className: "w-full flex border-t border_color px-5",
            id: `${minerItem.miner_id}-${minerIndex}`,
            children: _contents_account__WEBPACK_IMPORTED_MODULE_7__/* .account_miners */ .Oy.groups_miners_columns.map((itemDate, index)=>{
                const { render, title, width, dataIndex } = itemDate;
                const value = minerItem[dataIndex];
                let showValue = render ? render(value) : minerItem[dataIndex];
                if (dataIndex === "miner_tag") {
                    showValue = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tagInput__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                        text: value,
                        record: {
                            ...minerItem
                        },
                        onChange: (value)=>handleSaveMiners({
                                group_id: Number(groupItem.group_id),
                                is_default: groupItem.is_default
                            }, {
                                ...minerItem,
                                miner_tag: value
                            })
                    });
                } else if (dataIndex == "edit") {
                    showValue = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: "flex items-center gap-x-2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "cursor-pointer hover:text-primary",
                                children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_4__/* .getSvgIcon */ .a)("openAllIcon")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "cursor-pointer hover:text-primary",
                                    onClick: ()=>{
                                        setModalItems({
                                            id: minerItem.miner_id,
                                            minerItem,
                                            type: "miner",
                                            show: true,
                                            groupItem,
                                            minerIndex
                                        });
                                    },
                                    children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_4__/* .getSvgIcon */ .a)("deleteIcon")
                                })
                            })
                        ]
                    });
                }
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                    style: {
                        width
                    },
                    className: " py-5",
                    children: showValue
                }, index);
            })
        }, minerIndex);
    };
    const showType = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        return modalItems?.type || "miner";
    }, [
        modalItems
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_3__.DragDropContext, {
                onDragEnd: handleDragEnd,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_collapse__WEBPACK_IMPORTED_MODULE_2___default()), {
                    className: "custom_collapse_gaps",
                    collapsible: "header",
                    expandIconPosition: "end",
                    children: data.map((groupItem, dataIndex)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_collapse__WEBPACK_IMPORTED_MODULE_2___default().Panel), {
                            header: GroupItemHeader(groupItem),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_3__.Droppable, {
                                droppableId: groupItem.group_id + "_" + dataIndex,
                                children: (provided)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        ref: provided.innerRef,
                                        ...provided.droppableProps,
                                        className: "main_bgColor text-sm font-medium text_des rounded-xl",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                                className: "flex p-5",
                                                children: _contents_account__WEBPACK_IMPORTED_MODULE_7__/* .account_miners */ .Oy.groups_miners_columns.map((minerHeader, index)=>{
                                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        className: "w-full",
                                                        style: {
                                                            width: minerHeader.width
                                                        },
                                                        children: tr(minerHeader.title)
                                                    }, index);
                                                })
                                            }),
                                            groupItem?.miners_info?.map((minerItem, minerIndex)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_beautiful_dnd__WEBPACK_IMPORTED_MODULE_3__.Draggable, {
                                                    draggableId: minerItem.miner_id + "_" + minerIndex,
                                                    index: minerIndex,
                                                    children: (provided)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            ref: provided.innerRef,
                                                            ...provided.draggableProps,
                                                            ...provided.dragHandleProps,
                                                            children: minersChildren(minerItem, minerIndex, groupItem)
                                                        })
                                                }, minerItem.miner_id)),
                                            provided.placeholder
                                        ]
                                    })
                            })
                        }, groupItem.group_id))
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_modal__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                closeIcon: false,
                title: tr(`delete_${showType}`),
                show: modalItems.show,
                loading: deleteLoading,
                onOk: (e)=>{
                    //  e.stopPropagation();
                    if (modalItems.type === "miner") {
                        handleDelMiner(modalItems);
                    } else {
                        handleDelGroup(modalItems.group_id);
                    }
                    setModalItems({
                        show: false
                    });
                },
                onCancel: (e)=>{
                    e.stopPropagation();
                    setModalItems({
                        show: false
                    });
                //  setShowDeleteModal(false);
                },
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "m-5",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "mb-1",
                            children: tr(`delete_record_${showType}`, {
                                value: modalItems?.id
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: tr(`delete_${showType}_text`)
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Groups);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3398:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2881);
/* harmony import */ var _Add__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9147);
/* harmony import */ var _components_hooks_useHash__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8087);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8054);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _GroupAdd__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8812);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8108);
/* harmony import */ var _content__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9794);
/* harmony import */ var _Groups__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(179);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _Add__WEBPACK_IMPORTED_MODULE_2__, _GroupAdd__WEBPACK_IMPORTED_MODULE_7__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__, _Groups__WEBPACK_IMPORTED_MODULE_10__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _Add__WEBPACK_IMPORTED_MODULE_2__, _GroupAdd__WEBPACK_IMPORTED_MODULE_7__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__, _Groups__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 










/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ minersNum })=>{
    const { hashParams } = (0,_components_hooks_useHash__WEBPACK_IMPORTED_MODULE_3__/* .useHash */ .H)();
    const { type, group } = hashParams || {};
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "account"
    });
    const [groups, setGroups] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)([]);
    const [defaultGroupsId, setDefaultGroupsId] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)();
    const [minerNum, setMinerNum] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(minersNum);
    const { setAllNum } = (0,_content__WEBPACK_IMPORTED_MODULE_9__/* .useMinerStore */ .mO)();
    const { data: groupsData, loading, error } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_4__/* .proApi */ .g2.getGroups);
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        loadMinersNum();
    }, []);
    const loadMinersNum = async ()=>{
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_4__/* .proApi */ .g2.account_miners, {}, {
            isCancel: false
        });
        setMinerNum(result);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        calcGroups(groupsData?.group_info_list || []);
    }, [
        groupsData
    ]);
    //组成公共select item
    const calcGroups = (groupResult)=>{
        const new_data = [];
        let default_groups_id;
        groupResult?.forEach((item)=>{
            if (item.is_default) {
                default_groups_id = item.group_id;
            }
            new_data.push({
                ...item,
                label: item.is_default ? tr("default_group") : item.group_name,
                value: item.group_id
            });
        });
        setDefaultGroupsId(default_groups_id);
        setGroups(new_data);
    };
    const groupDetail = (0,react__WEBPACK_IMPORTED_MODULE_5__.useMemo)(()=>{
        if (group) {
            const file = groups?.find((v)=>v.group_id === Number(group));
            return file;
        }
        return undefined;
    }, [
        group,
        groups
    ]);
    const renderChildren = ()=>{
        if (type === "miner_add" && groupsData) {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Add__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                groups: groups,
                defaultId: defaultGroupsId,
                minersNum: minerNum
            });
        }
        if (type === "group_add") {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_GroupAdd__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                groupId: group,
                groupDetail: groupDetail,
                minersNum: minerNum
            });
        }
        if (group && groupDetail) {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_GroupAdd__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                groupId: group,
                groupDetail: groupDetail,
                minersNum: minerNum
            });
        }
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Groups__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
            groups: groups
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_content__WEBPACK_IMPORTED_MODULE_9__/* .GroupsStoreContext */ .Rp.Provider, {
        value: {
            groups,
            setMinerNum: (mineNum)=>{
                setMinerNum(mineNum);
                setAllNum(mineNum);
            },
            setGroups: (groupsArr)=>{
                calcGroups(groupsArr);
            }
        },
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                className: "w-full mb-5 flex align-baseline justify-between ",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: "font-semibold text-lg font-PingFang",
                        children: [
                            tr("miners"),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "text_des text-sm ml-2 font-DIN",
                                children: [
                                    minerNum?.miners_count,
                                    "/",
                                    minerNum?.max_miners_count
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex gap-x-2.5 items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                                href: `/account#miners?type=group_add`,
                                scroll: false,
                                className: `flex rounded-[5px] border border-color  items-center gap-x-2.5 text_color ${type === "group_add" ? "confirm_btn" : "cancel_btn"}`,
                                children: tr("group_add")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                                href: `/account#miners?type=miner_add`,
                                scroll: false,
                                className: `cancel_btn  border border-color flex rounded-[5px] items-center gap-x-2.5 text_color ${type === "miner_add" ? "confirm_btn" : "cancel_btn"}`,
                                children: tr("miners_add")
                            })
                        ]
                    })
                ]
            }),
            renderChildren()
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2085:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: "ddd"
    });
});


/***/ }),

/***/ 8847:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2881);
/* harmony import */ var _components_loading__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1493);
/* harmony import */ var _contents_account__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7701);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8054);
/* harmony import */ var _packages_Table__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(430);
/* harmony import */ var _packages_exportExcel__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6459);
/* harmony import */ var _packages_selects__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(869);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8108);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7947);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3495);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_11__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_account__WEBPACK_IMPORTED_MODULE_3__, _packages_Table__WEBPACK_IMPORTED_MODULE_5__, _packages_exportExcel__WEBPACK_IMPORTED_MODULE_6__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__, _utils__WEBPACK_IMPORTED_MODULE_10__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_account__WEBPACK_IMPORTED_MODULE_3__, _packages_Table__WEBPACK_IMPORTED_MODULE_5__, _packages_exportExcel__WEBPACK_IMPORTED_MODULE_6__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__, _utils__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 











/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ selectedKey })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "account"
    });
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)("-1");
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_11__.useMemo)(()=>{
        return _contents_account__WEBPACK_IMPORTED_MODULE_3__/* .overview */ .G_.columns(tr).map((item)=>{
            return {
                ...item,
                title: tr(item.title)
            };
        });
    }, [
        tr
    ]);
    //proApi
    const { data: overviewData, loading } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_4__/* .proApi */ .g2.getOverview, {
        group_id: active ? Number(active) : ""
    });
    const { data: groupsData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_4__/* .proApi */ .g2.getGroupsId, {
        group_id: active ? Number(active) : null
    });
    const groups = (0,react__WEBPACK_IMPORTED_MODULE_11__.useMemo)(()=>{
        let newGroups = [
            {
                value: "-1",
                label: tr("all")
            }
        ];
        (groupsData?.group_list || []).forEach((group)=>{
            newGroups.push({
                ...group,
                value: String(group.group_id),
                label: tr(group?.group_name)
            });
        });
        return newGroups;
    }, [
        groupsData?.group_list,
        tr
    ]);
    if (loading) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_loading__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {});
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex justify-between items-center",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex  flex-col",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "w-full text-lg font-semibold font-PingFang ",
                                children: tr(selectedKey)
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "text-xs text_des",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: tr("last_time")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "ml-2",
                                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_10__/* .formatDateTime */ .o0)(overviewData?.epoch_time, "YYYY/MM/DD HH:mm")
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex gap-x-2.5",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_selects__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                value: active,
                                options: groups,
                                onChange: (value)=>{
                                    setActive(value);
                                }
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_exportExcel__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                columns: columns,
                                data: overviewData?.miner_info_detail_list || [],
                                fileName: "expired"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "mt-5 flex flex-col gap-y-5",
                children: _contents_account__WEBPACK_IMPORTED_MODULE_3__/* .overview */ .G_.headerList.map((itemArray, index)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                        className: `flex flex-wrap gap-x-5 min-h-[133px]`,
                        children: itemArray.map((item)=>{
                            const { icon, dataIndex, render } = item;
                            const showValue = render(overviewData && overviewData[dataIndex], overviewData, tr);
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                className: "flex flex-1 p-6 card_shadow border border_color  rounded-xl justify-between items-start",
                                children: [
                                    showValue,
                                    icon && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_9__/* .getSvgIcon */ .a)(icon)
                                    })
                                ]
                            }, item.dataIndex);
                        })
                    }, index);
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "card_shadow border border_color rounded-xl p-4 mt-5 overflow-auto",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_Table__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                    data: overviewData?.miner_info_detail_list || [],
                    columns: columns,
                    loading: loading
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 510:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2881);
/* harmony import */ var _store_UserStore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9821);
/* harmony import */ var _assets_images_logo_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8091);
/* harmony import */ var _assets_images_user_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8134);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3495);
/* harmony import */ var _contents_account__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7701);
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3800);
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(antd_lib_button__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var antd_lib_form__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6190);
/* harmony import */ var antd_lib_form__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(antd_lib_form__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(675);
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(antd_lib_input__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8108);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8054);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _packages_message__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(275);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(7947);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _utils__WEBPACK_IMPORTED_MODULE_5__, _contents_account__WEBPACK_IMPORTED_MODULE_6__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _utils__WEBPACK_IMPORTED_MODULE_5__, _contents_account__WEBPACK_IMPORTED_MODULE_6__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 















/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "account"
    });
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_12__.useState)(false);
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_13__.useRouter)();
    const userInfo = (0,_store_UserStore__WEBPACK_IMPORTED_MODULE_2__/* .UserInfo */ .a)();
    const [form] = antd_lib_form__WEBPACK_IMPORTED_MODULE_8___default().useForm();
    const [edit, setEdit] = (0,react__WEBPACK_IMPORTED_MODULE_12__.useState)(false);
    const [name, setName] = (0,react__WEBPACK_IMPORTED_MODULE_12__.useState)("");
    const handleSaveName = async ()=>{
        setEdit(false);
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_11__/* .proApi */ .g2.updateInfo, {
            name
        });
        if (result) {
            _packages_message__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z.showMessage({
                type: "success",
                content: "Update successful"
            });
        }
    };
    const handleSave = async ()=>{
        setLoading(true);
        const payload = form.getFieldsValue();
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_11__/* .proApi */ .g2.updateInfo, {
            ...payload
        });
        if (result) {
            const newInfo = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_11__/* .proApi */ .g2.userInfo);
            _packages_message__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z.showMessage({
                type: "success",
                content: "Update successful"
            });
            localStorage.removeItem("token");
            userInfo.setUserInfo({});
            router.push("/account/login");
        }
        setLoading(false);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "font-semibold text-lg font-PingFang",
                children: tr("personal")
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "card_shadow mt-8 p-5 border border_color rounded-xl",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex justify-between",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex gap-x-2 items-center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_logo_svg__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                    width: 60,
                                    height: 60
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex flex-col justify-start ",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex items-center gap-x-2",
                                            children: [
                                                edit ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_input__WEBPACK_IMPORTED_MODULE_9___default()), {
                                                    defaultValue: userInfo.name,
                                                    showCount: true,
                                                    maxLength: 10,
                                                    onChange: (e)=>setName(e.target.value),
                                                    onPressEnter: handleSaveName,
                                                    onBlur: handleSaveName
                                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "font-PingFang font-semibold text-xl ",
                                                    children: name || userInfo.name
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "cursor-pointer",
                                                    onClick: ()=>setEdit(true),
                                                    children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_15__/* .getSvgIcon */ .a)("edit")
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "text_des text-xs",
                                            children: userInfo.mail
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex flex-col items-end",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    className: "des_bg_color flex gap-x-2 px-[6px] w-fit py-1 rounded-[5px]",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_user_svg__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                            width: 20,
                                            height: 20
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            children: tr("default_user")
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    className: "mt-2 text_des text-xs ",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            className: "mr-2",
                                            children: [
                                                tr("last_login"),
                                                ":"
                                            ]
                                        }),
                                        (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .formatDateTime */ .o0)(userInfo.last_login)
                                    ]
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mt-5 card_shadow p-5 border border_color rounded-xl",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "font-semibold text-lg font-PingFang",
                        children: tr("personal_setting")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((antd_lib_form__WEBPACK_IMPORTED_MODULE_8___default()), {
                            initialValues: {
                                old_password: "",
                                name: userInfo?.name || ""
                            },
                            form: form,
                            onFinish: handleSave,
                            layout: "vertical",
                            className: "w-3/5 min-w-[300px] mt-5",
                            children: [
                                _contents_account__WEBPACK_IMPORTED_MODULE_6__/* .personal_setting */ .GK.map((item)=>{
                                    const objShow = {};
                                    if (item.dataIndex === "name") {
                                        objShow.showCount = true;
                                        objShow.maxLength = _utils__WEBPACK_IMPORTED_MODULE_5__/* .max_name_length */ .Mr;
                                    }
                                    const newRules = [];
                                    item?.rules?.forEach((v)=>{
                                        newRules.push({
                                            ...v,
                                            message: tr(v.message)
                                        });
                                        if (item.name === "name") {
                                            newRules.push(()=>({
                                                    validator (_, value) {
                                                        if (!value || value.length < _utils__WEBPACK_IMPORTED_MODULE_5__/* .max_name_length */ .Mr) {
                                                            return Promise.resolve();
                                                        }
                                                        return Promise.reject(new Error(tr("name_length")));
                                                    }
                                                }));
                                        }
                                        if (item.name === "new_password") {
                                            newRules.push(()=>({
                                                    validator (_, value) {
                                                        if (!value || (0,_utils__WEBPACK_IMPORTED_MODULE_5__/* .validatePassword */ .uo)(value, form.getFieldValue("old_password"))) {
                                                            return Promise.resolve();
                                                        }
                                                        return Promise.reject(new Error(tr("password_rules")));
                                                    }
                                                }));
                                        } else if (item.name === "confirm_password") {
                                            newRules.push(({ getFieldValue })=>({
                                                    validator (_, value) {
                                                        if (!value || getFieldValue("new_password") === value) {
                                                            return Promise.resolve();
                                                        }
                                                        return Promise.reject(new Error(tr("confirm_password_rules")));
                                                    }
                                                }));
                                        }
                                    });
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_form__WEBPACK_IMPORTED_MODULE_8___default().Item), {
                                        rules: item.rules,
                                        name: item.dataIndex,
                                        label: tr(item.title),
                                        children: item?.dataIndex?.includes("password") ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_input__WEBPACK_IMPORTED_MODULE_9___default().Password), {
                                            className: "h-12 custom_input",
                                            ...objShow,
                                            defaultValue: "",
                                            placeholder: tr(item.placeholder)
                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_input__WEBPACK_IMPORTED_MODULE_9___default()), {
                                            className: "h-12 custom_input",
                                            defaultValue: "",
                                            ...objShow,
                                            placeholder: tr(item.placeholder)
                                        })
                                    }, item.dataIndex);
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_form__WEBPACK_IMPORTED_MODULE_8___default().Item), {
                                    className: "mt-5 !w-full flex-1 flex",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_button__WEBPACK_IMPORTED_MODULE_7___default()), {
                                        htmlType: "submit",
                                        className: "confirm_btn",
                                        loading: loading,
                                        children: tr("confirm")
                                    })
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1326:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2881);
/* harmony import */ var _packages_breadcrumb__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8656);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3495);
/* harmony import */ var _packages_exportExcel__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6459);
/* harmony import */ var _packages_Table__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(430);
/* harmony import */ var _src_account_DateTIme__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7998);
/* harmony import */ var _contents_account__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7701);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8108);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8054);
/* harmony import */ var _packages_tooltip__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2305);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _utils__WEBPACK_IMPORTED_MODULE_4__, _packages_exportExcel__WEBPACK_IMPORTED_MODULE_5__, _packages_Table__WEBPACK_IMPORTED_MODULE_6__, _contents_account__WEBPACK_IMPORTED_MODULE_8__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _utils__WEBPACK_IMPORTED_MODULE_4__, _packages_exportExcel__WEBPACK_IMPORTED_MODULE_5__, _packages_Table__WEBPACK_IMPORTED_MODULE_6__, _contents_account__WEBPACK_IMPORTED_MODULE_8__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 











/** @format */ /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ miner, selectedKey })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "account"
    });
    const routerItems = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        if (miner && typeof miner === "string") {
            return [
                {
                    title: tr("overview_power"),
                    path: "/account#power"
                },
                {
                    title: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: miner
                    }),
                    path: `/account#power?miner=${miner}`
                }
            ];
        }
        return [];
    }, [
        miner
    ]);
    const [date, setDate] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({
        startTime: (0,_utils__WEBPACK_IMPORTED_MODULE_4__/* .formatDateTime */ .o0)((0,_utils__WEBPACK_IMPORTED_MODULE_4__/* .getCalcTime */ .pf)(6), "YYYY-MM-DDTHH:mm:ssZ"),
        endTime: (0,_utils__WEBPACK_IMPORTED_MODULE_4__/* .formatDateTime */ .o0)(new Date().getTime() / 1000, "YYYY-MM-DDTHH:mm:ssZ")
    });
    //proApi
    const { data: powerDataDetail, loading } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_10__/* .proApi */ .g2.getPower, {
        miner_id: miner,
        start_date: date.startTime,
        end_date: date.endTime
    });
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        return _contents_account__WEBPACK_IMPORTED_MODULE_8__/* .account_power */ .Gu.columns(tr, "detail").map((item)=>{
            if (item.titleTip) {
                item.excelTitle = item.dataIndex === "sector_count_change" ? `${tr("raw_power")}/${tr("sector_power_count")}` : tr(item.title), item.title = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "flex items-center gap-x-1",
                    children: [
                        tr(item.title),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tooltip__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                            context: tr(item.titleTip)
                        })
                    ]
                });
            } else {
                item.title = tr(item.title);
            }
            return {
                ...item
            };
        });
    }, [
        tr
    ]);
    const showData = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        const newData = powerDataDetail?.power_detail_list || [];
        return newData || [];
    }, [
        powerDataDetail
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            routerItems && routerItems.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_breadcrumb__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                items: routerItems
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex justify-between items-center mt-10",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex  flex-col",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "w-full text-lg font-semibold font-PingFang ",
                                children: miner
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "text-xs text_des",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: tr("last_time")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "ml-2",
                                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_4__/* .formatDateTime */ .o0)(powerDataDetail?.epoch_time, "YYYY/MM/DD HH:mm")
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex gap-x-2.5",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_account_DateTIme__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                showEnd: true,
                                defaultValue: [
                                    date.startTime,
                                    date.endTime
                                ],
                                onChange: (start, end)=>{
                                    setDate({
                                        startTime: start,
                                        endTime: end
                                    });
                                }
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_exportExcel__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                columns: columns,
                                data: showData,
                                fileName: tr(selectedKey) + miner ? String(miner) : ""
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "card_shadow border border_color rounded-xl p-4 mt-5 overflow-auto",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_Table__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    data: showData,
                    columns: columns,
                    loading: loading
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3743:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2881);
/* harmony import */ var _packages_Table__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(430);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _contents_account__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7701);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8054);
/* harmony import */ var _packages_selects__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(869);
/* harmony import */ var _packages_exportExcel__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6459);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8108);
/* harmony import */ var _src_account_DateTIme__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7998);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3495);
/* harmony import */ var _components_hooks_useHash__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8087);
/* harmony import */ var _Detail__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1326);
/* harmony import */ var _packages_tooltip__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2305);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _packages_Table__WEBPACK_IMPORTED_MODULE_2__, _contents_account__WEBPACK_IMPORTED_MODULE_4__, _packages_exportExcel__WEBPACK_IMPORTED_MODULE_7__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__, _utils__WEBPACK_IMPORTED_MODULE_10__, _Detail__WEBPACK_IMPORTED_MODULE_12__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _packages_Table__WEBPACK_IMPORTED_MODULE_2__, _contents_account__WEBPACK_IMPORTED_MODULE_4__, _packages_exportExcel__WEBPACK_IMPORTED_MODULE_7__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__, _utils__WEBPACK_IMPORTED_MODULE_10__, _Detail__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 













/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ selectedKey })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "account"
    });
    const { hashParams } = (0,_components_hooks_useHash__WEBPACK_IMPORTED_MODULE_11__/* .useHash */ .H)();
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("-1");
    const [date, setDate] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({
        startTime: (0,_utils__WEBPACK_IMPORTED_MODULE_10__/* .formatDateTime */ .o0)(new Date().getTime() / 1000, "YYYY-MM-DDTHH:mm:ssZ"),
        endTime: (0,_utils__WEBPACK_IMPORTED_MODULE_10__/* .formatDateTime */ .o0)(new Date().getTime() / 1000, "YYYY-MM-DDTHH:mm:ssZ")
    });
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        return _contents_account__WEBPACK_IMPORTED_MODULE_4__/* .account_power */ .Gu.columns(tr).map((item)=>{
            if (item.titleTip) {
                item.excelTitle = item.dataIndex === "sector_count_change" ? `${tr("raw_power")}/${tr("sector_power_count")}` : tr(item.title), item.title = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "flex items-center gap-x-1",
                    children: [
                        tr(item.title),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_tooltip__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                            context: tr(item.titleTip)
                        })
                    ]
                });
            } else {
                item.title = tr(item.title);
            }
            return {
                ...item
            };
        });
    }, [
        tr
    ]);
    //proApi
    const { data: powerData, loading } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_5__/* .proApi */ .g2.getPower, {
        group_id: active ? Number(active) : 0,
        start_date: date.startTime,
        end_date: date.endTime || date.startTime
    });
    const { data: groupsData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_5__/* .proApi */ .g2.getGroupsId, {
        group_id: active ? Number(active) : null
    });
    const groups = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        let newGroups = [
            {
                value: "-1",
                label: tr("all")
            }
        ];
        (groupsData?.group_list || []).forEach((group)=>{
            newGroups.push({
                ...group,
                value: String(group.group_id),
                label: tr(group?.group_name)
            });
        });
        return newGroups;
    }, [
        groupsData?.group_list,
        tr
    ]);
    const data = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        return powerData?.power_detail_list || [];
    }, [
        powerData
    ]);
    if (hashParams?.miner) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Detail__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
            miner: hashParams.miner,
            selectedKey: selectedKey
        });
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex justify-between items-center",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex  flex-col",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "w-full text-lg font-semibold font-PingFang ",
                                children: tr(selectedKey)
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "text-xs text_des",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: tr("last_time")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "ml-2",
                                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_10__/* .formatDateTime */ .o0)(powerData?.epoch_time)
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex gap-x-2.5",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_selects__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                value: String(active),
                                options: groups,
                                onChange: (v)=>{
                                    setActive(v);
                                // load(v);
                                }
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_account_DateTIme__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                defaultValue: [
                                    date.startTime,
                                    date.endTime
                                ],
                                onChange: (start, end)=>{
                                    setDate({
                                        startTime: start,
                                        endTime: end
                                    });
                                }
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_exportExcel__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                columns: columns,
                                data: data,
                                fileName: tr(selectedKey)
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "card_shadow border border_color rounded-xl p-4 mt-5",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_Table__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    data: data,
                    columns: columns,
                    loading: loading
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5707:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2881);
/* harmony import */ var _packages_breadcrumb__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8656);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3495);
/* harmony import */ var _packages_exportExcel__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6459);
/* harmony import */ var _packages_Table__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(430);
/* harmony import */ var _src_account_DateTIme__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7998);
/* harmony import */ var _contents_account__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7701);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8108);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8054);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _utils__WEBPACK_IMPORTED_MODULE_4__, _packages_exportExcel__WEBPACK_IMPORTED_MODULE_5__, _packages_Table__WEBPACK_IMPORTED_MODULE_6__, _contents_account__WEBPACK_IMPORTED_MODULE_8__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _utils__WEBPACK_IMPORTED_MODULE_4__, _packages_exportExcel__WEBPACK_IMPORTED_MODULE_5__, _packages_Table__WEBPACK_IMPORTED_MODULE_6__, _contents_account__WEBPACK_IMPORTED_MODULE_8__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 










/** @format */ /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ miner, selectedKey })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "account"
    });
    const routerItems = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        if (miner && typeof miner === "string") {
            return [
                {
                    title: tr("overview_reward"),
                    path: "/account#reward"
                },
                {
                    title: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: miner
                    }),
                    path: `/account#reward?miner=${miner}`
                }
            ];
        }
        return [];
    }, [
        miner
    ]);
    const [date, setDate] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({
        startTime: (0,_utils__WEBPACK_IMPORTED_MODULE_4__/* .formatDateTime */ .o0)((0,_utils__WEBPACK_IMPORTED_MODULE_4__/* .getCalcTime */ .pf)(6), "YYYY-MM-DDTHH:mm:ssZ"),
        endTime: (0,_utils__WEBPACK_IMPORTED_MODULE_4__/* .formatDateTime */ .o0)(new Date().getTime() / 1000, "YYYY-MM-DDTHH:mm:ssZ")
    });
    //proApi.getReward
    const { data: rewardDataDetail, loading } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_10__/* .proApi */ .g2.getReward, {
        miner_id: miner,
        start_date: date.startTime,
        end_date: date.endTime
    });
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        return _contents_account__WEBPACK_IMPORTED_MODULE_8__/* .account_reward */ .vw.columns(tr, "detail").map((item)=>{
            return {
                ...item,
                title: tr(item.title)
            };
        });
    }, [
        tr
    ]);
    const showData = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        const newData = rewardDataDetail?.reward_detail_list || [];
        return newData || [];
    }, [
        rewardDataDetail
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            routerItems && routerItems.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_breadcrumb__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                items: routerItems
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex justify-between items-center mt-10",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex  flex-col",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "w-full text-lg font-semibold font-PingFang ",
                                children: miner
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "text-xs text_des",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: tr("last_time")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "ml-2",
                                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_4__/* .formatDateTime */ .o0)(rewardDataDetail?.epoch_time, "YYYY/MM/DD HH:mm")
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex gap-x-2.5",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_account_DateTIme__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                showEnd: true,
                                defaultValue: [
                                    date.startTime,
                                    date.endTime
                                ],
                                onChange: (start, end)=>{
                                    setDate({
                                        startTime: start,
                                        endTime: end
                                    });
                                }
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_exportExcel__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                columns: columns,
                                data: showData,
                                fileName: tr(selectedKey) + miner ? String(miner) : ""
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "card_shadow border border_color rounded-xl p-4 mt-5 overflow-auto",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_Table__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    data: showData,
                    columns: columns,
                    loading: loading
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5208:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2881);
/* harmony import */ var _packages_Table__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(430);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _contents_account__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7701);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8054);
/* harmony import */ var _packages_selects__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(869);
/* harmony import */ var _packages_exportExcel__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6459);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8108);
/* harmony import */ var _src_account_DateTIme__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7998);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3495);
/* harmony import */ var _components_hooks_useHash__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8087);
/* harmony import */ var _Detail__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5707);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _packages_Table__WEBPACK_IMPORTED_MODULE_2__, _contents_account__WEBPACK_IMPORTED_MODULE_4__, _packages_exportExcel__WEBPACK_IMPORTED_MODULE_7__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__, _utils__WEBPACK_IMPORTED_MODULE_10__, _Detail__WEBPACK_IMPORTED_MODULE_12__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _packages_Table__WEBPACK_IMPORTED_MODULE_2__, _contents_account__WEBPACK_IMPORTED_MODULE_4__, _packages_exportExcel__WEBPACK_IMPORTED_MODULE_7__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__, _utils__WEBPACK_IMPORTED_MODULE_10__, _Detail__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 












/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ selectedKey })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "account"
    });
    const { hashParams } = (0,_components_hooks_useHash__WEBPACK_IMPORTED_MODULE_11__/* .useHash */ .H)();
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)("-1");
    const [date, setDate] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({
        startTime: (0,_utils__WEBPACK_IMPORTED_MODULE_10__/* .formatDateTime */ .o0)(new Date().getTime() / 1000, "YYYY-MM-DDTHH:mm:ssZ"),
        endTime: (0,_utils__WEBPACK_IMPORTED_MODULE_10__/* .formatDateTime */ .o0)(new Date().getTime() / 1000, "YYYY-MM-DDTHH:mm:ssZ")
    });
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        return _contents_account__WEBPACK_IMPORTED_MODULE_4__/* .account_reward */ .vw.columns(tr).map((item)=>{
            return {
                ...item,
                title: tr(item.title)
            };
        });
    }, [
        tr
    ]);
    //proApi.getReward
    const { data: rewardData, loading } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_5__/* .proApi */ .g2.getReward, {
        group_id: active ? Number(active) : 0,
        start_date: date.startTime,
        end_date: date.endTime
    });
    const data = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        return rewardData?.reward_detail_list || [];
    }, [
        rewardData
    ]);
    const { data: groupsData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_5__/* .proApi */ .g2.getGroupsId, {
        group_id: active ? Number(active) : null
    });
    const groups = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        let newGroups = [
            {
                value: "-1",
                label: tr("all")
            }
        ];
        (groupsData?.group_list || []).forEach((group)=>{
            newGroups.push({
                ...group,
                value: String(group.group_id),
                label: tr(group?.group_name)
            });
        });
        return newGroups;
    }, [
        groupsData?.group_list,
        tr
    ]);
    if (hashParams?.miner) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Detail__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
            miner: hashParams.miner,
            selectedKey: selectedKey
        });
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex justify-between items-center",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex  flex-col",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "w-full text-lg font-semibold font-PingFang ",
                                children: tr(selectedKey)
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "text-xs text_des",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: tr("last_time")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "ml-2",
                                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_10__/* .formatDateTime */ .o0)(rewardData?.epoch_time)
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex gap-x-2.5",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_selects__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                value: String(active),
                                options: groups,
                                onChange: (v)=>{
                                    setActive(v);
                                // load(v);
                                }
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_account_DateTIme__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                defaultValue: [
                                    date.startTime,
                                    date.endTime
                                ],
                                onChange: (start, end)=>{
                                    setDate({
                                        startTime: start,
                                        endTime: end
                                    });
                                }
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_exportExcel__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                columns: columns,
                                data: data,
                                fileName: tr(selectedKey)
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "card_shadow border border_color rounded-xl p-4 mt-5",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_Table__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    data: rewardData?.reward_detail_list || [],
                    columns: columns,
                    loading: loading
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2727:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/cssinjs");

/***/ }),

/***/ 7529:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons/lib/icons/LoadingOutlined");

/***/ }),

/***/ 6762:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons/lib/icons/LockOutlined");

/***/ }),

/***/ 2127:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons/lib/icons/UserOutlined");

/***/ }),

/***/ 3800:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/button");

/***/ }),

/***/ 8633:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/collapse");

/***/ }),

/***/ 2616:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/config-provider");

/***/ }),

/***/ 6190:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/form");

/***/ }),

/***/ 675:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/input");

/***/ }),

/***/ 4946:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/locale/en_US");

/***/ }),

/***/ 9353:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/locale/zh_CN");

/***/ }),

/***/ 274:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/menu");

/***/ }),

/***/ 7369:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/message");

/***/ }),

/***/ 6418:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/modal");

/***/ }),

/***/ 4528:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/pagination");

/***/ }),

/***/ 3526:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/select");

/***/ }),

/***/ 1030:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/skeleton");

/***/ }),

/***/ 4285:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/table");

/***/ }),

/***/ 9348:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/tooltip");

/***/ }),

/***/ 9003:
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ 8887:
/***/ ((module) => {

"use strict";
module.exports = require("copy-to-clipboard");

/***/ }),

/***/ 1635:
/***/ ((module) => {

"use strict";
module.exports = require("dayjs");

/***/ }),

/***/ 8109:
/***/ ((module) => {

"use strict";
module.exports = require("file-saver");

/***/ }),

/***/ 6517:
/***/ ((module) => {

"use strict";
module.exports = require("lodash");

/***/ }),

/***/ 6641:
/***/ ((module) => {

"use strict";
module.exports = require("next-seo");

/***/ }),

/***/ 3076:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module.js");

/***/ }),

/***/ 4140:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 9716:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 3100:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 6368:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 6724:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 5132:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 8743:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/html-context.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 9191:
/***/ ((module) => {

"use strict";
module.exports = require("react-beautiful-dnd");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 4612:
/***/ ((module) => {

"use strict";
module.exports = require("use-deep-compare-effect");

/***/ }),

/***/ 6302:
/***/ ((module) => {

"use strict";
module.exports = require("xlsx");

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 9766:
/***/ ((module) => {

"use strict";
module.exports = import("bignumber.js");;

/***/ }),

/***/ 2021:
/***/ ((module) => {

"use strict";
module.exports = import("i18next");;

/***/ }),

/***/ 7987:
/***/ ((module) => {

"use strict";
module.exports = import("react-i18next");;

/***/ }),

/***/ 4325:
/***/ ((module) => {

"use strict";
module.exports = import("web3");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8355,1163,430,8087,869], () => (__webpack_exec__(3292)));
module.exports = __webpack_exports__;

})();