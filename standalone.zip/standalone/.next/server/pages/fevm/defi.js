(() => {
var exports = {};
exports.id = 926;
exports.ids = [926];
exports.modules = {

/***/ 73772:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgDefiLogo = function SvgDefiLogo(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 202 97"
  }, props), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    stroke: "#1d6bfc"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    strokeWidth: 0.691,
    opacity: 0.08,
    transform: "rotate(-21 295.01 -416.722)"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("ellipse", {
    cx: 13.508,
    cy: 9.593,
    rx: 11.898,
    ry: 6.077,
    transform: "rotate(-16 13.508 9.593)"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M24.663 6.797c.226.056.424.14.571.254.29.222.522.664.656 1.157.252.93.158 1.921-.24 2.92-.397.996-1.1 2.001-2.058 2.953-1.838 1.827-4.618 3.46-7.909 4.46-3.293 1-6.47 1.173-8.945.655-1.293-.27-2.396-.73-3.235-1.355-.84-.625-1.418-1.416-1.671-2.35a4.05 4.05 0 0 1-.14-1.047l-.004-1.112.634.914c.875 1.263 2.618 2.052 4.806 2.337 2.227.29 4.92.05 7.697-.794 2.821-.856 5.256-2.192 7.007-3.717 1.722-1.5 2.789-3.179 2.846-4.76.006-.17.001-.342-.015-.515z"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    strokeWidth: 0.616,
    opacity: 0.05,
    transform: "rotate(-39 103.1 -220.178)"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("ellipse", {
    cx: 12.507,
    cy: 9.088,
    rx: 11.071,
    ry: 5.74,
    transform: "rotate(-16 12.507 9.088)"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M23.102 5.815c.259.207.485.448.679.72.245.343.428.722.54 1.131.235.852.147 1.76-.223 2.674-.37.913-1.026 1.833-1.917 2.704-1.712 1.674-4.302 3.17-7.367 4.085-3.066.915-6.025 1.075-8.33.6-1.203-.247-2.23-.667-3.01-1.239-.78-.572-1.319-1.295-1.554-2.15a3.65 3.65 0 0 1-.13-.957l-.004-.977.563.798c.819 1.16 2.448 1.886 4.493 2.147 2.078.266 4.59.046 7.183-.728 2.676-.799 4.98-2.052 6.62-3.48 1.606-1.4 2.582-2.965 2.577-4.429a3.62 3.62 0 0 0-.12-.899z"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    strokeWidth: 0.8,
    opacity: 0.1,
    transform: "rotate(59 -31.036 44.87)"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("ellipse", {
    cx: 18.66,
    cy: 13.132,
    rx: 16.534,
    ry: 8.358,
    transform: "rotate(-16 18.66 13.132)"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M34.314 8.828c.267.099.502.226.683.38.377.325.672.904.845 1.543.338 1.243.211 2.567-.322 3.9-.535 1.338-1.483 2.687-2.772 3.963-2.482 2.46-6.237 4.658-10.68 6.003-4.447 1.346-8.737 1.582-12.08.884-1.738-.363-3.223-.979-4.352-1.817-1.125-.834-1.9-1.889-2.239-3.136a5.386 5.386 0 0 1-.187-1.396c-.001-.443.049-.88.154-1.307.155.388.347.749.575 1.077 1.194 1.716 3.569 2.795 6.555 3.183 3.024.392 6.68.068 10.451-1.074 3.84-1.162 7.152-2.976 9.53-5.046 2.35-2.044 3.795-4.333 3.861-6.485.007-.222 0-.446-.022-.672z"
  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    opacity: 0.1
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#1d6bfc",
    stroke: "#fff",
    strokeWidth: 0.652,
    d: "m126.499 16.882 6.731 7.082c.17.18.338.361.502.546.056.064.104.134.16.199.298.345.585.7.862 1.064l.172.212c.016.021.029.045.045.067.34.463.66.942.964 1.434.022.037.049.07.071.107.187.305.364.616.536.93l.09.174c.118.223.237.446.35.673.048.1.092.204.14.305l.17.37c.14.31.273.625.4.943.039.096.08.19.116.287l.042.104c.148.391.285.79.413 1.193.022.067.04.137.06.205.098.317.194.635.28.96.013.05.023.103.036.154.06.232.109.467.163.702.057.255.117.51.168.77.045.239.083.482.123.724.032.2.074.397.102.6.01.075.017.153.027.229.017.129.03.26.046.39.042.356.076.715.104 1.078.01.129.021.257.03.386.029.474.049.951.054 1.434 0 .068-.002.137-.001.206.001.31.002.62-.007.934-.003.102-.012.207-.016.31a29.596 29.596 0 0 1-.103 1.577c-.017.193-.035.385-.056.579-.04.359-.087.72-.14 1.083-.023.17-.044.34-.071.51-.085.533-.18 1.068-.293 1.608l-.128-.135.128.135a34.561 34.561 0 0 1-.399 1.684c-.047.183-.103.366-.155.548a36.8 36.8 0 0 1-.325 1.116c-.017.056-.03.113-.049.169-.111.35-.231.697-.353 1.044-.018.052-.034.105-.053.157-.167.467-.345.93-.53 1.39-.055.137-.114.271-.17.407a37.755 37.755 0 0 1-.638 1.45c-.058.124-.112.251-.172.376-.062.13-.132.259-.196.39a42.362 42.362 0 0 1-.785 1.514c-.151.277-.306.551-.463.824-.071.124-.137.25-.21.374l-.202.328a45.848 45.848 0 0 1-.842 1.335c-.121.186-.244.371-.37.555-.063.094-.122.19-.186.281-.053.077-.113.149-.166.225a42.75 42.75 0 0 1-1.423 1.925l-.005.007-.027.031a43.135 43.135 0 0 1-1.411 1.686l-.182.218c-.057.064-.12.123-.176.187a43.336 43.336 0 0 1-1.478 1.572l-.017.018c-.025.026-.053.05-.078.075-.475.476-.964.937-1.46 1.39l-.203.194c-.068.061-.14.118-.209.179-.516.459-1.04.91-1.576 1.342-.017.014-.033.029-.06.05-.566.455-1.146.89-1.733 1.316-.072.052-.14.11-.212.161-.072.051-.146.096-.218.146a41.27 41.27 0 0 1-1.872 1.254l-.032.022c-.41.257-.824.504-1.24.746-.115.066-.231.128-.346.193-.258.145-.515.293-.775.432l-.18.093c-.206.11-.414.213-.622.319-.258.13-.516.261-.775.386-.213.102-.427.2-.641.297-.171.08-.34.163-.513.239-.074.032-.149.059-.222.091-.373.161-.748.313-1.124.462-.168.067-.335.137-.504.201a36.158 36.158 0 0 1-1.657.585c-.444.143-.89.275-1.336.401-.131.037-.263.071-.394.106-.34.091-.68.177-1.02.258-.136.031-.272.064-.408.094-.442.098-.886.19-1.33.27l-.05.01c-.461.082-.922.151-1.384.213a30.255 30.255 0 0 1-1.44.157c-.138.012-.275.025-.412.035-.465.034-.93.06-1.396.074-7.468.204-13.712-2.415-17.988-6.913l-6.73-7.083c4.275 4.5 10.518 4.75 17.987 4.546.465-.013.93-.04 1.395-.074.138-.01.275-.023.412-.035.346-.03.69-.065 1.035-.107.135-.017.27-.032.405-.05.463-.062.925-.13 1.385-.213l.044-.008a33.115 33.115 0 0 0 2.764-.624l.393-.105c.451-.128.903 2.106 1.35 1.961a36.108 36.108 0 0 0 1.643-.58c.17-.064.337-.134.506-.201.376-.149.75-.301 1.123-.462.245-.106.49-.217.733-.329.215-.098.43-.196.644-.298.259-.125.515-.255.772-.385.208-.106.417-.21.624-.32.32-.17.64-.347.957-.527.114-.064.229-.125.343-.191.427-.248.852-.504 1.272-.768.635-.398 1.258-.82 1.874-1.254l.428-.306c.587-.425 1.168-.861 1.735-1.317l.056-.047a42.933 42.933 0 0 0 1.992-1.718c.494-.452.982-.913 1.457-1.388l.097-.094c.507-.511.997-1.038 1.478-1.574.12-.133.238-.268.357-.402.483-.552.956-1.11 1.41-1.686l.034-.04a42.77 42.77 0 0 0 1.423-1.925c.118-.168.237-.335.352-.505a42.958 42.958 0 0 0 1.212-1.89 41.589 41.589 0 0 0 .874-1.526 40.38 40.38 0 0 0 .784-1.514 41.418 41.418 0 0 0 .586-1.239c.146-.324.286-.65.422-.978l.17-.406c.185-.461.363-.924.53-1.39.018-.053.035-.108.054-.16a34.544 34.544 0 0 0 .727-2.326c.05-.184.106-.366.154-.55.146-.557.302-1.626.42-2.19l.065.08c.076-.396.144-.79.206-1.18.028-.172.048-.34.073-.51.052-.364-1.04-1.274-1-1.633.02-.193.038-.386.056-.578a31.546 31.546 0 0 0 .125-2.826l.002-.2c-.006-.484-1.199-.962-1.228-1.436-.008-.129-.02-.256-.03-.384-.011-.156.185-.21.41-.25l.227-.038c.224-.039.416-.092.398-.245-.015-.13-.028-.259-.045-.387-.037-.28 1.088-.555 1.043-.832-.04-.24-.077-.483-.123-.721-.05-.26-.11-.516-.168-.772-.053-.234-.103-.47-.163-.7a23.778 23.778 0 0 0-.315-1.117c-.02-.067-.038-.136-.06-.203-.14-.44-.292-.872-.455-1.297l-.116-.286a22.772 22.772 0 0 0-1.062-2.294l-.088-.17a22.587 22.587 0 0 0-.608-1.04c-.304-.491-.624-.97-.963-1.433l-.218-.28a21.284 21.284 0 0 0-.86-1.063c-.219-.251-.434-.504-.663-.745z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#1d6bfc",
    stroke: "#fff",
    strokeWidth: 1.1,
    d: "M95.633 71.51c-16.55.453-27.083-12.956-23.526-29.95 3.556-16.995 19.854-31.138 36.404-31.591 16.55-.454 27.083 12.955 23.527 29.95-3.556 16.994-19.855 31.137-36.405 31.59z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#fff",
    d: "m100.452 41.773 5.989 2.328-.862 1.395-5.88-2.301c-.805 1.195-1.421 2.543-2.307 3.61-.943 1.269-1.886 2.537-2.91 3.678-1.354 1.488-3.222 2.315-5.38 2.107-1.255-.095-2.536-.516-3.318-1.458-.27-.28-.484-.762-.399-1.062.114-.4.474-.848.858-.968.246-.046.763.188 1.062.368.242.381.455.862.56 1.316.427.962 1.27 1.276 2.314.89 1.208-.56 2.066-1.528 2.706-2.55 1.335-2.242 2.643-4.385 3.87-6.654l.113-.4-5.552-2.221.644-1.449 5.77 2.274 1.644-2.917-5.96-2.427.673-1.549 6.206 2.381c.389-.547.64-1.021 1-1.468 1.057-1.669 2.113-3.338 3.876-4.618 1.763-1.281 3.574-1.908 5.835-1.245.982.24 1.878.782 2.333 1.644.081.127.242.38.186.58-.114.401-.256.902-.668 1.122-.522.193-1.039-.04-1.361-.548-.242-.381-.375-.735-.617-1.116-.427-.962-1.38-1.303-2.342-.79-.687.368-1.432.935-1.957 1.555-1.36 1.916-2.53 3.985-3.918 6l5.77 2.275-.862 1.395-5.553-2.22"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    stroke: "#fff",
    strokeWidth: 1.056,
    d: "M79.818 25.338c-20.083-1.762-34.579.842-36.247 7.592-2.464 9.975 24.01 25.224 59.13 34.062 35.12 8.837 65.59 7.915 68.053-2.059 1.762-7.132-11.271-16.961-31.683-25.215"
  }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgDefiLogo);

/***/ }),

/***/ 58101:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap": "defi_wrap__3dShc",
	"staked-top": "defi_staked-top__gZ_BF",
	"content": "defi_content__aYRpV",
	"title": "defi_title__g7yCQ",
	"value": "defi_value__Cvg8F",
	"staked-bottom": "defi_staked-bottom__Zhgjy"
};


/***/ }),

/***/ 50909:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   config: () => (/* binding */ config),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   getServerSideProps: () => (/* binding */ getServerSideProps),
/* harmony export */   getStaticPaths: () => (/* binding */ getStaticPaths),
/* harmony export */   getStaticProps: () => (/* binding */ getStaticProps),
/* harmony export */   reportWebVitals: () => (/* binding */ reportWebVitals),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   unstable_getServerProps: () => (/* binding */ unstable_getServerProps),
/* harmony export */   unstable_getServerSideProps: () => (/* binding */ unstable_getServerSideProps),
/* harmony export */   unstable_getStaticParams: () => (/* binding */ unstable_getStaticParams),
/* harmony export */   unstable_getStaticPaths: () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   unstable_getStaticProps: () => (/* binding */ unstable_getStaticProps)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(23185);
/* harmony import */ var next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(35244);
/* harmony import */ var next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57182);
/* harmony import */ var private_next_pages_document_tsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(13162);
/* harmony import */ var private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(44178);
/* harmony import */ var private_next_pages_fevm_defi_index_tsx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(87760);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__, private_next_pages_fevm_defi_index_tsx__WEBPACK_IMPORTED_MODULE_5__]);
([private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__, private_next_pages_fevm_defi_index_tsx__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// @ts-ignore this need to be imported from next/dist to be external



// Import the app and document modules.
// @ts-expect-error - replaced by webpack/turbopack loader

// @ts-expect-error - replaced by webpack/turbopack loader

// Import the userland code.
// @ts-expect-error - replaced by webpack/turbopack loader

const PagesRouteModule = next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__.PagesRouteModule;
// Re-export the component (should be the default export).
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_fevm_defi_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "default"));
// Re-export methods.
const getStaticProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_fevm_defi_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "getStaticProps");
const getStaticPaths = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_fevm_defi_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "getStaticPaths");
const getServerSideProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_fevm_defi_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "getServerSideProps");
const config = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_fevm_defi_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "config");
const reportWebVitals = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_fevm_defi_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "reportWebVitals");
// Re-export legacy methods.
const unstable_getStaticProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_fevm_defi_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticProps");
const unstable_getStaticPaths = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_fevm_defi_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticPaths");
const unstable_getStaticParams = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_fevm_defi_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticParams");
const unstable_getServerProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_fevm_defi_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getServerProps");
const unstable_getServerSideProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_fevm_defi_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getServerSideProps");
// Create and export the route module that will be consumed.
const routeModule = new PagesRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__/* .RouteKind */ .x.PAGES,
        page: "/fevm/defi",
        pathname: "/fevm/defi",
        // The following aren't used in production.
        bundlePath: "",
        filename: ""
    },
    components: {
        App: private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__["default"],
        Document: private_next_pages_document_tsx__WEBPACK_IMPORTED_MODULE_3__["default"]
    },
    userland: private_next_pages_fevm_defi_index_tsx__WEBPACK_IMPORTED_MODULE_5__
});

//# sourceMappingURL=pages.js.map
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 92964:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(25675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8054);
/** @format */ 



const ImageWithFallback = (props)=>{
    const { src, fallbackSrc = _contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__/* .fvmUrl */ .dE + `/images/default.png`, ...rest } = props;
    const [imgSrc, setImgSrc] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(src || fallbackSrc);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const showSrc = src || fallbackSrc;
        setImgSrc(showSrc);
    }, [
        src
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
        alt: "",
        ...rest,
        className: "rounded-full cursor-pointer",
        src: imgSrc,
        onError: ()=>{
            setImgSrc(fallbackSrc);
        }
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ImageWithFallback);


/***/ }),

/***/ 52218:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/** @format */ 
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ left })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
        className: "flex gap-x-px w-fit h-fit relative",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                className: `absolute mark h-full ${left ? "mark" : "bg-transparent"} right-0`,
                style: {
                    width: left
                }
            }),
            [
                1,
                2,
                3,
                4,
                5,
                6,
                7,
                8,
                9,
                10
            ].map((item)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                    className: "w-[5px] h-[12px] rounded-[1px] bg-primary"
                }, item);
            })
        ]
    });
});


/***/ }),

/***/ 87760:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(62881);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8054);
/* harmony import */ var _contents_fevm__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(82059);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(68108);
/* harmony import */ var _src_fevm_defi__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(49412);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(23495);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(29676);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(58101);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _packages_skeleton__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(88465);
/* harmony import */ var _assets_images_defiLogo_svg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(73772);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_fevm__WEBPACK_IMPORTED_MODULE_3__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_4__, _src_fevm_defi__WEBPACK_IMPORTED_MODULE_5__, _utils__WEBPACK_IMPORTED_MODULE_6__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_fevm__WEBPACK_IMPORTED_MODULE_3__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_4__, _src_fevm_defi__WEBPACK_IMPORTED_MODULE_5__, _utils__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    const { data: defiData, loading } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_2__/* .apiUrl */ .JW.fevm_defiSummary);
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "fevm"
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()("main_contain", (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().wrap)),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_device_detect__WEBPACK_IMPORTED_MODULE_7__/* .MobileView */ .$, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: _contents_fevm__WEBPACK_IMPORTED_MODULE_3__/* .defi_market */ .hw.filter((value)=>{
                            return value.dataIndex === "fevm_staked";
                        }).map((value, index)=>{
                            const data = defiData && defiData[value.dataIndex];
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: classnames__WEBPACK_IMPORTED_MODULE_8___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default()["staked-top"])),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().content),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().value),
                                                children: (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .get$Number */ .Uy)(data)
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().title),
                                                children: tr(value.title)
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_defiLogo_svg__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {})
                                ]
                            }, index);
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: classnames__WEBPACK_IMPORTED_MODULE_8___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default()["staked-bottom"])),
                        children: _contents_fevm__WEBPACK_IMPORTED_MODULE_3__/* .defi_market */ .hw.filter((value)=>{
                            return value.dataIndex !== "fevm_staked";
                        }).map((value, index)=>{
                            const data = defiData && defiData[value.dataIndex];
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: classnames__WEBPACK_IMPORTED_MODULE_8___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().content)),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().value),
                                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .get$Number */ .Uy)(data)
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_11___default().title),
                                        children: tr(value.title)
                                    })
                                ]
                            }, index);
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_device_detect__WEBPACK_IMPORTED_MODULE_7__/* .BrowserView */ .I, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                        className: "flex p-5 border border_color card_shadow rounded-xl h-[104px] items-center",
                        children: _contents_fevm__WEBPACK_IMPORTED_MODULE_3__/* .defi_market */ .hw.map((item)=>{
                            const { title, dataIndex, render } = item;
                            const value = defiData && defiData[dataIndex];
                            const showValue = render ? render(value, defiData) : value;
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: "flex-1 flex items-center justify-center border-r border_color last:border-0",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    className: "flex flex-col w-fit ",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "text-sm font-DIN mb-2.5 text_des",
                                            children: tr(title)
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "text-xl font-DINPro-Bold",
                                            children: loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_skeleton__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {}) : showValue
                                        })
                                    ]
                                })
                            }, item.dataIndex);
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mt-5",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "mx-2.5",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "text-lg font-DINPro-Bold ",
                                        children: [
                                            " ",
                                            tr("defi_overview")
                                        ]
                                    }),
                                    defiData?.updated_at && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text_des text-xs ml-2",
                                        children: tr("defi_list_time", {
                                            value: (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatDateTime */ .o0)(defiData?.updated_at)
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_fevm_defi__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_7__/* .MobileView */ .$, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_fevm_defi__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 52727:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/cssinjs");

/***/ }),

/***/ 77529:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons/lib/icons/LoadingOutlined");

/***/ }),

/***/ 86762:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons/lib/icons/LockOutlined");

/***/ }),

/***/ 62127:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons/lib/icons/UserOutlined");

/***/ }),

/***/ 92616:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/config-provider");

/***/ }),

/***/ 30675:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/input");

/***/ }),

/***/ 4946:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/locale/en_US");

/***/ }),

/***/ 79353:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/locale/zh_CN");

/***/ }),

/***/ 10274:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/menu");

/***/ }),

/***/ 17369:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/message");

/***/ }),

/***/ 14528:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/pagination");

/***/ }),

/***/ 71030:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/skeleton");

/***/ }),

/***/ 74285:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/table");

/***/ }),

/***/ 69348:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/tooltip");

/***/ }),

/***/ 59003:
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ 68887:
/***/ ((module) => {

"use strict";
module.exports = require("copy-to-clipboard");

/***/ }),

/***/ 1635:
/***/ ((module) => {

"use strict";
module.exports = require("dayjs");

/***/ }),

/***/ 46517:
/***/ ((module) => {

"use strict";
module.exports = require("lodash");

/***/ }),

/***/ 36211:
/***/ ((module) => {

"use strict";
module.exports = require("mobx");

/***/ }),

/***/ 22062:
/***/ ((module) => {

"use strict";
module.exports = require("mobx-react");

/***/ }),

/***/ 16641:
/***/ ((module) => {

"use strict";
module.exports = require("next-seo");

/***/ }),

/***/ 43076:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module.js");

/***/ }),

/***/ 94140:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 89716:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 33100:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 76368:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 53918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 45732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 56724:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 35132:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 18743:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/html-context.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 50744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 35843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 93431:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 11751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 71109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 28854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 93297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 87782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 82470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 40618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 71853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 16689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 66405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 94612:
/***/ ((module) => {

"use strict";
module.exports = require("use-deep-compare-effect");

/***/ }),

/***/ 99648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 49766:
/***/ ((module) => {

"use strict";
module.exports = import("bignumber.js");;

/***/ }),

/***/ 22021:
/***/ ((module) => {

"use strict";
module.exports = import("i18next");;

/***/ }),

/***/ 57987:
/***/ ((module) => {

"use strict";
module.exports = import("react-i18next");;

/***/ }),

/***/ 34325:
/***/ ((module) => {

"use strict";
module.exports = import("web3");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8355,1163,430,7103], () => (__webpack_exec__(50909)));
module.exports = __webpack_exports__;

})();