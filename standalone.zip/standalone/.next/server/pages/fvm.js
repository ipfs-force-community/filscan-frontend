(() => {
var exports = {};
exports.id = 7953;
exports.ids = [7953];
exports.modules = {

/***/ 4183:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _path;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgNetwork = function SvgNetwork(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 16 16"
  }, props), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M1 8.699h3.854a12.447 12.447 0 0 0 2.057 6.204C3.771 14.418 1.317 11.87 1 8.699zM1 7.3c.317-3.171 2.77-5.72 5.911-6.204a12.446 12.446 0 0 0-2.057 6.204zm14 0h-3.854A12.446 12.446 0 0 0 9.09 1.097c3.14.485 5.594 3.033 5.911 6.204zM15 8.7c-.317 3.171-2.77 5.72-5.911 6.204a12.447 12.447 0 0 0 2.057-6.204zm-8.737 0h3.474C9.617 10.643 8.995 13.45 8 15c-.995-1.55-1.616-4.357-1.737-6.301zm0-1.398C6.383 5.357 7.005 2.55 8 1c.995 1.55 1.616 4.357 1.737 6.301z"
  })));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgNetwork);

/***/ }),

/***/ 2117:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _path;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgTwitter = function SvgTwitter(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 16 16"
  }, props), _path || (_path = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M15 4.343a5.78 5.78 0 0 1-1.652.442 2.849 2.849 0 0 0 1.262-1.573 5.684 5.684 0 0 1-1.82.69A2.87 2.87 0 0 0 10.692 3a2.86 2.86 0 0 0-2.869 2.854c0 .22.027.441.07.654A8.169 8.169 0 0 1 1.98 3.522a2.85 2.85 0 0 0 .888 3.817 2.907 2.907 0 0 1-1.297-.363v.035c0 1.387.986 2.536 2.3 2.8-.24.062-.498.097-.755.097-.187 0-.364-.018-.542-.043a2.872 2.872 0 0 0 2.682 1.979 5.771 5.771 0 0 1-3.562 1.22A5.9 5.9 0 0 1 1 13.027a8.159 8.159 0 0 0 4.406 1.28c5.277 0 8.164-4.346 8.164-8.118 0-.124 0-.248-.009-.371A6.16 6.16 0 0 0 15 4.343z"
  })));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgTwitter);

/***/ }),

/***/ 3530:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap": "fvm_wrap__qH3YP",
	"twitter": "fvm_twitter__FP1t_",
	"network": "fvm_network__uuqhS",
	"select": "fvm_select__q1fj_",
	"content-wrap": "fvm_content-wrap__x7Bzo",
	"item-wrap": "fvm_item-wrap__Dc4cY",
	"right": "fvm_right__Fg_ZD",
	"text": "fvm_text__sYfRt",
	"popupWrap": "fvm_popupWrap__9bpzz"
};


/***/ }),

/***/ 2434:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   config: () => (/* binding */ config),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   getServerSideProps: () => (/* binding */ getServerSideProps),
/* harmony export */   getStaticPaths: () => (/* binding */ getStaticPaths),
/* harmony export */   getStaticProps: () => (/* binding */ getStaticProps),
/* harmony export */   reportWebVitals: () => (/* binding */ reportWebVitals),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   unstable_getServerProps: () => (/* binding */ unstable_getServerProps),
/* harmony export */   unstable_getServerSideProps: () => (/* binding */ unstable_getServerSideProps),
/* harmony export */   unstable_getStaticParams: () => (/* binding */ unstable_getStaticParams),
/* harmony export */   unstable_getStaticPaths: () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   unstable_getStaticProps: () => (/* binding */ unstable_getStaticProps)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3185);
/* harmony import */ var next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5244);
/* harmony import */ var next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7182);
/* harmony import */ var private_next_pages_document_tsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3162);
/* harmony import */ var private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4178);
/* harmony import */ var private_next_pages_fvm_index_tsx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8055);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__, private_next_pages_fvm_index_tsx__WEBPACK_IMPORTED_MODULE_5__]);
([private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__, private_next_pages_fvm_index_tsx__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// @ts-ignore this need to be imported from next/dist to be external



// Import the app and document modules.
// @ts-expect-error - replaced by webpack/turbopack loader

// @ts-expect-error - replaced by webpack/turbopack loader

// Import the userland code.
// @ts-expect-error - replaced by webpack/turbopack loader

const PagesRouteModule = next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__.PagesRouteModule;
// Re-export the component (should be the default export).
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_fvm_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "default"));
// Re-export methods.
const getStaticProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_fvm_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "getStaticProps");
const getStaticPaths = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_fvm_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "getStaticPaths");
const getServerSideProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_fvm_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "getServerSideProps");
const config = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_fvm_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "config");
const reportWebVitals = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_fvm_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "reportWebVitals");
// Re-export legacy methods.
const unstable_getStaticProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_fvm_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticProps");
const unstable_getStaticPaths = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_fvm_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticPaths");
const unstable_getStaticParams = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_fvm_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticParams");
const unstable_getServerProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_fvm_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getServerProps");
const unstable_getServerSideProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_fvm_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getServerSideProps");
// Create and export the route module that will be consumed.
const routeModule = new PagesRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__/* .RouteKind */ .x.PAGES,
        page: "/fvm",
        pathname: "/fvm",
        // The following aren't used in production.
        bundlePath: "",
        filename: ""
    },
    components: {
        App: private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__["default"],
        Document: private_next_pages_document_tsx__WEBPACK_IMPORTED_MODULE_3__["default"]
    },
    userland: private_next_pages_fvm_index_tsx__WEBPACK_IMPORTED_MODULE_5__
});

//# sourceMappingURL=pages.js.map
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2964:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8054);
/** @format */ 



const ImageWithFallback = (props)=>{
    const { src, fallbackSrc = _contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__/* .fvmUrl */ .dE + `/images/default.png`, ...rest } = props;
    const [imgSrc, setImgSrc] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(src || fallbackSrc);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const showSrc = src || fallbackSrc;
        setImgSrc(showSrc);
    }, [
        src
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
        alt: "",
        ...rest,
        className: "rounded-full ",
        src: imgSrc,
        onError: ()=>{
            setImgSrc(fallbackSrc);
        }
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ImageWithFallback);


/***/ }),

/***/ 8055:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2881);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8054);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8108);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _packages_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2964);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9676);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(3530);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var antd_lib_select__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3526);
/* harmony import */ var antd_lib_select__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(antd_lib_select__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1061);
/* harmony import */ var _assets_images_twitter_svg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2117);
/* harmony import */ var _assets_images_network_svg__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4183);
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(8804);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_3__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);














/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    const { theme } = (0,_store_FilscanStore__WEBPACK_IMPORTED_MODULE_12__/* .useFilscanStore */ .J)();
    const { isMobile } = (0,_components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "fvm"
    });
    const { data, loading } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_2__/* .apiUrl */ .JW.fvm_category);
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("all");
    const [content, setContent] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)([]);
    const fvmListOpt = (0,react__WEBPACK_IMPORTED_MODULE_4__.useMemo)(()=>{
        let num = 0;
        let newData = [];
        data?.forEach((v)=>{
            num = num + v.num;
            newData.push({
                ...v,
                label: isMobile ? `${v.label}(${v.num})` : v.label,
                value: v.label
            });
        });
        return [
            {
                label: isMobile ? `All(${num})` : "All",
                value: "all",
                num
            },
            ...newData
        ];
    }, [
        data
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        load();
    }, []);
    const load = (act)=>{
        const category = act || active;
        axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_2__/* .apiUrl */ .JW.fvm_items, {
            category
        }).then((result)=>{
            setContent(result || []);
        });
    };
    const handleClick = (item)=>{
        setActive(item.value);
        load(item.value);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: classnames__WEBPACK_IMPORTED_MODULE_7___default()("main_contain", (_index_module_scss__WEBPACK_IMPORTED_MODULE_13___default().wrap)),
            children: [
                isMobile ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_select__WEBPACK_IMPORTED_MODULE_8___default()), {
                    popupClassName: (_index_module_scss__WEBPACK_IMPORTED_MODULE_13___default().popupWrap),
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_13___default().select),
                    onChange: (e)=>{
                        setActive(e);
                        load(e);
                    },
                    defaultValue: active,
                    options: fvmListOpt
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_6__/* .BrowserView */ .I, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                        className: "text-lg font-DINPro-Medium mb-4",
                        children: "Explore FVM on Filscan"
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex gap-x-5",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_6__/* .BrowserView */ .I, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                className: "w-[210px] border border_color rounded-lg card_shadow px-4 py-5",
                                children: fvmListOpt.map((item)=>{
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: `flex items-center justify-between px-5 h-10 text-sm cursor-pointer rounded-md ${active === item.value ? "bg-bg_hover text-primary" : "text_des"}`,
                                        onClick: ()=>{
                                            handleClick(item);
                                        },
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: tr(item.label)
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: item.num
                                            })
                                        ]
                                    }, item.label);
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex-1",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                className: classnames__WEBPACK_IMPORTED_MODULE_7___default()("flex flex-wrap gap-4", (_index_module_scss__WEBPACK_IMPORTED_MODULE_13___default()["content-wrap"])),
                                children: content?.map((item, index)=>{
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: classnames__WEBPACK_IMPORTED_MODULE_7___default()("flex justify-between items-center w-[220px] m-h-[68px] p-4 border border_color card_shadow rounded-[12px] !overflow-hidden", (_index_module_scss__WEBPACK_IMPORTED_MODULE_13___default()["item-wrap"])),
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: classnames__WEBPACK_IMPORTED_MODULE_7___default()("flex items-center gap-x-1", (_index_module_scss__WEBPACK_IMPORTED_MODULE_13___default().right)),
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_image__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                                        src: item.logo,
                                                        alt: "",
                                                        width: "36",
                                                        height: "36"
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                        className: classnames__WEBPACK_IMPORTED_MODULE_7___default()("flex flex-col ", (_index_module_scss__WEBPACK_IMPORTED_MODULE_13___default().text)),
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                className: "font-medium",
                                                                children: item?.name || ""
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                                className: "text-xs text_des",
                                                                children: item?.detail || ""
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "flex gap-x-2",
                                                children: [
                                                    item.twitter && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        onClick: ()=>{
                                                            if (item.twitter) {
                                                                window.open(item.twitter);
                                                            }
                                                        },
                                                        className: classnames__WEBPACK_IMPORTED_MODULE_7___default()("border border_color rounded-[5px] p-[7px] box-border cursor-pointer  hover:bg-primary", (_index_module_scss__WEBPACK_IMPORTED_MODULE_13___default().twitter)),
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_twitter_svg__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {})
                                                    }),
                                                    item.main_site && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        onClick: ()=>{
                                                            if (item.main_site) {
                                                                window.open(item.main_site);
                                                            }
                                                        },
                                                        className: classnames__WEBPACK_IMPORTED_MODULE_7___default()("border border_color rounded-[5px] p-[7px] cursor-pointer hover:bg-primary", (_index_module_scss__WEBPACK_IMPORTED_MODULE_13___default().network)),
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_network_svg__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {})
                                                    })
                                                ]
                                            })
                                        ]
                                    }, index);
                                })
                            })
                        })
                    ]
                })
            ]
        })
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2727:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/cssinjs");

/***/ }),

/***/ 7529:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons/lib/icons/LoadingOutlined");

/***/ }),

/***/ 2616:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/config-provider");

/***/ }),

/***/ 675:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/input");

/***/ }),

/***/ 4946:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/locale/en_US");

/***/ }),

/***/ 9353:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/locale/zh_CN");

/***/ }),

/***/ 274:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/menu");

/***/ }),

/***/ 7369:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/message");

/***/ }),

/***/ 3526:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/select");

/***/ }),

/***/ 9003:
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ 8887:
/***/ ((module) => {

"use strict";
module.exports = require("copy-to-clipboard");

/***/ }),

/***/ 1635:
/***/ ((module) => {

"use strict";
module.exports = require("dayjs");

/***/ }),

/***/ 6517:
/***/ ((module) => {

"use strict";
module.exports = require("lodash");

/***/ }),

/***/ 6641:
/***/ ((module) => {

"use strict";
module.exports = require("next-seo");

/***/ }),

/***/ 3076:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module.js");

/***/ }),

/***/ 4140:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 9716:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 3100:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 6368:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 6724:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 5132:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 8743:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/html-context.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 4612:
/***/ ((module) => {

"use strict";
module.exports = require("use-deep-compare-effect");

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 9766:
/***/ ((module) => {

"use strict";
module.exports = import("bignumber.js");;

/***/ }),

/***/ 2021:
/***/ ((module) => {

"use strict";
module.exports = import("i18next");;

/***/ }),

/***/ 7987:
/***/ ((module) => {

"use strict";
module.exports = import("react-i18next");;

/***/ }),

/***/ 4325:
/***/ ((module) => {

"use strict";
module.exports = import("web3");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8355,1163], () => (__webpack_exec__(2434)));
module.exports = __webpack_exports__;

})();