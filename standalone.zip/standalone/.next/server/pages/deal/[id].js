(() => {
var exports = {};
exports.id = 5588;
exports.ids = [5588];
exports.modules = {

/***/ 3450:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgCloud = function SvgCloud(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    width: "1em",
    height: "1em",
    viewBox: "0 0 30 30"
  }, props), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    d: "M0 0h30v30H0z"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#000",
    fillRule: "nonzero",
    d: "M15 2.143a9.545 9.545 0 0 1 9.535 10.007 8.182 8.182 0 0 1-2.716 15.902H8.181A8.182 8.182 0 0 1 5.466 12.15 9.545 9.545 0 0 1 15 2.143zm0 2.727a6.818 6.818 0 0 0-6.81 7.15l.096 2.029-1.915.674a5.455 5.455 0 0 0 1.811 10.602h13.636a5.455 5.455 0 1 0-5.176-7.18c-.182.47-.856.997-1.722.59-.866-.407-1.01-.876-.866-1.453a8.186 8.186 0 0 1 7.764-5.594A6.818 6.818 0 0 0 15 4.87z"
  }))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgCloud);

/***/ }),

/***/ 66460:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _defs, _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgDealClient = function SvgDealClient(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "1em",
    height: "1em",
    viewBox: "0 0 90 90"
  }, props), _defs || (_defs = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("defs", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("linearGradient", {
    id: "dealClient_svg__d",
    x1: "28.377%",
    x2: "20.216%",
    y1: "8.655%",
    y2: "85.659%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 0,
    stopColor: "#e9f6ff"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 1,
    stopColor: "#145cff"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("linearGradient", {
    id: "dealClient_svg__e",
    x1: "37.781%",
    x2: "32.532%",
    y1: "20.421%",
    y2: "91.783%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 0,
    stopColor: "#e1f3ff"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 1,
    stopColor: "#145cff"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("linearGradient", {
    id: "dealClient_svg__h",
    x1: "91.933%",
    x2: "40.615%",
    y1: "80.707%",
    y2: "41.954%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 0,
    stopColor: "#398bef"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 1,
    stopColor: "#1c6afd"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("linearGradient", {
    id: "dealClient_svg__k",
    x1: "65.396%",
    x2: "58.253%",
    y1: "83.992%",
    y2: "7.27%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 0,
    stopColor: "#7caaff",
    stopOpacity: 0.4
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 1,
    stopColor: "#edfaff"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("linearGradient", {
    id: "dealClient_svg__m",
    x1: "34.113%",
    x2: "6.44%",
    y1: "6.507%",
    y2: "79.971%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 0,
    stopColor: "#e0f5ff"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 1,
    stopColor: "#8dc6ff"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("filter", {
    id: "dealClient_svg__f",
    width: "310.3%",
    height: "207.2%",
    x: "-105.2%",
    y: "-53.6%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("feGaussianBlur", {
    in: "SourceGraphic",
    stdDeviation: 15.901
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("filter", {
    id: "dealClient_svg__i",
    width: "223%",
    height: "223%",
    x: "-61.5%",
    y: "-61.5%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("feGaussianBlur", {
    in: "SourceGraphic",
    stdDeviation: 9.223
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("filter", {
    id: "dealClient_svg__l",
    width: "185.7%",
    height: "180%",
    x: "-42.9%",
    y: "-40%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("feGaussianBlur", {
    in: "SourceGraphic",
    stdDeviation: 5
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("filter", {
    id: "dealClient_svg__n",
    width: "200%",
    height: "192.3%",
    x: "-50%",
    y: "-46.1%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("feGaussianBlur", {
    in: "SourceGraphic",
    stdDeviation: 4.444
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("filter", {
    id: "dealClient_svg__p",
    width: "170.8%",
    height: "168.4%",
    x: "-35.4%",
    y: "-34.2%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("feGaussianBlur", {
    in: "SourceGraphic",
    stdDeviation: 4.444
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("mask", {
    id: "dealClient_svg__g",
    fill: "#fff"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("use", {
    xlinkHref: "#dealClient_svg__a",
    fillRule: "evenodd"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("mask", {
    id: "dealClient_svg__j",
    fill: "#fff"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("use", {
    xlinkHref: "#dealClient_svg__b",
    fillRule: "evenodd"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("mask", {
    id: "dealClient_svg__o",
    fill: "#fff"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("use", {
    xlinkHref: "#dealClient_svg__c",
    fillRule: "evenodd"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("circle", {
    id: "dealClient_svg__a",
    cx: 45,
    cy: 45,
    r: 45
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("circle", {
    id: "dealClient_svg__b",
    cx: 37.969,
    cy: 37.969,
    r: 37.969
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", {
    id: "dealClient_svg__c",
    width: 40,
    height: 40,
    rx: 10
  }))), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("circle", {
    cx: 45,
    cy: 45,
    r: 45,
    fill: "url(#dealClient_svg__d)"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("use", {
    xlinkHref: "#dealClient_svg__a",
    fill: "url(#dealClient_svg__e)"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#00dbff",
    d: "M61.652 0c7.853 21.905 13.798 39.418 17.836 52.536 6.056 19.678-35.375 26.172-24.093 35.072 11.282 8.9 43.406-26.718 43.406-56.89C98.801 10.603 86.418.364 61.652 0z",
    filter: "url(#dealClient_svg__f)",
    mask: "url(#dealClient_svg__g)",
    opacity: 0.6
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    transform: "translate(6.71 6.576)"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("use", {
    xlinkHref: "#dealClient_svg__b",
    fill: "url(#dealClient_svg__h)"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("circle", {
    cx: 61.875,
    cy: 22.5,
    r: 22.5,
    fill: "#00c7fe",
    filter: "url(#dealClient_svg__i)",
    mask: "url(#dealClient_svg__j)",
    opacity: 0.9
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("circle", {
    cx: 37.969,
    cy: 37.969,
    r: 37.031,
    stroke: "url(#dealClient_svg__k)",
    strokeWidth: 1.875,
    mask: "url(#dealClient_svg__j)"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#0948c0",
    d: "M17.5 35h35v37.5h-35z",
    filter: "url(#dealClient_svg__l)",
    opacity: 0.48
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    transform: "translate(25 25)"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("use", {
    xlinkHref: "#dealClient_svg__c",
    fill: "url(#dealClient_svg__m)"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#a8eaff",
    d: "M31.111 46.667c7.364 0 13.333-5.97 13.333-13.334 0-6.9-6.629-18.4-9.827-14.924-.215.234-1.498 3.445-1.65 3.813-2.421 5.846-15.19 3.748-15.19 11.111 0 7.364 5.97 13.334 13.334 13.334z",
    filter: "url(#dealClient_svg__n)",
    mask: "url(#dealClient_svg__o)",
    opacity: 0.39
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#2878f8",
    fillOpacity: 0.496,
    d: "M5.556 51.111c9.204 0 30-3.333 16.666-16.667C8.89 21.111 11.567 12.13 2.362 12.13s-13.473 13.11-13.473 22.314c0 9.205 7.462 16.667 16.667 16.667z",
    filter: "url(#dealClient_svg__p)",
    mask: "url(#dealClient_svg__o)",
    opacity: 0.4
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    stroke: "#1c6afd",
    strokeWidth: 2.667
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("circle", {
    cx: 20,
    cy: 15.556,
    r: 5.333,
    mask: "url(#dealClient_svg__o)"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    strokeLinecap: "round",
    d: "m8.889 28.889.52-.623a4.444 4.444 0 0 1 3.413-1.6h14.356c1.319 0 2.57.587 3.414 1.6l.52.623",
    mask: "url(#dealClient_svg__o)"
  }))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgDealClient);

/***/ }),

/***/ 83184:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var _defs, _g;
function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

var SvgDealMiner = function SvgDealMiner(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", _extends({
    xmlns: "http://www.w3.org/2000/svg",
    xmlnsXlink: "http://www.w3.org/1999/xlink",
    width: "1em",
    height: "1em",
    viewBox: "0 0 90 90"
  }, props), _defs || (_defs = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("defs", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("linearGradient", {
    id: "dealMiner_svg__d",
    x1: "28.377%",
    x2: "20.216%",
    y1: "8.655%",
    y2: "85.659%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 0,
    stopColor: "#e9f6ff"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 1,
    stopColor: "#145cff"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("linearGradient", {
    id: "dealMiner_svg__e",
    x1: "32.529%",
    x2: "32.529%",
    y1: "22.298%",
    y2: "90.916%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 0,
    stopColor: "#e8f6ff"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 1,
    stopColor: "#145cff"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("linearGradient", {
    id: "dealMiner_svg__h",
    x1: "91.933%",
    x2: "40.615%",
    y1: "80.707%",
    y2: "41.954%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 0,
    stopColor: "#398bef"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 1,
    stopColor: "#1c6afd"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("linearGradient", {
    id: "dealMiner_svg__k",
    x1: "38.295%",
    x2: "45.426%",
    y1: "91.949%",
    y2: "0%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 0,
    stopColor: "#7caaff",
    stopOpacity: 0.4
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 1,
    stopColor: "#e9f9ff"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("linearGradient", {
    id: "dealMiner_svg__m",
    x1: "34.113%",
    x2: "6.44%",
    y1: "6.507%",
    y2: "79.971%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 0,
    stopColor: "#e0f5ff"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("stop", {
    offset: 1,
    stopColor: "#8dc6ff"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("filter", {
    id: "dealMiner_svg__f",
    width: "310.3%",
    height: "207.2%",
    x: "-105.2%",
    y: "-53.6%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("feGaussianBlur", {
    in: "SourceGraphic",
    stdDeviation: 15.901
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("filter", {
    id: "dealMiner_svg__i",
    width: "223%",
    height: "223%",
    x: "-61.5%",
    y: "-61.5%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("feGaussianBlur", {
    in: "SourceGraphic",
    stdDeviation: 9.223
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("filter", {
    id: "dealMiner_svg__l",
    width: "185.7%",
    height: "180%",
    x: "-42.9%",
    y: "-40%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("feGaussianBlur", {
    in: "SourceGraphic",
    stdDeviation: 5
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("filter", {
    id: "dealMiner_svg__n",
    width: "200%",
    height: "192.3%",
    x: "-50%",
    y: "-46.1%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("feGaussianBlur", {
    in: "SourceGraphic",
    stdDeviation: 4.444
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("filter", {
    id: "dealMiner_svg__p",
    width: "170.8%",
    height: "168.4%",
    x: "-35.4%",
    y: "-34.2%"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("feGaussianBlur", {
    in: "SourceGraphic",
    stdDeviation: 4.444
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("mask", {
    id: "dealMiner_svg__g",
    fill: "#fff"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("use", {
    xlinkHref: "#dealMiner_svg__a",
    fillRule: "evenodd"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("mask", {
    id: "dealMiner_svg__j",
    fill: "#fff"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("use", {
    xlinkHref: "#dealMiner_svg__b",
    fillRule: "evenodd"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("mask", {
    id: "dealMiner_svg__o",
    fill: "#fff"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("use", {
    xlinkHref: "#dealMiner_svg__c",
    fillRule: "evenodd"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("circle", {
    id: "dealMiner_svg__a",
    cx: 45,
    cy: 45,
    r: 45
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("circle", {
    id: "dealMiner_svg__b",
    cx: 37.969,
    cy: 37.969,
    r: 37.969
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", {
    id: "dealMiner_svg__c",
    width: 40,
    height: 40,
    rx: 10
  }))), _g || (_g = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    fill: "none",
    fillRule: "evenodd"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("circle", {
    cx: 45,
    cy: 45,
    r: 45,
    fill: "url(#dealMiner_svg__d)"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("use", {
    xlinkHref: "#dealMiner_svg__a",
    fill: "url(#dealMiner_svg__e)"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#00dbff",
    d: "M61.652 0c7.853 21.905 13.798 39.418 17.836 52.536 6.056 19.678-35.375 26.172-24.093 35.072 11.282 8.9 43.406-26.718 43.406-56.89C98.801 10.603 86.418.364 61.652 0z",
    filter: "url(#dealMiner_svg__f)",
    mask: "url(#dealMiner_svg__g)",
    opacity: 0.6
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    transform: "translate(6.71 6.576)"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("use", {
    xlinkHref: "#dealMiner_svg__b",
    fill: "url(#dealMiner_svg__h)"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("circle", {
    cx: 61.875,
    cy: 22.5,
    r: 22.5,
    fill: "#00c7fe",
    filter: "url(#dealMiner_svg__i)",
    mask: "url(#dealMiner_svg__j)",
    opacity: 0.9
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("circle", {
    cx: 37.969,
    cy: 37.969,
    r: 37.031,
    stroke: "url(#dealMiner_svg__k)",
    strokeWidth: 1.875,
    mask: "url(#dealMiner_svg__j)"
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#0948c0",
    d: "M17.5 35h35v37.5h-35z",
    filter: "url(#dealMiner_svg__l)",
    opacity: 0.48
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("g", {
    transform: "translate(25 25)"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("use", {
    xlinkHref: "#dealMiner_svg__c",
    fill: "url(#dealMiner_svg__m)"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#a8eaff",
    d: "M31.111 46.667c7.364 0 13.333-5.97 13.333-13.334 0-6.9-6.629-18.4-9.827-14.924-.215.234-1.498 3.445-1.65 3.813-2.421 5.846-15.19 3.748-15.19 11.111 0 7.364 5.97 13.334 13.334 13.334z",
    filter: "url(#dealMiner_svg__n)",
    mask: "url(#dealMiner_svg__o)",
    opacity: 0.39
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#2878f8",
    fillOpacity: 0.496,
    d: "M5.556 51.111c9.204 0 30-3.333 16.666-16.667C8.89 21.111 11.567 12.13 2.362 12.13s-13.473 13.11-13.473 22.314c0 9.205 7.462 16.667 16.667 16.667z",
    filter: "url(#dealMiner_svg__p)",
    mask: "url(#dealMiner_svg__o)",
    opacity: 0.4
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", {
    width: 10,
    height: 10,
    x: 7.5,
    y: 7.5,
    stroke: "#1c6afd",
    strokeWidth: 2.5,
    mask: "url(#dealMiner_svg__o)",
    rx: 2.5
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", {
    fill: "#1c6afd",
    fillRule: "nonzero",
    d: "M27.5 8.75a3.75 3.75 0 0 1 3.733 3.389l.017.361v3.75a1.25 1.25 0 0 1-2.5 0V12.5a1.25 1.25 0 0 0-1.025-1.23l-.225-.02h-3.75a1.25 1.25 0 0 1 0-2.5zm-13.75 22.5a3.75 3.75 0 0 1-3.733-3.389L10 27.5v-3.75a1.25 1.25 0 0 1 2.5 0v3.75a1.25 1.25 0 0 0 1.025 1.23l.225.02h2.5a1.25 1.25 0 0 1 0 2.5z",
    mask: "url(#dealMiner_svg__o)"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("rect", {
    width: 10,
    height: 10,
    x: 22.5,
    y: 22.5,
    stroke: "#1c6afd",
    strokeWidth: 2.5,
    mask: "url(#dealMiner_svg__o)",
    rx: 2.5
  })))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgDealMiner);

/***/ }),

/***/ 21289:
/***/ ((module) => {

// Exports
module.exports = {
	"deal": "deal_deal__YovH8",
	"line": "deal_line__Mntm_",
	"title": "deal_title__9HVvV",
	"card": "deal_card__Y8mvh",
	"right": "deal_right__YzEIx",
	"name": "deal_name__7onkr",
	"space": "deal_space__wQGA8",
	"time": "deal_time__g7Vyb",
	"cash": "deal_cash__bZJ5Y"
};


/***/ }),

/***/ 55286:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   config: () => (/* binding */ config),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   getServerSideProps: () => (/* binding */ getServerSideProps),
/* harmony export */   getStaticPaths: () => (/* binding */ getStaticPaths),
/* harmony export */   getStaticProps: () => (/* binding */ getStaticProps),
/* harmony export */   reportWebVitals: () => (/* binding */ reportWebVitals),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   unstable_getServerProps: () => (/* binding */ unstable_getServerProps),
/* harmony export */   unstable_getServerSideProps: () => (/* binding */ unstable_getServerSideProps),
/* harmony export */   unstable_getStaticParams: () => (/* binding */ unstable_getStaticParams),
/* harmony export */   unstable_getStaticPaths: () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   unstable_getStaticProps: () => (/* binding */ unstable_getStaticProps)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(23185);
/* harmony import */ var next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(35244);
/* harmony import */ var next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57182);
/* harmony import */ var private_next_pages_document_tsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(13162);
/* harmony import */ var private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(44178);
/* harmony import */ var private_next_pages_deal_id_tsx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(70094);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__, private_next_pages_deal_id_tsx__WEBPACK_IMPORTED_MODULE_5__]);
([private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__, private_next_pages_deal_id_tsx__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// @ts-ignore this need to be imported from next/dist to be external



// Import the app and document modules.
// @ts-expect-error - replaced by webpack/turbopack loader

// @ts-expect-error - replaced by webpack/turbopack loader

// Import the userland code.
// @ts-expect-error - replaced by webpack/turbopack loader

const PagesRouteModule = next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__.PagesRouteModule;
// Re-export the component (should be the default export).
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_deal_id_tsx__WEBPACK_IMPORTED_MODULE_5__, "default"));
// Re-export methods.
const getStaticProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_deal_id_tsx__WEBPACK_IMPORTED_MODULE_5__, "getStaticProps");
const getStaticPaths = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_deal_id_tsx__WEBPACK_IMPORTED_MODULE_5__, "getStaticPaths");
const getServerSideProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_deal_id_tsx__WEBPACK_IMPORTED_MODULE_5__, "getServerSideProps");
const config = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_deal_id_tsx__WEBPACK_IMPORTED_MODULE_5__, "config");
const reportWebVitals = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_deal_id_tsx__WEBPACK_IMPORTED_MODULE_5__, "reportWebVitals");
// Re-export legacy methods.
const unstable_getStaticProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_deal_id_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticProps");
const unstable_getStaticPaths = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_deal_id_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticPaths");
const unstable_getStaticParams = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_deal_id_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticParams");
const unstable_getServerProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_deal_id_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getServerProps");
const unstable_getServerSideProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_deal_id_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getServerSideProps");
// Create and export the route module that will be consumed.
const routeModule = new PagesRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__/* .RouteKind */ .x.PAGES,
        page: "/deal/[id]",
        pathname: "/deal/[id]",
        // The following aren't used in production.
        bundlePath: "",
        filename: ""
    },
    components: {
        App: private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__["default"],
        Document: private_next_pages_document_tsx__WEBPACK_IMPORTED_MODULE_3__["default"]
    },
    userland: private_next_pages_deal_id_tsx__WEBPACK_IMPORTED_MODULE_5__
});

//# sourceMappingURL=pages.js.map
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 92964:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(25675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8054);
/** @format */ 



const ImageWithFallback = (props)=>{
    const { src, fallbackSrc = _contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__/* .fvmUrl */ .dE + `/images/default.png`, ...rest } = props;
    const [imgSrc, setImgSrc] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(src || fallbackSrc);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const showSrc = src || fallbackSrc;
        setImgSrc(showSrc);
    }, [
        src
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
        alt: "",
        ...rest,
        className: "rounded-full cursor-pointer",
        src: imgSrc,
        onError: ()=>{
            setImgSrc(fallbackSrc);
        }
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ImageWithFallback);


/***/ }),

/***/ 70094:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(62881);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8054);
/* harmony import */ var _contents_detail__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(78817);
/* harmony import */ var _packages_content__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(55586);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(68108);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(23495);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _assets_images_dealMiner_svg__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(83184);
/* harmony import */ var _assets_images_dealClient_svg__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(66460);
/* harmony import */ var _assets_images_cloud_svg__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3450);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(29676);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(21289);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _components_copy__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(25174);
/* harmony import */ var _assets_images_icon_copy_svg__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(45903);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_detail__WEBPACK_IMPORTED_MODULE_3__, _packages_content__WEBPACK_IMPORTED_MODULE_4__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_5__, _utils__WEBPACK_IMPORTED_MODULE_6__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_detail__WEBPACK_IMPORTED_MODULE_3__, _packages_content__WEBPACK_IMPORTED_MODULE_4__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_5__, _utils__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);

















/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_7__.useRouter)();
    const { id } = router.query;
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "detail"
    });
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)({});
    (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(()=>{
        if (id) {
            load();
        }
    }, [
        id
    ]);
    const load = async ()=>{
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_2__/* .apiUrl */ .JW.detail_deal, {
            deal_id: Number(id)
        });
        setData(result?.deal_details);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_13___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().deal), "main_contain"),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "font-PingFang font-semibold text-lg",
                children: tr("deal_details")
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mt-4 border rounded-xl p-5 card_shadow border_color text_xs",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_content__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        contents: _contents_detail__WEBPACK_IMPORTED_MODULE_3__/* .deal_list */ .xy.list,
                        ns: "detail",
                        data: data
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_12__/* .BrowserView */ .I, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex border-t border_color text_des pt-5 mt-2.5",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "min-w-[120px] ",
                                    children: tr("deal_hosting")
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex gap-x-5 ml-4",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex items-center justify-center gap-y-2 flex-col py-2.5 w-[114px] h-[114px] rounded-[5px] border border-color ",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: tr(_contents_detail__WEBPACK_IMPORTED_MODULE_3__/* .deal_list */ .xy.content.left_title)
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_dealClient_svg__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                                    width: 36,
                                                    height: 36
                                                }),
                                                data?.client_id && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    className: "flex gap-x-1 items-center",
                                                    children: (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .get_account_type */ .$B)(data.client_id)
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex items-center justify-center flex-col gap-y-4 py-2.5 w-[383px] h-[114px] rounded-[5px] border border-color ",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    className: "flex items-center gap-x-1 text_color font-DINPro-Medium",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_cloud_svg__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                                            width: 14,
                                                            height: 14
                                                        }),
                                                        data?.piece_size && (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .unitConversion */ .dN)(data.piece_size)
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    children: [
                                                        (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatDateTime */ .o0)(data?.service_start_time),
                                                        tr(_contents_detail__WEBPACK_IMPORTED_MODULE_3__/* .deal_list */ .xy.content.time),
                                                        (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatDateTime */ .o0)(data?.end_time)
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    children: [
                                                        tr(_contents_detail__WEBPACK_IMPORTED_MODULE_3__/* .deal_list */ .xy.content?.cash),
                                                        ":",
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                            className: "text_color font-DINPro-Medium",
                                                            children: [
                                                                " ",
                                                                data?.storage_price_per_epoch && (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatFilNum */ .Nm)(data?.storage_price_per_epoch)
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex items-center justify-center gap-y-2 flex-col py-2.5 w-[114px] h-[114px] rounded-[5px] border border-color ",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: tr(_contents_detail__WEBPACK_IMPORTED_MODULE_3__/* .deal_list */ .xy.content.right_title)
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_dealMiner_svg__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                    width: 36,
                                                    height: 36
                                                }),
                                                data?.provider_id && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                    className: "flex gap-x-1 items-center",
                                                    children: [
                                                        " ",
                                                        (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .get_account_type */ .$B)(data.provider_id)
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_device_detect__WEBPACK_IMPORTED_MODULE_12__/* .MobileView */ .$, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().line)
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().title),
                                children: tr("deal_hosting")
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().card),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().left),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_dealClient_svg__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                            width: 45,
                                            height: 45
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().right),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().name),
                                                children: tr(_contents_detail__WEBPACK_IMPORTED_MODULE_3__/* .deal_list */ .xy.content.left_title)
                                            }),
                                            data?.client_id && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: "copy-row",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "text",
                                                        children: data?.client_id
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                                                        text: data.client_id,
                                                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_icon_copy_svg__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {}),
                                                        className: "copy"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: classnames__WEBPACK_IMPORTED_MODULE_13___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().space), `flex items-center justify-center flex-col gap-y-4 py-2.5 h-[114px] rounded-[5px] border border-color`),
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "flex items-center gap-x-1 text_color font-DINPro-Medium",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_cloud_svg__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                                width: 14,
                                                height: 14
                                            }),
                                            data?.piece_size && (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .unitConversion */ .dN)(data.piece_size)
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: classnames__WEBPACK_IMPORTED_MODULE_13___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().time)),
                                        children: [
                                            (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatDateTime */ .o0)(data?.service_start_time),
                                            tr(_contents_detail__WEBPACK_IMPORTED_MODULE_3__/* .deal_list */ .xy.content.time),
                                            (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatDateTime */ .o0)(data?.end_time)
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().cash),
                                                children: [
                                                    tr(_contents_detail__WEBPACK_IMPORTED_MODULE_3__/* .deal_list */ .xy.content?.cash),
                                                    ":"
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                className: "text_color font-DINPro-Medium",
                                                children: data?.storage_price_per_epoch && (0,_utils__WEBPACK_IMPORTED_MODULE_6__/* .formatFilNum */ .Nm)(data?.storage_price_per_epoch)
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().card),
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().left),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_dealMiner_svg__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                            width: 45,
                                            height: 45
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().right),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().name),
                                                children: tr(_contents_detail__WEBPACK_IMPORTED_MODULE_3__/* .deal_list */ .xy.content.right_title)
                                            }),
                                            data?.provider_id && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                                className: "copy-row",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        className: "text",
                                                        children: data.provider_id
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                                                        text: data.provider_id,
                                                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_icon_copy_svg__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {}),
                                                        className: "copy"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 52727:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/cssinjs");

/***/ }),

/***/ 77529:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons/lib/icons/LoadingOutlined");

/***/ }),

/***/ 86762:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons/lib/icons/LockOutlined");

/***/ }),

/***/ 62127:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons/lib/icons/UserOutlined");

/***/ }),

/***/ 92616:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/config-provider");

/***/ }),

/***/ 1788:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/dropdown");

/***/ }),

/***/ 30675:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/input");

/***/ }),

/***/ 4946:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/locale/en_US");

/***/ }),

/***/ 79353:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/locale/zh_CN");

/***/ }),

/***/ 10274:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/menu");

/***/ }),

/***/ 17369:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/message");

/***/ }),

/***/ 69348:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/tooltip");

/***/ }),

/***/ 59003:
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ 68887:
/***/ ((module) => {

"use strict";
module.exports = require("copy-to-clipboard");

/***/ }),

/***/ 1635:
/***/ ((module) => {

"use strict";
module.exports = require("dayjs");

/***/ }),

/***/ 46517:
/***/ ((module) => {

"use strict";
module.exports = require("lodash");

/***/ }),

/***/ 36211:
/***/ ((module) => {

"use strict";
module.exports = require("mobx");

/***/ }),

/***/ 22062:
/***/ ((module) => {

"use strict";
module.exports = require("mobx-react");

/***/ }),

/***/ 16641:
/***/ ((module) => {

"use strict";
module.exports = require("next-seo");

/***/ }),

/***/ 43076:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module.js");

/***/ }),

/***/ 94140:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 89716:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 33100:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 76368:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 53918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 45732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 56724:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 35132:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 18743:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/html-context.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 50744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 35843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 93431:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 11751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 71109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 28854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 93297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 87782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 82470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 40618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 71853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 16689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 66405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 94612:
/***/ ((module) => {

"use strict";
module.exports = require("use-deep-compare-effect");

/***/ }),

/***/ 99648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 49766:
/***/ ((module) => {

"use strict";
module.exports = import("bignumber.js");;

/***/ }),

/***/ 22021:
/***/ ((module) => {

"use strict";
module.exports = import("i18next");;

/***/ }),

/***/ 57987:
/***/ ((module) => {

"use strict";
module.exports = import("react-i18next");;

/***/ }),

/***/ 34325:
/***/ ((module) => {

"use strict";
module.exports = import("web3");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8355,1163,5586,8817], () => (__webpack_exec__(55286)));
module.exports = __webpack_exports__;

})();