(() => {
var exports = {};
exports.id = 1462;
exports.ids = [1462];
exports.modules = {

/***/ 79813:
/***/ ((module) => {

// Exports
module.exports = {
	"address-list": "address-list_address-list__bM3Ve",
	"header-wrap": "address-list_header-wrap__JENwL",
	"select": "address-list_select__1fXHP"
};


/***/ }),

/***/ 94254:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   config: () => (/* binding */ config),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   getServerSideProps: () => (/* binding */ getServerSideProps),
/* harmony export */   getStaticPaths: () => (/* binding */ getStaticPaths),
/* harmony export */   getStaticProps: () => (/* binding */ getStaticProps),
/* harmony export */   reportWebVitals: () => (/* binding */ reportWebVitals),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   unstable_getServerProps: () => (/* binding */ unstable_getServerProps),
/* harmony export */   unstable_getServerSideProps: () => (/* binding */ unstable_getServerSideProps),
/* harmony export */   unstable_getStaticParams: () => (/* binding */ unstable_getStaticParams),
/* harmony export */   unstable_getStaticPaths: () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   unstable_getStaticProps: () => (/* binding */ unstable_getStaticProps)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(23185);
/* harmony import */ var next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(35244);
/* harmony import */ var next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57182);
/* harmony import */ var private_next_pages_document_tsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(13162);
/* harmony import */ var private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(44178);
/* harmony import */ var private_next_pages_tipset_address_list_index_tsx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(48626);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__, private_next_pages_tipset_address_list_index_tsx__WEBPACK_IMPORTED_MODULE_5__]);
([private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__, private_next_pages_tipset_address_list_index_tsx__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// @ts-ignore this need to be imported from next/dist to be external



// Import the app and document modules.
// @ts-expect-error - replaced by webpack/turbopack loader

// @ts-expect-error - replaced by webpack/turbopack loader

// Import the userland code.
// @ts-expect-error - replaced by webpack/turbopack loader

const PagesRouteModule = next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__.PagesRouteModule;
// Re-export the component (should be the default export).
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_tipset_address_list_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "default"));
// Re-export methods.
const getStaticProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_tipset_address_list_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "getStaticProps");
const getStaticPaths = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_tipset_address_list_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "getStaticPaths");
const getServerSideProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_tipset_address_list_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "getServerSideProps");
const config = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_tipset_address_list_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "config");
const reportWebVitals = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_tipset_address_list_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "reportWebVitals");
// Re-export legacy methods.
const unstable_getStaticProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_tipset_address_list_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticProps");
const unstable_getStaticPaths = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_tipset_address_list_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticPaths");
const unstable_getStaticParams = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_tipset_address_list_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticParams");
const unstable_getServerProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_tipset_address_list_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getServerProps");
const unstable_getServerSideProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_tipset_address_list_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getServerSideProps");
// Create and export the route module that will be consumed.
const routeModule = new PagesRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__/* .RouteKind */ .x.PAGES,
        page: "/tipset/address-list",
        pathname: "/tipset/address-list",
        // The following aren't used in production.
        bundlePath: "",
        filename: ""
    },
    components: {
        App: private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__["default"],
        Document: private_next_pages_document_tsx__WEBPACK_IMPORTED_MODULE_3__["default"]
    },
    userland: private_next_pages_tipset_address_list_index_tsx__WEBPACK_IMPORTED_MODULE_5__
});

//# sourceMappingURL=pages.js.map
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 48626:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(62881);
/* harmony import */ var _components_hooks_useRemoveQuery__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(86699);
/* harmony import */ var _components_hooks_useUpdateQuery__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(42680);
/* harmony import */ var _contents_tipset__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(17147);
/* harmony import */ var _packages_Table__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(70430);
/* harmony import */ var _packages_selects__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(60869);
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(48804);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(23495);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(68108);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(79813);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(31061);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _components_hooks_useUpdateQuery__WEBPACK_IMPORTED_MODULE_4__, _contents_tipset__WEBPACK_IMPORTED_MODULE_5__, _packages_Table__WEBPACK_IMPORTED_MODULE_6__, _utils__WEBPACK_IMPORTED_MODULE_9__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_12__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _components_hooks_useUpdateQuery__WEBPACK_IMPORTED_MODULE_4__, _contents_tipset__WEBPACK_IMPORTED_MODULE_5__, _packages_Table__WEBPACK_IMPORTED_MODULE_6__, _utils__WEBPACK_IMPORTED_MODULE_9__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 















/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__/* .Translation */ .W)({
        ns: "tipset"
    });
    const { theme, lang } = (0,_store_FilscanStore__WEBPACK_IMPORTED_MODULE_8__/* .useFilscanStore */ .J)();
    const updateQuery = (0,_components_hooks_useUpdateQuery__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
    const removeQueryParam = (0,_components_hooks_useRemoveQuery__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
    const { axiosData, loading } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)();
    const { isMobile } = (0,_components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z)();
    const { name, p } = (0,next_router__WEBPACK_IMPORTED_MODULE_10__.useRouter)().query;
    // const [loading, setLoading] = useState(false);
    const [dataSource, setDataSource] = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)({
        data: [],
        total: undefined
    });
    const headerOptions = (0,react__WEBPACK_IMPORTED_MODULE_11__.useMemo)(()=>{
        return _contents_tipset__WEBPACK_IMPORTED_MODULE_5__/* .address_list */ .X.options.map((v)=>{
            return {
                ...v,
                label: tr(v.label)
            };
        });
    }, [
        lang
    ]);
    const method = (0,react__WEBPACK_IMPORTED_MODULE_11__.useMemo)(()=>{
        if (name && typeof name === "string") {
            return name;
        }
        return "all";
    }, [
        name
    ]);
    const current = (0,react__WEBPACK_IMPORTED_MODULE_11__.useMemo)(()=>{
        if (p && typeof p === "string") {
            return Number(p);
        }
        return 1;
    }, [
        p
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_11__.useEffect)(()=>{
        load(current, method);
    }, [
        method,
        current
    ]);
    const load = async (cur, method)=>{
        // setLoading(true);
        const showIndex = cur || current;
        const method_name = method === "all" ? "" : method;
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.tipset_address, {
            index: showIndex - 1,
            limit: _utils__WEBPACK_IMPORTED_MODULE_9__/* .pageLimit */ .P5,
            order: {
                field: method_name
            }
        });
        // setLoading(false);
        const showData = result?.get_rich_account_list?.map((item, index)=>{
            return {
                ...item,
                rank: _utils__WEBPACK_IMPORTED_MODULE_9__/* .pageLimit */ .P5 * (showIndex - 1) + index + 1
            };
        }) || [];
        setDataSource({
            data: showData,
            total: result?.total_count
        });
    };
    const columns = (0,react__WEBPACK_IMPORTED_MODULE_11__.useMemo)(()=>{
        const content = _contents_tipset__WEBPACK_IMPORTED_MODULE_5__/* .address_list */ .X.columns.map((v)=>{
            if (isMobile) {
                if (v.dataIndex === "rank") {
                    v.render = (value, record, index)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: `No.${record.rank}`
                        });
                    };
                }
            }
            if (v.dataIndex === "account_type") {
                return {
                    ...v,
                    title: tr(v.title),
                    render: (text)=>tr(text)
                };
            }
            return {
                ...v,
                title: tr(v.title)
            };
        });
        return content;
    }, [
        theme,
        tr
    ]);
    const handleChange = (pagination, filters, sorter)=>{
        const showCurrent = pagination?.current;
        if (showCurrent) {
            if (showCurrent === 1) {
                removeQueryParam("p");
            } else {
                updateQuery({
                    p: pagination.current
                });
            }
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_13___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default()["address-list"]), "main_contain"),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_13___default()("flex justify-between items-center", (_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default()["header-wrap"])),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mx-2.5",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "font-PingFang font-semibold text-lg ",
                                children: tr("address_list")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text_des text-xs",
                                children: tr(_contents_tipset__WEBPACK_IMPORTED_MODULE_5__/* .address_list */ .X.total_list, {
                                    value: (0,_utils__WEBPACK_IMPORTED_MODULE_9__/* .formatNumber */ .uf)(dataSource?.total || 0)
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_selects__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        className: classnames__WEBPACK_IMPORTED_MODULE_13___default()((_index_module_scss__WEBPACK_IMPORTED_MODULE_15___default().select)),
                        value: method,
                        options: headerOptions,
                        onChange: (value)=>{
                            if (value !== "all") {
                                updateQuery({
                                    name: value,
                                    p: "removed"
                                });
                            } else {
                                removeQueryParam("name");
                            }
                        }
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "mt-4 border  rounded-xl p-5 card_shadow border_color",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_Table__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    className: "-mt-2.5 ",
                    data: dataSource.data,
                    total: dataSource.total,
                    current: current,
                    columns: columns,
                    loading: loading,
                    onChange: handleChange
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 52727:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/cssinjs");

/***/ }),

/***/ 77529:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons/lib/icons/LoadingOutlined");

/***/ }),

/***/ 86762:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons/lib/icons/LockOutlined");

/***/ }),

/***/ 62127:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons/lib/icons/UserOutlined");

/***/ }),

/***/ 92616:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/config-provider");

/***/ }),

/***/ 30675:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/input");

/***/ }),

/***/ 4946:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/locale/en_US");

/***/ }),

/***/ 79353:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/locale/zh_CN");

/***/ }),

/***/ 10274:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/menu");

/***/ }),

/***/ 17369:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/message");

/***/ }),

/***/ 14528:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/pagination");

/***/ }),

/***/ 53526:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/select");

/***/ }),

/***/ 71030:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/skeleton");

/***/ }),

/***/ 74285:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/table");

/***/ }),

/***/ 69348:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/tooltip");

/***/ }),

/***/ 59003:
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ 68887:
/***/ ((module) => {

"use strict";
module.exports = require("copy-to-clipboard");

/***/ }),

/***/ 1635:
/***/ ((module) => {

"use strict";
module.exports = require("dayjs");

/***/ }),

/***/ 46517:
/***/ ((module) => {

"use strict";
module.exports = require("lodash");

/***/ }),

/***/ 36211:
/***/ ((module) => {

"use strict";
module.exports = require("mobx");

/***/ }),

/***/ 22062:
/***/ ((module) => {

"use strict";
module.exports = require("mobx-react");

/***/ }),

/***/ 16641:
/***/ ((module) => {

"use strict";
module.exports = require("next-seo");

/***/ }),

/***/ 43076:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module.js");

/***/ }),

/***/ 94140:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 89716:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 33100:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 76368:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 53918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 45732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 56724:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 35132:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 18743:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/html-context.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 50744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 35843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 93431:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 11751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 71109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 28854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 93297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 87782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 82470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 40618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 71853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 16689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 66405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 94612:
/***/ ((module) => {

"use strict";
module.exports = require("use-deep-compare-effect");

/***/ }),

/***/ 99648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 49766:
/***/ ((module) => {

"use strict";
module.exports = import("bignumber.js");;

/***/ }),

/***/ 22021:
/***/ ((module) => {

"use strict";
module.exports = import("i18next");;

/***/ }),

/***/ 57987:
/***/ ((module) => {

"use strict";
module.exports = import("react-i18next");;

/***/ }),

/***/ 34325:
/***/ ((module) => {

"use strict";
module.exports = import("web3");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8355,1163,430,1921,869,7147], () => (__webpack_exec__(94254)));
module.exports = __webpack_exports__;

})();