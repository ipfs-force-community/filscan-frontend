(() => {
var exports = {};
exports.id = 1232;
exports.ids = [1232];
exports.modules = {

/***/ 3475:
/***/ ((module) => {

// Exports
module.exports = {
	"first": "first_first__tYTAu",
	"title": "first_title___1QT9",
	"content": "first_content__xBOQ3",
	"img-wrap": "first_img-wrap__L8PRn",
	"tips": "first_tips__mq6z2"
};


/***/ }),

/***/ 3805:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-accelerate.aliyuncs.com/client/_next/static/media/img-safe.b6fb74dd.png","height":522,"width":520,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA40lEQVR42mP4//8X27sPv2MZ0MCEZX9YwIxPn3/w/P37K79+1h9H/7o/GaVT/0Rduv1XEqLsFxMDlMHjUvnnjn7Bn//GRX/+Z/X++blq199MuHHbj/ydG9Py579B/s/fATU/f0hk/frfu+TvMbiC2w//hm0//Pf/2au/fq7d/etn18I//7ce+nsuse2PDsO5a3+jjl/4q25T+mdHXt+f/xOW/f2/9+TfD////wv+//8/E8h+VpApjXP/CDpW/FmnUfC7hoHhJ+eHT79nf/n6swJsRWz7H0YGNHDz3m/Hdx9+6gIAM0l90FAfyFsAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 75:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   config: () => (/* binding */ config),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   getServerSideProps: () => (/* binding */ getServerSideProps),
/* harmony export */   getStaticPaths: () => (/* binding */ getStaticPaths),
/* harmony export */   getStaticProps: () => (/* binding */ getStaticProps),
/* harmony export */   reportWebVitals: () => (/* binding */ reportWebVitals),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   unstable_getServerProps: () => (/* binding */ unstable_getServerProps),
/* harmony export */   unstable_getServerSideProps: () => (/* binding */ unstable_getServerSideProps),
/* harmony export */   unstable_getStaticParams: () => (/* binding */ unstable_getStaticParams),
/* harmony export */   unstable_getStaticPaths: () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   unstable_getStaticProps: () => (/* binding */ unstable_getStaticProps)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3185);
/* harmony import */ var next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5244);
/* harmony import */ var next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7182);
/* harmony import */ var private_next_pages_document_tsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3162);
/* harmony import */ var private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4178);
/* harmony import */ var private_next_pages_contract_verify_index_tsx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5579);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__, private_next_pages_contract_verify_index_tsx__WEBPACK_IMPORTED_MODULE_5__]);
([private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__, private_next_pages_contract_verify_index_tsx__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// @ts-ignore this need to be imported from next/dist to be external



// Import the app and document modules.
// @ts-expect-error - replaced by webpack/turbopack loader

// @ts-expect-error - replaced by webpack/turbopack loader

// Import the userland code.
// @ts-expect-error - replaced by webpack/turbopack loader

const PagesRouteModule = next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__.PagesRouteModule;
// Re-export the component (should be the default export).
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_contract_verify_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "default"));
// Re-export methods.
const getStaticProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_contract_verify_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "getStaticProps");
const getStaticPaths = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_contract_verify_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "getStaticPaths");
const getServerSideProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_contract_verify_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "getServerSideProps");
const config = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_contract_verify_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "config");
const reportWebVitals = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_contract_verify_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "reportWebVitals");
// Re-export legacy methods.
const unstable_getStaticProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_contract_verify_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticProps");
const unstable_getStaticPaths = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_contract_verify_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticPaths");
const unstable_getStaticParams = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_contract_verify_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticParams");
const unstable_getServerProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_contract_verify_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getServerProps");
const unstable_getServerSideProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_contract_verify_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getServerSideProps");
// Create and export the route module that will be consumed.
const routeModule = new PagesRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__/* .RouteKind */ .x.PAGES,
        page: "/contract/verify",
        pathname: "/contract/verify",
        // The following aren't used in production.
        bundlePath: "",
        filename: ""
    },
    components: {
        App: private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__["default"],
        Document: private_next_pages_document_tsx__WEBPACK_IMPORTED_MODULE_3__["default"]
    },
    userland: private_next_pages_contract_verify_index_tsx__WEBPACK_IMPORTED_MODULE_5__
});

//# sourceMappingURL=pages.js.map
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5579:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_useHash__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8087);
/* harmony import */ var _src_contract_verify_first__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8425);
/* harmony import */ var _src_contract_verify__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1215);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_src_contract_verify_first__WEBPACK_IMPORTED_MODULE_2__, _src_contract_verify__WEBPACK_IMPORTED_MODULE_3__]);
([_src_contract_verify_first__WEBPACK_IMPORTED_MODULE_2__, _src_contract_verify__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




//验证合约
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    const { hashParams } = (0,_components_hooks_useHash__WEBPACK_IMPORTED_MODULE_1__/* .useHash */ .H)();
    //验证合约
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "main_contain",
        children: hashParams?.contractAddress ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_contract_verify__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_contract_verify_first__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9207:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2881);
/* harmony import */ var _components_hooks_useHash__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8087);
/* harmony import */ var _contents_contract__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5509);
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3800);
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(antd_lib_button__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(675);
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(antd_lib_input__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var antd_lib_select__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3526);
/* harmony import */ var antd_lib_select__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(antd_lib_select__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var antd_lib_notification__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3528);
/* harmony import */ var antd_lib_notification__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(antd_lib_notification__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _Upload__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8563);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8054);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_11__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_contract__WEBPACK_IMPORTED_MODULE_3__, _Upload__WEBPACK_IMPORTED_MODULE_9__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_contract__WEBPACK_IMPORTED_MODULE_3__, _Upload__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const { TextArea } = (antd_lib_input__WEBPACK_IMPORTED_MODULE_5___default());
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((props)=>{
    const { onChange, loading } = props;
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "contract"
    });
    const { hashParams } = (0,_components_hooks_useHash__WEBPACK_IMPORTED_MODULE_2__/* .useHash */ .H)();
    const { type } = hashParams;
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)({
        contract_address: "",
        compile_version: "",
        optimize: true,
        optimize_runs: 200,
        arguments: ""
    });
    const [files, setFiles] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)({});
    const [configFile, setConfigFile] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)({});
    (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(()=>{
        if (hashParams) {
            setData({
                ...data,
                contract_address: hashParams.contractAddress || "",
                compile_version: hashParams.version || ""
            });
        }
    }, [
        hashParams
    ]);
    const handleSave = ()=>{
        const obj = {
            ...data
        };
        const filesList = Object.keys(files) || [];
        const configFiles = Object.keys(configFile) || [];
        if (filesList.length === 0) {
            return antd_lib_notification__WEBPACK_IMPORTED_MODULE_7___default().warning({
                className: "custom-notification",
                message: "Warning",
                duration: 100,
                description: "please select file"
            });
        }
        if (type === "multi" && configFiles.length === 0) {
            return antd_lib_notification__WEBPACK_IMPORTED_MODULE_7___default().warning({
                className: "custom-notification",
                message: "Warning",
                duration: 100,
                description: "Please select Metadata File"
            });
        }
        let source_file = [];
        const config_files = [];
        if (type === "multi") {
            configFiles.forEach((v)=>{
                const show_file = configFile[v];
                const item = {
                    file_name: show_file.name,
                    source_code: show_file.value
                };
                config_files.push(item);
            });
        }
        filesList.forEach((v)=>{
            const show_file = files[v];
            const item = {
                file_name: show_file.name,
                source_code: show_file.value
            };
            source_file.push(item);
        });
        obj.source_file = source_file;
        obj.optimize_runs = data.optimize_runs ? Number(data.optimize_runs) : undefined;
        obj.optimize = data.optimize === "true";
        obj.mate_data_file = config_files[0];
        if (type === "standard") {
            obj.hardhat_build_info_file = source_file[0];
        }
        const url = type === "standard" ? _contents_apiUrl__WEBPACK_IMPORTED_MODULE_10__/* .apiUrl */ .JW.contract_hard_verify : _contents_apiUrl__WEBPACK_IMPORTED_MODULE_10__/* .apiUrl */ .JW.contract_verify;
        onChange(obj, url);
    };
    const renderChildren = (item)=>{
        const { dataIndex, title, placeholder = "" } = item;
        let content;
        switch(item.type){
            case "Input":
                return content = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_input__WEBPACK_IMPORTED_MODULE_5___default()), {
                    className: "custom_input !h-10 !text_des",
                    value: data[dataIndex],
                    placeholder: tr(placeholder)
                });
            case "Select":
                return content = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_select__WEBPACK_IMPORTED_MODULE_6___default()), {
                    className: "custom_select !text_des",
                    options: item.options,
                    defaultValue: data[dataIndex],
                    placeholder: tr(placeholder)
                });
        }
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
            className: "border border_text h-10 flex items-center rounded-[5px] px-2",
            children: data[dataIndex] || ""
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "border rounded-xl p-5 card_shadow border_color mt-2.5 text_des text-xs",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                        className: "border border_color rounded-[5px] p-4 leading-6",
                        children: _contents_contract__WEBPACK_IMPORTED_MODULE_3__/* .verify_source */ .yP.desList.map((item)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                children: tr(item.title)
                            }, item.title);
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                        className: "flex gap-y-2 mt-5 gap-x-5",
                        children: _contents_contract__WEBPACK_IMPORTED_MODULE_3__/* .verify_source */ .yP.headerList.map((item)=>{
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                className: "flex flex-col flex-1",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text_color text-sm mb-2",
                                        children: tr(item.title)
                                    }),
                                    renderChildren(item)
                                ]
                            }, item.dataIndex);
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "border border_color card_shadow rounded-[12px] p-5 mt-5",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Upload__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                    fileData: files,
                    confiles: configFile,
                    onChange: (files, type)=>{
                        if (type === "config") {
                            setConfigFile(files);
                        } else {
                            setFiles(files);
                        }
                    }
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "border border_color card_shadow rounded-[12px] p-5 mt-5",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "mb-2 text-sm font-medium",
                        children: tr("arguments")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TextArea, {
                        value: data.arguments || "",
                        autoSize: {
                            minRows: 4,
                            maxRows: 6
                        },
                        className: "custom_input",
                        onChange: (e)=>{
                            setData({
                                ...data,
                                arguments: e.target.value
                            });
                        }
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex gap-x-2 mt-5",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((antd_lib_button__WEBPACK_IMPORTED_MODULE_4___default()), {
                                className: "primary_btn flex items-center gap-x-2 h-8",
                                onClick: handleSave,
                                loading: loading,
                                children: [
                                    " ",
                                    tr("confirm")
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_11___default()), {
                                href: `/contract/verify`,
                                className: "flex items-center justify-center cancel_btn border border_color rounded-md",
                                children: [
                                    " ",
                                    tr("reset")
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_11___default()), {
                                href: `/home`,
                                className: "flex items-center justify-center cancel_btn border border_color rounded-md",
                                children: [
                                    " ",
                                    tr("back")
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8563:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3800);
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd_lib_button__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd_lib_upload__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9538);
/* harmony import */ var antd_lib_upload__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd_lib_upload__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var antd_lib_message__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7369);
/* harmony import */ var antd_lib_message__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(antd_lib_message__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2881);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7947);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _contents_contract__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5509);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_6__, _contents_contract__WEBPACK_IMPORTED_MODULE_9__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_6__, _contents_contract__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const Editor = next_dynamic__WEBPACK_IMPORTED_MODULE_8___default()(null, {
    loadableGenerated: {
        modules: [
            "../src/contract/verify/Upload.tsx -> " + "@/components/ace"
        ]
    },
    ssr: false
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ onChange, fileData, confiles })=>{
    const { type } = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)().query;
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_6__/* .Translation */ .W)({
        ns: "contract"
    });
    const maxCount = (0,react__WEBPACK_IMPORTED_MODULE_4__.useMemo)(()=>{
        if (type === "standard") {
            return 1;
        }
        return 50;
    }, [
        type
    ]);
    const handleFile = (file, filesList)=>{
        //1.将文件读取为二进制数据
        const ace = {
            ...fileData
        };
        filesList.forEach((data, index)=>{
            if (Object.keys(ace).length + index + 1 > maxCount) {
                antd_lib_message__WEBPACK_IMPORTED_MODULE_3___default().warning("file already exists");
                return;
            }
            if (data.size / 1024 / 1024 > 10) {
                antd_lib_message__WEBPACK_IMPORTED_MODULE_3___default().warning("file size more than 10M");
                return false;
            }
            let reader = new FileReader();
            reader.readAsText(data, "UTF-8");
            reader.onload = (e)=>{
                //获取数据
                //const ace:any = {};
                const value = e.currentTarget.result;
                ace[data.uid] = {
                    name: data.name,
                    uid: data.uid,
                    value
                };
                if (onChange) {
                    onChange(ace, "files");
                }
            };
            //4.2 //读取中断事件
            reader.onabort = ()=>{
                console.log("读取中断了");
            };
        });
    };
    const handleConfigFile = (data)=>{
        let reader = new FileReader();
        const configAce = {
            ...confiles
        };
        reader.readAsText(data, "UTF-8");
        reader.onload = (e)=>{
            //获取数据
            //const ace:any = {};
            const value = e.currentTarget.result;
            configAce[data.uid] = {
                name: data.name,
                uid: data.uid,
                value
            };
            if (onChange) {
                onChange(configAce, "config");
            }
        };
        //4.2 //读取中断事件
        reader.onabort = ()=>{
            console.log("读取中断了");
        };
    };
    const handleRemove = (uid, type)=>{
        let newFiles = {
            ...fileData
        };
        delete newFiles[uid];
        if (type === "config") {
            if (onChange) {
                onChange(newFiles, "config");
            }
        } else {
            if (onChange) {
                onChange(newFiles, "file");
            }
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_upload__WEBPACK_IMPORTED_MODULE_2___default()), {
                        accept: type === "standard" ? ".json" : ".sol",
                        maxCount: maxCount,
                        beforeUpload: handleFile,
                        multiple: type !== "standard",
                        fileList: [],
                        customRequest: (file)=>{
                            file.onProgress({
                                percent: 100
                            });
                            file.onSuccess({
                                status: 200
                            });
                        },
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: " flex items-center gap-x-2 h-8",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((antd_lib_button__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    className: "primary_btn flex items-center gap-x-2 h-8",
                                    children: [
                                        (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_7__/* .getSvgIcon */ .a)("uploadIcon"),
                                        tr(type === "standard" ? "file_name_json" : "file_name")
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "text_des text-xs",
                                    children: type === "standard" ? tr("file_name_json") : tr("file_name")
                                })
                            ]
                        })
                    }),
                    fileData && Object.keys(fileData)?.map((acekey, index)=>{
                        const aceItem = fileData[acekey];
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "my-2.5",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex justify-between items-center mb-2.5",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            className: "flex gap-x-2 text_des items-center",
                                            children: [
                                                (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_7__/* .getSvgIcon */ .a)("fileIcon"),
                                                aceItem.name
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "cursor-pointer",
                                            onClick: ()=>handleRemove(acekey, "files"),
                                            children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_7__/* .getSvgIcon */ .a)("deleteIcon")
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Editor, {
                                    value: aceItem.value
                                }, acekey)
                            ]
                        }, index);
                    }),
                    type === "standard" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                        className: "border border_color rounded-[5px] p-5 mt-5 leading-6",
                        children: _contents_contract__WEBPACK_IMPORTED_MODULE_9__/* .verify */ .T.meta_list_des.map((listItem, index)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: "text_des",
                                children: tr(listItem.label)
                            }, index);
                        })
                    })
                ]
            }),
            type === "multi" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mt-2.5",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_upload__WEBPACK_IMPORTED_MODULE_2___default()), {
                        accept: ".json",
                        maxCount: 1,
                        fileList: [],
                        beforeUpload: handleConfigFile,
                        multiple: false,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((antd_lib_button__WEBPACK_IMPORTED_MODULE_1___default()), {
                            className: "primary_btn flex items-center gap-x-2 h-8 mt-2.5",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: "+"
                                }),
                                tr("config_file_name")
                            ]
                        })
                    }),
                    confiles && Object.keys(confiles)?.map((acekey, index)=>{
                        const aceItem = confiles[acekey];
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "my-2.5",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex justify-between items-center mb-2.5",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            className: "flex gap-x-2 text_des items-center",
                                            children: [
                                                (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_7__/* .getSvgIcon */ .a)("fileIcon"),
                                                aceItem.name
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "cursor-pointer",
                                            onClick: ()=>handleRemove(acekey, "config"),
                                            children: (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_7__/* .getSvgIcon */ .a)("deleteIcon")
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Editor, {
                                    value: aceItem.value
                                }, acekey)
                            ]
                        }, index);
                    })
                ]
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4296:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2881);
/* harmony import */ var _contents_contract__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5509);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7947);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_contract__WEBPACK_IMPORTED_MODULE_2__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_contract__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ data })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "contract"
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "border rounded-xl card_shadow border_color mt-2.5 ",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                className: "border border_color rounded-[5px] m-5 text_des  text-xs p-4",
                children: _contents_contract__WEBPACK_IMPORTED_MODULE_2__/* .verify_source */ .yP.desList.map((item)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                        children: tr(item.title)
                    }, item.title);
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mt-5 p-5",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "font-medium",
                        children: tr("byte_code")
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: `flex items-center gap-x-1 my-4 ${!data?.is_verified && !data?.has_been_verified ? "text_red" : "text_green"}`,
                        children: [
                            !data?.is_verified && !data?.has_been_verified ? (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_3__/* .getSvgIcon */ .a)("errorIcon") : (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_3__/* .getSvgIcon */ .a)("successIcon"),
                            data?.has_been_verified ? tr("has_been_verified") : data?.is_verified ? tr("ver_sucess") : tr("ver_err")
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "border border_color overflow-auto  min-h-[9px] max-h-[150px] rounded-[5px] p-5 break-words",
                        children: data.byte_code
                    })
                ]
            }),
            data.is_verified && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                        className: "p-5 border-t border-b border_color ",
                        children: _contents_contract__WEBPACK_IMPORTED_MODULE_2__/* .verify_output */ ._4.headerList.map((item)=>{
                            const value = data[item.dataIndex];
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                className: "flex items-center h-9 text-sm",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "text_des w-28 ",
                                        children: [
                                            tr(item.title),
                                            ":"
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "font-DINPro-Medium",
                                        children: String(value)
                                    })
                                ]
                            }, item.dataIndex);
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "m-5 border border_color rounded-[5px] text-sm",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "m-5",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: tr("contract_name")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "flex items-center h-9 mt-3 border border_color rounded-[5px] px-2.5 ",
                                        children: data?.contract_name || ""
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "m-5",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: tr("contract_abi")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "h-[166px]  text_des overflow-auto mt-3 border border_color rounded-[5px] break-words ",
                                        children: data?.ABI || ""
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex gap-x-4 m-8",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                href: `/address/${data.contract_address}`,
                                className: "primary_btn flex items-center gap-x-2 h-8",
                                children: [
                                    " ",
                                    tr("look_adres")
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                href: `/contract/verify`,
                                className: "flex items-center justify-center cancel_btn border border_color rounded-md",
                                children: [
                                    " ",
                                    tr("back")
                                ]
                            })
                        ]
                    })
                ]
            }),
            !data.is_verified && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex gap-x-4 m-8",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                    href: `/contract/verify`,
                    className: "flex items-center justify-center cancel_btn border border_color rounded-md",
                    children: [
                        " ",
                        tr("back")
                    ]
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8425:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9676);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2881);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8054);
/* harmony import */ var _contents_contract__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5509);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8108);
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3800);
/* harmony import */ var antd_lib_button__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(antd_lib_button__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var antd_lib_form__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6190);
/* harmony import */ var antd_lib_form__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(antd_lib_form__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(675);
/* harmony import */ var antd_lib_input__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(antd_lib_input__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var antd_lib_select__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3526);
/* harmony import */ var antd_lib_select__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(antd_lib_select__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var antd_lib_space__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7374);
/* harmony import */ var antd_lib_space__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(antd_lib_space__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _assets_images_img_safe_png__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(3805);
/* harmony import */ var _first_module_scss__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(3475);
/* harmony import */ var _first_module_scss__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_first_module_scss__WEBPACK_IMPORTED_MODULE_15__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_contract__WEBPACK_IMPORTED_MODULE_4__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_5__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_contract__WEBPACK_IMPORTED_MODULE_4__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
















/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__/* .Translation */ .W)({
        ns: "contract"
    });
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_11__.useRouter)();
    const [form] = antd_lib_form__WEBPACK_IMPORTED_MODULE_7___default().useForm();
    const { data: versionData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__/* .apiUrl */ .JW.contract_solidity);
    const { data: licensesData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__/* .apiUrl */ .JW.contract_Licenses);
    const versionOptions = (0,react__WEBPACK_IMPORTED_MODULE_12__.useMemo)(()=>{
        if (versionData?.version_list) {
            return versionData?.version_list?.map((item)=>{
                return {
                    item,
                    label: item,
                    value: item
                };
            });
        }
        return [];
    }, [
        versionData
    ]);
    const licensesOptions = (0,react__WEBPACK_IMPORTED_MODULE_12__.useMemo)(()=>{
        if (licensesData?.version_list) {
            return licensesData?.version_list?.map((item)=>{
                return {
                    item,
                    label: item,
                    value: item
                };
            });
        }
        return [];
    }, [
        licensesData
    ]);
    const handleFinish = (values)=>{
        router.push(`/contract/verify?contractAddress=${values.contract_address}&version=${values.compile_version}&type=${values.verify_model}`);
    };
    const renderChildren = (item)=>{
        const { dataIndex, title, placeholder = "" } = item;
        const options = dataIndex === "compile_version" ? versionOptions : licensesOptions;
        let content;
        switch(item.type){
            case "Input":
                content = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_input__WEBPACK_IMPORTED_MODULE_8___default()), {
                    className: "custom_input !h-9",
                    placeholder: tr(placeholder)
                });
                break;
            default:
                content = /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_select__WEBPACK_IMPORTED_MODULE_9___default()), {
                    className: "custom_select",
                    popupClassName: "custom_select_wrapper",
                    options: item.options || options,
                    placeholder: tr(placeholder)
                });
                break;
        }
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_form__WEBPACK_IMPORTED_MODULE_7___default().Item), {
            help: undefined,
            required: false,
            name: dataIndex,
            className: "!w-full",
            label: tr(title),
            rules: item.rules,
            children: content
        }, item.dataIndex);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_1__/* .MobileView */ .$, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_first_module_scss__WEBPACK_IMPORTED_MODULE_15___default().first),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_first_module_scss__WEBPACK_IMPORTED_MODULE_15___default().title),
                            children: tr("contract_verify")
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_first_module_scss__WEBPACK_IMPORTED_MODULE_15___default().content),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_first_module_scss__WEBPACK_IMPORTED_MODULE_15___default()["img-wrap"]),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_13___default()), {
                                        src: _assets_images_img_safe_png__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z,
                                        alt: "",
                                        width: 220,
                                        height: 220
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_first_module_scss__WEBPACK_IMPORTED_MODULE_15___default().tips),
                                    children: tr("contract_verify_tips")
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_device_detect__WEBPACK_IMPORTED_MODULE_1__/* .BrowserView */ .I, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "flex flex-col text-xl font-medium gap-y-2.5 mx-2.5",
                                children: tr("verify_title")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "text_des text-xs  mx-2.5",
                                children: tr("verify_des")
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "border rounded-xl p-5 card_shadow border_color mt-2.5  flex flex-col items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "text_des text-xs leading-6",
                                children: tr("verify_content")
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "mt-12 w-[500px]",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((antd_lib_form__WEBPACK_IMPORTED_MODULE_7___default()), {
                                    className: "!w-full custom_form",
                                    form: form,
                                    size: "small",
                                    onFinish: handleFinish,
                                    layout: "vertical",
                                    children: [
                                        _contents_contract__WEBPACK_IMPORTED_MODULE_4__/* .verify_first */ .mO.list.map((item)=>{
                                            return renderChildren(item);
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_form__WEBPACK_IMPORTED_MODULE_7___default().Item), {
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((antd_lib_space__WEBPACK_IMPORTED_MODULE_10___default()), {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_button__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        htmlType: "submit",
                                                        className: "primary_btn !w-[140px] !h-9",
                                                        children: tr("next")
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((antd_lib_button__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        htmlType: "reset",
                                                        className: "cancel_btn !w-[140px] !h-9",
                                                        children: tr("reset")
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1215:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2881);
/* harmony import */ var _contents_contract__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5509);
/* harmony import */ var _packages_segmented__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5622);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _Source__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9207);
/* harmony import */ var _VerifyData__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4296);
/* harmony import */ var antd_lib_notification__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3528);
/* harmony import */ var antd_lib_notification__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(antd_lib_notification__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8108);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_contract__WEBPACK_IMPORTED_MODULE_2__, _packages_segmented__WEBPACK_IMPORTED_MODULE_3__, _Source__WEBPACK_IMPORTED_MODULE_5__, _VerifyData__WEBPACK_IMPORTED_MODULE_6__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__, _contents_contract__WEBPACK_IMPORTED_MODULE_2__, _packages_segmented__WEBPACK_IMPORTED_MODULE_3__, _Source__WEBPACK_IMPORTED_MODULE_5__, _VerifyData__WEBPACK_IMPORTED_MODULE_6__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









//验证合约
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_1__/* .Translation */ .W)({
        ns: "contract"
    });
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    const [active, setActive] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)("source_code");
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const [outData, setOutData] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)({});
    const handleSave = (files, url)=>{
        setLoading(true);
        axiosData(url, {
            ...files
        }).then((res)=>{
            setLoading(false);
            if (res) {
                setOutData({
                    ...res?.compiled_file || {},
                    is_verified: res?.is_verified
                });
                setActive("compile_output");
                if (res.is_verified) {
                    antd_lib_notification__WEBPACK_IMPORTED_MODULE_7___default().success({
                        className: "custom-notification",
                        message: "success",
                        duration: 100,
                        description: "Success"
                    });
                } else {
                    antd_lib_notification__WEBPACK_IMPORTED_MODULE_7___default().error({
                        className: "custom-notification",
                        message: "Error",
                        duration: 100,
                        description: "Invalid Arguments"
                    });
                }
            }
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mb-5",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "flex flex-col text-xl font-medium gap-y-2.5",
                        children: tr("verify_title")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "text_des text-xs",
                        children: tr("step1_verify_des")
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_segmented__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                data: _contents_contract__WEBPACK_IMPORTED_MODULE_2__/* .verify */ .T.tabList,
                ns: "contract",
                defaultValue: active,
                isHash: false,
                onChange: (v)=>setActive(v)
            }),
            active === "source_code" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Source__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                onChange: handleSave,
                loading: loading
            }),
            active === "compile_output" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_VerifyData__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                data: outData
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2727:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/cssinjs");

/***/ }),

/***/ 7529:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons/lib/icons/LoadingOutlined");

/***/ }),

/***/ 3800:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/button");

/***/ }),

/***/ 2616:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/config-provider");

/***/ }),

/***/ 6190:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/form");

/***/ }),

/***/ 675:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/input");

/***/ }),

/***/ 4946:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/locale/en_US");

/***/ }),

/***/ 9353:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/locale/zh_CN");

/***/ }),

/***/ 274:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/menu");

/***/ }),

/***/ 7369:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/message");

/***/ }),

/***/ 3528:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/notification");

/***/ }),

/***/ 3526:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/select");

/***/ }),

/***/ 7374:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/space");

/***/ }),

/***/ 9348:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/tooltip");

/***/ }),

/***/ 9538:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/upload");

/***/ }),

/***/ 9003:
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ 8887:
/***/ ((module) => {

"use strict";
module.exports = require("copy-to-clipboard");

/***/ }),

/***/ 1635:
/***/ ((module) => {

"use strict";
module.exports = require("dayjs");

/***/ }),

/***/ 6517:
/***/ ((module) => {

"use strict";
module.exports = require("lodash");

/***/ }),

/***/ 6641:
/***/ ((module) => {

"use strict";
module.exports = require("next-seo");

/***/ }),

/***/ 3076:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module.js");

/***/ }),

/***/ 4140:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 9716:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 3100:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 6368:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 6724:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 5132:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 8743:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/html-context.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3431:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 4612:
/***/ ((module) => {

"use strict";
module.exports = require("use-deep-compare-effect");

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 9766:
/***/ ((module) => {

"use strict";
module.exports = import("bignumber.js");;

/***/ }),

/***/ 2021:
/***/ ((module) => {

"use strict";
module.exports = import("i18next");;

/***/ }),

/***/ 7987:
/***/ ((module) => {

"use strict";
module.exports = import("react-i18next");;

/***/ }),

/***/ 4325:
/***/ ((module) => {

"use strict";
module.exports = import("web3");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8355,5152,1163,8087,5622,5509], () => (__webpack_exec__(75)));
module.exports = __webpack_exports__;

})();