(() => {
var exports = {};
exports.id = 2949;
exports.ids = [2949];
exports.modules = {

/***/ 6148:
/***/ ((module) => {

// Exports
module.exports = {
	"miner": "style_miner__v1WuB",
	"title-wrap": "style_title-wrap__Neh1i",
	"title": "style_title___CLK1",
	"balance": "style_balance__SzdgO",
	"column": "style_column__iR7A9"
};


/***/ }),

/***/ 64168:
/***/ ((module) => {

// Exports
module.exports = {
	"wrap": "accountDetail_wrap__1fbRK",
	"title": "accountDetail_title__tfHEC",
	"content": "accountDetail_content__JU7a7"
};


/***/ }),

/***/ 82385:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   config: () => (/* binding */ config),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   getServerSideProps: () => (/* binding */ getServerSideProps),
/* harmony export */   getStaticPaths: () => (/* binding */ getStaticPaths),
/* harmony export */   getStaticProps: () => (/* binding */ getStaticProps),
/* harmony export */   reportWebVitals: () => (/* binding */ reportWebVitals),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   unstable_getServerProps: () => (/* binding */ unstable_getServerProps),
/* harmony export */   unstable_getServerSideProps: () => (/* binding */ unstable_getServerSideProps),
/* harmony export */   unstable_getStaticParams: () => (/* binding */ unstable_getStaticParams),
/* harmony export */   unstable_getStaticPaths: () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   unstable_getStaticProps: () => (/* binding */ unstable_getStaticProps)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(23185);
/* harmony import */ var next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(35244);
/* harmony import */ var next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57182);
/* harmony import */ var private_next_pages_document_tsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(13162);
/* harmony import */ var private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(44178);
/* harmony import */ var private_next_pages_miner_miner_tsx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(57520);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__, private_next_pages_miner_miner_tsx__WEBPACK_IMPORTED_MODULE_5__]);
([private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__, private_next_pages_miner_miner_tsx__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// @ts-ignore this need to be imported from next/dist to be external



// Import the app and document modules.
// @ts-expect-error - replaced by webpack/turbopack loader

// @ts-expect-error - replaced by webpack/turbopack loader

// Import the userland code.
// @ts-expect-error - replaced by webpack/turbopack loader

const PagesRouteModule = next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__.PagesRouteModule;
// Re-export the component (should be the default export).
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_miner_miner_tsx__WEBPACK_IMPORTED_MODULE_5__, "default"));
// Re-export methods.
const getStaticProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_miner_miner_tsx__WEBPACK_IMPORTED_MODULE_5__, "getStaticProps");
const getStaticPaths = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_miner_miner_tsx__WEBPACK_IMPORTED_MODULE_5__, "getStaticPaths");
const getServerSideProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_miner_miner_tsx__WEBPACK_IMPORTED_MODULE_5__, "getServerSideProps");
const config = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_miner_miner_tsx__WEBPACK_IMPORTED_MODULE_5__, "config");
const reportWebVitals = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_miner_miner_tsx__WEBPACK_IMPORTED_MODULE_5__, "reportWebVitals");
// Re-export legacy methods.
const unstable_getStaticProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_miner_miner_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticProps");
const unstable_getStaticPaths = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_miner_miner_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticPaths");
const unstable_getStaticParams = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_miner_miner_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticParams");
const unstable_getServerProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_miner_miner_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getServerProps");
const unstable_getServerSideProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_miner_miner_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getServerSideProps");
// Create and export the route module that will be consumed.
const routeModule = new PagesRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__/* .RouteKind */ .x.PAGES,
        page: "/miner/[miner]",
        pathname: "/miner/[miner]",
        // The following aren't used in production.
        bundlePath: "",
        filename: ""
    },
    components: {
        App: private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__["default"],
        Document: private_next_pages_document_tsx__WEBPACK_IMPORTED_MODULE_3__["default"]
    },
    userland: private_next_pages_miner_miner_tsx__WEBPACK_IMPORTED_MODULE_5__
});

//# sourceMappingURL=pages.js.map
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 57520:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8054);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _src_detail_accountBalance__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(19866);
/* harmony import */ var _src_detail_Power__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(64362);
/* harmony import */ var _src_detail_overView__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(97986);
/* harmony import */ var _contents_detail__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(78817);
/* harmony import */ var _src_detail_accountChange__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(16735);
/* harmony import */ var _src_detail_powerChange__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(87916);
/* harmony import */ var _src_detail_list__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(31830);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(62881);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(29676);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(6148);
/* harmony import */ var _style_module_scss__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(_style_module_scss__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _components_copy__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(25174);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(68108);
/* harmony import */ var _src_detail_accountDetail__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(41725);
/* harmony import */ var _assets_images_icon_copy_svg__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(45903);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_src_detail_accountBalance__WEBPACK_IMPORTED_MODULE_4__, _src_detail_Power__WEBPACK_IMPORTED_MODULE_5__, _src_detail_overView__WEBPACK_IMPORTED_MODULE_6__, _contents_detail__WEBPACK_IMPORTED_MODULE_7__, _src_detail_accountChange__WEBPACK_IMPORTED_MODULE_8__, _src_detail_powerChange__WEBPACK_IMPORTED_MODULE_9__, _src_detail_list__WEBPACK_IMPORTED_MODULE_10__, _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_11__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_15__, _src_detail_accountDetail__WEBPACK_IMPORTED_MODULE_16__]);
([_src_detail_accountBalance__WEBPACK_IMPORTED_MODULE_4__, _src_detail_Power__WEBPACK_IMPORTED_MODULE_5__, _src_detail_overView__WEBPACK_IMPORTED_MODULE_6__, _contents_detail__WEBPACK_IMPORTED_MODULE_7__, _src_detail_accountChange__WEBPACK_IMPORTED_MODULE_8__, _src_detail_powerChange__WEBPACK_IMPORTED_MODULE_9__, _src_detail_list__WEBPACK_IMPORTED_MODULE_10__, _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_11__, _store_useAxiosData__WEBPACK_IMPORTED_MODULE_15__, _src_detail_accountDetail__WEBPACK_IMPORTED_MODULE_16__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/** @format */ 


















/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { miner } = router.query;
    const [data, setData] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)({});
    const [loadingBalance, setBalanceLoading] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(true);
    const [method, setMethod] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)([]);
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_11__/* .Translation */ .W)({
        ns: "detail"
    });
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z)();
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        let newMiner = miner;
        if (miner === "miner" || miner === "address") {
            newMiner = router?.query?.miner || router?.query?.address;
        }
        if (newMiner && typeof newMiner === "string") {
            loadMinerData(newMiner);
            loadMethod();
        }
    }, [
        miner,
        router
    ]);
    const loadMethod = async ()=>{
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.detail_list_method, {
            account_id: miner
        }, {
            isCancel: false
        });
        const newMethod = [
            {
                title: tr("all_method"),
                dataIndex: "all",
                value: "all"
            }
        ];
        Object.keys(result?.method_name_list || {}).forEach((li)=>{
            newMethod.push({
                label: li,
                dataIndex: li,
                value: li
            });
        });
        setMethod(newMethod);
    };
    const loadMinerData = async (minerId)=>{
        try {
            setBalanceLoading(true);
            const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_1__/* .apiUrl */ .JW.detail_account, {
                account_id: minerId || miner
            }, {
                isCancel: false
            });
            setData(result?.account_info?.account_miner || {});
        } catch (error) {
            console.error(error); // 这里可以打印错误信息，或者进行其他的错误处理
        } finally{
            setBalanceLoading(false); // 无论是否发生错误，都将 loading 状态设置为 false
        }
    // setBalanceLoading(true);
    // const result: any = await axiosData(apiUrl.detail_account, {
    //   account_id: miner,
    // });
    // setBalanceLoading(false);
    // setData(result?.account_info?.account_miner || {});
    };
    const newTabList = (0,react__WEBPACK_IMPORTED_MODULE_3__.useMemo)(()=>{
        const newTabs = [];
        _contents_detail__WEBPACK_IMPORTED_MODULE_7__/* .minerTabs */ .xR.forEach((v)=>{
            if (v?.optionsUrl === "AllMethodByAccountID") {
                v.headerOptions = method;
            }
            newTabs.push({
                ...v
            });
        });
        return newTabs;
    }, [
        method
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_13___default()((_style_module_scss__WEBPACK_IMPORTED_MODULE_18___default().miner), "main_contain"),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_13___default()("mb-2.5 DINPro-Medium font-medium text-lg flex items-center", (_style_module_scss__WEBPACK_IMPORTED_MODULE_18___default()["title-wrap"])),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_12__/* .BrowserView */ .I, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: classnames__WEBPACK_IMPORTED_MODULE_13___default()("ml-4 flex items-center gap-x-1", (_style_module_scss__WEBPACK_IMPORTED_MODULE_18___default().title)),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    children: [
                                        tr("account_title"),
                                        ":"
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: miner || ""
                                }),
                                miner && typeof miner === "string" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                                    text: miner
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_12__/* .MobileView */ .$, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: classnames__WEBPACK_IMPORTED_MODULE_13___default()("ml-4 flex items-center gap-x-1", (_style_module_scss__WEBPACK_IMPORTED_MODULE_18___default().title)),
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    children: [
                                        tr("account_title"),
                                        ":"
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    className: "copy-row",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "normal-text",
                                            children: miner || ""
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            children: miner && typeof miner === "string" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                                                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_icon_copy_svg__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {}),
                                                text: miner,
                                                className: "copy-lg"
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_13___default()("flex w-full card_shadow rounded-xl !overflow-hidden", (_style_module_scss__WEBPACK_IMPORTED_MODULE_18___default().balance)),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_detail_accountBalance__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        data: data?.account_indicator || {},
                        loading: loadingBalance
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_detail_Power__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        data: data?.account_indicator || {}
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_detail_overView__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                overView: _contents_detail__WEBPACK_IMPORTED_MODULE_7__/* .miner_overview */ .Nt,
                accountId: miner
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_13___default()((_style_module_scss__WEBPACK_IMPORTED_MODULE_18___default().column), "flex mt-6 gap-x-5"),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_detail_accountChange__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        accountId: miner,
                        interval: "1m"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_detail_powerChange__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                        accountId: miner,
                        type: "miner"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_detail_accountDetail__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                data: data,
                type: "miner"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_detail_list__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                    tabList: newTabList,
                    defaultActive: "message_list",
                    accountId: miner
                })
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 41725:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _components_device_detect__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(29676);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(62881);
/* harmony import */ var _contents_detail__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(78817);
/* harmony import */ var _packages_content__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(55586);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(59003);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(64168);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(31061);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(23495);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(41664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_copy__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(25174);
/* harmony import */ var _assets_images_icon_copy_svg__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(45903);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_detail__WEBPACK_IMPORTED_MODULE_3__, _packages_content__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_8__]);
([_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__, _contents_detail__WEBPACK_IMPORTED_MODULE_3__, _packages_content__WEBPACK_IMPORTED_MODULE_4__, _utils__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);













/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ data, type })=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_2__/* .Translation */ .W)({
        ns: "detail"
    });
    const { isMobile } = (0,_components_hooks_useWindown__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    const contents = (0,react__WEBPACK_IMPORTED_MODULE_6__.useMemo)(()=>{
        if (type === "owner") {
            return _contents_detail__WEBPACK_IMPORTED_MODULE_3__/* .owner_detail_overview */ .Ef.list;
        }
        return _contents_detail__WEBPACK_IMPORTED_MODULE_3__/* .account_detail */ .fm.list(tr).map((value)=>{
            if (isMobile) {
                if (value.dataIndex === "peer_id") {
                    value.render = (text, record)=>{
                        if (!text) return "--";
                        const accountId = record?.account_basic?.account_id;
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "flex items-baseline gap-x-2 copy-row",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    className: "text",
                                    children: [
                                        " ",
                                        accountId ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_9___default()), {
                                            href: `/peer/${accountId}`,
                                            className: "link_text",
                                            children: (0,_utils__WEBPACK_IMPORTED_MODULE_8__/* .isIndent */ .EA)(text, 10)
                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            children: (0,_utils__WEBPACK_IMPORTED_MODULE_8__/* .isIndent */ .EA)(text, 10)
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                    text: text,
                                    icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_icon_copy_svg__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {}),
                                    className: "copy"
                                })
                            ]
                        });
                    };
                }
                if (value.dataIndex === "owner_address") {
                    value.render = (text)=>{
                        if (!text) return "--";
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "flex items-baseline gap-x-2 copy-row",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "text",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_9___default()), {
                                        href: `/address/${text}`,
                                        className: "link",
                                        children: (0,_utils__WEBPACK_IMPORTED_MODULE_8__/* .isIndent */ .EA)(text, 10)
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                    text: text,
                                    icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_icon_copy_svg__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {}),
                                    className: "copy"
                                })
                            ]
                        });
                    };
                }
                if (value.dataIndex === "worker_address") {
                    value.render = (text)=>{
                        if (!text) return "--";
                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                            className: "flex items-baseline gap-x-2 copy-row",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_9___default()), {
                                    href: `/address/${text}`,
                                    className: "link_text",
                                    children: (0,_utils__WEBPACK_IMPORTED_MODULE_8__/* .isIndent */ .EA)(text, 10)
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                    text: text,
                                    icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_icon_copy_svg__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {}),
                                    className: "copy"
                                })
                            ]
                        });
                    };
                }
                if (value.dataIndex === "beneficiary_address") {
                    value.render = (text, record)=>{
                        if (!text) return "--";
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex flex-wrap items-baseline gap-x-2 copy-row",
                            children: text && Array.isArray(text) ? text?.map((linkItem, index)=>{
                                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    className: "flex items-baseline gap-x-2",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "text",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_9___default()), {
                                                href: `/address/${linkItem}`,
                                                className: "link_text",
                                                children: (0,_utils__WEBPACK_IMPORTED_MODULE_8__/* .isIndent */ .EA)(linkItem, 10)
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                            text: linkItem,
                                            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_icon_copy_svg__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {}),
                                            className: "copy"
                                        })
                                    ]
                                }, linkItem);
                            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "flex items-baseline gap-x-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "text",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_9___default()), {
                                            href: `/address/${text}`,
                                            className: "link_text",
                                            children: (0,_utils__WEBPACK_IMPORTED_MODULE_8__/* .isIndent */ .EA)(text, 10)
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_copy__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                        text: text,
                                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_images_icon_copy_svg__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {}),
                                        className: "copy"
                                    })
                                ]
                            })
                        });
                    };
                }
            }
            return value;
        });
    }, [
        type
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: classnames__WEBPACK_IMPORTED_MODULE_5___default()("mt-5", (_index_module_scss__WEBPACK_IMPORTED_MODULE_12___default().wrap)),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_5___default()("mb-2 h-[32px] text-lg font-semibold mr-5 name-height mx-2.5", (_index_module_scss__WEBPACK_IMPORTED_MODULE_12___default().title)),
                children: tr(type === "owner" ? "owner_title" : "account_overview")
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: classnames__WEBPACK_IMPORTED_MODULE_5___default()("card_shadow w-full border rounded-xl p-2.5 pt-5 border_color", (_index_module_scss__WEBPACK_IMPORTED_MODULE_12___default().content)),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_1__/* .MobileView */ .$, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_content__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                            contents: contents,
                            ns: "detail",
                            columns: 1,
                            data: data
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_device_detect__WEBPACK_IMPORTED_MODULE_1__/* .BrowserView */ .I, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_packages_content__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                            contents: contents,
                            ns: "detail",
                            columns: type === "owner" ? 1 : 2,
                            data: data
                        })
                    })
                ]
            })
        ]
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 52727:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/cssinjs");

/***/ }),

/***/ 77529:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons/lib/icons/LoadingOutlined");

/***/ }),

/***/ 86762:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons/lib/icons/LockOutlined");

/***/ }),

/***/ 62127:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons/lib/icons/UserOutlined");

/***/ }),

/***/ 92616:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/config-provider");

/***/ }),

/***/ 1788:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/dropdown");

/***/ }),

/***/ 30675:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/input");

/***/ }),

/***/ 4946:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/locale/en_US");

/***/ }),

/***/ 79353:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/locale/zh_CN");

/***/ }),

/***/ 10274:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/menu");

/***/ }),

/***/ 17369:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/message");

/***/ }),

/***/ 14528:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/pagination");

/***/ }),

/***/ 53526:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/select");

/***/ }),

/***/ 71030:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/skeleton");

/***/ }),

/***/ 74285:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/table");

/***/ }),

/***/ 69348:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/tooltip");

/***/ }),

/***/ 59003:
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ 68887:
/***/ ((module) => {

"use strict";
module.exports = require("copy-to-clipboard");

/***/ }),

/***/ 1635:
/***/ ((module) => {

"use strict";
module.exports = require("dayjs");

/***/ }),

/***/ 29201:
/***/ ((module) => {

"use strict";
module.exports = require("echarts");

/***/ }),

/***/ 46517:
/***/ ((module) => {

"use strict";
module.exports = require("lodash");

/***/ }),

/***/ 36211:
/***/ ((module) => {

"use strict";
module.exports = require("mobx");

/***/ }),

/***/ 22062:
/***/ ((module) => {

"use strict";
module.exports = require("mobx-react");

/***/ }),

/***/ 16641:
/***/ ((module) => {

"use strict";
module.exports = require("next-seo");

/***/ }),

/***/ 43076:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module.js");

/***/ }),

/***/ 94140:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 89716:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 33100:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 76368:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 53918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 45732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 56724:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 35132:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 18743:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/html-context.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 50744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 35843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 95832:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 93431:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 11751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 71109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 28854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 93297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 87782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 82470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 40618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 71853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 16689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 66405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 94612:
/***/ ((module) => {

"use strict";
module.exports = require("use-deep-compare-effect");

/***/ }),

/***/ 99648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 49766:
/***/ ((module) => {

"use strict";
module.exports = import("bignumber.js");;

/***/ }),

/***/ 22021:
/***/ ((module) => {

"use strict";
module.exports = import("i18next");;

/***/ }),

/***/ 57987:
/***/ ((module) => {

"use strict";
module.exports = import("react-i18next");;

/***/ }),

/***/ 34325:
/***/ ((module) => {

"use strict";
module.exports = import("web3");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8355,5152,1163,430,8087,5622,5509,5586,1921,8817,3469,869,3055,1830,9918], () => (__webpack_exec__(82385)));
module.exports = __webpack_exports__;

})();