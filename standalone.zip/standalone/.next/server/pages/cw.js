(() => {
var exports = {};
exports.id = 9742;
exports.ids = [9742];
exports.modules = {

/***/ 91185:
/***/ ((module) => {

// Exports
module.exports = {
	"t-height": "cw_t-height__BYY_x",
	"t-miner": "cw_t-miner__8jHdJ",
	"cw_contain": "cw_cw_contain__xJIvO",
	"donut": "cw_donut__6cmwC",
	"donut-spin": "cw_donut-spin__OR0fy",
	"donut-wrap": "cw_donut-wrap__wY8Yc",
	"bc-search": "cw_bc-search__SvNZt",
	"back-top": "cw_back-top__TOGF1",
	"tip-show": "cw_tip-show__hWbOs",
	"block-header": "cw_block-header__3LxRV",
	"block-header-search": "cw_block-header-search__IG3dz",
	"block-header-chart": "cw_block-header-chart__y3edC",
	"block-header-chart-noData": "cw_block-header-chart-noData__qtQ1x",
	"lc-tooltip": "cw_lc-tooltip__twbsD",
	"top-wrap": "cw_top-wrap___XaIl"
};


/***/ }),

/***/ 48443:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"https://filscan-v2.oss-accelerate.aliyuncs.com/client/_next/static/media/loading.f5615e5e.png","height":800,"width":800,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 62968:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   config: () => (/* binding */ config),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   getServerSideProps: () => (/* binding */ getServerSideProps),
/* harmony export */   getStaticPaths: () => (/* binding */ getStaticPaths),
/* harmony export */   getStaticProps: () => (/* binding */ getStaticProps),
/* harmony export */   reportWebVitals: () => (/* binding */ reportWebVitals),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   unstable_getServerProps: () => (/* binding */ unstable_getServerProps),
/* harmony export */   unstable_getServerSideProps: () => (/* binding */ unstable_getServerSideProps),
/* harmony export */   unstable_getStaticParams: () => (/* binding */ unstable_getStaticParams),
/* harmony export */   unstable_getStaticPaths: () => (/* binding */ unstable_getStaticPaths),
/* harmony export */   unstable_getStaticProps: () => (/* binding */ unstable_getStaticProps)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(23185);
/* harmony import */ var next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(35244);
/* harmony import */ var next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57182);
/* harmony import */ var private_next_pages_document_tsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(13162);
/* harmony import */ var private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(44178);
/* harmony import */ var private_next_pages_cw_index_tsx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(18518);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__, private_next_pages_cw_index_tsx__WEBPACK_IMPORTED_MODULE_5__]);
([private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__, private_next_pages_cw_index_tsx__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
// @ts-ignore this need to be imported from next/dist to be external



// Import the app and document modules.
// @ts-expect-error - replaced by webpack/turbopack loader

// @ts-expect-error - replaced by webpack/turbopack loader

// Import the userland code.
// @ts-expect-error - replaced by webpack/turbopack loader

const PagesRouteModule = next_dist_server_future_route_modules_pages_module__WEBPACK_IMPORTED_MODULE_0__.PagesRouteModule;
// Re-export the component (should be the default export).
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_cw_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "default"));
// Re-export methods.
const getStaticProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_cw_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "getStaticProps");
const getStaticPaths = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_cw_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "getStaticPaths");
const getServerSideProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_cw_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "getServerSideProps");
const config = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_cw_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "config");
const reportWebVitals = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_cw_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "reportWebVitals");
// Re-export legacy methods.
const unstable_getStaticProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_cw_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticProps");
const unstable_getStaticPaths = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_cw_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticPaths");
const unstable_getStaticParams = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_cw_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getStaticParams");
const unstable_getServerProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_cw_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getServerProps");
const unstable_getServerSideProps = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_cw_index_tsx__WEBPACK_IMPORTED_MODULE_5__, "unstable_getServerSideProps");
// Create and export the route module that will be consumed.
const routeModule = new PagesRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__/* .RouteKind */ .x.PAGES,
        page: "/cw",
        pathname: "/cw",
        // The following aren't used in production.
        bundlePath: "",
        filename: ""
    },
    components: {
        App: private_next_pages_app_tsx__WEBPACK_IMPORTED_MODULE_4__["default"],
        Document: private_next_pages_document_tsx__WEBPACK_IMPORTED_MODULE_3__["default"]
    },
    userland: private_next_pages_cw_index_tsx__WEBPACK_IMPORTED_MODULE_5__
});

//# sourceMappingURL=pages.js.map
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 18518:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(91185);
/* harmony import */ var _index_module_scss__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_index_module_scss__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _src_cw_leecharts__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(25414);
/* harmony import */ var _contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8054);
/* harmony import */ var _assets_images_loading_png__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(48443);
/* harmony import */ var _store_useAxiosData__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(68108);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(25675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var mytoolkit__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(95153);
/* harmony import */ var mytoolkit__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(mytoolkit__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _src_cw_utils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(84727);
/* harmony import */ var _store_FilscanStore__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(48804);
/* harmony import */ var _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(62881);
/* harmony import */ var _store_modules_Cw__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(85166);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(22062);
/* harmony import */ var mobx_react__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(mobx_react__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _src_cw_Search__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(39297);
/* harmony import */ var _svgsIcon__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7947);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_15__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_store_useAxiosData__WEBPACK_IMPORTED_MODULE_5__, _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_10__, _src_cw_Search__WEBPACK_IMPORTED_MODULE_13__]);
([_store_useAxiosData__WEBPACK_IMPORTED_MODULE_5__, _components_hooks_Translation__WEBPACK_IMPORTED_MODULE_10__, _src_cw_Search__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);

















const baseYAxis = 30;
const calcHeight = 100;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,mobx_react__WEBPACK_IMPORTED_MODULE_12__.observer)(()=>{
    const { tr } = (0,_components_hooks_Translation__WEBPACK_IMPORTED_MODULE_10__/* .Translation */ .W)({
        ns: "static"
    });
    const { theme } = (0,_store_FilscanStore__WEBPACK_IMPORTED_MODULE_9__/* .useFilscanStore */ .J)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_15__.useRouter)();
    // const [drawData, setDrawData] = useState<Array<any>>([]);
    const [chartLoading, setChartLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const chartContainerRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const chartRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const { finalHeight } = _store_modules_Cw__WEBPACK_IMPORTED_MODULE_11__["default"];
    const { axiosData } = (0,_store_useAxiosData__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    const blockMap = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)({});
    const transformX = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(0);
    const transformY = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(30);
    const k = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(1);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        reDrawChart();
    }, [
        theme
    ]);
    const chartColor = {
        dark: {
            cidColor: "#ffffff",
            linkColor: `rgba(102,102,102,1)`,
            yLinkColor: `rgba(51, 51, 51, 1)`,
            yCircleColor: "#000000",
            fistText: `rgba(255,255,255,1)`,
            yAxisColor: `rgba(255,255,255,0.6)`,
            textColor: `rgba(255,255,255,0.6)`
        },
        light: {
            cidColor: "#000000",
            linkColor: `rgba(216,216,216,1)`,
            yLinkColor: `rgba(238, 239, 241, 1)`,
            yCircleColor: "#FFFFFF",
            fistText: `rgba(0,0,0,1)`,
            yAxisColor: `rgba(0,0,0,0.6)`,
            textColor: `rgba(0,0,0,0.6)`
        }
    };
    //chart
    const stageClipId = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)("lc-" + (0,mytoolkit__WEBPACK_IMPORTED_MODULE_7__.randStr)(8));
    const axisXClipId = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)("lc-" + (0,mytoolkit__WEBPACK_IMPORTED_MODULE_7__.randStr)(8));
    const axisYClipId = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)("lc-" + (0,mytoolkit__WEBPACK_IMPORTED_MODULE_7__.randStr)(8));
    const bhm = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const blockHeightList = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const drawData = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)([]);
    const searchCid = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)("");
    const searchHeight = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const finalCurrentHeight = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const endHeight = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const reset = ()=>{
        transformX.current = 0;
        transformY.current = 30;
        k.current = 1;
        blockMap.current = {};
        bhm.current = null;
        blockHeightList.current = null;
        drawData.current = null;
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        window.addEventListener("resize", onResize);
        if (finalCurrentHeight.current) {
            init();
        }
        return ()=>{
            window.removeEventListener("resize", onResize);
            if (chartRef.current) {
                chartRef.current.destroy();
            }
        };
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (finalHeight && !finalCurrentHeight.current) {
            finalCurrentHeight.current = finalHeight;
            init();
        }
    }, [
        finalHeight
    ]);
    const init = ()=>{
        if (chartRef.current) {
            chartRef.current.destroy();
        }
        chartRef.current = (0,_src_cw_leecharts__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(chartContainerRef.current);
        getBlocks();
        let container = chartContainerRef.current;
        let cc = window.document.querySelector(".chart-wrapper");
        let innerHeight = window.screen.availHeight;
        let containerHeight = innerHeight;
        containerHeight = cc?.getBoundingClientRect().height;
        (0,mytoolkit__WEBPACK_IMPORTED_MODULE_7__.setStyle)(container, "height", containerHeight);
    };
    const getBlocks = async (value, type)=>{
        const end = Number(value) || finalCurrentHeight.current;
        endHeight.current = end;
        setChartLoading(true);
        let payload = {
            filters: {
                start: end - calcHeight,
                end: end
            }
        };
        if (type === "cid") {
            payload = {
                filters: {
                    cid: value,
                    len: calcHeight
                }
            };
        }
        const result = await axiosData(_contents_apiUrl__WEBPACK_IMPORTED_MODULE_3__/* .cwUrl */ .eU, payload);
        let resultData = result?.tipset_list || [];
        let newData = [];
        let bhmObj = {};
        if (type === "cid" || type === "height") {
            reset();
        }
        const res = [
            ...resultData
        ];
        // resultData.forEach((v:any) => {
        //   if (v?.ChainBlocks) {
        //     res.push(v)
        //   } else if (v?.OrphanBlocks?.length > 0) {
        //     res.push(v)
        //   }
        // });
        if (type === "up") {
            //滚动条向下请求
            newData = [
                ...drawData.current,
                ...res
            ];
        } else {
            newData = [
                ...res
            ];
        }
        const blockList = [];
        const calcData = [];
        if (newData.length > 0) {
            newData.forEach((v)=>{
                //[孤块,高度]｜[高度]
                bhmObj[v.Height] = v.OrphanBlocks ? [
                    v.OrphanBlocks,
                    v.ChainBlocks
                ] : [
                    v.ChainBlocks
                ];
                blockList.push(v.Height);
                let showSearch = false;
                if (v.ChainBlocks && v.ChainBlocks.length > 0) {
                    v.ChainBlocks.forEach((chainItem)=>{
                        blockMap.current[chainItem._id] = chainItem;
                        if (type === "cid" && chainItem._id === searchCid.current) {
                            showSearch = true;
                            searchHeight.current = Number(chainItem.Epoch);
                        }
                    });
                    calcData.push(v);
                } else if (v?.OrphanBlocks?.length > 0) {
                    calcData.push(v);
                }
                if (!showSearch && v?.OrphanBlocks?.length > 0) {
                    v.OrphanBlocks.forEach((orphanItem)=>{
                        if (type === "cid" && orphanItem._id === searchCid.current) {
                            showSearch = true;
                            console.log("----333", orphanItem);
                            searchHeight.current = Number(orphanItem.Epoch);
                        }
                    });
                }
            });
            if (type === "cid" && calcData.length > 0) {
                endHeight.current = calcData[0].Height - 1;
            }
            drawData.current = [
                ...calcData
            ];
            bhm.current = bhmObj;
            blockHeightList.current = blockList;
            drawChart(calcData, bhmObj, blockList);
        }
        setChartLoading(false);
    };
    const clearDrawChart = (value, type)=>{
        if (chartRef.current) {
            chartRef.current.destroy();
        }
        chartRef.current = (0,_src_cw_leecharts__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(chartContainerRef.current);
        getBlocks(value, type);
    };
    const reDrawChart = ()=>{
        if (drawData?.current && bhm?.current && blockHeightList?.current) {
            drawChart(drawData.current, bhm.current, blockHeightList.current);
        }
    };
    const drawChart = (data, bhm = {}, blockHeightList)=>{
        let textColor = chartColor[theme]?.textColor;
        let yAxisColor = chartColor[theme].yAxisColor;
        chartRef.current.setOptions({
            grid: {
                top: 0,
                right: 20,
                left: 85,
                bottom: 20
            },
            tooltip: {
                show: true,
                formatter: (toolTipData)=>{
                    let p = "<ul style='padding-top: 10px;'>";
                    (toolTipData.Parents || []).forEach((item)=>{
                        p += `<li style="padding-left: 20px;margin-bottom: 10px;">${item}</li>`;
                    });
                    p += "</ul>";
                    return `
                <div class="tt">
                  <div style="margin-bottom: 10px;">cid: ${toolTipData._id}</div>
                  <div style="margin-bottom: 10px;">miner: ${toolTipData.Miner}</div>
                  <div style="margin-bottom: 10px;">height: ${toolTipData.Epoch}</div>
                  <div style="margin-bottom: 10px;">parent weight: ${toolTipData.ParentWeight}</div>
                              <div>
                                parents:
                                ${p}
                              </div>
                              <div style="margin-bottom: 10px;">block time: ${toolTipData.Timestamp ? (0,mytoolkit__WEBPACK_IMPORTED_MODULE_7__.timeToStr)(toolTipData.Timestamp, "yyyy-mm-dd hh:mm:ss") : ""}</div>
                              <div style="margin-bottom: 10px;">first seen: ${toolTipData.FirstSeen ? (0,mytoolkit__WEBPACK_IMPORTED_MODULE_7__.timeToStr)(toolTipData.FirstSeen, "yyyy-mm-dd hh:mm:ss") : ""}</div>
                            </div>
                          `;
                },
                styles: {
                    background: "rgba(0,0,0,.8)",
                    "font-size": "14px",
                    padding: "20px",
                    color: "#fff",
                    "border-radius": "4px",
                    "box-shadow": "1px 1px 5px #000"
                }
            },
            series: [
                {
                    type: "custom",
                    draw: (chart, layer, s)=>{
                        let d3 = chart.d3;
                        let emitter = chart.emitter;
                        let stageWrap = layer.safeSelect("g.stage-wrap");
                        let axisYWrap = layer.safeSelect("g.ay-wrap");
                        let axisXWrap = layer.safeSelect("g.ax-wrap");
                        // stageWrap.attr(
                        //   "transform",
                        //   `translate(0,20) scale(1)`
                        // )
                        const blockWidth = 160;
                        const blockHeight = 100;
                        const ph = 60;
                        let ellipseRX = 0.95 * blockWidth;
                        let ellipseRY = 0.55 * blockHeight;
                        const heightExtent = [
                            blockHeightList[blockHeightList.length - 1],
                            blockHeightList[0]
                        ];
                        const maxBlockCount = 10;
                        const groupCount = 1;
                        let viewBoxWidth = maxBlockCount * blockWidth + groupCount * ph;
                        let viewBoxHeight = (heightExtent[1] - heightExtent[0]) * blockHeight;
                        let stageWidth = Math.max(viewBoxWidth, chart.containerWidth);
                        let stageHeight = Math.max(viewBoxHeight, chart.containerHeight);
                        let yCalc = d3.scaleLinear().domain(heightExtent).range([
                            stageHeight - chart.gridTop,
                            chart.gridBottom
                        ]);
                        let clipPath, clipPathId, clipRect;
                        // make clip path axis x
                        clipPathId = axisXClipId.current;
                        clipPath = chart.sections.defs.safeSelect(`clipPath#${clipPathId}`);
                        clipRect = clipPath.safeSelect("rect");
                        clipRect.attrs({
                            x: chart.gridLeft,
                            width: chart.containerWidth - chart.gridRight - chart.gridLeft,
                            height: 60
                        });
                        axisXWrap.attr("transform", `translate(0,${chart.containerHeight - chart.gridBottom})`).attr("clip-path", `url(#${clipPathId})`);
                        // axisXWrap.safeSelect("line.border").attrs({
                        //   stroke: "rgba(243,146,27,1)",
                        //   "stroke-width": "6px",
                        //   x2: chart.containerWidth
                        // })
                        // make clip path axis y
                        clipPathId = axisYClipId.current;
                        clipPath = chart.sections.defs.safeSelect(`clipPath#${clipPathId}`);
                        clipRect = clipPath.safeSelect("rect");
                        clipRect.attrs({
                            x: -80,
                            y: chart.gridTop * 2,
                            width: 100,
                            height: chart.containerHeight - chart.gridBottom - chart.gridTop + 3
                        });
                        axisYWrap.attr("clip-path", `url(#${clipPathId})`).attr("transform", `translate(${chart.gridLeft}, ${baseYAxis})`);
                        axisYWrap.safeSelect("line.border").attrs({
                            stroke: chartColor[theme].yLinkColor,
                            "stroke-width": "2px",
                            y2: chart.containerHeight
                        });
                        axisYWrap.safeSelect("line.border").attr("stroke-dasharray", "2, 4");
                        axisYWrap.safeSelect("g.axis-y").call(d3.axisLeft(yCalc).ticks(Math.round(heightExtent[1] - heightExtent[0])));
                        axisYWrap.safeSelect("path.domain").attrs({
                            stroke: "rgba(0,0,0,0)"
                        });
                        let yTicks = axisYWrap.safeSelect("g.axis-y").selectAll("g.tick");
                        yTicks.each(function(yData) {
                            //@ts-ignore
                            let t = d3.select(this);
                            t.safeSelect("line").attr("stroke", chartColor[theme].yLinkColor);
                            t.safeSelect("text").attrs({
                                fill: Number(searchHeight.current) === Number(yData) ? "rgba(29, 107, 253, 1)" : yAxisColor,
                                "font-size": 14
                            });
                            t.safeSelect("circle").attrs({
                                stroke: Number(searchHeight.current) === Number(yData) ? "rgba(29, 107, 253, 1)" : chartColor[theme].yLinkColor,
                                "stroke-width": "2px",
                                fill: chartColor[theme].yCircleColor,
                                r: 4
                            });
                        });
                        if (Object.keys(blockMap.current).length === 0) {
                            return;
                        }
                        //make clip path for stage
                        let stage = stageWrap.safeSelect("g.c-stage");
                        clipPathId = stageClipId.current;
                        clipPath = chart.sections.defs.safeSelect(`clipPath#${clipPathId}`);
                        clipRect = clipPath.safeSelect("rect");
                        clipRect.attrs({
                            x: chart.gridLeft,
                            y: chart.gridTop,
                            width: chart.containerWidth - chart.gridRight - chart.gridLeft,
                            height: chart.containerHeight - chart.gridBottom - chart.gridTop
                        });
                        stageWrap.attr("clip-path", `url(#${clipPathId})`);
                        let linkGroup = stage.safeSelect("g.link-group");
                        let tipsetGroup = stage.safeSelect("g.tipset-group");
                        let tipsetList = [];
                        let forkEndLinkGroup = stage.safeSelect("g.fork-end-link-group");
                        let nodeGroup = stage.safeSelect("g.node-group");
                        nodeGroup.selectAll("g.block-height").data(s.data).join("g.block-height").each(function(blh, numIndex) {
                            //@ts-ignore
                            const self = this; // 👈️ closure of this
                            let bhEle = d3.select(self);
                            let groupList = bhm[blh] || [];
                            let groupWidth = (0,_src_cw_utils__WEBPACK_IMPORTED_MODULE_8__/* .getGroupListWidth */ .kn)(groupList, blockWidth, ph);
                            let gx = (stageWidth - groupWidth) / 2;
                            bhEle.selectAll("g.block-group").data(groupList).join("g.block-group").each(function(blockGroupData, bhEIndex) {
                                //@ts-ignore
                                let bgEle = d3.select(this);
                                let blockGroup = blockGroupData;
                                if (blockGroup) {
                                    let gw = (0,_src_cw_utils__WEBPACK_IMPORTED_MODULE_8__/* .getGroupListWidth */ .kn)(blockGroup || [], blockWidth, 0);
                                    let showGray = groupList.length === 2 && bhEIndex === 0;
                                    blockGroup.x = gx;
                                    //数据高度：
                                    blockGroup.y = yCalc(blockGroup[0]?.Epoch) - blockHeight * 0.35;
                                    blockGroup.width = gw;
                                    blockGroup.height = blockHeight * 0.7;
                                    gx += gw + ph;
                                    tipsetList.push({
                                        x: blockGroup.x - 5,
                                        y: blockGroup.y + baseYAxis,
                                        width: blockGroup.width + 10,
                                        height: blockGroup.height,
                                        fill: showGray ? "rgba(102, 102, 102, 0.1)" : _src_cw_utils__WEBPACK_IMPORTED_MODULE_8__/* .colors */ .O9[numIndex % _src_cw_utils__WEBPACK_IMPORTED_MODULE_8__/* .colors */ .O9.length],
                                        rx: 10,
                                        ry: 10
                                    });
                                    blockGroup[0].tipsetList = blockGroup[0]?.tipsetList || [];
                                    blockGroup[0].tipsetList.push(blockGroup);
                                    bgEle.selectAll("g.block-header").data(blockGroup).join("g.block-header").each(function(d, i) {
                                        let curHeight = d.Epoch;
                                        const showCid = searchCid.current === d._id;
                                        let showColor = _src_cw_utils__WEBPACK_IMPORTED_MODULE_8__/* .colorsText */ .uK[numIndex % _src_cw_utils__WEBPACK_IMPORTED_MODULE_8__/* .colorsText */ .uK.length];
                                        if (theme === "light") {
                                        // showColor = 'rgba(255,255,255,1)'
                                        }
                                        if (showCid) {
                                            showColor = "rgba(29, 107, 253, 1)";
                                        }
                                        //@ts-ignore
                                        let bh = d3.select(this);
                                        let wrapX = blockGroup.x + (i + 0.5) * blockWidth;
                                        let wrapY = yCalc(curHeight) + baseYAxis;
                                        d.x = wrapX;
                                        d.y = wrapY;
                                        bh.attr("transform", `translate(${wrapX}, ${wrapY})`);
                                        // bh.safeSelect("ellipse")
                                        //   .attrs({
                                        //     rx: ellipseRX,
                                        //     ry: ellipseRY,
                                        //     fill: mainColor
                                        //   })
                                        bh.on("mouseover", onMMove).on("mouseout", onMOut);
                                        bh.on("click", function() {
                                            router.push(`/cid/${d._id}`);
                                        });
                                        bh.safeSelect("rect").attrs({
                                            width: ellipseRX,
                                            height: ellipseRY,
                                            fill: showGray && !showCid ? "rgba(102, 102, 102, 0.6)" : showColor,
                                            rx: 3,
                                            ry: 3,
                                            x: -ellipseRX / 2,
                                            y: -ellipseRY / 2
                                        });
                                        bh.safeSelect("text.t-height").text(`${(0,_src_cw_utils__WEBPACK_IMPORTED_MODULE_8__/* .dotString */ .dP)(d._id)}`).attrs({
                                            fill: showGray || showCid ? "#ffffff" : chartColor[theme].cidColor,
                                            y: -12,
                                            "text-anchor": "middle",
                                            "font-size": 12
                                        }).on("click", function() {
                                        // vue中的bci是this，指向的是这个组件，但组件上没有goto方法，需要确认
                                        // goto 需要自己实现，看起来是跳转到另一个页面
                                        // bci.goTo("tipset", {
                                        //   query: { hash: d.cid }
                                        // })
                                        });
                                        bh.safeSelect("text.t-miner").text(`${d.Miner} - ${d.Epoch}`).attrs({
                                            fill: showGray || showCid ? "#ffffff" : textColor,
                                            "text-anchor": "middle",
                                            "font-size": 11,
                                            y: 5
                                        }).on("click", function() {
                                        // goto需要自己实现，看起来是跳转到另一个页面
                                        // bci.goTo("addressDetail", {
                                        //   query: { address: d.miner }
                                        // })
                                        });
                                        bh.safeSelect("text.t-time").text(`${(0,mytoolkit__WEBPACK_IMPORTED_MODULE_7__.timeToStr)(d.FirstSeen, "yyyy-mm-dd hh:mm:ss")}`).attrs({
                                            fill: showGray || showCid ? "#ffffff" : textColor,
                                            "text-anchor": "middle",
                                            "font-size": 10,
                                            y: 20
                                        });
                                        let switchTooltip = makeSwitchTooltip();
                                        function onMMove() {
                                            switchTooltip(true, d3.event);
                                        }
                                        function onMOut() {
                                            switchTooltip(false, d3.event);
                                        }
                                        function makeSwitchTooltip() {
                                            let timeHandle = null;
                                            let shouldShow = false;
                                            let delta = 100;
                                            return (show, d3Event)=>{
                                                shouldShow = show;
                                                if (timeHandle) {
                                                    clearTimeout(timeHandle);
                                                }
                                                timeHandle = setTimeout(()=>{
                                                    let emitData = {
                                                        type: "item",
                                                        data: null
                                                    };
                                                    if (shouldShow) {
                                                        emitData.data = d;
                                                        emitData.event = d3Event;
                                                    }
                                                    emitter.emit("showTooltip", emitData);
                                                    timeHandle = null;
                                                }, delta);
                                            };
                                        }
                                    });
                                }
                            });
                        });
                        tipsetGroup.selectAll("rect.tipset").data(tipsetList).join("rect.tipset").each(function(d) {
                            //@ts-ignore
                            d3.select(this).attrs(d);
                        });
                        //next link
                        let [linkData, forkEndLinkData] = getLinkData(data, blockMap.current);
                        linkGroup.selectAll("g.link").data(linkData).join("g.link").each(function(d) {
                            //@ts-ignore
                            let lg = d3.select(this);
                            let p1 = {}, p2 = {};
                            p1.x = d.start.x + d.start.width / 2;
                            p1.y = d.start.y + blockHeight * 0.7 + baseYAxis;
                            p2.x = d.end.x + d.end.width / 2;
                            p2.y = d.end.y + baseYAxis;
                            let line = lg.safeSelect("line").attrs({
                                stroke: chartColor[theme].linkColor,
                                "stroke-width": 1,
                                x1: p1.x,
                                y1: p1.y,
                                x2: p2.x,
                                y2: p2.y
                            });
                            if (d.type == "fork") {
                                line.attr("stroke-dasharray", "8, 4");
                            }
                            let wtY = p1.y - p2.y;
                            let wtX = p1.x - p2.x;
                            let angleTan = Math.abs(wtY) / Math.abs(wtX);
                            let angDegree = getTanDeg(angleTan);
                            if (wtX < 0) {
                                angDegree = 180 - angDegree;
                            }
                            let arrowSideLength = 9;
                            let arrowAngle = 25 * Math.PI / 180;
                            lg.safeSelect("path").attrs({
                                transform: `translate(${p2.x}, ${p2.y}) rotate(-${angDegree})`,
                                fill: chartColor[theme].linkColor,
                                d: ()=>{
                                    let c1 = arrowSideLength * Math.cos(arrowAngle);
                                    let c2 = arrowSideLength * Math.sin(arrowAngle);
                                    let d2 = -c2;
                                    return `M0,0L${c1},${d2}L${c1},${c2}z`;
                                }
                            });
                        });
                        forkEndLinkGroup.selectAll("g.link").data(forkEndLinkData).join("g.link").each(function(d) {
                            //@ts-ignore
                            let lg = d3.select(this);
                            let p1 = {}, p2 = {};
                            p1.x = d.start.x + d.start.width / 2;
                            p1.y = d.start.y + blockHeight * 0.7 + baseYAxis;
                            p2.x = d.end.x;
                            p2.y = d.end.y - blockHeight * 0.29;
                            lg.safeSelect("line").attrs({
                                stroke: chartColor[theme].linkColor,
                                "stroke-width": 1,
                                "stroke-dasharray": "8,4",
                                x1: p1.x,
                                y1: p1.y,
                                x2: p2.x,
                                y2: p2.y
                            });
                            let wtY = p1.y - p2.y;
                            let wtX = p1.x - p2.x;
                            let angleTan = Math.abs(wtY) / Math.abs(wtX);
                            let angDegree = getTanDeg(angleTan);
                            if (wtX < 0) {
                                angDegree = 180 - angDegree;
                            }
                            let arrowSideLength = 8;
                            let arrowAngle = 16 * Math.PI / 180;
                            lg.safeSelect("path").attrs({
                                transform: `translate(${p2.x}, ${p2.y}) rotate(-${angDegree})`,
                                fill: chartColor[theme].linkColor,
                                d: ()=>{
                                    let c1 = arrowSideLength * Math.cos(arrowAngle);
                                    let c2 = arrowSideLength * Math.sin(arrowAngle);
                                    let d2 = -c2;
                                    return `M${c1},${d2}L0,0L${c1},${c2}`;
                                }
                            });
                        });
                        //zoom
                        let startT, startX, startY, endX, endY;
                        startX = startY = endX = endY = null;
                        if (transformY.current === 0) {
                            stage.attr("transform", `translate(${transformX.current}, ${transformY.current}) scale(${k.current})`);
                            axisYWrap.select("g.axis-y").attr("transform", `translate(0, ${transformY.current + 50}) scale(1,${k.current})`);
                        }
                        let zoom = d3.zoom().scaleExtent([
                            1,
                            1
                        ]).on("start", zoomStart).on("zoom", zoomed).on("end", zoomEnd);
                        d3.select(".lc-root").call(zoom);
                        function zoomed() {
                            let t = d3.event.transform;
                            let sevent = d3.event.sourceEvent;
                            if (!sevent) {
                                return;
                            }
                            endX = sevent.pageX;
                            endY = sevent.pageY;
                            if (startX === null) {
                                startX = endX;
                                startY = endY;
                            }
                            let dx = endX - startX;
                            let dy = endY - startY;
                            k.current = t.k;
                            stage.attr("transform", `translate(${transformX.current + dx}, ${transformY.current + dy}) scale(${t.k})`);
                            // axisXWrap
                            //   .select("g.axis-x")
                            //   .attr(
                            //     "transform",
                            //     `translate(${bci.transformX + dx}, 0) scale(${t.k}, 1)`
                            //   );
                            axisYWrap.select("g.axis-y").attr("transform", `translate(0, ${transformY.current + dy}) scale(1,${t.k})`);
                        }
                        function zoomStart() {
                            startT = d3.event.transform;
                            let sevent = d3.event.sourceEvent;
                            if (sevent) {
                                startX = sevent.pageX;
                                startY = sevent.pageY;
                            }
                        }
                        function zoomEnd() {
                            if (endY && startY) {
                                transformX.current += endX - startX;
                                transformY.current += endY - startY;
                                startX = startY = endX = endY = null;
                                let t = d3.event.transform;
                                let x = transformX.current;
                                let y = transformY.current;
                                let gx, gy, direction;
                                gx = t.x - startT.x;
                                gy = t.y - startT.y;
                                if (Math.abs(gx) > Math.abs(gy)) {
                                    if (gx > 0) {
                                        direction = "right";
                                    } else if (gx < 0) {
                                        direction = "left";
                                    }
                                } else {
                                    if (gy < 0) {
                                        direction = "up";
                                    } else if (gy > 0) {
                                        direction = "down";
                                    }
                                }
                                if (viewBoxWidth + x + chart.gridRight - chart.containerWidth < 0 && direction === "left") {
                                //fromBottom = false;
                                }
                                if (x > 0 && direction === "right") {
                                //console.log("right", x);
                                //fromBottom = true;
                                }
                                if (y > 0 && direction === "down") {
                                //fromBottom = false;
                                }
                                if (y - chart.containerHeight + viewBoxHeight + chart.gridBottom < 0 && direction === "up") {
                                    // console.log('====0033',endHeight.current)
                                    getBlocks(endHeight.current - calcHeight, "up");
                                } else if (direction === "down" && transformY.current > 30) {
                                // getBlocks(endHeight.current + calcHeight,'down')
                                }
                            }
                            if (transformY.current >= 10) {
                                transformY.current = 10;
                                stage.transition().duration(200).attr("transform", `translate(${transformX.current}, ${transformY.current}) scale(${k.current})`);
                                axisYWrap.select("g.axis-y").transition().duration(200).attr("transform", `translate(0, ${transformY.current}) scale(1,${k.current})`);
                            }
                        }
                    //last
                    },
                    data: blockHeightList
                }
            ]
        });
    };
    const getLinkData = (data, blockMap)=>{
        let linkData = [];
        let forkEndLinkData = [];
        data.forEach((dataItem, index)=>{
            const endIndex = index + 1;
            if (data[endIndex]) {
                const newObj = {
                    start: data[index].ChainBlocks,
                    end: data[endIndex].ChainBlocks,
                    type: "main"
                };
                linkData.push(newObj);
            }
            if (dataItem.OrphanBlocks && Array.isArray(dataItem.OrphanBlocks)) {
                dataItem.OrphanBlocks.forEach((orpItem)=>{
                    if (orpItem.Parents && Array.isArray(orpItem.Parents)) {
                        orpItem.Parents.forEach((parItem)=>{
                            if (blockMap[parItem]) {
                                const newPar = {
                                    start: dataItem.OrphanBlocks,
                                    end: blockMap[parItem],
                                    type: "fork-end"
                                };
                                forkEndLinkData.push(newPar);
                            }
                        });
                    }
                });
            }
        });
        return [
            linkData,
            forkEndLinkData
        ];
    };
    function getTanDeg(tan) {
        let result = Math.atan(tan) / (Math.PI / 180);
        result = Math.round(result);
        return result;
    }
    const onResize = ()=>{
        if (chartRef.current) {
            chartRef.current.resize();
        }
    };
    const handleSearch = (value, type)=>{
        if (value === "") {
            searchCid.current = "";
            searchHeight.current = null;
            getBlocks();
        } else if (type === "height") {
            searchCid.current = "";
            searchHeight.current = Number(value);
            clearDrawChart(Number(value) + 1, type);
        } else if (type === "cid") {
            searchCid.current = value;
            searchHeight.current = null;
            clearDrawChart(value, type);
        }
    };
    const handleClickTop = ()=>{
        finalCurrentHeight.current = finalHeight;
        clearDrawChart(Number(finalHeight) + 1, "height");
    };
    const hasData = !drawData?.current || drawData?.current?.length === 0;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `main_contain ${(_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default().cw_contain)} `,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default()["block-header"])}`,
                children: [
                    (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_14__/* .getSvgIcon */ .a)("tip"),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: tr("cw_des")
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default()["block-header-search"])}`,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_cw_Search__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                    onSearch: handleSearch
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default()["block-header-chart"])} card_shadow border border_color `,
                ref: chartContainerRef
            }),
            !chartLoading && hasData && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `${(_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default()["block-header-chart-noData"])}`,
                children: "No Data"
            }),
            chartLoading && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default()["loading-wrap"]),
                style: {
                    position: "absolute",
                    left: 0,
                    top: 0,
                    width: "100%",
                    height: "100%"
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default()["donut-wrap"]),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_6___default()), {
                        src: _assets_images_loading_png__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z,
                        alt: "",
                        width: 160
                    })
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_index_module_scss__WEBPACK_IMPORTED_MODULE_16___default()["top-wrap"]),
                onClick: handleClickTop,
                children: [
                    (0,_svgsIcon__WEBPACK_IMPORTED_MODULE_14__/* .getSvgIcon */ .a)("upIcon"),
                    tr("cw_top")
                ]
            })
        ]
    });
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 39297:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(85893);
/* harmony import */ var _components_search__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1519);
/* harmony import */ var _ant_design_icons_lib_icons_SearchOutlined__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(99177);
/* harmony import */ var _ant_design_icons_lib_icons_SearchOutlined__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons_lib_icons_SearchOutlined__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_search__WEBPACK_IMPORTED_MODULE_1__]);
_components_search__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (({ onSearch })=>{
    // const [force,setForce]= useState(false)
    const handleSearch = (value)=>{
        if (Number(value)) {
            onSearch(value, "height");
        } else {
            onSearch(value, "cid");
        }
    };
    //bafy2bzacedj7o2cshul2y5ckjrwdfkghiojm3f4aehwwhsuu3xm6ec2tjq4aq
    const handleBlur = ()=>{
    //setForce(false)
    };
    // if(!force ){
    //   return <div className='w-[32px] h-[32px] flex items-center justify-center border border_color rounded-[5px] cursor-pointer' onClick={()=>{setForce(true)}}>
    //     <SearchOutlined />
    //   </div>
    // }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_search__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
        className: "!w-[400px] !h-10",
        placeholder: "cw-search",
        onSearch: handleSearch,
        onClick: handleSearch,
        onBlur: handleBlur,
        ns: "static",
        suffix: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_ant_design_icons_lib_icons_SearchOutlined__WEBPACK_IMPORTED_MODULE_2___default()), {})
    });
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 25414:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Z: () => (/* binding */ cw_leecharts)
});

;// CONCATENATED MODULE: external "d3"
const external_d3_namespaceObject = require("d3");
;// CONCATENATED MODULE: external "d3-ease"
const external_d3_ease_namespaceObject = require("d3-ease");
;// CONCATENATED MODULE: ./src/cw/leecharts/options.js

function options_options() {
    return {
        grid: {
            left: 40,
            top: 80,
            right: 40,
            bottom: 30
        },
        title: {
            text: ""
        },
        subtitle: {
            text: ""
        },
        axisPointer: {
            type: "line",
            color: "#ddd"
        },
        yAxis: {
            type: "value",
            show: true,
            splitLine: {
                show: true,
                color: "#ddd",
                type: "dashed"
            }
        },
        xAxis: {
            type: "category",
            show: true,
            data: [],
            splitLine: {
                show: false,
                color: "#ddd",
                type: "solid"
            }
        },
        legend: {
            layout: "horizontal",
            align: "right",
            left: 10,
            right: 10,
            top: 0,
            bottom: 0,
            color: "#505158",
            padding: 15,
            fontSize: 12,
            fontWeight: 555,
            lineHeight: 20,
            iconSize: 12,
            iconPadding: 10
        },
        series: []
    };
}
let colors = [
    "#5665FF",
    "#569CFF",
    "#8AF0F8",
    "#FF7C49",
    "#CA8DF7",
    "#D2488A",
    "#7cb5ec",
    "#434348",
    "#90ed7d",
    "#f7a35c",
    "#8085e9",
    "#f15c80",
    "#e4d354",
    "#2b908f"
];
let areaColors = [
    "rgba(124,181,236,.6)",
    "rgba(67,67,72,.6)",
    "rgba(144,237,125,.6)",
    "rgba(247,163,92,.6)",
    "rgba(128,133,233,.6)",
    "rgba(241,92,128,.6)",
    "rgba(228,211,84,.6)",
    "rgba(43,144,143,.6)"
];
options_options.seriesColor = colors;
options_options.getColor = (i)=>{
    return colors[i % colors.length];
};
options_options.getAreaColor = (i)=>{
    return areaColors[i % areaColors.length];
};
options_options.focusAniDuration = 300;
options_options.focusRate = 1.1;
options_options.focusPieEase = external_d3_ease_namespaceObject.easeBounce;
options_options.enterAniDuration = 2000;
options_options.enterAniEase = external_d3_ease_namespaceObject.easeSinInOut;
options_options.changeAniDuraiton = 800;
options_options.tickNumber = 5;
options_options.axisLineColor = "#ddd";
options_options.axisTickSize = 6;
options_options.axisTickColor = "#ddd";
options_options.axisLabel = {
    fontSize: 12,
    color: "#aaa",
    padding: 10,
    rotate: 0
};
options_options.strokeDasharray = "6 3";
options_options.plot = {
    show: true,
    type: "circle",
    size: 10,
    lineWidth: 1
};
options_options.bgCircleOpacity = 0.4;
options_options.areaStyle = {
    show: false
};
options_options.lineStyle = {
    show: true,
    curve: false,
    width: 1
};
options_options.highlightOtherOpacity = 0.2;
let ldicons = {
    "line": "lineCircle",
    "bar": "rect"
};
options_options.legendIcon = (type)=>{
    return ldicons[type] || "circle";
};
options_options.barStyle = {
    barMaxWidth: 60,
    interval: 5
};
options_options.shadowPointerColor = "rgba(125,125,125, 0.6)";
options_options.radar = {
    startAngle: 0,
    splitNumber: 5,
    splitArea: {
        colors,
        lineType: "dashed",
        lineColor: "#ddd"
    },
    axisLine: {
        color: "#ddd",
        show: true
    },
    axisLabel: {
        show: false,
        color: "#ddd",
        fontSize: 12
    },
    indicator: {
        color: "#505158",
        fontSize: 12,
        padding: 10
    },
    plots: {
        show: true,
        type: "circle",
        attr: {
            r: 5
        },
        style: {
            opacity: 1
        }
    }
};

// EXTERNAL MODULE: external "mytoolkit"
var external_mytoolkit_ = __webpack_require__(95153);
;// CONCATENATED MODULE: ./src/cw/leecharts/utils.js

function getData(arr, index) {
    let item = arr[index];
    return item && (0,external_mytoolkit_.isSet)(item.value) ? item.value : item;
}
function maybePercentValue(value, target) {
    if (/^\d+(\.\d+)?%$/.test(value)) {
        if ((0,external_mytoolkit_.isUnset)(target)) {
            target = 1;
        }
        return parsePercent(value) * target;
    }
    return value;
}
function parsePercent(p) {
    if (!/^\d+(\.\d+)?%$/.test(p)) return p;
    return parseFloat(p) / 100;
}
function isInBound(bound, x, y) {
    let bl = bound[0], br = bound[1];
    if (bl[0] - x > 0) return false;
    if (br[0] - x < 0) return false;
    if (bl[1] - y > 0) return false;
    if (br[1] - y < 0) return false;
    return true;
}
function deepExtend(source, target = {}) {
    Object.keys(target).forEach((tk)=>{
        if ((0,external_mytoolkit_.isObject)(source[tk]) && (0,external_mytoolkit_.isObject)(target[tk])) {
            deepExtend(source[tk], target[tk]);
        } else {
            source[tk] = target[tk];
        }
    });
    return source;
}
function getBoundingRect(doc) {
    if (doc && doc.getBoundingClientRect) {
        return doc.getBoundingClientRect();
    }
    return {
        left: 0,
        top: 0,
        width: 0,
        height: 0
    };
}
function d3Augment(d3) {
    if (!d3.transition.prototype.attrs) {
        let attrs = function(name) {
            if ((0,external_mytoolkit_.isObject)(name)) {
                Object.keys(name).forEach((k)=>{
                    this.attr(k, name[k]);
                });
            }
            return this;
        };
        d3.transition.prototype.attrs = attrs;
    }
    if (!d3.transition.prototype.styles) {
        let styles = function(name) {
            if ((0,external_mytoolkit_.isObject)(name)) {
                Object.keys(name).forEach((k)=>{
                    this.style(k, name[k]);
                });
            }
            return this;
        };
        d3.transition.prototype.styles = styles;
    }
    if (!d3.selection.prototype.attrs) {
        let attrs = function(name) {
            if ((0,external_mytoolkit_.isObject)(name)) {
                Object.keys(name).forEach((k)=>{
                    this.attr(k, name[k]);
                });
            }
            return this;
        };
        d3.selection.prototype.attrs = attrs;
    }
    if (!d3.selection.prototype.styles) {
        let styles = function(name) {
            if ((0,external_mytoolkit_.isObject)(name)) {
                Object.keys(name).forEach((k)=>{
                    this.style(k, name[k]);
                });
            }
            return this;
        };
        d3.selection.prototype.styles = styles;
    }
    // make selection.append can accept [tag][class] synctax , it can also accept an initial attributes, an initial styles
    let appendProto = d3.selection.prototype.append;
    if (!appendProto.lc_extended) {
        let append = function(name, attrs, styles) {
            if ((0,external_mytoolkit_.isUnset)(name)) {
                return appendProto.call(this, name);
            }
            let [tagName, className] = name.split(/[.#]/);
            let s = appendProto.call(this, tagName);
            if (className) {
                name.includes("#") && s.attr("id", className);
                name.includes(".") && s.classed(className, "true");
            }
            (0,external_mytoolkit_.isObject)(attrs) && s.attr(attrs);
            (0,external_mytoolkit_.isObject)(styles) && s.style(styles);
            return s;
        };
        append.lc_extended = true;
        d3.selection.prototype.append = append;
    }
    if (!d3.selection.prototype.safeSelect) {
        d3.selection.prototype.safeSelect = function(selector) {
            let s = this.select(selector);
            if (s.empty()) {
                s = this.append(selector);
            }
            return s;
        };
    }
}

;// CONCATENATED MODULE: ./src/cw/leecharts/draw/axisX.js

function axisX(chart) {
    let { d3, defaultOptions, containerWidth: cw, containerHeight: ch, options: { series, xAxis }, sections: { axisX }, maxValue, maxValueFixed, gridLeft, gridRight, gridTop, gridBottom } = chart;
    let showAxis = true;
    if (series.length === 0) showAxis = false;
    // draw axis only when series contains line or bar
    if (series.filter((s)=>s.type === "line" || s.type === "bar").length === 0) showAxis = false;
    if (!showAxis) {
        axisX.html("");
        return;
    }
    let scaleX, domainData, max, tickNumber, tickIncrement, tickValues, category;
    if (xAxis.type !== "value") {
        domainData = xAxis.data.map((item)=>item && item.value ? item.value : item);
        scaleX = d3.scaleBand().domain(domainData).range([
            gridLeft,
            cw - gridRight
        ]);
        tickValues = domainData;
        category = true;
    } else {
        max = maxValue;
        tickNumber = Math.min(max, xAxis.tickNumber || defaultOptions.tickNumber);
        if (!maxValueFixed) {
            tickIncrement = d3.tickIncrement(0, max, tickNumber);
            max = Math.ceil(max / tickIncrement) * tickIncrement;
        }
        scaleX = d3.scaleLinear().domain([
            0,
            max
        ]).range([
            gridLeft,
            cw - gridRight
        ]);
        tickValues = d3.ticks(0, max, tickNumber);
        category = false;
    }
    chart.xAxisTickValues = tickValues;
    chart.scaleX = scaleX;
    axisX.attr("transform", `translate(0, ${ch - gridBottom})`);
    let lineColor = xAxis.lineColor || defaultOptions.axisLineColor;
    let tickSize = xAxis.tickSize || defaultOptions.axisTickSize;
    let tickColor = xAxis.tickColor || defaultOptions.axisTickColor;
    if (xAxis.show) {
        // axis bar 
        axisX.safeSelect("line.domain").attrs({
            fill: "none",
            stroke: lineColor,
            x1: scaleX.range()[0],
            x2: scaleX.range()[1]
        });
        // axis ticks 
        axisX.selectAll("line.lc-axis-tick").data(tickValues).join("line.lc-axis-tick").attrs({
            fill: "none",
            stroke: tickColor,
            y2: xAxis.tickInside ? -tickSize : tickSize,
            x1: (d)=>scaleX(d),
            x2: (d)=>scaleX(d)
        });
        let axisLabelSetting = (0,external_mytoolkit_.extend)({}, defaultOptions.axisLabel, xAxis.axisLabel || {});
        // axis label
        let labelPadding = axisLabelSetting.padding + (xAxis.tickInside ? 0 : tickSize);
        let labelgroup = axisX.selectAll("g.lc-axis-label-g").data(tickValues).join("g.lc-axis-label-g").attr("transform", (d)=>`translate(${scaleX(d) + (category ? scaleX.bandwidth() * 0.5 : 0)}, ${labelPadding + axisLabelSetting.fontSize * 0.5})`);
        labelgroup.each(function(d, i) {
            d3.select(this).safeSelect("text").text((d)=>{
                if ((0,external_mytoolkit_.isFunction)(axisLabelSetting.formatter)) {
                    return axisLabelSetting.formatter(d);
                }
                return /^\d+$/.test(d) ? (0,external_mytoolkit_.addComma)(d) : d;
            }).attrs({
                "text-anchor": axisLabelSetting.textAnchor || "middle",
                "writing-mode": axisLabelSetting.writingMode || "inherit",
                stroke: "none",
                fill: axisLabelSetting.color,
                transform: `rotate(${axisLabelSetting.rotate})`
            }).styles({
                "font-size": axisLabelSetting.fontSize
            });
        });
        // split lines 
        let sls = xAxis.splitLine;
        let splitLines = axisX.safeSelect("g.lc-split-lines");
        if (sls.show) {
            splitLines.selectAll("line").data(tickValues.filter((v)=>v !== 0)).join("line").attrs({
                fill: "none",
                stroke: sls.color,
                "stroke-dasharray": sls.type === "dashed" ? defaultOptions.strokeDasharray : "none",
                x1: (d)=>scaleX(d),
                y2: -(ch - gridBottom - gridTop),
                x2: (d)=>scaleX(d)
            });
        } else {
            splitLines.html("");
        }
    } else {
        axisX.html("");
    }
}

;// CONCATENATED MODULE: ./src/cw/leecharts/draw/axisY.js

function axisY(chart) {
    let { d3, defaultOptions, containerWidth: cw, containerHeight: ch, options: { series, yAxis }, sections: { axisY }, maxValue, maxValueFixed, gridLeft, gridRight, gridTop, gridBottom } = chart;
    let showAxis = true;
    if (series.length === 0) showAxis = false;
    // draw axis only when series contains line or bar
    if (series.filter((s)=>s.type === "line" || s.type === "bar").length === 0) showAxis = false;
    if (!showAxis) {
        axisY.html("");
        return;
    }
    let scaleY, domainData, max, tickNumber, tickIncrement, tickValues, category;
    if (yAxis.type === "category" && yAxis.data && yAxis.data.length) {
        domainData = yAxis.data.map((item)=>item && item.value ? item.value : item);
        scaleY = d3.scaleBand().domain(domainData).range([
            ch - gridBottom,
            gridTop
        ]);
        tickValues = domainData;
        category = true;
    } else {
        max = maxValue;
        tickNumber = Math.min(max, yAxis.tickNumber || defaultOptions.tickNumber);
        if (!maxValueFixed) {
            tickIncrement = d3.tickIncrement(0, max, tickNumber);
            max = Math.ceil(max / tickIncrement) * tickIncrement;
        }
        scaleY = d3.scaleLinear().domain([
            0,
            max
        ]).range([
            ch - gridBottom,
            gridTop
        ]);
        tickValues = d3.ticks(0, max, tickNumber);
        category = false;
    }
    chart.yAxisTickValues = tickValues;
    chart.scaleY = scaleY;
    axisY.attr("transform", `translate(${gridLeft}, 0)`);
    let lineColor = yAxis.lineColor || defaultOptions.axisLineColor;
    let tickSize = yAxis.tickSize || defaultOptions.axisTickSize;
    let tickColor = yAxis.tickColor || defaultOptions.axisTickColor;
    if (yAxis.show) {
        // axis bar 
        axisY.safeSelect("line.domain").attrs({
            fill: "none",
            stroke: lineColor,
            y1: scaleY.range()[1],
            y2: scaleY.range()[0]
        });
        // axis ticks 
        axisY.selectAll("line.lc-axis-tick").data(tickValues).join("line.lc-axis-tick").attrs({
            fill: "none",
            stroke: tickColor,
            x1: yAxis.tickInside ? tickSize : -tickSize,
            y1: (d)=>scaleY(d),
            y2: (d)=>scaleY(d)
        });
        let axisLabelSetting = (0,external_mytoolkit_.extend)({}, defaultOptions.axisLabel, yAxis.axisLabel || {});
        // axis label
        let labelPadding = axisLabelSetting.padding + (yAxis.tickInside ? 0 : tickSize);
        let labelgroup = axisY.selectAll("g.lc-axis-label-g").data(tickValues).join("g.lc-axis-label-g").attr("transform", (d)=>`translate(${-labelPadding}, ${(category ? scaleY.bandwidth() * 0.5 : 0) + scaleY(d) + axisLabelSetting.fontSize / 3})`);
        labelgroup.each(function(d, i) {
            d3.select(this).safeSelect("text").text((d)=>{
                if ((0,external_mytoolkit_.isFunction)(axisLabelSetting.formatter)) {
                    return axisLabelSetting.formatter(d);
                }
                return /^\d+$/.test(d) ? (0,external_mytoolkit_.addComma)(d) : d;
            }).attrs({
                "text-anchor": axisLabelSetting.textAnchor || "end",
                "writing-mode": axisLabelSetting.writingMode || "inherit",
                stroke: "none",
                fill: axisLabelSetting.color,
                transform: `rotate(${axisLabelSetting.rotate})`
            }).styles({
                "font-size": axisLabelSetting.fontSize
            });
        });
        // split lines 
        let sls = yAxis.splitLine;
        let splitLines = axisY.safeSelect("g.lc-split-lines");
        if (sls.show) {
            splitLines.selectAll("line").data(tickValues.filter((v)=>v !== 0)).join("line").attrs({
                fill: "none",
                stroke: sls.color,
                "stroke-dasharray": sls.type === "dashed" ? defaultOptions.strokeDasharray : "none",
                y1: (d)=>scaleY(d),
                x2: cw - gridRight - gridLeft,
                y2: (d)=>scaleY(d)
            });
        } else {
            splitLines.html("");
        }
    } else {
        axisY.html("");
    }
}

;// CONCATENATED MODULE: ./src/cw/leecharts/draw/gradient.js

function drawGradient(chart, color, defaultColor) {
    let { sections: { defs }, gradientPool } = chart;
    if ((0,external_mytoolkit_.isUnset)(color)) {
        return defaultColor;
    }
    if ((0,external_mytoolkit_.isObject)(color)) {
        let colorString = (0,external_mytoolkit_.encodeJSON)(color);
        let gradientObj = gradientPool.find((p)=>p.colorString === colorString);
        if (gradientObj) {
            return `url(#${gradientObj.id})`;
        }
        let r = "", id = "lc-gradient-" + (0,external_mytoolkit_.randStr)(6);
        if (color.type === "linear") {
            color.colorStops.forEach((item)=>{
                r += `<stop offset="${(0,external_mytoolkit_.toFixed)(item.offset, 0, 100)}%" stop-color="${item.color}"/>`;
            });
            defs.append("linearGradient").attrs({
                id,
                x1: (0,external_mytoolkit_.isUnset)(color.x) ? 0 : color.x,
                x2: (0,external_mytoolkit_.isUnset)(color.x2) ? 0 : color.x2,
                y1: (0,external_mytoolkit_.isUnset)(color.y) ? 0 : color.y,
                y2: (0,external_mytoolkit_.isUnset)(color.y2) ? 1 : color.y2
            }).html(r);
            gradientPool.push({
                id,
                colorString
            });
            return `url(#${id})`;
        } else if (color.type === "radial") {
            color.colorStops.forEach((item)=>{
                r += `<stop offset="${(0,external_mytoolkit_.toFixed)(item.offset, 0, 100)}%" stop-color="${item.color}"/>`;
            });
            defs.append("radialGradient").attrs({
                id,
                cx: color.x,
                cy: color.y,
                r: color.r
            }).html(r);
            gradientPool.push({
                id,
                colorString
            });
            return `url(#${id})`;
        }
        return r;
    }
    return color;
}

;// CONCATENATED MODULE: ./src/cw/leecharts/draw/line.js



function drawLine(chart, layer, s, index) {
    let { emitter, defaultOptions, d3, containerWidth: cw, containerHeight: ch, options: { grid, xAxis, yAxis, onClick: clickHandle, lineStyle: ls, plotStyle: plts }, sections: { defs, series, plotGroup }, scaleY, scaleX, gridLeft, gridRight, gridTop, gridBottom } = chart;
    let lineStyle = (0,external_mytoolkit_.extend)({}, defaultOptions.lineStyle, ls || {}, s.lineStyle || {});
    let color = lineStyle.color || defaultOptions.getColor(index);
    let scaleCategory, scaleValue, orient;
    if (scaleX.bandwidth) {
        scaleCategory = scaleX;
        scaleValue = scaleY;
        orient = "h";
    } else if (scaleY.bandwidth) {
        scaleCategory = scaleY;
        scaleValue = scaleX;
        orient = "v";
    } else {
        scaleCategory = scaleX;
        scaleValue = scaleY;
        orient = "h";
    }
    let bandWidth = scaleCategory && scaleCategory.bandwidth ? scaleCategory.bandwidth() : 0;
    let rData = s.data || [];
    if (rData.length === 0) {
        layer.html("");
        plotGroup.safeSelect(`g.lc-plot-group-${index}`).html("");
        return;
    }
    let sData = rData = rData.map((item)=>item && item.value ? item.value : item);
    sData = sData.map((d)=>{
        return Math.max(0.01, d);
    });
    let stacked = false, prevData;
    if (s.stackData) {
        stacked = true;
        sData = s.stackData;
    }
    let areaStyle = (0,external_mytoolkit_.extend)({}, defaultOptions.areaStyle, s.areaStyle || {});
    if (areaStyle.show) {
        let area = d3.area().x((d, i)=>position(d, i, true)).y((d, i)=>position(d, i, false)).defined((d)=>!!d);
        lineStyle.curve && area.curve(d3.curveCardinal);
        if (orient === "h") {
            area.y1((d, i)=>{
                if (stacked) {
                    return scaleValue(d[0]);
                } else {
                    return ch - gridBottom;
                }
            });
        } else {
            area.x1((d, i)=>{
                if (stacked) {
                    return scaleValue(d[0]);
                } else {
                    return gridLeft;
                }
            });
        }
        let areaColor = areaStyle.color || null;
        areaColor = drawGradient(chart, areaColor, defaultOptions.getAreaColor(index));
        let areaEle = layer.safeSelect("path.lc-area")//.attr('d', area(sData))
        .attrs({
            stroke: "none",
            fill: areaColor
        });
        prevData = (0,external_mytoolkit_.decodeJSON)(areaEle.attr("prevData"));
        if (!prevData) {
            areaEle.attr("d", area(sData)).attr("prevData", (0,external_mytoolkit_.encodeJSON)(sData));
        } else {
            areaEle.transition().duration(defaultOptions.changeAniDuraiton).ease(defaultOptions.enterAniEase).attrTween("d", function() {
                return (t)=>{
                    let interData = sData.map((p, i)=>{
                        let start0, end0, pd, inter0, inter1, start1, end1;
                        pd = prevData[i] || p;
                        if ((0,external_mytoolkit_.isArray)(p)) {
                            start0 = (0,external_mytoolkit_.isArray)(pd) ? pd[0] : pd;
                            end0 = p[0];
                            inter0 = start0 + (end0 - start0) * t;
                            start1 = (0,external_mytoolkit_.isArray)(pd) ? pd[1] : pd;
                            end1 = p[1];
                            inter1 = start1 + (end1 - start1) * t;
                            return [
                                inter0,
                                inter1
                            ];
                        } else {
                            start1 = (0,external_mytoolkit_.isArray)(pd) ? pd[1] : pd;
                            end1 = p;
                            inter1 = start1 + (end1 - start1) * t;
                            return inter1;
                        }
                    });
                    return area(interData);
                };
            }).on("end", function() {
                d3.select(this).attr("prevData", (0,external_mytoolkit_.encodeJSON)(sData));
            });
        }
    }
    if (lineStyle.show) {
        let line = d3.line().x((d, i)=>position(d, i, true)).y((d, i)=>position(d, i, false)).defined((d)=>!!d);
        lineStyle.curve && line.curve(d3.curveCardinal);
        let lineEle = layer.safeSelect("path.lc-line").attrs({
            stroke: color,
            fill: "none",
            "stroke-width": lineStyle.width
        });
        prevData = (0,external_mytoolkit_.decodeJSON)(lineEle.attr("prevData"));
        if (!prevData) {
            lineEle.attr("d", line(sData)).attr("prevData", (0,external_mytoolkit_.encodeJSON)(sData));
        } else {
            lineEle.transition().duration(defaultOptions.changeAniDuraiton).ease(defaultOptions.enterAniEase).attrTween("d", function() {
                return (t)=>{
                    let interData = sData.map((p, i)=>{
                        let start, end, pd, inter;
                        end = stacked ? p[1] : p;
                        pd = prevData[i] || p;
                        start = (0,external_mytoolkit_.isArray)(pd) ? pd[1] : pd;
                        inter = start + (end - start) * t;
                        return (0,external_mytoolkit_.isArray)(p) ? [
                            p[0],
                            inter
                        ] : inter;
                    });
                    return line(interData);
                };
            }).on("end", function() {
                d3.select(this).attr("prevData", (0,external_mytoolkit_.encodeJSON)(sData));
            });
        }
    }
    let plotSetting = (0,external_mytoolkit_.extend)({}, defaultOptions.plot, plts || {}, s.plotStyle || {});
    let currentPlotGroup;
    if (plotSetting.show) {
        currentPlotGroup = plotGroup.safeSelect(`g.lc-plot-group-${index}`);
        let r = plotSetting.size / 2;
        currentPlotGroup.on("click", ()=>{
            if ((0,external_mytoolkit_.isSet)(s.highlightAnimation) && !s.highlightAnimation) return;
            chart.highlightIndex = chart.highlightIndex === index ? null : index;
            emitter.emit("highlightChange", chart.highlightIndex);
        });
        let plots = currentPlotGroup.selectAll("g.lc-node-wrap").data(sData).join("g.lc-node-wrap");
        plots//.attr('transform', (d, i) => `translate(${position(d, i, true)}, ${position(d, i, false)})`)
        .each(function(d, i) {
            let wrap = d3.select(this);
            let bgCircle = wrap.safeSelect("circle.lc-bgcircle").attrs({
                r: r * 3,
                stroke: "none",
                fill: color,
                opacity: 0
            });
            let node = wrap.safeSelect("circle.lc-node");
            node.attrs({
                r: (d)=>d ? r : 0,
                fill: "#ffffff",
                stroke: color,
                "stroke-width": plotSetting.lineWidth
            }).on("mouseover", ()=>{
                bgCircle.attr("opacity", defaultOptions.bgCircleOpacity);
            }).on("mouseout", ()=>{
                bgCircle.attr("opacity", 0);
            }).on("click", ()=>{
                emitter.emit("clickItem", {
                    value: stacked ? rData[i] : d,
                    seriesIndex: index,
                    dataIndex: i,
                    seriesData: s
                });
            });
            if (!chart.firstRender) {
                wrap.transition().duration(defaultOptions.changeAniDuraiton).ease(defaultOptions.enterAniEase).attr("transform", ()=>`translate(${position(d, i, true)}, ${position(d, i, false)})`);
            } else {
                wrap.attr("transform", ()=>`translate(${position(d, i, true)}, ${position(d, i, false)})`);
            }
            wrap.on("click", function() {
                if ((0,external_mytoolkit_.isFunction)(clickHandle)) {
                    clickHandle({
                        type: "itemClicked",
                        data: rData[i],
                        value: getData(rData, i),
                        dataIndex: i,
                        seriesIndex: index,
                        series: s,
                        seriesData: s.data
                    });
                }
            });
        });
        emitter.on("axisChange", (i)=>{
            let n = currentPlotGroup.selectAll(`.lc-active-node`);
            !n.empty() && n.classed("lc-active-node", false).transition().duration(defaultOptions.focusAniDuration).attr("r", r);
            if (i !== null) {
                currentPlotGroup.selectAll(".lc-node").filter((d, idx)=>(0,external_mytoolkit_.isSet)(d) && i === idx).classed("lc-active-node", true).transition().duration(defaultOptions.focusAniDuration).attr("r", r * 1.5);
            }
        });
    }
    // ini clip path animation 
    let clipPath, clipPathId, clipRect;
    if (chart.firstRender) {
        clipPathId = "lc-" + (0,external_mytoolkit_.randStr)(8);
        clipPath = defs.safeSelect(`clipPath#${clipPathId}`);
        clipRect = clipPath.safeSelect("rect");
        layer.attr("clip-path", `url(#${clipPathId})`);
        if (currentPlotGroup) {
            currentPlotGroup.attr("clip-path", `url(#${clipPathId})`);
        }
        if (orient === "h") {
            clipRect.attrs({
                x: 0,
                y: 0,
                height: ch,
                width: 0
            }).transition().duration(defaultOptions.enterAniDuration).ease(defaultOptions.enterAniEase).attr("width", cw).on("end", ()=>{
                layer.attr("clip-path", null);
                currentPlotGroup && currentPlotGroup.attr("clip-path", null);
                clipPath.remove();
            });
        } else {
            clipRect.attrs({
                x: 0,
                y: ch,
                height: 0,
                width: cw
            }).transition().duration(defaultOptions.enterAniDuration).ease(defaultOptions.enterAniEase).attr("height", ch).attr("y", 0).on("end", ()=>{
                layer.attr("clip-path", null);
                currentPlotGroup && currentPlotGroup.attr("clip-path", null);
                clipPath.remove();
            });
        }
    }
    layer.on("click", ()=>{
        if ((0,external_mytoolkit_.isSet)(s.highlightAnimation) && !s.highlightAnimation) return;
        chart.highlightIndex = chart.highlightIndex === index ? null : index;
        emitter.emit("highlightChange", chart.highlightIndex);
    });
    if ((0,external_mytoolkit_.isUnset)(s.highlightAnimation) || s.highlightAnimation) {
        emitter.on("highlightChange", (ci)=>{
            if (ci === null || ci === index) {
                layer.transition().duration(defaultOptions.focusAniDuration).style("opacity", 1);
                if (currentPlotGroup) {
                    currentPlotGroup.transition().duration(defaultOptions.focusAniDuration).style("opacity", 1);
                }
            } else {
                layer.transition().duration(defaultOptions.focusAniDuration).style("opacity", defaultOptions.highlightOtherOpacity);
                if (currentPlotGroup) {
                    currentPlotGroup.transition().duration(defaultOptions.focusAniDuration).style("opacity", defaultOptions.highlightOtherOpacity);
                }
            }
        });
    }
    function position(d, i, isX) {
        let td, scale, bw;
        if (isX) {
            if (orient === "h") {
                scale = scaleCategory;
                td = xAxis.data[i];
                bw = bandWidth;
            } else {
                scale = scaleValue;
                td = stacked ? d[1] : d;
                bw = 0;
            }
        } else {
            if (orient === "v") {
                scale = scaleCategory;
                td = yAxis.data[i];
                bw = bandWidth;
            } else {
                scale = scaleValue;
                td = stacked ? d[1] : d;
                bw = 0;
            }
        }
        return scale(td) + bw / 2;
    }
}

;// CONCATENATED MODULE: ./src/cw/leecharts/draw/bar.js



function drawBar(chart, layer, s, index) {
    let { emitter, defaultOptions, d3, containerWidth: cw, containerHeight: ch, options: { xAxis, yAxis, onClick: clickHandle }, sections: { defs, series, plotGroup }, scaleY, scaleX, gridLeft, gridRight, gridTop, gridBottom } = chart;
    let scaleCategory, scaleValue, orient, barWidth, barOffset;
    barWidth = s._barWidth;
    barOffset = s._barOffset;
    if (scaleX.bandwidth) {
        scaleCategory = scaleX;
        scaleValue = scaleY;
        orient = "h";
    } else if (scaleY.bandwidth) {
        scaleCategory = scaleY;
        scaleValue = scaleX;
        orient = "v";
    } else {
        scaleCategory = scaleX;
        scaleValue = scaleY;
        orient = "h";
    }
    let bandWidth = scaleCategory && scaleCategory.bandwidth ? scaleCategory.bandwidth() : 0;
    let rData = s.data || [];
    if (rData.length === 0) {
        layer.html("");
        return;
    }
    let sData = rData = rData.map((item)=>item && item.value ? item.value : item);
    let stacked = false;
    if (s.stackData) {
        stacked = true;
        sData = s.stackData;
    }
    let barStyle = (0,external_mytoolkit_.extend)({}, defaultOptions.barStyle, s.barStyle || {});
    let barColor = drawGradient(chart, barStyle.color || null, defaultOptions.getColor(index));
    let tDuration = 500;
    let barWrap = layer.selectAll("g.lc-bar-wrap").data(sData).join("g.lc-bar-wrap").each(function(d, i) {
        let bar = d3.select(this);
        let x, y, y1, x1, width, height;
        let barColorByData = s.data[i].color || barColor;
        let barTween = bar.transition().duration(chart.firstRender ? 0 : tDuration).ease(defaultOptions.enterAniEase);
        if (stacked) {
            if (orient === "h") {
                x = scaleCategory(getData(xAxis.data, i)) + barOffset + barWidth * 0.5;
                y = scaleValue(d[1]);
                y1 = scaleValue(d[0]);
                width = barWidth;
                height = y1 - y;
                barTween.attr("transform", `translate(${x}, ${y + height * 0.5})`);
            } else {
                x = scaleValue(d[1]);
                y = scaleCategory(getData(yAxis.data, i)) + barOffset + barWidth * 0.5;
                x1 = scaleValue(d[0]);
                width = x - x1;
                height = barWidth;
                barTween.attr("transform", `translate(${x - width * 0.5}, ${y})`);
            }
        } else {
            if (orient === "h") {
                x = scaleCategory(getData(xAxis.data, i)) + barOffset + barWidth * 0.5;
                y = scaleValue(d);
                y1 = ch - gridBottom;
                width = barWidth;
                height = y1 - y;
                barTween.attr("transform", `translate(${x}, ${y + height * 0.5})`);
            } else {
                x = scaleValue(d);
                y = scaleCategory(getData(yAxis.data, i)) + barOffset + barWidth * 0.5;
                x1 = gridLeft;
                width = x - x1;
                height = barWidth;
                barTween.attr("transform", `translate(${x - width * 0.5}, ${y})`);
            }
        }
        let barRect = bar.safeSelect("rect");
        let barRectTween = barRect.transition().duration(chart.firstRender ? defaultOptions.enterAniDuration : tDuration).ease(defaultOptions.enterAniEase);
        barRect.attrs({
            x: ()=>{
                return width * -0.5;
            },
            stroke: "none",
            fill: barColorByData
        });
        if (orient === "h") {
            if (chart.firstRender) {
                barRect.attrs({
                    y: height * 0.5,
                    width,
                    height: 0
                });
            }
            barRectTween.attr("width", width).attr("height", height).attr("y", -0.5 * height).on("start", function() {
                d3.select(this).attr("tweening", 1);
            }).on("end", function() {
                d3.select(this).attr("tweening", null);
            });
        } else {
            if (chart.firstRender) {
                barRect.attrs({
                    y: height * -0.5,
                    width: 0,
                    height
                });
            }
            barRectTween.attr("height", height).attr("width", function(d, i) {
                let x = position(d, i, true);
                return stacked ? x - scaleValue(d[0]) : x - gridLeft;
            }).on("start", function() {
                barRect.attr("tweening", 1);
            }).on("end", function() {
                barRect.attr("tweening", null);
            });
        }
        barRect.on("mouseover", function() {
            if (barRect.attr("tweening") == "1") return;
            if (orient === "h") {
                barRect.transition().duration(defaultOptions.focusAniDuration).ease(defaultOptions.enterAniEase).attr("transform", "scale(1.1, 1)");
            } else {
                barRect.transition().duration(defaultOptions.focusAniDuration).ease(defaultOptions.enterAniEase).attr("transform", "scale(1, 1.1)");
            }
        }).on("mouseout", function() {
            if (barRect.attr("tweening") == "1") return;
            if (orient === "h") {
                barRect.transition().duration(defaultOptions.focusAniDuration).ease(defaultOptions.enterAniEase).attr("transform", "scale(1)");
            } else {
                barRect.transition().duration(defaultOptions.focusAniDuration).ease(defaultOptions.enterAniEase).attr("transform", "scale(1)");
            }
        }).on("click", function() {
            if ((0,external_mytoolkit_.isFunction)(clickHandle)) {
                clickHandle({
                    type: "itemClicked",
                    data: rData[i],
                    value: getData(rData, i),
                    dataIndex: i,
                    seriesIndex: index,
                    seriesData: s.data,
                    series: s
                });
            }
        });
        let labelStyle = (0,external_mytoolkit_.extend)({}, s.labelStyle || {});
        let label, padding, textStyle;
        if (labelStyle.show) {
            padding = labelStyle.padding || 10;
            textStyle = labelStyle.textStyle || {};
            label = bar.safeSelect("text.lc-bar-label");
            label.attrs({
                "text-anchor": ()=>{
                    return orient === "h" ? "middle" : "start";
                },
                x: ()=>{
                    return orient === "v" ? 0.5 * width + padding : 0;
                },
                y: ()=>{
                    return orient === "h" ? -0.5 * height - padding : barWidth;
                },
                fill: textStyle.color || "#000"
            }).text(function() {
                return stacked ? d[1] : d;
            }).styles({
                ...textStyle
            });
        }
    });
    layer.on("click", ()=>{
        if ((0,external_mytoolkit_.isSet)(s.highlightAnimation) && !s.highlightAnimation) return;
        chart.highlightIndex = chart.highlightIndex === index ? null : index;
        emitter.emit("highlightChange", chart.highlightIndex);
    });
    if ((0,external_mytoolkit_.isUnset)(s.highlightAnimation) || s.highlightAnimation) {
        emitter.on("highlightChange", (ci)=>{
            if (ci === null || ci === index) {
                layer.transition().duration(defaultOptions.focusAniDuration).style("opacity", 1);
            } else {
                layer.transition().duration(defaultOptions.focusAniDuration).style("opacity", defaultOptions.highlightOtherOpacity);
            }
        });
    }
    function position(d, i, isX) {
        let td, scale;
        if (isX) {
            if (orient === "h") {
                scale = scaleCategory;
                td = xAxis.data[i];
            } else {
                scale = scaleValue;
                td = stacked ? d[1] : d;
            }
        } else {
            if (orient === "v") {
                scale = scaleCategory;
                td = yAxis.data[i];
            } else {
                scale = scaleValue;
                td = stacked ? d[1] : d;
            }
        }
        return scale(td);
    }
}

;// CONCATENATED MODULE: ./src/cw/leecharts/draw/pie.js



function drawPie(chart, layer, s, index) {
    let { emitter, defaultOptions, d3, containerWidth: cw, containerHeight: ch, containerCenter: cc, options: { onClick: clickHandle } } = chart;
    let data = s.data;
    if (!data || !data.length) {
        layer.html("").attr("transform", null);
        return;
    }
    let focusAnimation = (0,external_mytoolkit_.isSet)(s.focusAnimation) ? s.focusAnimation : true;
    let pieCenter = s.center || [
        0.5,
        0.5
    ];
    pieCenter = [
        cw * parsePercent(pieCenter[0]),
        ch * parsePercent(pieCenter[1])
    ];
    let radius = s.radius || [
        0,
        0.7
    ];
    let innerRadius = Math.min(cw, ch) * parsePercent(radius[0]) * 0.5;
    let outerRadius = Math.min(cw, ch) * parsePercent(radius[1]) * 0.5;
    let arcs = d3.pie();
    if (!s.sort) {
        arcs.sortValues(null);
    }
    let startAngle = s.startAngle || 0, endAngle = s.endAngle || Math.PI * 2;
    arcs.startAngle(startAngle);
    arcs.endAngle(endAngle);
    arcs = arcs(data.map((item)=>item.value));
    let d3arc = d3.arc().outerRadius(outerRadius).innerRadius(innerRadius);
    layer.attr("transform", `translate(${pieCenter[0]}, ${pieCenter[1]})`);
    let pieItems = layer.selectAll("path.lc-arc").data(arcs).join("path.lc-arc").attr("item-index", (d, i)=>i).attr("fill", (d, i)=>{
        let itemData = data[i];
        return drawGradient(chart, itemData.color, defaultOptions.getColor(i));
    }).style("opacity", (0,external_mytoolkit_.isSet)(s.opacity) ? s.opacity : 1).on("click", function(d, i) {
        if (!(0,external_mytoolkit_.isSet)(s.click) || s.click) {
            emitter.emit("clickItem", {
                value: d.data,
                seriesIndex: index,
                dataIndex: i,
                seriesData: s
            });
        }
        if ((0,external_mytoolkit_.isFunction)(clickHandle)) {
            clickHandle({
                type: "itemClicked",
                data: {
                    ...d,
                    ...data[i]
                },
                dataIndex: i,
                series: s,
                seriesIndex: index,
                seriesData: s.data
            });
        }
        if ((0,external_mytoolkit_.isSet)(s.clickHighlight) && !s.clickHighlight) return;
        let highlightIndex;
        if (i === chart.highlightIndex) {
            highlightIndex = null;
        } else {
            highlightIndex = i;
        }
        chart.highlightIndex = highlightIndex;
        emitter.emit("highlightChange", highlightIndex);
    }).on("mouseover", function(d, i) {
        if (!focusAnimation) return;
        let ele = d3.select(this);
        let startOuter = outerRadius;
        let endOuter = outerRadius * defaultOptions.focusRate;
        ele.transition().duration(defaultOptions.focusAniDuration).ease(defaultOptions.focusPieEase).attrTween("d", ()=>{
            let d = arcs[i];
            let inter = d3.interpolate(startOuter, endOuter);
            return (t)=>{
                return d3.arc().innerRadius(innerRadius).outerRadius(inter(t))(d);
            };
        });
    }).on("mouseout", function(d, i) {
        if (!focusAnimation) return;
        let ele = d3.select(this);
        let startOuter = outerRadius * defaultOptions.focusRate;
        let endOuter = outerRadius;
        ele.transition().duration(defaultOptions.focusAniDuration).ease(defaultOptions.focusPieEase).attrTween("d", ()=>{
            let d = arcs[i];
            let inter = d3.interpolate(startOuter, endOuter);
            return (t)=>{
                return d3.arc().innerRadius(innerRadius).outerRadius(inter(t))(d);
            };
        });
        if ((0,external_mytoolkit_.isObject)(s.tooltip) && !s.tooltip.show) return;
        emitter.emit("showTooltip", {
            type: "item",
            data: null
        });
    }).on("mousemove", function(d, i) {
        if ((0,external_mytoolkit_.isObject)(s.tooltip) && !s.tooltip.show) return;
        emitter.emit("showTooltip", {
            type: "item",
            dataIndex: i,
            data: {
                ...d,
                ...data[i],
                seriesIndex: index
            },
            seriesIndex: index,
            event: d3.event
        });
    });
    if (chart.firstRender && (!(0,external_mytoolkit_.isSet)(s.enterAnimation) || s.enterAnimation)) {
        pieItems.transition().duration(defaultOptions.enterAniDuration).ease(defaultOptions.enterAniEase).attrTween("d", function(d, i) {
            let inter = d3.interpolate(d.startAngle, d.endAngle);
            return (t)=>{
                return d3arc({
                    startAngle: d.startAngle,
                    endAngle: inter(t)
                });
            };
        }).on("end", function(d, i) {
            d3.select(this).attr("prevData", (0,external_mytoolkit_.encodeJSON)(d));
        });
    } else {
        //pieItems.attr('d', d3arc)
        pieItems.transition().duration(defaultOptions.changeAniDuraiton).ease(defaultOptions.enterAniEase).attrTween("d", function(d, i) {
            let ele = d3.select(this);
            let prevData = (0,external_mytoolkit_.decodeJSON)(ele.attr("prevData")) || d;
            let interStart = d3.interpolate(prevData.startAngle, d.startAngle);
            let interEnd = d3.interpolate(prevData.endAngle, d.endAngle);
            return (t)=>{
                return d3arc({
                    startAngle: interStart(t),
                    endAngle: interEnd(t)
                });
            };
        }).on("end", function(d, i) {
            d3.select(this).attr("prevData", (0,external_mytoolkit_.encodeJSON)(d));
        });
    }
    if (!(0,external_mytoolkit_.isSet)(s.clickHighlight) || s.clickHighlight) {
        emitter.on("highlightChange", (i)=>{
            pieItems.each(function(d, idx) {
                let targetOpacity = i !== null ? i === idx ? 1 : defaultOptions.highlightOtherOpacity : 1;
                d3.select(this).transition().duration(defaultOptions.focusAniDuration).style("opacity", targetOpacity);
            });
        });
    }
    // draw label 
    let label = layer.safeSelect("g.lc-pie-label");
    label.html("");
    if (s.label && (0,external_mytoolkit_.isFunction)(s.label.formatter)) {
        label.html(s.label.formatter(data));
    }
}

;// CONCATENATED MODULE: ./src/cw/leecharts/draw/linepointer.js


function drawLinePointer(chart, index) {
    let { d3, defaultOptions, scaleX, scaleY, containerHeight: ch, containerWidth: cw, options: { xAxis, yAxis, axisPointer }, sections: { linePointer }, gridLeft, gridRight, gridTop, gridBottom } = chart;
    if ((0,external_mytoolkit_.isSet)(axisPointer.show) && !axisPointer.show || axisPointer.type !== "line") {
        linePointer.style("opacity", 0);
        return;
    }
    let scaleCategory, scaleValue, orient, color;
    color = axisPointer.color || "#aaa";
    if (scaleX.bandwidth) {
        scaleCategory = scaleX;
        scaleValue = scaleY;
        orient = "h";
    } else if (scaleY.bandwidth) {
        scaleCategory = scaleY;
        scaleValue = scaleX;
        orient = "v";
    } else {
        scaleCategory = scaleX;
        scaleValue = scaleY;
        orient = "h";
    }
    let bandWidth = scaleCategory && scaleCategory.bandwidth ? scaleCategory.bandwidth() : 0;
    if (index === null) {
        linePointer.style("opacity", 0);
    } else {
        let x1, y1, x2, y2, cd;
        if (orient === "h") {
            cd = getData(xAxis.data, index);
            x2 = x1 = scaleCategory(cd) + bandWidth * 0.5;
            y1 = gridTop;
            y2 = ch - gridBottom;
        } else {
            cd = getData(yAxis.data, index);
            y1 = y2 = scaleCategory(cd) + bandWidth * 0.5;
            x1 = gridLeft;
            x2 = cw - gridRight;
        }
        linePointer.style("opacity", 1).attrs({
            x1,
            y1,
            x2,
            y2,
            stroke: color,
            "stroke-dasharray": defaultOptions.strokeDasharray,
            opacity: 1
        });
    }
}

;// CONCATENATED MODULE: ./src/cw/leecharts/draw/legend.js


function drawLegend(chart) {
    let { d3, emitter, defaultOptions, containerWidth: cw, containerHeight: ch, options: { legend, series }, sections: { legend: legendLayer } } = chart;
    if ((0,external_mytoolkit_.isSet)(legend.show) && !legend.show) {
        legendLayer.html("");
        return;
    }
    let legendData = legend.data || [];
    let filteredSeries = series.filter((s)=>s.type === "line" || s.type === "bar");
    if (!legendData.length) {
        legendData = filteredSeries.map((s, i)=>s.name || `series ${1}`);
    }
    if (!legendData.length) {
        legendLayer.html("");
        return;
    }
    // prepare legend  
    legendData = legendData.map((l, i)=>{
        let matchSeries = series[i] || {};
        (0,external_mytoolkit_.isString)(l) && (l = {
            name: l
        });
        return {
            icon: defaultOptions.legendIcon(matchSeries.type),
            ...l
        };
    });
    // set legend layer invisiable 
    let legendTop, legendLeft, legendRight, legendBottom;
    legendTop = maybePercentValue(legend.top, ch);
    legendLeft = maybePercentValue(legend.left, cw);
    legendRight = maybePercentValue(legend.right, cw);
    legendBottom = maybePercentValue(legend.bottom, ch);
    let fontSize = legend.fontSize;
    let lineHeight = legend.lineHeight;
    let iconSize = legend.iconSize;
    lineHeight = Math.max(fontSize * 1.4, iconSize * 1.4, lineHeight);
    let fontWeight = legend.fontWeight;
    let legendWraps = [];
    legendLayer.selectAll("g.lc-legend-item-wrap").data(legendData).join("g.lc-legend-item-wrap").each(function(d, i) {
        let ele = d3.select(this);
        let html = "", x = iconSize + legend.iconPadding, formatter;
        formatter = (0,external_mytoolkit_.isFunction)(d.formatter) ? d.formatter : ()=>d.name;
        html += icon(d, i);
        if (d.icon === "lineCircle") {
            x = iconSize * 1.8 + legend.iconPadding;
        }
        html += `<text x=${x} y=${fontSize} fill="${legend.color}" style="cursor:pointer;font-size: ${fontSize}px;font-weight: ${fontWeight};">${formatter()}</text>`;
        ele.html(html);
        let { width, height } = ele.node().getBBox();
        legendWraps[i] = {
            ele,
            width,
            height,
            highlightIndex: d.highlightIndex
        };
    }).on("click", (d, i)=>{
        if (d.triggerHighlight === false) return;
        let dataIndex = d.highlightIndex || i;
        chart.highlightIndex = dataIndex === chart.highlightIndex ? null : dataIndex;
        emitter.emit("highlightChange", chart.highlightIndex);
    });
    // legend layout 
    let layoutX = legendLeft + legend.padding;
    let layoutRight = cw - legendRight - legend.padding;
    let layoutWidth = cw - legendRight - legend.padding - layoutX;
    let penX, penY, leftSpace, rows = [
        []
    ], rowIndex = 0;
    penX = layoutX;
    penY = legendTop + lineHeight / 2;
    if (legend.layout === "horizontal") {
        leftSpace = layoutWidth;
        for(let i = 0, l = legendWraps.length; i < l; i++){
            let item = legendWraps[i];
            let row = rows[rowIndex];
            if (item.width <= leftSpace) {
                row.push(item);
                leftSpace -= item.width + legend.padding;
            } else {
                rowIndex++;
                row = rows[rowIndex] = [];
                row.push(item);
                leftSpace = layoutWidth;
            }
        }
        rows.forEach((row, rowIndex)=>{
            let right = legend.align === "right";
            right ? penX = layoutRight : penX = layoutX;
            for(let i = 0, l = row.length; i < l; i++){
                let item;
                if (right) {
                    item = row[l - 1 - i];
                    penX -= item.width;
                    item.ele.attr("transform", `translate(${penX},${penY})`);
                    penX -= legend.padding;
                } else {
                    item = row[i];
                    item.ele.attr("transform", `translate(${penX},${penY})`);
                    penX += item.width + legend.padding;
                }
            }
            penY += lineHeight;
        });
    } else {
        let maxItemWidth = Math.max.apply(this, legendWraps.map((l)=>l.width));
        legend.align === "right" && (penX = layoutRight - maxItemWidth - legend.padding);
        for(let i = 0, l = legendWraps.length; i < l; i++){
            let item = legendWraps[i];
            item.ele.attr("transform", `translate(${penX},${penY})`);
            penY += lineHeight;
        }
    }
    emitter.on("highlightChange", (i)=>{
        legendWraps.forEach((l, k)=>{
            let dataIndex = l.highlightIndex || k;
            let targetOpacity = i !== null ? i == dataIndex ? 1 : defaultOptions.highlightOtherOpacity : 1;
            l.ele.style("opacity", targetOpacity);
        });
    });
    function icon(d, i) {
        let r = "";
        let iconColor = d.color || defaultOptions.getColor(i);
        switch(d.icon){
            case "lineCircle":
                r += `<path stroke-width="2" stroke="${iconColor}" d="M0,${(fontSize + 2) / 2}L${iconSize * 1.8},${(fontSize + 2) / 2}"/>`;
                r += `<circle stroke-width="2" stroke="${iconColor}" fill="#ffffff" cx="${iconSize * 0.9}" cy="${(fontSize + 2) / 2}" r="${iconSize / 2}"/>`;
                return r;
            case "rect":
                let halfHeight = 0.5 * (iconSize - 2 - fontSize);
                r += `<rect stroke="none" fill="${iconColor}" y="${-halfHeight}" width="${iconSize}" height="${iconSize}"/>`;
                return r;
            case "circle":
                r += `<circle stroke="none" fill="${iconColor}" cy="${(fontSize + 2) / 2}" r="${iconSize / 2}"/>`;
                return r;
            case "custom":
                r += (0,external_mytoolkit_.isFunction)(d.drawIcon) ? d.drawIcon() : "";
                return r;
            default:
                return r;
        }
    }
}

;// CONCATENATED MODULE: ./src/cw/leecharts/emitter.js

class emitter {
    constructor(){
        this.listeners = {};
    }
    on(type, func) {
        let listenersByType = this.listeners[type];
        !listenersByType && (this.listeners[type] = listenersByType = []);
        // find previous func with same id 
        if (!listenersByType.find((l)=>l === func)) {
            listenersByType.push(func);
        }
    }
    off(type, func) {
        let listenersByType = this.listeners[type];
        if (listenersByType && (0,external_mytoolkit_.isFunction)(func)) {
            listenersByType = listenersByType.filter((l)=>l !== func);
        }
    }
    emit(type, ...arg) {
        let listenersByType = this.listeners[type];
        if (listenersByType) {
            listenersByType.forEach((l)=>{
                l(...arg);
            });
        }
    }
    clear(type) {
        if ((0,external_mytoolkit_.isUnset)(type)) {
            this.listeners = {};
            return;
        }
        let listenersByType = this.listeners[type];
        if (listenersByType && listenersByType.length) {
            this.listeners[type] = [];
        }
    }
}
/* harmony default export */ const leecharts_emitter = (emitter);

;// CONCATENATED MODULE: ./src/cw/leecharts/draw/shadowpointer.js



function drawShadowPointer(chart, index) {
    let { d3, defaultOptions, scaleX, scaleY, containerHeight: ch, containerWidth: cw, options: { xAxis, yAxis, axisPointer }, sections: { shadowPointer }, gridLeft, gridRight, gridTop, gridBottom } = chart;
    if ((0,external_mytoolkit_.isSet)(axisPointer.show) && !axisPointer.show || axisPointer.type !== "shadow") {
        shadowPointer.style("opacity", 0);
        return;
    }
    let scaleCategory, scaleValue, orient, color;
    color = drawGradient(chart, axisPointer.color, defaultOptions.shadowPointerColor);
    if (scaleX.bandwidth) {
        scaleCategory = scaleX;
        scaleValue = scaleY;
        orient = "h";
    } else if (scaleY.bandwidth) {
        scaleCategory = scaleY;
        scaleValue = scaleX;
        orient = "v";
    } else {
        scaleCategory = scaleX;
        scaleValue = scaleY;
        orient = "h";
    }
    let bandWidth = scaleCategory && scaleCategory.bandwidth ? scaleCategory.bandwidth() : 0;
    if (index === null) {
        shadowPointer.style("opacity", 0);
    } else {
        let x, y, width, height, cd;
        if (orient === "h") {
            cd = getData(xAxis.data, index);
            x = scaleCategory(cd);
            y = gridTop;
            width = bandWidth;
            height = ch - gridBottom - gridTop;
        } else {
            cd = getData(yAxis.data, index);
            y = scaleCategory(cd);
            x = gridLeft;
            height = bandWidth;
            width = cw - gridRight - gridLeft;
        }
        shadowPointer.style("opacity", 1).attrs({
            x,
            y,
            width,
            height,
            stroke: "none",
            fill: color
        });
    }
}

;// CONCATENATED MODULE: ./src/cw/leecharts/draw/tooltip.js


function drawTooltip(chart, opts) {
    let { d3, defaultOptions, containerHeight: ch, containerWidth: cw, options: { series, tooltip: tooltipOpts }, sections: { tooltip } } = chart;
    if (!tooltipOpts || tooltipOpts.show === false) return;
    if (!(0,external_mytoolkit_.isFunction)(tooltipOpts.formatter)) return; // only support function type formatter 
    let formatter = tooltipOpts.formatter;
    let e = opts.event || {};
    let hide = false;
    let tooltipStyles = tooltipOpts.styles || {};
    tooltip.styles({
        ...tooltipStyles
    });
    if (opts.type === "axisPointer") {
        if (opts.activeIndex === null) {
            tooltip.styles({
                opacity: 0,
                display: "none"
            });
            hide = true;
        } else {
            let data = series.filter((s)=>s.type === "bar" || s.type === "line").map((s)=>{
                return {
                    name: s.name,
                    data: s.data[opts.activeIndex],
                    value: getData(s.data, opts.activeIndex),
                    dataIndex: opts.activeIndex
                };
            });
            tooltip.styles({
                display: "block"
            }).html(formatter(data));
        }
    } else if (opts.type === "item") {
        if (opts.data === null) {
            tooltip.styles({
                opacity: 0,
                display: "none"
            });
            hide = true;
        } else {
            tooltip.styles({
                display: "block"
            }).html(formatter(opts.data));
        }
    }
    if (hide) return;
    // dealing with tooltip position
    let threshold = 10, x = e.pageX, y = e.pageY, padding = 15;
    let { width: ttWidth, height: ttHeight } = tooltip.node().getBoundingClientRect();
    let remainWidth, remainHeight;
    remainWidth = cw - e.offsetX;
    remainHeight = ch - e.offsetY;
    if (remainWidth + threshold < ttWidth) {
        x -= ttWidth + padding;
    } else {
        x += padding;
    }
    if (remainHeight + threshold < ttHeight) {
        y -= ttHeight + padding;
    } else {
        y += padding;
    }
    tooltip.transition().duration(defaultOptions.focusAniDuration).ease(defaultOptions.enterAniEase).style("opacity", 1).style("top", y + "px").style("left", x + "px");
}

;// CONCATENATED MODULE: ./src/cw/leecharts/draw/point.js

function drawPoint(chart, layer, s, index) {
    let { emitter, defaultOptions, d3, containerWidth: cw, containerHeight: ch, options: { xAxis, yAxis }, sections: { defs, series, plotGroup }, scaleY, scaleX } = chart;
    let lineStyle = (0,external_mytoolkit_.extend)({}, defaultOptions.lineStyle, s.lineStyle || {});
    let color = lineStyle.color || defaultOptions.getColor(index);
    let scaleCategory, scaleValue, orient;
    if (scaleX.bandwidth) {
        scaleCategory = scaleX;
        scaleValue = scaleY;
        orient = "h";
    } else if (scaleY.bandwidth) {
        scaleCategory = scaleY;
        scaleValue = scaleX;
        orient = "v";
    } else {
        scaleCategory = scaleX;
        scaleValue = scaleY;
        orient = "h";
    }
    let bandWidth = scaleCategory && scaleCategory.bandwidth ? scaleCategory.bandwidth() : 0;
    let rData = s.data || [];
    if (rData.length === 0) {
        layer.html("");
        return;
    }
    let sData = rData = rData.map((item)=>item && item.value ? item.value : item);
    let customShape = s.customShape;
    let currentPlotGroup;
    currentPlotGroup = layer;
    let plotSetting = (0,external_mytoolkit_.extend)({}, defaultOptions.plot, s.plot || {});
    let r = plotSetting.size / 2;
    currentPlotGroup.on("click", ()=>{
        if ((0,external_mytoolkit_.isSet)(s.highlightAnimation) && !s.highlightAnimation) return;
        chart.highlightIndex = chart.highlightIndex === index ? null : index;
        emitter.emit("highlightChange", chart.highlightIndex);
    });
    let plots = currentPlotGroup.selectAll("g.lc-node-wrap").data(sData).join("g.lc-node-wrap");
    plots.each(function(d, i) {
        let wrap = d3.select(this);
        let node = wrap.safeSelect("g.lc-custom-shape-g");
        if ((0,external_mytoolkit_.isFunction)(customShape)) {
            let htmlString = customShape({
                bandWidth
            });
            node.html(htmlString);
        } else {
            node.html('<circle r="5" />');
        }
        if (!chart.firstRender) {
            wrap.transition().duration(defaultOptions.changeAniDuraiton).ease(defaultOptions.enterAniEase).attr("transform", ()=>`translate(${position(d, i, true)}, ${position(d, i, false)})`);
        } else {
            wrap.attr("transform", ()=>`translate(${position(d, i, true)}, ${position(d, i, false)})`);
        }
    });
    emitter.on("axisChange", (i)=>{
        let n = currentPlotGroup.selectAll(`.lc-active-node`);
        !n.empty() && n.classed("lc-active-node", false).transition().duration(defaultOptions.focusAniDuration).attr("transform", "scale(1)");
        if (i !== null) {
            currentPlotGroup.selectAll(".lc-custom-shape-g").filter((d, idx)=>(0,external_mytoolkit_.isSet)(d) && i === idx).classed("lc-active-node", true).transition().duration(defaultOptions.focusAniDuration).attr("transform", "scale(1.2)");
        }
    });
    // ini clip path animation 
    let clipPath, clipPathId, clipRect;
    if (chart.firstRender) {
        clipPathId = "lc-" + (0,external_mytoolkit_.randStr)(8);
        clipPath = defs.safeSelect(`clipPath#${clipPathId}`);
        clipRect = clipPath.safeSelect("rect");
        layer.attr("clip-path", `url(#${clipPathId})`);
        if (currentPlotGroup) {
            currentPlotGroup.attr("clip-path", `url(#${clipPathId})`);
        }
        if (orient === "h") {
            clipRect.attrs({
                x: 0,
                y: 0,
                height: ch,
                width: 0
            }).transition().duration(defaultOptions.enterAniDuration).ease(defaultOptions.enterAniEase).attr("width", cw).on("end", ()=>{
                layer.attr("clip-path", null);
                currentPlotGroup && currentPlotGroup.attr("clip-path", null);
                clipPath.remove();
            });
        } else {
            clipRect.attrs({
                x: 0,
                y: ch,
                height: 0,
                width: cw
            }).transition().duration(defaultOptions.enterAniDuration).ease(defaultOptions.enterAniEase).attr("height", ch).attr("y", 0).on("end", ()=>{
                layer.attr("clip-path", null);
                currentPlotGroup && currentPlotGroup.attr("clip-path", null);
                clipPath.remove();
            });
        }
    }
    layer.on("click", ()=>{
        if ((0,external_mytoolkit_.isSet)(s.highlightAnimation) && !s.highlightAnimation) return;
        chart.highlightIndex = chart.highlightIndex === index ? null : index;
        emitter.emit("highlightChange", chart.highlightIndex);
    });
    if ((0,external_mytoolkit_.isUnset)(s.highlightAnimation) || s.highlightAnimation) {
        emitter.on("highlightChange", (ci)=>{
            if (ci === null || ci === index) {
                layer.transition().duration(defaultOptions.focusAniDuration).style("opacity", 1);
                if (currentPlotGroup) {
                    currentPlotGroup.transition().duration(defaultOptions.focusAniDuration).style("opacity", 1);
                }
            } else {
                layer.transition().duration(defaultOptions.focusAniDuration).style("opacity", defaultOptions.highlightOtherOpacity);
                if (currentPlotGroup) {
                    currentPlotGroup.transition().duration(defaultOptions.focusAniDuration).style("opacity", defaultOptions.highlightOtherOpacity);
                }
            }
        });
    }
    function position(d, i, isX) {
        let td, scale, bw;
        if (isX) {
            if (orient === "h") {
                scale = scaleCategory;
                td = xAxis.data[i];
                bw = bandWidth;
            } else {
                scale = scaleValue;
                td = d;
                bw = 0;
            }
        } else {
            if (orient === "v") {
                scale = scaleCategory;
                td = yAxis.data[i];
                bw = bandWidth;
            } else {
                scale = scaleValue;
                td = d;
                bw = 0;
            }
        }
        return scale(td) + bw / 2;
    }
}

;// CONCATENATED MODULE: ./src/cw/leecharts/draw/custom.js

function custom_drawBar(chart, layer, s, index) {
    if (!(0,external_mytoolkit_.isFunction)(s.draw)) return;
    s.draw(chart, layer, s, index);
}

;// CONCATENATED MODULE: ./src/cw/leecharts/draw/label.js

function drawLabel(chart, layer, opts, i) {
    let { d3, emitter, defaultOptions, containerWidth: cw, containerHeight: ch } = chart;
    let html = opts.html;
    if ((0,external_mytoolkit_.isUnset)(html) || html === "") {
        layer.html("");
        return;
    }
    let align, left, top, right, bottom;
    align = opts.align || "left";
    left = opts.left || 0;
    top = opts.top || 0;
    right = opts.right || 0;
    bottom = opts.bottom || 0;
    layer.html(html);
    let { width, height } = layer.node().getBBox();
    if (align === "middle") {
        layer.attr("transform", `translate(${(cw + left - right - width) / 2},${top})`);
    } else if (align == "right") {
        layer.attr("transform", `translate(${cw - right - width},${top})`);
    } else {
        layer.attr("transform", `translate(${left}, ${top})`);
    }
}

;// CONCATENATED MODULE: ./src/cw/leecharts/draw/treemap.js



function treemap_drawLine(chart, layer, s, index) {
    let { d3, emitter, defaultOptions, containerWidth: cw, containerHeight: ch, gridTop, gridBottom, gridLeft, gridRight, options: { onClick: clickHandle } } = chart;
    let backgroundColor = s.bgColor || "#ffffff";
    let foregroundColor = s.itemColor || defaultOptions.getColor(0);
    let labelColor = s.labelColor || "#ffffff";
    let labelSize = s.labelSize || 12;
    let treeData = s.data || [];
    if (treeData.length === 0) {
        layer.html("");
        return;
    }
    let root = d3.hierarchy(treeData);
    let treemapLayout = d3.treemap();
    treemapLayout.size([
        cw - gridLeft - gridRight,
        ch - gridTop - gridBottom
    ]).paddingInner(2);
    root.sum(function(d) {
        return d.value;
    });
    treemapLayout(root);
    let maplayout = layer.safeSelect("g.lc-treemap-layout");
    maplayout.attr("transform", `translate(${gridLeft},${gridLeft})`);
    maplayout.selectAll("g.lc-map-node").data(root.descendants()).join("g.lc-map-node").attr("transform", (d)=>`translate(${d.x0},${d.y0})`).each(function(d, i) {
        let g = d3.select(this);
        let id = `mapnode-${index}-${i}`;
        let clipId = `mapnode-clip-${index}-${i}`;
        g.safeSelect("rect").attrs({
            id,
            width: function(d) {
                return d.x1 - d.x0;
            },
            height: function(d) {
                return d.y1 - d.y0;
            },
            stroke: "none",
            fill: ()=>{
                return i === 0 ? backgroundColor : foregroundColor;
            }
        }).on("click", ()=>{
            if ((0,external_mytoolkit_.isFunction)(clickHandle)) {
                clickHandle({
                    type: "itemClicked",
                    data: d.data,
                    value: d.data.value,
                    dataIndex: i,
                    seriesIndex: index,
                    series: s,
                    seriesData: s.data
                });
            }
        });
        g.safeSelect("clip-path").html("").attr("id", clipId).append("use").attr("xlink:href", `#${id}`);
        g.safeSelect("text").text(d.data.name).attrs({
            "clip-path": `url(#${clipId})`,
            fill: labelColor,
            stroke: "none",
            x: 15,
            y: 20
        }).styles({
            "font-size": labelSize
        });
    }).on("mousemove", function(d, i) {
        if ((0,external_mytoolkit_.isObject)(s.tooltip) && !s.tooltip.show) return;
        emitter.emit("showTooltip", {
            type: "item",
            dataIndex: i,
            data: d.data,
            event: d3.event
        });
    }).on("mouseout", function() {
        if ((0,external_mytoolkit_.isObject)(s.tooltip) && !s.tooltip.show) return;
        emitter.emit("showTooltip", {
            type: "item",
            data: null
        });
    }).on("click", function(d, i) {
        if (!(0,external_mytoolkit_.isSet)(s.click) || s.click) {
            emitter.emit("clickItem", {
                value: d.data,
                seriesIndex: index,
                dataIndex: i,
                seriesData: s
            });
        }
    });
}

;// CONCATENATED MODULE: ./src/cw/leecharts/draw/radar.js



function drawRadar(chart, layer, s, index) {
    let { emitter, defaultOptions, d3, containerWidth: cw, containerHeight: ch, containerCenter: cc, options: { onClick: clickHandle } } = chart;
    let indicator = s.indicator;
    if (!indicator || !indicator.length) {
        layer.html("").attr("transform", null);
        return;
    }
    let data = s.data;
    if (!data || !data.length) {
        layer.html("").attr("transform", null);
        return;
    }
    let maxValue = 0;
    data.forEach((item)=>{
        let d = item.data || [];
        for(let i = 0, l = d.length; i < l; i++){
            maxValue = Math.max(maxValue, getData(d, i));
        }
    });
    maxValue = Math.round(maxValue * 1.2);
    maxValue = Math.ceil(maxValue / Math.pow(10, String(maxValue).length - 1)) * Math.pow(10, String(maxValue).length - 1);
    if (s.maxValue) {
        maxValue = Number(s.maxValue);
    }
    let focusAnimation = (0,external_mytoolkit_.isSet)(s.focusAnimation) ? s.focusAnimation : true;
    let radarCenter = s.center || [
        0.5,
        0.5
    ];
    radarCenter = [
        cw * parsePercent(radarCenter[0]),
        ch * parsePercent(radarCenter[1])
    ];
    let radius = s.radius || 0.7;
    radius = Math.min(cw, ch) * parsePercent(radius) * 0.5;
    let radarSettings = (0,external_mytoolkit_.extend)({}, deepExtend((0,external_mytoolkit_.deepCopy)(defaultOptions.radar), s.radar || {}));
    let startAngle = (0,external_mytoolkit_.deg2angle)(radarSettings.startAngle) + (0,external_mytoolkit_.deg2angle)(-90);
    let meanAngle = 2 * Math.PI / indicator.length;
    let splitLength = radius / radarSettings.splitNumber;
    let radarRoot = layer.safeSelect("g.lc-radar-root").attr("transform", `translate(${radarCenter[0]}, ${radarCenter[1]})`);
    let splitAreaColors = radarSettings.splitArea.colors || [];
    splitAreaColors = splitAreaColors.slice(0, radarSettings.splitNumber + 1);
    let scaleRadius = d3.scaleLinear().domain([
        0,
        maxValue
    ]).range([
        0,
        radius
    ]);
    // draw split area and lne
    radarRoot.selectAll("path.lc-radar-split-area").data(d3.range(radarSettings.splitNumber + 1)).join("path.lc-radar-split-area").attrs({
        stroke: radarSettings.splitArea.lineColor,
        fill: (d)=>{
            let l = splitAreaColors.length;
            if (l > 0) {
                return splitAreaColors[radarSettings.splitNumber - d - 1];
            } else {
                return "none";
            }
        },
        d: (d)=>{
            let r = splitLength * (radarSettings.splitNumber - d);
            return (0,external_mytoolkit_.drawEquilateral)({
                radius: r,
                startAngle,
                sidesNum: indicator.length
            });
        }
    });
    // draw axis 
    radarRoot.selectAll("g.lc-radar-axis").data(d3.range(indicator.length)).join("g.lc-radar-axis").each(function(d, i) {
        let g = d3.select(this);
        g.safeSelect("line").attrs({
            stroke: radarSettings.axisLine.show ? radarSettings.axisLine.color : "rgba(0,0,0,0)",
            fill: "none",
            "stroke-dasharray": radarSettings.axisLine.type != "dashed" ? [
                5,
                2
            ] : "none",
            x2: (d)=>radius * Math.cos(startAngle + d * meanAngle),
            y2: (d)=>radius * Math.sin(startAngle + d * meanAngle)
        });
    });
    // draw indicator 
    radarRoot.selectAll("g.lc-radar-indicator").data(d3.range(indicator.length)).join("g.lc-radar-indicator").each(function(d) {
        let g = d3.select(this);
        let x, y, angle = startAngle + d * meanAngle, textAnchor = "start";
        x = (radius + radarSettings.indicator.padding) * Math.cos(angle);
        y = (radius + radarSettings.indicator.padding) * Math.sin(angle);
        if (x < 0) {
            textAnchor = "end";
        } else if (Math.round(x) == 0) {
            textAnchor = "middle";
        }
        g.attr("transform", `translate(${x}, ${y})`);
        g.safeSelect("text").text(indicator[d].text).attrs({
            fill: radarSettings.indicator.color,
            "text-anchor": textAnchor,
            y: Math.round(x) == 0 && y > 0 ? radarSettings.indicator.padding : 0
        }).styles({
            "font-size": radarSettings.indicator.fontSize
        });
    });
    // draw axis label 
    let axisLabelGroup = radarRoot.safeSelect("g.lc-radar-axis-label-group");
    if (radarSettings.axisLabel.show) {
        axisLabelGroup.selectAll("text").data(d3.range(radarSettings.splitNumber)).join("text").text((d)=>{
            let v = scaleRadius.invert((d + 1) * splitLength);
            return (0,external_mytoolkit_.toFixed)(v, 0);
        }).attrs({
            y: (d)=>-(d + 1) * splitLength - 5,
            fill: radarSettings.axisLabel.color,
            "text-anchor": "middle"
        }).styles({
            "font-size": radarSettings.axisLabel.fontSize
        });
    } else {
        axisLabelGroup.remove();
    }
    let sectionGroups = radarRoot.selectAll("g.lc-radar-section").data(data).join("g.lc-radar-section").each(function(sd, si) {
        let section = d3.select(this);
        let sdData = [];
        sdData = indicator.map((_, i)=>{
            return getData(sd.data || [], i);
        });
        let plotPoints = sdData.map((v, i)=>{
            let r = scaleRadius(v);
            let angle = startAngle + i * meanAngle;
            return [
                r * Math.cos(angle),
                r * Math.sin(angle)
            ];
        });
        let color = sd.color || defaultOptions.getColor(si);
        let areaColor = "none";
        if (sd.areaStyle && sd.areaStyle.show) {
            areaColor = drawGradient(chart, sd.areaStyle.color, defaultOptions.getAreaColor(si));
        }
        section.safeSelect("path").attrs({
            stroke: color,
            fill: areaColor
        }).transition().duration(defaultOptions.changeAniDuraiton).ease(defaultOptions.enterAniEase).attrTween("d", function() {
            let prevData = (0,external_mytoolkit_.decodeJSON)(d3.select(this).attr("prevData"));
            return (t)=>{
                let ps;
                if (!prevData || prevData.length !== plotPoints.length) {
                    ps = plotPoints.map((item)=>[
                            item[0] * t,
                            item[1] * t
                        ]);
                } else {
                    ps = plotPoints.map((item, k)=>{
                        let prevItem = prevData[k];
                        let x = t * plotPoints[0] + (1 - t) * prevItem[0];
                        let y = t * plotPoints[1] + (1 - t) * prevItem[1];
                        return [
                            x,
                            y
                        ];
                    });
                }
                return d3.line()(ps) + "Z";
            };
        }).on("end", function() {
            d3.select(this).attr("prevData", (0,external_mytoolkit_.encodeJSON)(plotPoints));
        });
        let plots = section.selectAll("g.lc-radar-plot-group").data(plotPoints).join("g.lc-radar-plot-group");
        if (radarSettings.plots.show) {
            plots.each(function(d, i) {
                let g = d3.select(this);
                g.safeSelect("circle").attrs({
                    stroke: color,
                    fill: "#ffffff",
                    ...radarSettings.plots.attr
                }).styles({
                    ...radarSettings.plots.style
                });
            }).on("mousemove", function(d, i) {
                if ((0,external_mytoolkit_.isObject)(s.tooltip) && !s.tooltip.show) return;
                emitter.emit("showTooltip", {
                    type: "item",
                    dataIndex: i,
                    data: {
                        value: sdData[i],
                        data: sdData[i],
                        indicator: indicator[i],
                        dataIndex: i,
                        seriesIndex: si,
                        seriesData: sd
                    },
                    seriesIndex: index,
                    event: d3.event
                });
            }).on("mouseout", function(d, i) {
                if ((0,external_mytoolkit_.isObject)(s.tooltip) && !s.tooltip.show) return;
                emitter.emit("showTooltip", {
                    type: "item",
                    data: null
                });
            });
            plots.transition().duration(defaultOptions.changeAniDuraiton).ease(defaultOptions.enterAniEase).attr("transform", (d)=>`translate(${d[0]}, ${d[1]})`);
        } else {
            plots.remove();
        }
        section.on("click", ()=>{
            if ((0,external_mytoolkit_.isSet)(s.highlightAnimation) && !s.highlightAnimation) return;
            chart.highlightIndex = chart.highlightIndex === si ? null : si;
            emitter.emit("highlightChange", chart.highlightIndex);
        });
        if ((0,external_mytoolkit_.isUnset)(s.highlightAnimation) || s.highlightAnimation) {
            emitter.on("highlightChange", (ci)=>{
                if (ci === null || ci === si) {
                    section.transition().duration(defaultOptions.focusAniDuration).style("opacity", 1);
                } else {
                    section.transition().duration(defaultOptions.focusAniDuration).style("opacity", defaultOptions.highlightOtherOpacity);
                }
            });
        }
    });
}

;// CONCATENATED MODULE: ./src/cw/leecharts/index.js



















d3Augment(external_d3_namespaceObject);
class chart {
    constructor(selector, options){
        //console.log(selector, options)
        //this.bind(['onMousemove'])
        this.d3 = external_d3_namespaceObject;
        this.selector = selector;
        this.defaultOptions = options_options;
        this.emitter = new leecharts_emitter();
        this.container = external_d3_namespaceObject.select(selector);
        this.options = deepExtend(options_options(), options);
        this.preOptions = null;
        this.previousOptions = null;
        this.sections = {};
        this.maxValue = 0;
        this.firstRender = true;
        this.maybePercentValue = maybePercentValue;
        this.gradientPool = [];
        let resize = this.resize.bind(this);
        this.resize = (0,external_mytoolkit_.debounce)(resize, 100);
        let showTooltip = this.__showTooltip.bind(this);
        this.__showTooltip = (0,external_mytoolkit_.debounce)(showTooltip, 20);
        this.init();
        options && this.drawChart();
    }
    setGrid() {
        let { containerWidth: cw, containerHeight: ch, options: { grid } } = this;
        this.gridLeft = maybePercentValue(grid.left, cw);
        this.gridRight = maybePercentValue(grid.right, cw);
        this.gridTop = maybePercentValue(grid.top, ch);
        this.gridBottom = maybePercentValue(grid.bottom, ch);
    }
    drawChart() {
        this.emitter?.clear("highlightChange");
        this.setGrid();
        axisX(this);
        axisY(this);
        this.calculateBarOffset();
        this.drawSeries();
        drawLegend(this);
        this.drawLabel();
        this.firstRender = false;
    }
    drawLabel() {
        let chart = this;
        let { options: { label = [] }, sections: { labels: labelGroup } } = chart;
        if ((0,external_mytoolkit_.isObject)(label)) {
            label = [
                label
            ];
        }
        if (label.length === 0) {
            labelGroup.html("");
            return;
        }
        labelGroup.selectAll("g.lc-label-g").data(label).join("g.lc-label-g").each(function(d, i) {
            let layer = external_d3_namespaceObject.select(this).classed(`lc-label-g-${i}`, true);
            drawLabel(chart, layer, d, i);
        });
    }
    drawSeries() {
        let chart = this;
        let { options: { series }, sections: { series: seriesGroup } } = chart;
        seriesGroup.selectAll("g.lc-layer").data(series).join((enter)=>{
            return enter.append("g.lc-layer");
        }, (update)=>{
            return update.attr("lc-updated", 1);
        }, (exit)=>{
            exit.each(function(d, i) {
                if (d.type === "line") {
                    external_d3_namespaceObject.select(`.lc-plot-group-${i}`).remove();
                }
                external_d3_namespaceObject.select(this).remove();
            });
        }).each(function(s, i) {
            let layer = external_d3_namespaceObject.select(this);
            // deal with series update
            let classStr = `lc-${s.type}-layer-${i}`;
            if (layer.attr("lc-updated")) {
                if (!layer.classed(classStr)) {
                    if (layer.classed(`lc-line-layer-${i}`)) {
                        external_d3_namespaceObject.select(`.lc-plot-group-${i}`).remove();
                    }
                    layer.html("").attr("class", `lc-layer ${classStr}`).attr("lc-updated", null).attr("transform", null);
                }
            } else {
                layer.classed(classStr, true);
            }
            switch(s.type){
                case "line":
                    drawLine(chart, layer, s, i);
                    break;
                case "bar":
                    drawBar(chart, layer, s, i);
                    break;
                case "pie":
                    drawPie(chart, layer, s, i);
                    break;
                case "point":
                    drawPoint(chart, layer, s, i);
                    break;
                case "custom":
                    custom_drawBar(chart, layer, s, i);
                    break;
                case "treemap":
                    treemap_drawLine(chart, layer, s, i);
                    break;
                case "radar":
                    drawRadar(chart, layer, s, i);
                    break;
                default:
            }
        });
    }
    resize() {
        this.figureGeometry();
        this.drawChart();
    }
    figureGeometry() {
        let { width, height } = getBoundingRect(this.container.node());
        let cw = this.containerWidth = width;
        let ch = this.containerHeight = height;
        this.containerCenter = [
            cw / 2,
            ch / 2
        ];
        this.paper.attrs({
            width: cw,
            height: ch
        });
    }
    calculateStackData() {
        let { options: { series = [] } } = this;
        let types = [
            "line",
            "bar"
        ];
        types.forEach((type)=>{
            let chartsByType = series.filter((s)=>s.type === type);
            let chartsByStack = chartsByType.filter((s)=>!!s.stack);
            if (!chartsByStack.length) return;
            let stackGroups = (0,external_mytoolkit_.groupBy)(chartsByStack, "stack");
            Object.keys(stackGroups).forEach((k)=>{
                let group = stackGroups[k];
                let stackedData = [];
                group.forEach((item, idx)=>{
                    if (stackedData.length === 0) {
                        stackedData = Array.from({
                            length: item.data.length
                        }).map(()=>0);
                    }
                    let itemStackData = Array.from({
                        length: item.data.length
                    }).map(()=>[]);
                    item.data.forEach((d, i)=>{
                        d = (0,external_mytoolkit_.isSet)(d) ? (0,external_mytoolkit_.isSet)(d.value) ? d.value : d : 0;
                        let isd = itemStackData[i];
                        isd[0] = stackedData[i];
                        isd[1] = stackedData[i] + d;
                    });
                    item.stackData = itemStackData;
                    stackedData = itemStackData.map((item)=>item[1]);
                });
            });
        });
        // set bar index
        let barSeries = series.filter((s)=>s.type === "bar");
        let sgx = -1, stackName;
        for(let i = 0, l = barSeries.length; i < l; i++){
            let s = barSeries[i];
            if (!(0,external_mytoolkit_.isSet)(s.stack) || s.stack === "") {
                sgx++;
            } else if (s.stack !== stackName) {
                sgx++;
                stackName = s.stack;
            }
            s.stackGroupIndex = sgx;
        }
        barSeries.forEach((s)=>{
            s.stackGroupLength = sgx + 1;
        });
    }
    calculateBarOffset() {
        let { options: { series, barStyle: barOptionStyle }, scaleY, scaleX } = this;
        let barSeries = series.filter((s)=>s.type === "bar");
        if (!barSeries.length) return;
        let scaleCategory, bandWidth;
        if (scaleX.bandwidth) {
            scaleCategory = scaleX;
        } else if (scaleY.bandwidth) {
            scaleCategory = scaleY;
        } else {
            // to do: dealing with charts without category for both xAxis and yAxis
            return;
        }
        bandWidth = scaleCategory.bandwidth();
        let b, barStyle, groupIdx = -1, expectedBarWidth, groupLength, barWidth, barMinWidth, barMaxWidth, cache = [];
        groupLength = barSeries[0]["stackGroupLength"];
        expectedBarWidth = Math.max(1, bandWidth / groupLength - 8);
        barStyle = (0,external_mytoolkit_.extend)({}, options_options.barStyle, barOptionStyle || {});
        for(let i = 0, l = barSeries.length; i < l; i++){
            b = barSeries[i];
            if (b.stackGroupIndex > groupIdx) {
                if (b.barWidth) {
                    cache.push(b.barWidth);
                } else {
                    barMinWidth = b.barMinWidth || 0;
                    barMaxWidth = Math.min(b.barMaxWidth || expectedBarWidth, barStyle.barMaxWidth);
                    barWidth = Math.min(Math.max(barMinWidth, expectedBarWidth), barMaxWidth);
                    cache.push(barWidth);
                }
                groupIdx++;
            }
        }
        let space = Math.max(0, bandWidth - cache.reduce((a, b)=>a + b));
        let padding = 1, remainSpace;
        while(space - padding * cache.length > 0){
            padding += 1;
            if (padding >= barStyle.interval) {
                break;
            }
        }
        remainSpace = Math.max(0, space - padding * (cache.length - 1)) / 2;
        barSeries.forEach((b)=>{
            let gIdx = b.stackGroupIndex;
            b._barOffset = remainSpace + padding * gIdx + cache.slice(0, gIdx).reduce((a, b)=>a + b, 0);
            b._barWidth = cache[gIdx];
        });
    //console.log(barSeries, expectedBarWidth)
    }
    calculateMaxValue() {
        let { options: { xAxis, yAxis, series } } = this;
        if (xAxis.type === "value" && xAxis.max) {
            this.maxValue = xAxis.max;
            this.maxValueFixed = true;
            return;
        }
        if (yAxis.type === "value" && yAxis.max) {
            this.maxValue = yAxis.max;
            this.maxValueFixed = true;
            return;
        }
        let sArray = series.filter((s)=>s.type === "bar" || s.type === "line" || s.type === "point");
        let maxValue = 0;
        sArray.forEach((s)=>{
            let d = s.data || [];
            if (s.stackData) {
                d = s.stackData.map((item)=>item[1]);
            }
            d = d.map((item)=>item && item.value ? item.value : item);
            let max = Math.max.apply(this, d);
            maxValue = Math.max(maxValue, max);
        });
        this.maxValue = maxValue;
        this.maxValueFixed = false;
    //console.log(this.maxValue, 'max value')
    }
    setOptions(options, replace) {
        if (!options) return;
        this.preOptions = this.options;
        this.options = replace ? deepExtend(options_options(), options) : deepExtend(this.preOptions, options);
        this.figureGeometry();
        this.calculateStackData();
        this.calculateMaxValue();
        this.drawChart();
    }
    init() {
        if (!this.container) return;
        if (this.container.empty && this.container.empty()) return;
        const svgElement = this.selector.querySelector("svg.lc-root");
        if (svgElement) {
            svgElement.remove();
        }
        let chart = this;
        this.highlightIndex = null;
        this.paper = this.container.append("svg.lc-root");
        this.figureGeometry();
        this.calculateStackData();
        this.calculateMaxValue();
        this.paper.on("mousemove", function() {
            chart.__onMousemove();
        });
        this.sections.desc = this.paper.append("desc");
        this.sections.defs = this.paper.append("defs");
        this.sections.axisY = this.paper.append("g.lc-axis-y");
        this.sections.scrollXView = this.paper.append("g.lc-scroll-x-view");
        this.sections.axisX = this.sections.scrollXView.append("g.lc-axis-x");
        this.sections.shadowPointer = this.sections.scrollXView.append("rect.lc-shadow-pointer");
        this.sections.series = this.sections.scrollXView.append("g.lc-series");
        this.sections.linePointer = this.sections.scrollXView.append("line.lc-line-pointer");
        this.sections.plotGroup = this.sections.scrollXView.append("g.lc-plot-group");
        this.sections.legend = this.paper.append("g.lc-legend");
        this.sections.labels = this.paper.append("g.lc-labels");
        this.sections.title = this.paper.append("text.lc-title");
        this.sections.subtitle = this.paper.append("text.lc-subtitle");
        this.sections.tooltip = external_d3_namespaceObject.select(document.body).safeSelect("div.lc-tooltip");
        this.sections.tooltip.styles({
            position: "absolute",
            left: "-999999px",
            top: "-9999999px",
            opacity: 0
        });
        this.emitter.on("axisChange", (...args)=>{
            drawLinePointer(this, ...args);
            drawShadowPointer(this, ...args);
            if ((0,external_mytoolkit_.isFunction)(this.options.onAxisChange)) {
                this.options.onAxisChange(...args);
            }
        });
        this.emitter.on("showTooltip", this.__showTooltip);
    }
    __showTooltip(...args) {
        drawTooltip(this, ...args);
    }
    __onMousemove() {
        let { containerWidth: cw, containerHeight: ch, emitter, scaleX, scaleY, activeCategroryIndex, gridLeft, gridRight, gridBottom, gridTop } = this;
        if (!scaleX || !scaleY) return;
        let scaleCategory, orient;
        if (scaleX.bandwidth) {
            scaleCategory = scaleX;
            orient = "h";
        } else if (scaleY.bandwidth) {
            scaleCategory = scaleY;
            orient = "v";
        }
        if (!scaleCategory) return;
        let { offsetX: x, offsetY: y } = external_d3_namespaceObject.event;
        let gridBound = [
            [
                gridLeft,
                gridTop
            ],
            [
                cw - gridRight,
                ch - gridBottom
            ]
        ];
        let bandWidth = scaleCategory.bandwidth();
        if (isInBound(gridBound, x, y)) {
            let i, l, scaleRange;
            scaleRange = scaleCategory.range();
            l = Math.round(Math.abs(scaleRange[0] - scaleRange[1]) / bandWidth);
            if (orient === "h") {
                i = Math.ceil((x - gridLeft) / bandWidth) - 1;
            } else {
                i = Math.floor((y - gridBottom) / bandWidth) - 1;
            }
            i = orient === "v" ? l - i - 1 : i;
            i = Math.max(0, i);
            if (i !== activeCategroryIndex) {
                this.activeCategroryIndex = i;
                emitter.emit("axisChange", i);
            }
            emitter.emit("showTooltip", {
                type: "axisPointer",
                activeIndex: i,
                event: external_d3_namespaceObject.event
            });
        } else {
            if (activeCategroryIndex !== null) {
                this.activeCategroryIndex = null;
                emitter.emit("axisChange", null);
                emitter.emit("showTooltip", {
                    type: "axisPointer",
                    activeIndex: null
                });
            }
        }
    }
    destroy() {
        try {
            this.emitter = null;
            this.sections.tooltip.remove();
        } catch (error) {}
    }
}
function leecharts(selector, options) {
    return new chart(selector, options);
}
/* harmony default export */ const cw_leecharts = (leecharts);


/***/ }),

/***/ 84727:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   O9: () => (/* binding */ colors),
/* harmony export */   dP: () => (/* binding */ dotString),
/* harmony export */   kn: () => (/* binding */ getGroupListWidth),
/* harmony export */   uK: () => (/* binding */ colorsText)
/* harmony export */ });
/* harmony import */ var mytoolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(95153);
/* harmony import */ var mytoolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mytoolkit__WEBPACK_IMPORTED_MODULE_0__);

const colors = [
    "rgba(29, 107, 253, 0.08)",
    "rgba(112, 79, 228, 0.08)",
    "rgba(201,78,119,0.08)",
    "rgba(57, 178, 226, 0.08)",
    "rgba(233, 119, 70, 0.08)",
    "rgba(116, 204, 110, 0.08)",
    "rgba(240, 176, 71, 0.08)"
];
const colorsText = [
    "rgba(29, 107, 253, 0.1)",
    "rgba(112, 79, 228, 0.1)",
    "rgba(201,78,119,0.1)",
    "rgba(57, 178, 226, 0.1)",
    "rgba(233, 119, 70, 0.1)",
    "rgba(116, 204, 110, 0.1)",
    "rgba(240, 176, 71, 0.1)"
];
function getGroupListWidth(gl, bw, padding) {
    let w = (gl.length - 1) * padding;
    w += getGroupBlockCount(gl) * bw;
    return w;
}
function getGroupBlockCount(gl) {
    let c = 0;
    if (Array.isArray(gl)) {
        (gl || []).forEach((g)=>{
            if ((0,mytoolkit__WEBPACK_IMPORTED_MODULE_0__.isArray)(g)) {
                g.forEach(()=>{
                    c++;
                });
            } else {
                c++;
            }
        });
    }
    return c;
}
function dotString(str = "", headLen = 6, tailLen = 6) {
    let strLen = str.length;
    if (strLen < headLen + tailLen) {
        return str;
    }
    let headStr = str.slice(0, headLen);
    let tailStr = tailLen > 0 ? str.slice(-tailLen) : "";
    return `${headStr}...${tailStr}`;
} // export function getTanDeg(tan:any) {
 //   let result = Math.atan(tan) / (Math.PI / 180)
 //   result = Math.round(result)
 //   return result
 // }


/***/ }),

/***/ 52727:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/cssinjs");

/***/ }),

/***/ 77529:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons/lib/icons/LoadingOutlined");

/***/ }),

/***/ 86762:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons/lib/icons/LockOutlined");

/***/ }),

/***/ 99177:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons/lib/icons/SearchOutlined");

/***/ }),

/***/ 62127:
/***/ ((module) => {

"use strict";
module.exports = require("@ant-design/icons/lib/icons/UserOutlined");

/***/ }),

/***/ 92616:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/config-provider");

/***/ }),

/***/ 30675:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/input");

/***/ }),

/***/ 4946:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/locale/en_US");

/***/ }),

/***/ 79353:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/locale/zh_CN");

/***/ }),

/***/ 10274:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/menu");

/***/ }),

/***/ 17369:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/message");

/***/ }),

/***/ 69348:
/***/ ((module) => {

"use strict";
module.exports = require("antd/lib/tooltip");

/***/ }),

/***/ 59003:
/***/ ((module) => {

"use strict";
module.exports = require("classnames");

/***/ }),

/***/ 68887:
/***/ ((module) => {

"use strict";
module.exports = require("copy-to-clipboard");

/***/ }),

/***/ 1635:
/***/ ((module) => {

"use strict";
module.exports = require("dayjs");

/***/ }),

/***/ 46517:
/***/ ((module) => {

"use strict";
module.exports = require("lodash");

/***/ }),

/***/ 36211:
/***/ ((module) => {

"use strict";
module.exports = require("mobx");

/***/ }),

/***/ 22062:
/***/ ((module) => {

"use strict";
module.exports = require("mobx-react");

/***/ }),

/***/ 95153:
/***/ ((module) => {

"use strict";
module.exports = require("mytoolkit");

/***/ }),

/***/ 16641:
/***/ ((module) => {

"use strict";
module.exports = require("next-seo");

/***/ }),

/***/ 43076:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module.js");

/***/ }),

/***/ 94140:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/get-page-files.js");

/***/ }),

/***/ 89716:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/htmlescape.js");

/***/ }),

/***/ 33100:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/render.js");

/***/ }),

/***/ 76368:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/utils.js");

/***/ }),

/***/ 53918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 45732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 56724:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/constants.js");

/***/ }),

/***/ 35132:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 18743:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/html-context.js");

/***/ }),

/***/ 3539:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 50744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 35843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 78524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 93431:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-locale.js");

/***/ }),

/***/ 11751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 71109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 28854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 93297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 87782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 82470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 40618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 71853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 16689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 66405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 94612:
/***/ ((module) => {

"use strict";
module.exports = require("use-deep-compare-effect");

/***/ }),

/***/ 99648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ }),

/***/ 49766:
/***/ ((module) => {

"use strict";
module.exports = import("bignumber.js");;

/***/ }),

/***/ 22021:
/***/ ((module) => {

"use strict";
module.exports = import("i18next");;

/***/ }),

/***/ 57987:
/***/ ((module) => {

"use strict";
module.exports = import("react-i18next");;

/***/ }),

/***/ 34325:
/***/ ((module) => {

"use strict";
module.exports = import("web3");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8355,1163], () => (__webpack_exec__(62968)));
module.exports = __webpack_exports__;

})();